'use client';

/* ============================================================
   GameClient.tsx — React shell around the canvas game:
   title screen, HUD-adjacent touch controls, grimoire,
   character sheet, map hint, shrine shop, fusion altar,
   death & pause overlays.
   ============================================================ */
import { useEffect, useRef, useState, useCallback } from 'react';
import { createGame, type GameApi, type UISnapshot } from '@/game/game';
import { ELEMENTS, ALL_SPELL_IDS, spellDef, FUSE_COST } from '@/game/magic';
import { elColor } from '@/game/sprites';
import type { ElementId } from '@/game/core';
import { CLASSES, UNIVERSAL_MAX } from '@/game/classes';
import { Button } from '@/components/ui/button';

const PANEL =
  'bg-[#14101f]/95 border-2 border-[#3a3152] shadow-[0_0_0_2px_#0a0812,6px_6px_0_0_rgba(0,0,0,0.45)]';
const HEAD = 'font-pixel tracking-wide text-[#c9b0f2]';

function Bar({ v, max, color }: { v: number; max: number; color: string }) {
  return (
    <div className="h-2 w-full bg-[#241d33] border border-[#0a0812]">
      <div className="h-full" style={{ width: `${Math.max(0, Math.min(100, (v / max) * 100))}%`, background: color }} />
    </div>
  );
}

export default function GameClient() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [game, setGame] = useState<{ G: ReturnType<typeof createGame>['G']; api: GameApi } | null>(null);
  const [snap, setSnap] = useState<UISnapshot | null>(null);
  const [touchUI, setTouchUI] = useState(false);
  const [pickClass, setPickClass] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const { G, api } = createGame(canvas);
    setGame({ G, api });
    setSnap(api.getSnapshot());
    const iv = setInterval(() => {
      setSnap(api.getSnapshot());
      // touch controls are ONLY for real mobile devices — never on a PC screen
      setTouchUI(G.mobile);
    }, 140);
    const onCtx = (e: Event) => e.preventDefault();
    canvas.addEventListener('contextmenu', onCtx);
    return () => {
      clearInterval(iv);
      api.saveNow();
      G.destroy();
      canvas.removeEventListener('contextmenu', onCtx);
    };
  }, []);

  const api = game?.api ?? null;
  const G = game?.G ?? null;

  const holdBtn = useCallback((set: (v: boolean) => void) => ({
    onPointerDown: (e: React.PointerEvent) => { e.preventDefault(); set(true); },
    onPointerUp: () => set(false),
    onPointerLeave: () => set(false),
  }), []);

  return (
    <div className="fixed inset-0 bg-black overflow-hidden select-none">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ imageRendering: 'pixelated', touchAction: 'none' }}
      />

      {api && G && snap && (
        <>
          {/* ============ TITLE ============ */}
          {snap.mode === 'title' && (
            <div className="absolute inset-0 flex items-center justify-center z-30 bg-[#0d0a14]/60">
              <div className="flex flex-col items-center gap-6 px-4 max-w-2xl w-full">
                <div className="text-center">
                  <h1 className="font-pixel text-2xl sm:text-4xl text-[#c9b0f2] drop-shadow-[3px_3px_0_#000]">
                    ARCANA INFINITA
                  </h1>
                  <p className="mt-3 font-pixel text-[9px] sm:text-[10px] text-[#8a8098]">
                    THE WEALD OF A THOUSAND SPELLS
                  </p>
                  <p className="mt-2 text-xs text-[#7a7290] font-mono">
                    An open world with no quest and no chains. Hundreds of spells. Fusion. Necromancy.
                    <br />Eight bosses that will end you. Dodge, parry, or die.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    className="font-pixel text-[10px] bg-[#3a2a5e] hover:bg-[#4e3a7a] text-[#e8dff8] border-2 border-[#6a55a0] shadow-[4px_4px_0_#000] h-12 px-6"
                    onClick={() => { if (snap.hasSave && !confirm('Start over? This erases your current save.')) return; setPickClass(true); }}
                  >
                    NEW JOURNEY
                  </Button>
                  {snap.hasSave && (
                    <Button
                      className="font-pixel text-[10px] bg-[#1e3a2e] hover:bg-[#2a5240] text-[#d8f8e8] border-2 border-[#3e8a64] shadow-[4px_4px_0_#000] h-12 px-6"
                      onClick={() => api.continueGame()}
                    >
                      CONTINUE
                    </Button>
                  )}
                </div>
                {/* offline packaging — only shown on the hosted build */}
                {!(typeof window !== 'undefined' && window.__ARCANA_STANDALONE__) && (
                  <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1 font-mono text-[10px] text-[#6a6280]">
                    <span className="text-[#4a4460]">TAKE IT WITH YOU:</span>
                    <a href="/arcana-infinita.html" download="arcana-infinita.html" className="underline decoration-dotted underline-offset-2 hover:text-[#c9b0f2] transition-colors">⬇ single-file .html</a>
                    <a href="/arcana-infinita-source.zip" download="arcana-infinita-source.zip" className="underline decoration-dotted underline-offset-2 hover:text-[#c9b0f2] transition-colors">⬇ full source .zip</a>
                  </div>
                )}
                <div className={`${PANEL} p-4 text-[11px] font-mono text-[#a89ec0] leading-relaxed`}>
                  <p className={HEAD + ' text-[10px] mb-2'}>CONTROLS</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-1">
                    <span><b className="text-[#e8e4d4]">WASD / Arrows</b> — move</span>
                    <span><b className="text-[#e8e4d4]">Mouse</b> — aim</span>
                    <span><b className="text-[#e8e4d4]">Left Click</b> — cast attuned spell</span>
                    <span><b className="text-[#e8e4d4]">Right Click / F</b> — PARRY (0.10s window — whiff and eat the delay!)</span>
                    <span><b className="text-[#e8e4d4]">Space / Shift</b> — dodge roll (i-frames)</span>
                    <span><b className="text-[#e8e4d4]">V</b> — staff strike</span>
                    <span><b className="text-[#e8e4d4]">1–8 / Q / Wheel</b> — spell slots</span>
                    <span><b className="text-[#e8e4d4]">R</b> — drink potion</span>
                    <span><b className="text-[#e8e4d4]">E</b> — interact · <b className="text-[#e8e4d4]">T</b> — recall to shrine</span>
                    <span><b className="text-[#e8e4d4]">I</b> grimoire · <b className="text-[#e8e4d4]">K</b> skills · <b className="text-[#e8e4d4]">B</b> satchel · <b className="text-[#e8e4d4]">J</b> bounties · <b className="text-[#e8e4d4]">C</b> character · <b className="text-[#e8e4d4]">M</b> map · <b className="text-[#e8e4d4]">Esc</b> pause</span>
                  </div>
                  <p className="mt-2 text-[10px] text-[#6a6280]">24 schools · 384 spells · 8 classes · hard mode · the world fights back. Music: “Motif de Lumière” — muffled in menus.</p>
                  <p className="mt-1 text-[10px] text-[#4a4460]">PSST: press <b className="text-[#5a5480]">`</b> (backtick) for the forbidden console…</p>
                </div>
              </div>
            </div>
          )}

          {/* ============ CLASS PICKER (new journey) ============ */}
          {snap.mode === 'title' && pickClass && (
            <div className="absolute inset-0 z-40 bg-black/85 flex items-center justify-center p-3">
              <div className={`${PANEL} w-full max-w-3xl max-h-[92vh] flex flex-col`} >
                <div className="flex items-center justify-between px-4 py-3 border-b-2 border-[#3a3152]">
                  <h2 className={HEAD + ' font-pixel text-xs'}>CHOOSE YOUR PATH</h2>
                  <button className="font-pixel text-[9px] text-[#8a8098] hover:text-[#e8e4d4] px-2" onClick={() => setPickClass(false)}>✕</button>
                </div>
                <div className="p-4 overflow-y-auto custom-scroll">
                  <p className="text-[10px] font-mono text-[#8a8098] mb-3">
                    Your class decides where you START — not where you finish. Leveling grants SKILL POINTS; spend them on ANY school or art at the skill tree [K].
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {Object.values(CLASSES).map((c) => (
                      <button
                        key={c.id}
                        onClick={() => { setPickClass(false); api.startNew(c.id); }}
                        className="text-left border-2 border-[#3a3152] bg-[#181226] hover:border-[#6a55a0] hover:bg-[#241d33] p-3 transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 border border-black/60" style={{ background: c.color }} />
                          <span className="font-pixel text-[10px] text-[#e8dff8]">{c.name.toUpperCase()}</span>
                          <span className="text-[9px] font-mono text-[#6a6280]">{c.title}</span>
                        </div>
                        <p className="text-[10px] font-mono text-[#a89ec0] mt-1.5 leading-snug">{c.blurb}</p>
                        <p className="text-[9px] font-mono mt-1.5" style={{ color: c.color }}>★ {c.passive}</p>
                        <p className="text-[9px] font-mono text-[#6a6280] mt-1">
                          Starts: {Object.entries(c.start).map(([el, lv]) => `${ELEMENTS[el as ElementId].school} ${lv}`).join(' · ')}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ============ DEATH ============ */}
          {snap.mode === 'dead' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#1a0505]/80">
              <div className="text-center">
                <h1 className="font-pixel text-3xl sm:text-5xl text-[#a83232] drop-shadow-[3px_3px_0_#000] animate-pulse">
                  YOU DIED
                </h1>
                <p className="mt-4 font-mono text-xs text-[#a89ec0]">
                  Your aether pools where you fell. Return and reclaim it.
                </p>
                <p className="mt-1 font-mono text-[11px] text-[#6a6280]">
                  Deaths: {snap.deaths} · Level {snap.lvl} · {snap.kills} kills
                </p>
                <Button
                  className="mt-6 font-pixel text-[10px] bg-[#3a2a5e] hover:bg-[#4e3a7a] text-[#e8dff8] border-2 border-[#6a55a0] shadow-[4px_4px_0_#000] h-11 px-6"
                  onClick={() => api.respawn()}
                >
                  RISE AT THE SHRINE
                </Button>
              </div>
            </div>
          )}

          {/* ============ PAUSE ============ */}
          {snap.mode === 'pause' && (
            <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70">
              <div className={`${PANEL} p-6 w-80 flex flex-col gap-3`}>
                <h2 className={`${HEAD} font-pixel text-sm text-center`}>PAUSED</h2>
                <Button className="font-pixel text-[9px] bg-[#3a2a5e] hover:bg-[#4e3a7a] border border-[#6a55a0] h-10" onClick={() => api.setMode('play')}>RESUME</Button>
                <Button className="font-pixel text-[9px] bg-[#2a2436] hover:bg-[#3a3152] border border-[#4a4060] h-10" onClick={() => api.setMode('help')}>HOW TO PLAY</Button>
                <Button className="font-pixel text-[9px] bg-[#2a2436] hover:bg-[#3a3152] border border-[#4a4060] h-10" onClick={() => api.toggleMute()}>
                  SOUND: {snap.muted ? 'OFF' : 'ON'}
                </Button>
                <Button className="font-pixel text-[9px] bg-[#2a2436] hover:bg-[#3a3152] border border-[#4a4060] h-10" onClick={() => { api.saveNow(); api.quitToTitle(); }}>
                  SAVE &amp; QUIT TO TITLE
                </Button>
              </div>
            </div>
          )}

          {/* ============ HELP ============ */}
          {snap.mode === 'help' && (
            <Overlay onClose={() => api.setMode('pause')} title="HOW TO PLAY">
              <div className="text-[11px] font-mono text-[#a89ec0] space-y-2 leading-relaxed">
                <p><b className="text-[#c9b0f2]">MAGIC:</b> 24 schools × 16 forms = 384 spells — and every school PLAYS and LOOKS different. Fire is a comet that chain-detonates, Frost a faceted crystal that stacks freezes, Water a wobbling droplet, Lightning a jagged instant bolt, Metal a whirling blade that orbits you, Gravity a compressed singularity that drags foes in, Sound a pressure ripple that echoes backward, Bone a spinning crossbone, Plasma a burning micro-star, Mirror a glass twin that splits in two. You will NEVER mistake cryo for hydro.</p>
                <p><b className="text-[#c9b0f2]">CLASSES &amp; SKILL POINTS:</b> Pick one of 8 classes when you start — Summoner, Pyromancer, Elementalist, Necromancer, Storm Caller, Shadow Blade, Blood Ritualist, Chronomancer. Leveling grants SKILL POINTS (every 4th level, a bonus). Press K: invest points into ANY school (+2 levels each) or the universal arts (Vitality, Focus, Alacrity, Reflex, Warding, Intellect). Casting a school also fills its bar for bonus points — your class is a start, not a cage.</p>
                <p><b className="text-[#c9b0f2]">NECROMANCY:</b> Every Death spell devours nearby corpses for +40% damage each. Kills have a chance to RISE as skeleton thralls. At Death school level 3 you unlock Raise Dead — raise two at once.</p>
                <p><b className="text-[#c9b0f2]">PARRY = COUNTER:</b> Parry (Right Click / F) costs stamina. A PERFECT parry — the first ~0.04s of the window — negates everything, sends projectiles BACK as gleaming golden counter-shots (your movement steers them), staggers bodies that swing at you, and erupts in a golden counter-nova. A NORMAL parry merely BLOCKS: the shot dies, but 35% of the damage bleeds through and nothing is reflected. WHIFF, and you stand exhausted in the open — a long, punishable recovery. Do not spam F.</p>
                <p><b className="text-[#c9b0f2]">GRAZE:</b> Threads of bullet-hell that part your hair (without hitting you) feed your mana and combo. Dancing on the edge of a Touhou pattern is not just survivable — it pays.</p>
                <p><b className="text-[#c9b0f2]">RELICS:</b> Press B for the satchel. Relics are passive trinkets found in boss hoards, barrow delves, elite corpses and village markets — equip up to three. Lifesteal coils, graze charms, hollow lanterns that mourn you back to health.</p>
                <p><b className="text-[#c9b0f2]">VILLAGES:</b> Three of them dot the Weald — hearths, wells, and market stalls where the peddler sells relics. No foe will follow you inside. Discover them on the map (warm orange markers).</p>
                <p><b className="text-[#c9b0f2]">STATUES &amp; NG+:</b> Eight effigies ring the Wayfarer Shrine — one per boss. They sleep until you slay their master; then spend ECHO SHARDS (dropped by bosses, elites and delves) to challenge ASCENDED versions inside their realm — harder, crowned, one extra pattern per phase. Clear all eight and THE WEALD INVERTS: NG+ layers that strengthen every foe in the world.</p>
                <p><b className="text-[#c9b0f2]">DODGE = FEELING:</b> Dashing leaves chromatic afterimages, tears speed-lines, punches the camera, ignites the ground with your attuned element (it BITES anything chasing you), and lands with a shock of dust and sparks. Reflex ranks make it cheaper and safer.</p>
                <p><b className="text-[#c9b0f2]">HARD MODE:</b> The Weald wants you dead. Foes hit harder, bosses don’t waste time, potions mend less, and danger scales with distance. Rest at shrines — dying drops ALL your aether where you fell.</p>
                <p><b className="text-[#c9b0f2]">KEYS:</b> I grimoire · K skills · B relic satchel · J bounties · C character · M map · E interact · F/right-click parry · Space dodge · R potion · T recall · Esc pause.</p>
                <p><b className="text-[#c9b0f2]">COMBO &amp; OVERDRIVE:</b> Chain kills to build a combo — at x10 you hit OVERDRIVE: +35% damage, +30% cast speed, bigger explosions. High-tier spells get full casting ceremonies.</p>
                <p><b className="text-[#c9b0f2]">BOUNTIES:</b> Press J for your bounty journal. Hunts, elemental trials, elite culls, pilgrimages — aether and xp on completion.</p>
                <p><b className="text-[#c9b0f2]">EXPLORE:</b> Landmarks dot the Weald: loot caches, archmage towers, obelisks, healing groves, raider camps — plus BURIED BARROWS (3-wave delves with a Barrow Lord boss), WANDERING PEDDLERS (trade aether for random boons), and AETHER GEYSERS (loot with a risk). Watch the sky: falling stars, elite hunts and aether storms find you.</p>
                <p><b className="text-[#e2b8f2]">MINI-BOSSES:</b> The Weald’s apex predators hunt you — THE WEAVER (eight legs, each an anchor; tripod rule; collapse it), THE CINDER MAW (shells up — bait the belch, hit the mouth), THE STORM ROC (never lands — clip a wing and it crashes), THE BONE CHOIR (silence the singers to open the ancient jaw), and THE VAULT MIMIC (that treasure chest is looking at you). They announce themselves. Loudly.</p>
                <p><b className="text-[#c9b0f2]">MUSIC:</b> “Motif de Lumière” plays as the world’s theme; mini-bosses summon “Arachne’s Web”; true boss fights take over with “Pixel Boss Battle”. Open any menu and the music muffles — it’s still there, just not in your ears.</p>
                <p><b className="text-[#c9b0f2]">FUSION:</b> After your first boss kill (or level 10), Fusion Altars merge any two spells into a hybrid dual-element spell.</p>
                <p className="text-[#4a4460]">(Testing everything? Press ` backtick — or type a certain five-letter cheat from 1993.)</p>
              </div>
            </Overlay>
          )}

          {/* ============ JOURNAL (bounties) ============ */}
          {snap.mode === 'journal' && (
            <Overlay onClose={() => api.setMode('play')} title="BOUNTY JOURNAL">
              <Journal snap={snap} />
            </Overlay>
          )}

          {/* ============ GRIMOIRE ============ */}
          {snap.mode === 'grimoire' && (
            <Grimoire snap={snap} api={api} onClose={() => api.setMode('play')} />
          )}

          {/* ============ CHARACTER ============ */}
          {snap.mode === 'character' && (
            <Overlay onClose={() => api.setMode('play')} title="THE MAGE" wide>
              <CharacterSheet snap={snap} />
            </Overlay>
          )}

          {/* ============ SKILL TREE ============ */}
          {snap.mode === 'skills' && (
            <SkillTree snap={snap} api={api} onClose={() => api.setMode('play')} />
          )}

          {/* ============ RELIC SATCHEL ============ */}
          {snap.mode === 'relics' && (
            <Overlay onClose={() => api.setMode('play')} title="THE RELIC SATCHEL" wide>
              <Satchel snap={snap} api={api} />
            </Overlay>
          )}

          {/* ============ SHOP ============ */}
          {snap.mode === 'shop' && (
            <Overlay onClose={() => api.setMode('play')} title={snap.atVillage ? 'VILLAGE MARKET' : 'SHRINE OFFERINGS'}>
              <Shop snap={snap} api={api} />
            </Overlay>
          )}

          {/* ============ FUSION ============ */}
          {snap.mode === 'fusion' && (
            <FusionLab snap={snap} api={api} onClose={() => api.setMode('play')} />
          )}

          {/* ============ CHEAT CONSOLE ============ */}
          {snap.mode === 'cheat' && (
            <CheatPanel snap={snap} api={api} onClose={() => api.setMode('play')} />
          )}

          {/* ============ TOUCH CONTROLS ============ */}
          {touchUI && snap.mode === 'play' && (
            <div className="absolute bottom-3 right-3 z-20 flex flex-col gap-2 items-end">
              <div className="flex gap-2">
                <TouchBtn label="POT" {...holdBtn((v) => api.touchBtn('potion', v))} />
                <TouchBtn label="E" {...holdBtn((v) => api.touchBtn('interact', v))} />
              </div>
              <div className="flex gap-2">
                <TouchBtn label="PARRY" big {...holdBtn((v) => api.touchBtn('parry', v))} />
                <TouchBtn label="DODGE" big {...holdBtn((v) => api.touchBtn('dodge', v))} />
              </div>
            </div>
          )}
          {touchUI && snap.mode === 'play' && (
            <div className="absolute top-2 left-1/2 -translate-x-1/2 z-20 flex gap-2">
              <TouchBtn label="GRIM" small onClick={() => api.setMode('grimoire')} />
              <TouchBtn label="MAP" small onClick={() => api.setMode('map')} />
              <TouchBtn label="MENU" small onClick={() => api.setMode('pause')} />
            </div>
          )}
        </>
      )}

      {!game && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#0d0a14]">
          <p className="font-pixel text-[10px] text-[#6a6280] animate-pulse">WEAVING THE WORLD…</p>
        </div>
      )}
    </div>
  );
}

function TouchBtn({ label, big, small, onClick, ...rest }: {
  label: string; big?: boolean; small?: boolean; onClick?: () => void;
  onPointerDown?: (e: React.PointerEvent) => void;
  onPointerUp?: () => void;
  onPointerLeave?: () => void;
}) {
  const size = big ? 'w-16 h-16' : small ? 'w-10 h-8' : 'w-14 h-10';
  return (
    <button
      {...rest}
      onClick={onClick}
      className={`${size} rounded-full bg-[#1a1428]/80 border-2 border-[#4a4060] text-[#c9b0f2] font-pixel ${small ? 'text-[7px]' : 'text-[9px]'} flex items-center justify-center active:bg-[#3a2a5e] touch-none`}
    >
      {label}
    </button>
  );
}

function Overlay({ children, onClose, title, wide }: {
  children: React.ReactNode; onClose: () => void; title: string; wide?: boolean;
}) {
  return (
    <div className="absolute inset-0 z-30 bg-black/75 flex items-center justify-center p-3" onClick={onClose}>
      <div
        className={`${PANEL} ${wide ? 'w-full max-w-3xl' : 'w-full max-w-xl'} max-h-[92vh] overflow-hidden flex flex-col`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b-2 border-[#3a3152]">
          <h2 className={HEAD + ' font-pixel text-xs'}>{title}</h2>
          <button className="font-pixel text-[9px] text-[#8a8098] hover:text-[#e8e4d4] px-2" onClick={onClose}>ESC ✕</button>
        </div>
        <div className="overflow-y-auto p-4 custom-scroll">{children}</div>
      </div>
    </div>
  );
}

/* ---------------- GRIMOIRE ---------------- */
function Grimoire({ snap, api, onClose }: { snap: UISnapshot; api: GameApi; onClose: () => void }) {
  const [school, setSchool] = useState<ElementId>('fire');
  const [detail, setDetail] = useState<string | null>(null);
  const [slotPick, setSlotPick] = useState<number | null>(null);

  const schoolSpells = ALL_SPELL_IDS
    .map((id) => ({ id, def: spellDef(id)! }))
    .filter(({ def }) => def.el === school)
    .sort((a, b) => a.def.unlock - b.def.unlock);

  const detailDef = detail ? spellDef(detail) : null;
  const detailState = detail ? snap.allSpells.find((s) => s.id === detail) : null;
  const fusionIds = snap.fused.map((id) => ({ id, def: spellDef(id)! }));

  return (
    <div className="absolute inset-0 z-30 bg-black/75 flex items-center justify-center p-2 sm:p-4" onClick={onClose}>
      <div
        className={`${PANEL} w-full max-w-4xl h-[92vh] flex flex-col`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b-2 border-[#3a3152]">
          <h2 className={HEAD + ' font-pixel text-xs'}>THE GRIMOIRE — {snap.spellCount} spells known</h2>
          <button className="font-pixel text-[9px] text-[#8a8098] hover:text-[#e8e4d4]" onClick={onClose}>ESC ✕</button>
        </div>
        <div className="flex flex-1 min-h-0">
          {/* school list */}
          <div className="w-36 sm:w-48 border-r-2 border-[#3a3152] overflow-y-auto custom-scroll">
            {snap.schools.map((s) => (
              <button
                key={s.id}
                onClick={() => setSchool(s.id)}
                className={`w-full text-left px-3 py-2 border-b border-[#241d33] hover:bg-[#241d33] ${school === s.id ? 'bg-[#241d33]' : ''}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 border border-black/60" style={{ background: s.color }} />
                  <span className="text-[11px] font-mono text-[#e8e4d4]">{s.school}</span>
                </div>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-[9px] font-mono text-[#8a8098] w-8">Lv {s.lvl}</span>
                  <div className="flex-1"><Bar v={s.xp} max={s.need} color={s.color} /></div>
                </div>
              </button>
            ))}
          </div>
          {/* spell list */}
          <div className="flex-1 min-w-0 overflow-y-auto custom-scroll p-3 space-y-1.5">
            {schoolSpells.map(({ id, def }) => {
              const st = snap.allSpells.find((s) => s.id === id);
              const known = !!st;
              const locked = !known;
              return (
                <button
                  key={id}
                  onClick={() => setDetail(id)}
                  disabled={locked}
                  className={`w-full text-left px-3 py-2 border ${detail === id ? 'border-[#ffd75e]' : 'border-[#2a2436]'} ${locked ? 'opacity-35' : 'hover:border-[#4a4060]'} bg-[#181226] flex items-center gap-3`}
                >
                  <Glyph el={def.el} form={def.form} size={26} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] font-mono text-[#e8e4d4]">{locked ? '???' : def.name}</span>
                      <span className="text-[9px] font-mono px-1 border border-[#3a3152] text-[#8a8098]">{def.form.toUpperCase()}</span>
                      {known && <span className="text-[9px] font-mono text-[#c9b0f2]">Lv {st!.lvl}</span>}
                    </div>
                    <div className="text-[9px] font-mono text-[#6a6280] truncate">
                      {locked ? `Unlocks at ${ELEMENTS[def.el].school} level ${def.unlock}` : def.desc}
                    </div>
                  </div>
                  {known && <div className="w-16"><Bar v={st!.xp} max={st!.need} color={elColor(def.el)} /></div>}
                </button>
              );
            })}
            {fusionIds.length > 0 && (
              <div className="pt-3">
                <p className="font-pixel text-[9px] text-[#c95ee8] mb-2">FUSED SPELLS</p>
                {fusionIds.map(({ id, def }) => (
                  <button
                    key={id}
                    onClick={() => setDetail(id)}
                    className={`w-full text-left px-3 py-2 border ${detail === id ? 'border-[#ffd75e]' : 'border-[#2a2436]'} hover:border-[#4a4060] bg-[#181226] flex items-center gap-3`}
                  >
                    <Glyph el={def.el} form={def.form} size={26} el2={def.el2 ?? undefined} />
                    <div className="flex-1">
                      <span className="text-[11px] font-mono text-[#e8dff8]">{def.name}</span>
                      <div className="text-[9px] font-mono text-[#6a6280] truncate">{def.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        {/* detail + attune bar */}
        {detailDef && (
          <div className="border-t-2 border-[#3a3152] p-3 flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <Glyph el={detailDef.el} form={detailDef.form} size={34} el2={detailDef.el2 ?? undefined} />
            <div className="flex-1 min-w-0">
              <div className="text-[12px] font-mono text-[#e8dff8]">{detailDef.name}</div>
              <div className="text-[10px] font-mono text-[#8a8098]">{detailDef.desc}</div>
              <div className="text-[10px] font-mono text-[#6a6280] mt-0.5">
                {detailDef.dmg > 0 && <span className="mr-3">DMG {detailDef.dmg}</span>}
                <span className="mr-3">MANA {detailDef.mana}</span>
                <span>CD {detailDef.cd}s</span>
                {detailState && <span className="ml-3 text-[#c9b0f2]">Lv {detailState.lvl}/10</span>}
              </div>
            </div>
            <div className="flex flex-wrap gap-1">
              {snap.loadout.slice(0, snap.slots).map((id, i) => (
                <button
                  key={i}
                  onClick={() => {
                    if (slotPick === null) { setSlotPick(i); }
                    else {
                      api.attune(slotPick, detail);
                      setSlotPick(null);
                    }
                  }}
                  className={`w-8 h-8 border ${slotPick === i ? 'border-[#ffd75e] bg-[#3a2a5e]' : id === detail ? 'border-[#c9b0f2]' : 'border-[#3a3152]'} bg-[#14101f] flex items-center justify-center`}
                  title={id ? spellDef(id)?.name : 'empty'}
                >
                  <span className="text-[8px] font-mono text-[#8a8098]">{i + 1}</span>
                </button>
              ))}
            </div>
            <Button
              className="font-pixel text-[8px] bg-[#3a2a5e] hover:bg-[#4e3a7a] border border-[#6a55a0] h-9 px-3"
              onClick={() => {
                const empty = snap.loadout.findIndex((s, i) => i < snap.slots && !s);
                api.attune(empty >= 0 ? empty : snap.activeSlot, detail);
              }}
            >
              ATTUNE
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

function Glyph({ el, form, size, el2 }: { el: ElementId; form: string; size: number; el2?: ElementId }) {
  const c1 = elColor(el);
  const c2 = el2 ? elColor(el2) : undefined;
  return (
    <div
      className="rounded-full border border-black/70 flex-shrink-0"
      style={{
        width: size, height: size,
        background: c2
          ? `conic-gradient(${c1} 0 50%, ${c2} 50% 100%)`
          : `radial-gradient(circle at 35% 35%, #ffffff88, ${c1} 60%, #1a1020)`,
      }}
    >
      <div className="w-full h-full flex items-center justify-center text-white font-pixel" style={{ fontSize: size * 0.32 }}>
        {FORM_GLYPHS[form] ?? '?'}
      </div>
    </div>
  );
}

const FORM_GLYPHS: Record<string, string> = {
  bolt: '╱', volley:('⫶'), orb: '○', beam: '─', wave: '≈', nova: '✳',
  storm: '↓', field: '◌', trap: '✕', ward: '⛨', aura: '◎', enchant: '^',
  summon: '△', blink: '»', mend: '✚', ritual: '✴',
};

/* ---------------- CHARACTER ---------------- */
function CharacterSheet({ snap }: { snap: UISnapshot }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Stat label="LEVEL" value={String(snap.lvl)} />
        <Stat label="SPELLS" value={String(snap.spellCount)} />
        <Stat label="AETHER" value={String(snap.aether)} />
        <Stat label="DANGER TIER" value={snap.ngPlus > 0 ? `${snap.tier} (+${snap.ngPlus} INV)` : String(snap.tier)} />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Stat label="ECHO SHARDS" value={String(snap.echoes)} />
        <Stat label="REALMS CLEARED" value={String(Object.keys(snap.ascensions).length)} />
        <Stat label="RELICS" value={`${snap.relics.filter((r) => r.owned).length}/${snap.relics.length}`} />
        <Stat label="BOSS SLAIN" value={`${snap.bosses.length}/8`} />
      </div>
      {snap.clsName && (
        <div className="border-2 border-[#3a3152] bg-[#100c1a] px-3 py-2">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 border border-black/60" style={{ background: snap.clsColor }} />
            <span className="font-pixel text-[10px] text-[#e8dff8]">{snap.clsName.toUpperCase()} {snap.clsTitle}</span>
            <span className="ml-auto font-pixel text-[9px]" style={{ color: snap.points > 0 ? '#c95ee8' : '#6a6280' }}>{snap.points} SKILL POINT{snap.points === 1 ? '' : 'S'} — [K]</span>
          </div>
          {snap.clsPassive && <p className="text-[10px] font-mono mt-1" style={{ color: snap.clsColor }}>★ {snap.clsPassive}</p>}
        </div>
      )}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <p className="text-[10px] font-mono text-[#8a8098] mb-1">HEALTH {Math.ceil(snap.hp)}/{snap.maxHp}</p>
          <Bar v={snap.hp} max={snap.maxHp} color="#c23a3a" />
        </div>
        <div>
          <p className="text-[10px] font-mono text-[#8a8098] mb-1">MANA {Math.floor(snap.mana)}/{snap.maxMana}</p>
          <Bar v={snap.mana} max={snap.maxMana} color="#3aa8a0" />
        </div>
      </div>
      <div>
        <p className={HEAD + ' font-pixel text-[9px] mb-2'}>SCHOOLS OF MAGIC</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5">
          {snap.schools.map((s) => (
            <div key={s.id} className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 border border-black/60 flex-shrink-0" style={{ background: s.color }} />
              <span className="text-[10px] font-mono text-[#c9c2b0] w-28 truncate">{s.school}</span>
              <span className="text-[10px] font-mono text-[#8a8098] w-10">Lv{s.lvl}</span>
              <div className="flex-1"><Bar v={s.xp} max={s.need} color={s.color} /></div>
            </div>
          ))}
        </div>
      </div>
      <div>
        <p className={HEAD + ' font-pixel text-[9px] mb-2'}>SIGILS ({snap.sigils.filter((s) => s.owned).length}/8)</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
          {snap.sigils.map((s) => (
            <div key={s.id} className={`px-2 py-1.5 border text-[10px] font-mono ${s.owned ? 'border-[#ffd75e] text-[#e8d494] bg-[#241d10]' : 'border-[#2a2436] text-[#5a5468]'}`}>
              <b>{s.name}</b> — {s.owned ? s.desc : '???'}
            </div>
          ))}
        </div>
      </div>
      <div className="flex gap-4 text-[10px] font-mono text-[#6a6280]">
        <span>Kills: {snap.kills}</span>
        <span>Deaths: {snap.deaths}</span>
        <span>Playtime: {Math.floor(snap.playtime / 60)}m</span>
        <span>Fusions: {snap.fused.length}</span>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="border border-[#2a2436] bg-[#181226] px-3 py-2">
      <p className="text-[8px] font-mono text-[#6a6280]">{label}</p>
      <p className="font-pixel text-[11px] text-[#e8d494]">{value}</p>
    </div>
  );
}

/* ---------------- SHOP ---------------- */
function Shop({ snap, api }: { snap: UISnapshot; api: GameApi }) {
  const [, force] = useState(0);
  const slotCost = api.slotCost();
  const items: Array<{ key: 'vial' | 'draught' | 'slot'; name: string; desc: string; cost: number; disabled: boolean }> = [
    { key: 'vial', name: 'Health Vial', desc: 'Restores 45 HP. Carry up to 9. [R]', cost: 12, disabled: snap.vials >= 9 },
    { key: 'draught', name: 'Mana Draught', desc: 'Restores 40 MP. Carry up to 9. [R]', cost: 10, disabled: snap.draughts >= 9 },
    { key: 'slot', name: 'Attunement Slot', desc: `Permanently +1 spell slot (${snap.slots}/8).`, cost: slotCost, disabled: snap.slots >= 8 },
  ];
  const RCOL: Record<string, string> = { common: '#c9c2b0', rare: '#8ee8ff', cursed: '#e85eff', mythic: '#ffd75e' };
  return (
    <div>
      {!snap.atVillage && (
        <Button
          className="w-full mb-3 font-pixel text-[9px] bg-[#2a2436] hover:bg-[#3a3152] border-2 border-[#ffd75e] text-[#ffd75e] h-11"
          onClick={() => { api.rest(); api.setMode('play'); }}
        >
          REST — heal, refill potions, set respawn
        </Button>
      )}
      {snap.atVillage && (
        <p className="text-[10px] font-mono text-[#ffb05e] mb-2">The village well hums. A peddler lays out their wares — no resting here, traveler, but the relics are honest.</p>
      )}
      <p className="text-[11px] font-mono text-[#ffd75e] mb-3">You carry {snap.aether} aether.</p>
      <div className="space-y-2">
        {items.map((it) => (
          <div key={it.key} className="flex items-center gap-3 border border-[#2a2436] bg-[#181226] px-3 py-2">
            <div className="flex-1">
              <p className="text-[11px] font-mono text-[#e8e4d4]">{it.name} <span className="text-[#8a8098]">— {it.cost} aether</span></p>
              <p className="text-[9px] font-mono text-[#6a6280]">{it.desc}</p>
            </div>
            <Button
              disabled={it.disabled || snap.aether < it.cost}
              className="font-pixel text-[8px] bg-[#1e3a2e] hover:bg-[#2a5240] border border-[#3e8a64] h-8 px-3"
              onClick={() => { if (api.buy(it.key)) force((n) => n + 1); }}
            >
              BUY
            </Button>
          </div>
        ))}
        {snap.shopStock.map((r) => (
          <div key={r.id} className="flex items-center gap-3 border border-[#2a2436] bg-[#181226] px-3 py-2">
            <span className="font-pixel text-[13px] w-5 text-center" style={{ color: r.color }}>{r.glyph}</span>
            <div className="flex-1">
              <p className="text-[11px] font-mono" style={{ color: r.color }}>
                {r.name} <span className="text-[8px] uppercase" style={{ color: RCOL[r.rarity] }}>{r.rarity}</span> <span className="text-[#8a8098]">— {r.cost} aether</span>
              </p>
              <p className="text-[9px] font-mono text-[#6a6280]">{r.desc}</p>
            </div>
            <Button
              disabled={r.owned || snap.aether < r.cost}
              className="font-pixel text-[8px] bg-[#1e2a3e] hover:bg-[#2a3a52] border border-[#3e5a8a] h-8 px-3"
              onClick={() => { if (api.buyRelic(r.id)) force((n) => n + 1); }}
            >
              {r.owned ? 'OWNED' : 'BUY'}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- RELIC SATCHEL ---------------- */
function Satchel({ snap, api }: { snap: UISnapshot; api: GameApi }) {
  const [, force] = useState(0);
  const equipped: Array<{ id: string; name: string; glyph: string; color: string; rarity: string } | null> = [0, 1, 2].map((i) => {
    const r = snap.relics.find((x) => x.equipped === i && x.owned);
    return r ?? null;
  });
  const RCOL: Record<string, string> = { common: '#c9c2b0', rare: '#8ee8ff', cursed: '#e85eff', mythic: '#ffd75e' };
  const unequip = (slot: number) => { api.equipRelic(slot, null); force((n) => n + 1); };
  const equip = (slot: number, id: string) => { api.equipRelic(slot, id); force((n) => n + 1); };
  const owned = snap.relics.filter((r) => r.owned);
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Stat label="ECHO SHARDS" value={String(snap.echoes)} />
        <p className="text-[10px] font-mono text-[#8a8098] flex-1">Echo shards come from bosses, elites, barrow delves and statue realms. The effigy ring at the Wayfarer Shrine trades them for ASCENDED rematches.</p>
      </div>
      <div>
        <p className={HEAD + ' font-pixel text-[9px] mb-2'}>ATTUNED RELICS (equip up to 3)</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {equipped.map((r, i) => (
            <div key={i} className={`border-2 px-3 py-2 min-h-[64px] ${r ? 'border-[#4a4060] bg-[#181226]' : 'border-dashed border-[#2a2436] bg-[#100c1a]'} max-h-24 overflow-y-auto custom-scroll`}>
              {r ? (
                <>
                  <div className="flex items-center gap-2">
                    <span className="font-pixel text-[13px]" style={{ color: r.color }}>{r.glyph}</span>
                    <span className="text-[11px] font-mono" style={{ color: r.color }}>{r.name}</span>
                  </div>
                  <p className="text-[9px] font-mono text-[#6a6280] mt-1">{snap.relics.find((x) => x.id === r.id)?.desc}</p>
                  <button className="mt-1 font-pixel text-[8px] text-[#a89ec0] hover:text-[#ff8a9e]" onClick={() => unequip(i)}>UNEQUIP</button>
                </>
              ) : (
                <p className="text-[10px] font-mono text-[#4a4460]">empty socket — pick a relic below</p>
              )}
            </div>
          ))}
        </div>
      </div>
      <div>
        <p className={HEAD + ' font-pixel text-[9px] mb-2'}>COLLECTION ({owned.length}/{snap.relics.length})</p>
        {owned.length === 0 ? (
          <p className="text-[10px] font-mono text-[#6a6280]">You carry nothing yet. Bosses hoard them, barrows guard them, peddlers sell them. Delve deeper.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {owned.map((r) => (
              <div key={r.id} className="border border-[#2a2436] bg-[#181226] px-3 py-2">
                <div className="flex items-center gap-2">
                  <span className="font-pixel text-[12px]" style={{ color: r.color }}>{r.glyph}</span>
                  <span className="text-[11px] font-mono" style={{ color: r.color }}>{r.name}</span>
                  <span className="ml-auto text-[8px] font-mono uppercase" style={{ color: RCOL[r.rarity] }}>{r.rarity}</span>
                </div>
                <p className="text-[9px] font-mono text-[#6a6280] mt-0.5">{r.desc}</p>
                {r.equipped < 0 && (
                  <div className="flex gap-1 mt-1">
                    {equipped.map((_, si) => (
                      <button key={si} className="font-pixel text-[8px] px-2 py-0.5 border border-[#3e8a64] text-[#8effa8] hover:bg-[#1e3a2e]" onClick={() => equip(si, r.id)}>
                        EQUIP {si + 1}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      <div>
        <p className={HEAD + ' font-pixel text-[9px] mb-2'}>YET UNFOUND</p>
        <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto custom-scroll">
          {snap.relics.filter((r) => !r.owned).map((r) => (
            <span key={r.id} className="text-[10px] font-mono text-[#3a3448] border border-[#221c30] px-2 py-0.5" title={r.rarity}>{'?'}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------- FUSION LAB ---------------- */
function SpellPicker({ known, snap, value, set, label }: {
  known: string[]; snap: UISnapshot; value: string | null; set: (id: string) => void; label: string;
}) {
  return (
    <div className="flex-1">
      <p className="font-pixel text-[8px] text-[#8a8098] mb-1">{label}</p>
      <select
        value={value ?? ''}
        onChange={(e) => set(e.target.value)}
        className="w-full bg-[#181226] border-2 border-[#3a3152] text-[11px] font-mono text-[#e8e4d4] px-2 py-2 outline-none"
      >
        <option value="" disabled>choose spell…</option>
        {known.map((id) => {
          const d = spellDef(id);
          return d ? <option key={id} value={id}>{d.name} (Lv{snap.allSpells.find((s) => s.id === id)?.lvl ?? 1})</option> : null;
        })}
      </select>
    </div>
  );
}

function FusionLab({ snap, api, onClose }: { snap: UISnapshot; api: GameApi; onClose: () => void }) {
  const [a, setA] = useState<string | null>(null);
  const [b, setB] = useState<string | null>(null);
  const [msg, setMsg] = useState('');
  const known = snap.knownSpells;
  const check = a && b ? api.canFusePair(a, b) : null;
  const result = check?.result ?? null;

  return (
    <div className="absolute inset-0 z-30 bg-black/80 flex items-center justify-center p-3" onClick={onClose}>
      <div className={`${PANEL} w-full max-w-2xl max-h-[92vh] flex flex-col`} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b-2 border-[#3a3152]">
          <h2 className="font-pixel text-xs text-[#c95ee8]">FUSION ALTAR</h2>
          <button className="font-pixel text-[9px] text-[#8a8098] hover:text-[#e8e4d4]" onClick={onClose}>ESC ✕</button>
        </div>
        <div className="p-4 space-y-4 overflow-y-auto custom-scroll">
          <p className="text-[10px] font-mono text-[#8a8098]">
            Merge two known spells into a hybrid. The form follows the higher-leveled spell; both elements imbue it
            (primary at full power, secondary at 45%). Cost: <b className="text-[#ffd75e]">{FUSE_COST} aether</b> — you have {snap.aether}.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:items-end">
            <SpellPicker known={known} snap={snap} value={a} set={setA} label="FIRST SPELL" />
            <span className="font-pixel text-sm text-[#c95ee8] text-center pb-2">+</span>
            <SpellPicker known={known} snap={snap} value={b} set={setB} label="SECOND SPELL" />
          </div>
          <div className="min-h-24 border-2 border-dashed border-[#3a3152] bg-[#100c1a] p-3 flex items-center gap-3">
            {result ? (
              <>
                <Glyph el={result.el} form={result.form} size={40} el2={result.el2 ?? undefined} />
                <div>
                  <p className="text-[13px] font-mono text-[#e8d494]">{result.name}</p>
                  <p className="text-[10px] font-mono text-[#8a8098]">{result.desc}</p>
                  <p className="text-[10px] font-mono text-[#6a6280]">DMG {result.dmg} · MANA {result.mana} · CD {result.cd}s</p>
                </div>
              </>
            ) : (
              <p className="text-[10px] font-mono text-[#5a5468]">{check && !check.ok ? check.reason : 'Choose two spells to preview the fusion…'}</p>
            )}
          </div>
          {msg && <p className="text-[10px] font-mono text-[#ff8a9e]">{msg}</p>}
          <Button
            disabled={!result || !check?.ok || snap.aether < FUSE_COST}
            className="font-pixel text-[9px] bg-[#3a2a5e] hover:bg-[#4e3a7a] border-2 border-[#c95ee8] text-[#f2e4ff] h-11 w-full"
            onClick={() => {
              if (!a || !b) return;
              const r = api.fuse(a, b);
              setMsg(r.msg);
              if (r.ok) { setA(null); setB(null); }
            }}
          >
            FUSE
          </Button>
          {snap.fused.length > 0 && (
            <div>
              <p className="font-pixel text-[8px] text-[#8a8098] mb-1">YOUR FUSIONS ({snap.fused.length})</p>
              <div className="flex flex-wrap gap-1">
                {snap.fused.map((id) => {
                  const d = spellDef(id);
                  return d ? (
                    <span key={id} className="text-[9px] font-mono px-2 py-1 border border-[#3a3152] bg-[#181226] text-[#c9c2b0]">
                      {d.name}
                    </span>
                  ) : null;
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------- JOURNAL (bounties) ---------------- */
function Journal({ snap }: { snap: UISnapshot }) {
  const KIND_COLORS: Record<string, string> = {
    slay: '#ff8a9e', slayEl: '#c95ee8', elite: '#ff9e4e',
    discover: '#9ee8ff', rest: '#5ee8c9', boss: '#ffd75e',
  };
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-[10px] font-mono text-[#8a8098]">
        <span>Bounties completed: <b className="text-[#7ce8a8]">{snap.questsDone}</b></span>
        <span>Landmarks discovered: <b className="text-[#9ee8ff]">{snap.landmarksFound}</b></span>
      </div>
      {snap.quests.length === 0 && (
        <p className="text-[10px] font-mono text-[#5a5468]">The Weald is quiet… for now.</p>
      )}
      <div className="space-y-2">
        {snap.quests.map((q) => {
          const col = KIND_COLORS[q.kind] ?? '#c9b0f2';
          return (
            <div
              key={q.id}
              className={`border-2 p-3 ${q.done ? 'border-[#3e8a64] bg-[#12241a]/60' : 'border-[#3a3152] bg-[#100c1a]'}`}
            >
              <div className="flex items-start justify-between gap-3">
                <p className={`text-[11px] font-mono ${q.done ? 'text-[#7ce8a8] line-through' : 'text-[#e8e4d4]'}`}>
                  <span className="inline-block w-2 h-2 mr-2 border border-black/60" style={{ background: col }} />
                  {q.title}
                </p>
                <span className="text-[10px] font-mono text-[#ffd75e] whitespace-nowrap">+{q.reward} aether</span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <div className="flex-1"><Bar v={q.have} max={q.need} color={q.done ? '#3e8a64' : col} /></div>
                <span className="text-[9px] font-mono text-[#8a8098]">{q.have}/{q.need}</span>
              </div>
            </div>
          );
        })}
      </div>
      <p className="text-[9px] font-mono text-[#6a6280] leading-relaxed">
        New bounties appear as old ones are completed. Hunt elites, rest at shrines, wield every school of
        magic — the Weald rewards the restless. Landmarks glow on the horizon and dot your map.
      </p>
    </div>
  );
}

/* ---------------- SKILL TREE ---------------- */
function SkillTree({ snap, api, onClose }: { snap: UISnapshot; api: GameApi; onClose: () => void }) {
  const [, force] = useState(0);
  const bump = () => force((n) => n + 1);
  const canSpend = snap.points > 0;
  return (
    <div className="absolute inset-0 z-30 bg-black/80 flex items-center justify-center p-2 sm:p-4" onClick={onClose}>
      <div className={`${PANEL} w-full max-w-4xl max-h-[92vh] flex flex-col`} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b-2 border-[#3a3152]">
          <h2 className={HEAD + ' font-pixel text-xs'}>THE SKILL TREE</h2>
          <div className="flex items-center gap-3">
            <span className={`font-pixel text-[10px] px-2 py-1 border-2 ${canSpend ? 'text-[#c95ee8] border-[#c95ee8] bg-[#241a38] animate-pulse' : 'text-[#6a6280] border-[#3a3152]'}`}>
              {snap.points} POINT{snap.points === 1 ? '' : 'S'}
            </span>
            <button className="font-pixel text-[9px] text-[#8a8098] hover:text-[#e8e4d4]" onClick={onClose}>ESC ✕</button>
          </div>
        </div>
        <div className="overflow-y-auto custom-scroll p-4 space-y-4">
          {/* class banner */}
          <div className="border-2 border-[#3a3152] bg-[#100c1a] p-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 border border-black/60" style={{ background: snap.clsColor }} />
              <span className="font-pixel text-[10px] text-[#e8dff8]">{(snap.clsName ?? 'UNCLASSED').toUpperCase()}</span>
              <span className="text-[9px] font-mono text-[#6a6280]">{snap.clsTitle ?? ''}</span>
            </div>
            {snap.clsPassive && <p className="text-[10px] font-mono mt-1" style={{ color: snap.clsColor }}>★ {snap.clsPassive}</p>}
            <p className="text-[9px] font-mono text-[#6a6280] mt-1">Lifetime points earned: {snap.pointsEarned} · 1 point = +2 school levels · schools also earn bonus points as you cast them</p>
          </div>

          {/* universal arts */}
          <div>
            <p className="font-pixel text-[9px] text-[#ffd75e] mb-2">UNIVERSAL ARTS</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {snap.universalDefs.map((u) => {
                const rank = snap.universal[u.id] ?? 0;
                const maxed = rank >= u.max;
                return (
                  <button
                    key={u.id}
                    disabled={!canSpend || maxed}
                    onClick={() => { api.investSkill('universal', u.id); bump(); }}
                    className={`text-left border-2 p-2.5 transition-colors ${maxed ? 'border-[#ffd75e]/60 bg-[#241d10]' : canSpend ? 'border-[#3a3152] bg-[#181226] hover:border-[#ffd75e]' : 'border-[#2a2436] bg-[#181226] opacity-60'}`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-pixel text-[11px]" style={{ color: u.color }}>{u.glyph}</span>
                      <span className="text-[11px] font-mono text-[#e8e4d4]">{u.name}</span>
                      <span className="ml-auto flex gap-0.5">
                        {Array.from({ length: UNIVERSAL_MAX }).map((_, i) => (
                          <span key={i} className="w-1.5 h-2.5 border border-black/60" style={{ background: i < rank ? u.color : '#241d33' }} />
                        ))}
                      </span>
                    </div>
                    <p className="text-[9px] font-mono text-[#8a8098] mt-1">{u.desc}</p>
                    <p className="text-[9px] font-mono mt-0.5" style={{ color: maxed ? '#ffd75e' : '#6a6280' }}>{maxed ? 'MASTERED' : `Rank ${rank}/${u.max} — click to invest`}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* schools */}
          <div>
            <p className="font-pixel text-[9px] text-[#c9b0f2] mb-2">SCHOOLS OF MAGIC — invest anywhere, mix anything</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {snap.schools.map((s) => {
                const maxed = s.lvl >= 40;
                return (
                  <button
                    key={s.id}
                    disabled={!canSpend || maxed}
                    onClick={() => { api.investSkill('school', s.id); bump(); }}
                    className={`text-left border-2 p-2.5 transition-colors ${maxed ? 'border-[#c9b0f2]/60 bg-[#1c1430]' : canSpend ? 'border-[#3a3152] bg-[#181226] hover:border-[#c9b0f2]' : 'border-[#2a2436] bg-[#181226] opacity-60'}`}
                    title={ELEMENTS[s.id].blurb}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 border border-black/60 flex-shrink-0" style={{ background: s.color }} />
                      <span className="text-[11px] font-mono text-[#e8e4d4] truncate">{s.school}</span>
                      <span className="ml-auto text-[10px] font-mono" style={{ color: s.color }}>Lv {s.lvl}</span>
                    </div>
                    <div className="mt-1.5"><Bar v={s.xp} max={s.need} color={s.color} /></div>
                    <p className="text-[9px] font-mono mt-1 text-[#6a6280] truncate">{ELEMENTS[s.id].blurb.split('.')[0]}</p>
                    <p className="text-[9px] font-mono mt-0.5" style={{ color: maxed ? '#c9b0f2' : canSpend ? '#8a8098' : '#5a5468' }}>
                      {maxed ? 'MASTERED' : '+2 Lv per point'}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- CHEAT CONSOLE ---------------- */
function CheatPanel({ snap, api, onClose }: { snap: UISnapshot; api: GameApi; onClose: () => void }) {
  const [, force] = useState(0);
  const bump = () => force((n) => n + 1);
  const C = 'font-pixel text-[8px] h-9 px-2 border shadow-[2px_2px_0_#000] w-full';
  const actions: Array<{ label: string; act: string; color: string; title?: string }> = [
    { label: snap.cheatGod ? 'GOD MODE: ON' : 'GOD MODE: OFF', act: 'god', color: snap.cheatGod ? 'bg-[#4e2a1e] border-[#ff9e4e] text-[#ffd75e]' : 'bg-[#2a2436] border-[#4a4060] text-[#a89ec0]' },
    { label: snap.cheatMana ? '∞ MANA: ON' : '∞ MANA: OFF', act: 'mana', color: snap.cheatMana ? 'bg-[#1e3a3a] border-[#5ee8c9] text-[#9ef2e0]' : 'bg-[#2a2436] border-[#4a4060] text-[#a89ec0]' },
    { label: '+1 LEVEL', act: 'level', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: '+5 LEVELS', act: 'level5', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: '+1000 AETHER', act: 'aether', color: 'bg-[#2a2436] border-[#ffd75e]/50 text-[#ffd75e]' },
    { label: 'FULL HEAL', act: 'heal', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: 'FILL POTIONS', act: 'potions', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: 'UNLOCK ALL 384 SPELLS', act: 'unlockAll', color: 'bg-[#2e1a3e] border-[#c95ee8]/60 text-[#f2c9ff]' },
    { label: 'UNLOCK FUSION', act: 'fusion', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: 'GRANT ALL SIGILS', act: 'sigils', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: 'TRIGGER OVERDRIVE', act: 'overdrive', color: 'bg-[#3e2412] border-[#ff9e4e]/60 text-[#ffcf9e]' },
    { label: '+3 SKILL POINTS', act: 'points', color: 'bg-[#241a38] border-[#c95ee8]/60 text-[#e2b8f2]', title: 'Because the tree is right there' },
    { label: 'RELIC + 3 ECHOES', act: 'relic', color: 'bg-[#1e2a3e] border-[#8ee8ff]/60 text-[#b8ecff]', title: 'A random relic materializes + echo shards for the statue ring' },
    { label: 'SPAWN THE WEAVER', act: 'spawnWeaver', color: 'bg-[#241a38] border-[#c95ee8]/70 text-[#e2b8f2]', title: 'The eight-legged ambush — legs are anchors, drop it to 3 and it collapses' },
    { label: 'SPAWN RANDOM ELITE', act: 'spawnElite', color: 'bg-[#3e1a1a] border-[#ff5a5a]/60 text-[#ffb0a8]' },
    { label: 'KILL EVERYTHING', act: 'killAll', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: 'TELEPORT TO SHRINE', act: 'tpShrine', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]' },
    { label: 'REFUND UNIVERSAL ARTS', act: 'refundSkills', color: 'bg-[#2a2436] border-[#4a4060] text-[#c9c2b0]', title: 'Resets universal ranks, refunds those points' },
  ];
  return (
    <div className="absolute inset-0 z-30 bg-black/80 flex items-center justify-center p-3" onClick={onClose}>
      <div className={`${PANEL} w-full max-w-2xl max-h-[92vh] flex flex-col`} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b-2 border-[#3a3152]">
          <h2 className="font-pixel text-xs text-[#ffd75e]">⌘ THE FORBIDDEN CONSOLE ⌘</h2>
          <button className="font-pixel text-[9px] text-[#8a8098] hover:text-[#e8e4d4]" onClick={onClose}>ESC ✕</button>
        </div>
        <div className="p-4 space-y-4 overflow-y-auto custom-scroll">
          <p className="text-[10px] font-mono text-[#8a8098]">
            Test everything. Level, loot, spells, bosses — break the Weald over your knee. (Level: <b className="text-[#e8d494]">{snap.lvl}</b> · Aether: <b className="text-[#ffd75e]">{snap.aether}</b>)
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {actions.map((a) => (
              <button
                key={a.act}
                className={`${C} ${a.color}`}
                onClick={() => { api.cheat(a.act); bump(); }}
              >
                {a.label}
              </button>
            ))}
          </div>
          <div>
            <p className="font-pixel text-[9px] text-[#c95ee8] mb-2">SUMMON A MINI-BOSS (it comes to YOU)</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[['maw', 'CINDER MAW', 'Shells up — hit the mouth or the back'], ['roc', 'STORM ROC', 'Never lands — clip its wings'], ['choir', 'BONE CHOIR', 'Kill the singers, open the jaw'], ['mimic', 'VAULT MIMIC', 'It was never treasure']].map(([id, name, tip]) => (
                <button
                  key={id}
                  className={`${C} bg-[#1e1030] border-[#c95ee8]/60 text-[#e2b8f2]`}
                  title={tip}
                  onClick={() => { api.cheat('spawnMiniBoss', id); bump(); }}
                >
                  {name}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="font-pixel text-[9px] text-[#e2552e] mb-2">SUMMON A BOSS (teleports you to its arena)</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {snap.bossList.map((b) => (
                <button
                  key={b.id}
                  className={`${C} ${b.killed ? 'bg-[#181226] border-[#3a3152] text-[#6a6280]' : 'bg-[#2a1010] border-[#e2552e]/60 text-[#ffb0a0]'}`}
                  title={b.killed ? 'already slain — will be re-summoned' : b.name}
                  onClick={() => { api.cheat('spawnBoss', b.id); }}
                >
                  {b.name.split(',')[0].replace('The ', '')}
                </button>
              ))}
            </div>
          </div>
          <div className="border-t-2 border-[#241d33] pt-3">
            <button
              className={`${C} bg-[#1a0a0a] border-[#ff5a5a] text-[#ff8a8a]`}
              onClick={() => { if (confirm('Wipe the save? The world will be re-rolled on reload.')) api.cheat('wipe'); }}
            >
              WIPE SAVE (fresh world on reload)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
