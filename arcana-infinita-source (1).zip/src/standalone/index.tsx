/* ============================================================
   standalone/index.tsx — entry for the single-file offline
   build of Arcana Infinita. Bundled by scripts/build-standalone.ts
   (esbuild → IIFE) and inlined into public/arcana-infinita.html.
   No Next.js involved: we mount the exact same GameClient the
   hosted app uses onto a plain #root div.
   ============================================================ */
import { createRoot } from 'react-dom/client';
import GameClient from '@/components/game/GameClient';

window.__ARCANA_STANDALONE__ = true;

const el = document.getElementById('root');
if (el) {
  createRoot(el).render(<GameClient />);
}
