/* ============================================================
   quests.ts — BOUNTIES. Procedural objectives so the open
   world always gives you something to hunt besides bosses:
   culls, elemental trials, elite hunts, pilgrimages, and
   landmark discoveries. Rewards: aether + xp, auto-claimed.
   ============================================================ */
import { chance, pick, randR, type GameCtx, type Quest } from './core';
import { ELEMENTS } from './magic';
import { addText } from './fx';

export interface QuestPoolEntry { id: string; name: string; tier: number }
export interface QuestPool { kinds: QuestPoolEntry[] }

// xp awarding is wired by game.ts to avoid a circular import
let awardXp: ((G: GameCtx, amount: number) => void) | null = null;
export function registerXpHandler(fn: (G: GameCtx, amount: number) => void): void {
  awardXp = fn;
}

function lvlMul(G: GameCtx): number {
  return 1 + (G.prog.lvl - 1) * 0.09;
}

export function makeQuest(G: GameCtx, pool: QuestPool, seq: number): Quest {
  const kinds: Array<Quest['kind']> = ['slay', 'slayEl', 'elite', 'discover', 'rest', 'boss'];
  // weight: early game favors simple hunts
  const roll = Math.random();
  let kind: Quest['kind'];
  if (roll < 0.34) kind = 'slay';
  else if (roll < 0.55) kind = 'slayEl';
  else if (roll < 0.68) kind = 'elite';
  else if (roll < 0.82) kind = 'discover';
  else if (roll < 0.92) kind = 'rest';
  else kind = G.prog.bosses.length >= 1 || chance(0.3) ? 'boss' : 'elite';

  const id = `q_${Math.floor(G.prog.questSeed + seq)}_${Math.floor(randR(0, 1e6))}`;
  const mul = lvlMul(G);
  switch (kind) {
    case 'slay': {
      const candidates = pool.kinds.filter((k) => k.tier <= Math.min(3, 1 + Math.floor(G.prog.lvl / 8)));
      const k = pick(candidates.length ? candidates : pool.kinds);
      const need = k.tier >= 3 ? 4 : k.tier === 2 ? 6 : 10;
      return {
        id, kind, target: k.id, need, have: 0,
        title: `Cull the ${k.name}s — slay ${need}`,
        reward: Math.round((18 + k.tier * 14) * mul),
        xp: Math.round((30 + k.tier * 22) * mul),
        done: false, claimed: false,
      };
    }
    case 'slayEl': {
      const el = pick(Object.keys(ELEMENTS) as Array<keyof typeof ELEMENTS>);
      const need = 8;
      return {
        id, kind, target: el, need, have: 0,
        title: `Trial of ${ELEMENTS[el].name} — destroy ${need} foes with ${ELEMENTS[el].name} magic`,
        reward: Math.round(34 * mul),
        xp: Math.round(55 * mul),
        done: false, claimed: false,
      };
    }
    case 'elite': {
      const need = 1 + (chance(0.35) ? 1 : 0);
      return {
        id, kind, need, have: 0,
        title: `Big Game — slay ${need} elite ${need > 1 ? 'foes' : 'foe'}`,
        reward: Math.round(42 * mul),
        xp: Math.round(70 * mul),
        done: false, claimed: false,
      };
    }
    case 'discover': {
      const need = 2;
      return {
        id, kind, need, have: 0,
        title: `Cartographer — discover ${need} landmarks`,
        reward: Math.round(30 * mul),
        xp: Math.round(45 * mul),
        done: false, claimed: false,
      };
    }
    case 'rest': {
      return {
        id, kind, need: 1, have: 0,
        title: 'Pilgrimage — rest at a shrine',
        reward: Math.round(16 * mul),
        xp: Math.round(24 * mul),
        done: false, claimed: false,
      };
    }
    default: {
      return {
        id, kind: 'boss', need: 1, have: 0,
        title: 'Legend — vanquish any boss',
        reward: Math.round(90 * mul),
        xp: Math.round(150 * mul),
        done: false, claimed: false,
      };
    }
  }
}

export function ensureQuests(G: GameCtx, pool: QuestPool): void {
  while (G.prog.quests.length < 3) {
    G.prog.quests.push(makeQuest(G, pool, G.prog.quests.length + G.prog.questsDone));
  }
}

function complete(G: GameCtx, q: Quest): void {
  q.done = true;
  q.claimed = true;
  G.prog.questsDone++;
  G.prog.aether += q.reward;
  awardXp?.(G, q.xp);
  G.audio.sfx('quest');
  G.banner = {
    title: 'BOUNTY COMPLETE',
    sub: `${q.title}  ·  +${q.reward} aether  +${q.xp} xp`,
    t: 0,
    color: '#7ce8a8',
  };
  addText(G, G.player.x, G.player.y - 30, `+${q.reward} aether`, '#7ce8a8', 7, true);
  G.uiV++;
  // refresh on next ensureQuests call (called each step from game.ts)
}

function progressQuest(G: GameCtx, q: Quest, amount = 1): void {
  if (q.done) return;
  q.have = Math.min(q.need, q.have + amount);
  if (q.have >= q.need) complete(G, q);
}

// ---------- tracking hooks ----------
export function trackKill(G: GameCtx, kindId: string, el: string, elite: boolean, tier: number): void {
  void tier;
  G.prog.elKills[el] = (G.prog.elKills[el] ?? 0) + 1;
  if (elite) G.prog.eliteKills++;
  for (const q of G.prog.quests) {
    if (q.done) continue;
    if (q.kind === 'slay' && q.target === kindId) progressQuest(G, q);
    else if (q.kind === 'slayEl' && q.target === el) progressQuest(G, q);
    else if (q.kind === 'elite' && elite) progressQuest(G, q);
  }
}

export function trackDiscover(G: GameCtx): void {
  for (const q of G.prog.quests) {
    if (!q.done && q.kind === 'discover') progressQuest(G, q);
  }
}

export function trackRest(G: GameCtx): void {
  for (const q of G.prog.quests) {
    if (!q.done && q.kind === 'rest') progressQuest(G, q);
  }
}

export function trackBoss(G: GameCtx): void {
  for (const q of G.prog.quests) {
    if (!q.done && q.kind === 'boss') progressQuest(G, q);
  }
}

// refill completed bounty slots (call each step)
export function questTick(G: GameCtx, pool: QuestPool): void {
  ensureQuests(G, pool);
}
