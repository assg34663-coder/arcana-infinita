/* ============================================================
   ARCANA INFINITA — core.ts
   Shared constants, math, RNG/noise, and type definitions.
   Pure utilities + types only (no runtime deps on other files).
   ============================================================ */

export const TILE = 16;
export const CHUNK = 24; // tiles per chunk side
export const CHUNK_PX = TILE * CHUNK;

// ---------- types ----------
export type Team = 'player' | 'enemy';

export type ElementId =
  | 'fire' | 'frost' | 'lightning' | 'earth' | 'wind' | 'water'
  | 'poison' | 'blood' | 'shadow' | 'death' | 'radiant' | 'arcane'
  | 'time' | 'void' | 'nature' | 'chaos' | 'crystal' | 'metal'
  | 'gravity' | 'sound' | 'bone' | 'beast' | 'plasma' | 'mirror';

export const ELEMENT_IDS: ElementId[] = [
  'fire', 'frost', 'lightning', 'earth', 'wind', 'water',
  'poison', 'blood', 'shadow', 'death', 'radiant', 'arcane',
  'time', 'void', 'nature', 'chaos', 'crystal', 'metal',
  'gravity', 'sound', 'bone', 'beast', 'plasma', 'mirror',
];

export type FormId =
  | 'bolt' | 'volley' | 'orb' | 'beam' | 'wave' | 'nova'
  | 'storm' | 'field' | 'trap' | 'ward' | 'aura' | 'enchant'
  | 'summon' | 'blink' | 'mend' | 'ritual';

export const FORM_IDS: FormId[] = [
  'bolt', 'volley', 'orb', 'beam', 'wave', 'nova',
  'storm', 'field', 'trap', 'ward', 'aura', 'enchant',
  'summon', 'blink', 'mend', 'ritual',
];

export type BiomeId =
  | 'ocean' | 'beach' | 'grass' | 'forest' | 'darkwood' | 'desert'
  | 'swamp' | 'tundra' | 'volcanic' | 'wastes' | 'arcane';

export type SpellDef = {
  id: string;
  el: ElementId;       // primary element
  el2: ElementId | null; // secondary (fused hybrids)
  form: FormId;
  name: string;
  desc: string;
  dmg: number;   // base damage (or heal for mend)
  mana: number;  // base mana cost
  cd: number;    // base cooldown seconds
  unlock: number; // school level required
  fused?: boolean;
};

// ---------- statuses ----------
export type StatusFx = {
  burn?: { t: number; dps: number; team: Team };
  poison?: { t: number; dps: number };
  chill?: { t: number; mult: number };
  stun?: { t: number };
  frozen?: { t: number };   // frost lock: stunned + takes shatter damage
  root?: { t: number };
  wet?: { t: number };
  fear?: { t: number };
  haste?: { t: number; mult: number };
  amp?: { t: number; mult: number }; // takes extra damage
  // --- school mechanic stacks ---
  frzStack?: { n: number; t: number };   // frost: hits freeze at 3
  plague?: { n: number; t: number };     // poison: escalating stacks
  doom?: { t: number };                  // shadow: foe deals -30% damage
  packMark?: { n: number; t: number };   // beast: 3 marks -> spirit lunge
  tStop?: { n: number; t: number };      // time: charges stop time at 3
};

export interface Ent {
  x: number; y: number; vx: number; vy: number; r: number;
  hp: number; maxHp: number; team: Team;
  st: StatusFx;
  flash: number; dead: boolean; deadT: number;
  face: number; anim: number;
  undead?: boolean;
  fly?: boolean;
  passWalls?: boolean;
  scale?: number;
}

export type EnemyAI = 'melee' | 'ranged' | 'charger' | 'orbiter' | 'summoner' | 'ghost';

export type EnemyKind = {
  id: string; name: string; sprite: string;
  hp: number; dmg: number; speed: number; r: number;
  xp: number; aether: number; tier: number;
  ai: EnemyAI; el: ElementId;
  atkRange: number; atkCd: number;
  undead?: boolean; passWalls?: boolean; fly?: boolean;
  bulletSpeed?: number;
  parryMelee?: boolean;
  biomes: BiomeId[];
  corpse?: boolean;
};

export interface Enemy extends Ent {
  kind: EnemyKind;
  tier: number;         // difficulty ring scaling
  elite: 'frenzied' | 'titan' | 'volatile' | 'arcane' | null;
  state: 'roam' | 'chase' | 'windup' | 'attack' | 'flee';
  aiT: number; atkT: number; windup: number;
  roamX: number; roamY: number;
  dmgMul: number; hpMul: number;
  contactT: number;
  spawnGuard: number;
  exploded?: boolean;
  puppet?: boolean;     // choreographed externally (The Weaver's parts)
}

// ---------- the weaver (procedural giant spider miniboss) ----------
export interface SpiderLeg {
  e: Enemy;              // the damageable leg entity
  side: number;          // -1 left, 1 right
  idx: number;           // 0..3 front-to-back on its side
  baseAng: number;       // rest angle around the body (local)
  baseLen: number;       // rest distance from body center
  fx: number; fy: number;// planted foot position (world)
  planted: boolean;
  lift: number;          // 0..1 step lift progress
  sx: number; sy: number;// step start pos
  tx: number; ty: number;// step target pos
  stepT: number;         // step duration progress
  stepDur: number;
  atkCd: number;         // personal attack cooldown
  slamming: number;      // >0 while slamming toward the mark
  markX: number; markY: number;
  grieved: boolean;      // ichor burst fired for this leg's death
}

export interface SpiderState {
  body: Enemy;           // damageable body entity
  legs: SpiderLeg[];
  facing: number;        // radians the spider is heading
  groundX: number;       // where it landed (intro anchor — never recomputed)
  groundY: number;
  collapsed: number;     // >0 seconds of collapse remaining
  collapseCd: number;
  atkCd: number;         // body attack cooldown
  intro: number;         // drop-in timer
  dead: boolean;
  rewardT: number;       // guard so death rewards fire once
  gaitT: number;
}

// dash afterimage ghost (player silhouette echo)
export interface DashGhost {
  x: number; y: number; face: number; frame: number;
  t: number; dur: number; el: ElementId; walk: boolean;
}

export interface Minion extends Ent {
  mtype: string; sprite: string; el: ElementId;
  life: number; dmg: number; speed: number;
  ranged: boolean; atkT: number; atkCd: number;
  bulletSpeed: number;
}

export type BulletKind = 'bolt' | 'orb' | 'shard' | 'wave' | 'laser' | 'meteor' | 'gold' | 'soul';

export interface Bullet {
  x: number; y: number; vx: number; vy: number; r: number;
  dmg: number; el: ElementId; el2: ElementId | null; team: Team;
  life: number; maxLife: number; t: number;
  kind: BulletKind;
  pierce: number;
  homing: number;        // steering strength toward nearest foe
  accel: number;
  color: string; color2: string;
  parryable: boolean;
  passWalls: boolean;
  trail: number;         // 0 none, >0 trail intensity
  spin: number;
  boomR: number; boomDmg: number;
  hp: number;            // destructible orbs
  destructible: boolean;
  zigzag: number;
  gravity: number;
  seed: number;
  hit: Set<Ent>;
  from: Ent | null;
  potency: number;       // element status potency
  dead: boolean;
  grazed?: boolean;      // player threaded the needle — Touhou graze
  reflected?: boolean;   // sent back by a parry
  boomerang?: number;    // blood: returns to caster after t
  onBoomEl?: ElementId;  // secondary cloud on death
  orbit?: { ang: number; rad: number; spin: number }; // metal: circles the caster
}

// expanding shockwave ring fx
export interface RingFx {
  x: number; y: number; r: number; vr: number;
  t: number; dur: number; color: string; w: number;
}

export interface Zone {
  kind: 'field' | 'trap' | 'aura' | 'wardPad';
  x: number; y: number; r: number;
  t: number; dur: number;
  el: ElementId; el2: ElementId | null; team: Team;
  dmg: number; tick: number; tickT: number;
  owner: Ent | null;
  follow: Ent | null;
  armed: boolean;
  potency: number;
  dead: boolean;
}

export interface BeamFx {
  x: number; y: number; ang: number; len: number; w: number;
  t: number; dur: number; color: string; color2: string;
}

export interface Telegraph {
  kind: 'circle' | 'line' | 'cone';
  x: number; y: number; ang: number; len: number; r: number; w: number;
  t: number; dur: number; color: string; team: Team;
  onDone: () => void;
  dead: boolean;
}

export interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; maxLife: number; size: number;
  color: string; grav: number; glow: boolean; shrink: boolean;
}

export interface FloatText {
  x: number; y: number; vy: number;
  t: number; dur: number;
  text: string; color: string; size: number;
}

export interface Corpse {
  x: number; y: number; sprite: string;
  t: number; flip: boolean; used: boolean;
}

export interface Pickup {
  kind: 'vial' | 'draught' | 'aether' | 'relic' | 'echo';
  x: number; y: number; vx: number; vy: number;
  t: number; amount: number; mag: boolean;
  relicId?: string;      // which relic this pickup grants (kind === 'relic')
}

export interface Stain {
  x: number; y: number; amount: number;
}

// ---------- player ----------
export interface PlayerState extends Ent {
  lvl: number; xp: number;
  mana: number; maxMana: number; manaRegenT: number;
  stam: number; maxStam: number; stamRegenT: number;
  dodgeT: number; dodgeCd: number; ddX: number; ddY: number; dashed: boolean;
  parryT: number; parryCd: number; parryFlash: number; perfectT: number;
  castCd: number; meleeCd: number; meleeT: number; potionCd: number;
  ward: { t: number; amt: number; maxAmt: number; el: ElementId } | null;
  enchant: { t: number; el: ElementId } | null;
  buffHaste: number;
  history: { x: number; y: number }[];
  activeSlot: number;
  recallT: number; recallCd: number;
  iframes: number;
  hurtCd: number;
  stunT: number;
  castAnimT: number;     // staff raise animation timer
  parryReflT: number;    // reflect flash timer
  parryHits: number;     // deflects landed during the current parry window
}

// ---------- boss ----------
export interface Boss extends Ent {
  defId: string; name: string; title: string;
  phase: number; phaseCount: number;
  state: 'intro' | 'idle' | 'windup' | 'attack' | 'recover' | 'stagger' | 'dying';
  stT: number; atkIdx: number; atkT: number; patT: number;
  pat: Record<string, number>;
  nextPat: string;
  stagger: number;
  homeX: number; homeY: number;
  hpBase: number;
}

// ---------- world ----------
export interface Decor {
  x: number; y: number; sprite: string; solid: boolean; flip: boolean;
}

export interface Chunk {
  cx: number; cy: number;
  tiles: Uint8Array;    // CHUNK*CHUNK
  solid: Uint8Array;    // derived collision
  biome: BiomeId;
  decor: Decor[];
}

export interface World {
  seed: number;
  chunks: Map<string, Chunk>;
  biomeAt: (wx: number, wy: number) => BiomeId;
  tileAt: (wx: number, wy: number) => number;
  solidAt: (wx: number, wy: number) => boolean;
  chunkAt: (cx: number, cy: number) => Chunk;
  findLand: (x: number, y: number) => { x: number; y: number };
}

// ---------- quests / bounties ----------
export type QuestKind = 'slay' | 'slayEl' | 'elite' | 'discover' | 'rest' | 'boss' | 'landmark';

export interface Quest {
  id: string;             // unique per generation
  kind: QuestKind;
  target?: string;        // enemy kind id / element id
  need: number;           // amount required
  have: number;           // progress
  title: string;          // display
  reward: number;         // aether
  xp: number;             // player xp
  done: boolean;
  claimed: boolean;
}

// ---------- progress / save ----------
export interface SchoolState { lvl: number; xp: number }
export interface SpellState { lvl: number; xp: number }

export interface Progress {
  v: number;
  seed: number;
  x: number; y: number;
  lvl: number; xp: number;
  hp: number; mana: number;
  schools: Record<string, SchoolState>;
  spells: Record<string, SpellState>;
  loadout: (string | null)[];
  slotsExtra: number;      // purchased attunement slots
  aether: number;
  vials: number; draughts: number;
  fused: string[];
  sigils: string[];
  bosses: string[];
  shrineX: number; shrineY: number;
  discovered: string[];    // shrine / arena ids seen
  kills: number; deaths: number; playtime: number;
  fusionUnlocked: boolean;
  muted: boolean;
  // --- v2 additions (guarded on load) ---
  quests: Quest[];          // 3 active bounties
  questsDone: number;
  questSeed: number;
  poiDone: string[];        // landmark ids already interacted/cleared
  elKills: Record<string, number>; // kills per element (for bounties)
  eliteKills: number;
  // --- v3: classes + skill tree (guarded on load) ---
  cls: string;                       // class id ('' = unclassed legacy save)
  points: number;                    // unspent skill points
  universal: Record<string, number>; // vit/focus/alacrity/reflex/warding/intellect ranks
  pointsEarned: number;              // lifetime (for stats)
  // --- v4: relics, echoes, ascension (guarded on load) ---
  echoes: number;                    // Echo Shards: statue rematch currency
  relics: string[];                  // owned relic ids
  equipped: (string | null)[];       // attuned relics (max 3)
  ascensions: Record<string, number>;// bossId -> highest Ascendant tier cleared
  ngPlus: number;                    // Weald Inversion count (NG+ layers)
}

// ---------- audio ----------
export type MusicTrack = 'world' | 'boss' | 'miniboss' | 'none';
export interface AudioSys {
  sfx: (name: string, pitch?: number, vol?: number) => void;
  setMuted: (m: boolean) => void;
  isMuted: () => boolean;
  setTrack: (t: MusicTrack) => void;      // crossfade world/boss music
  setMuffled: (m: boolean) => void;       // muffle music while menus are open
}

// ---------- input ----------
export type UIMode =
  | 'title' | 'play' | 'dead' | 'pause' | 'grimoire' | 'character'
  | 'map' | 'shop' | 'fusion' | 'help' | 'journal' | 'cheat' | 'skills'
  | 'statues' | 'relics';

export interface InputState {
  keys: Set<string>;
  pressed: Set<string>;     // consumed this frame
  mx: number; my: number;   // screen px (internal res)
  wx: number; wy: number;   // world px
  lmb: boolean; rmb: boolean;
  lmbPress: boolean; rmbPress: boolean;
  wheel: number;
  touch: boolean;
  // touch virtual controls
  joyX: number; joyY: number; joyActive: boolean;
  tAimX: number; tAimY: number; tCast: boolean;
  tDodge: boolean; tParry: boolean; tPotion: boolean; tInteract: boolean;
  update: () => void;       // per-frame start housekeeping
  endFrame: () => void;
  detach: () => void;
  markInteract: (v: boolean) => void;
  interactVisible: boolean;
}

// ---------- game context ----------
export interface Callbacks {
  enemyHit: (e: Enemy, dmg: number, el: ElementId, crit: boolean) => void;
  enemyDie: (e: Enemy, el: ElementId) => void;
  minionHit: (m: Minion, dmg: number, el: ElementId) => void;
  minionDie: (m: Minion) => void;
  playerHit: (dmg: number, el: ElementId | null) => void;
  bossHit: (b: Boss, dmg: number, el: ElementId, crit: boolean) => void;
  bossDie: (b: Boss) => void;
  spellCast: (def: SpellDef) => void;
  spellHit: (def: SpellDef, hits: number) => void;
  overdrive: (n: number) => void;
}

export interface GameCtx {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  W: number; H: number;   // internal render resolution
  vw: number; vh: number; // css viewport
  scale: number;          // pixel scale
  time: number;           // game time (seconds, scaled)
  frame: number;
  hitstop: number;
  slowmo: { t: number; scale: number } | null;
  cam: { x: number; y: number; shake: number; shX: number; shY: number };
  player: PlayerState;
  enemies: Enemy[]; minions: Minion[];
  bullets: Bullet[]; zones: Zone[];
  beams: BeamFx[]; teles: Telegraph[];
  rings: RingFx[];
  parts: Particle[]; texts: FloatText[];
  corpses: Corpse[]; pickups: Pickup[];
  stain: Stain | null;
  boss: Boss | null;
  spider: SpiderState | null;   // the weaver miniboss
  spiderT: number;              // seconds until the weaver may ambush
  ghosts: DashGhost[];          // dash afterimages
  kickZoom: number;             // camera zoom punch on big moments
  screenFlash: { t: number; dur: number; color: string } | null;
  // dopamine engine
  combo: { n: number; t: number };
  overdrive: number;      // remaining seconds of overdrive
  odFlash: number;        // screen flash on triggers
  corpseBonus: number;    // corpse essence consumed recently (death school)
  world: World;
  prog: Progress;
  mode: UIMode;
  uiV: number;            // bump to notify React
  banner: { title: string; sub: string; t: number; color: string } | null;
  toasts: { text: string; t: number; color: string }[];
  audio: AudioSys;
  input: InputState;
  spawnT: number; saveT: number;
  running: boolean;
  cb: Callbacks;
  sched: Array<{ t: number; fn: () => void }>;
  gate: { x: number; y: number; r: number } | null;
  interactPrompt: { x: number; y: number; text: string } | null;
  fuseAltarNear: boolean;
  shrineNear: boolean;
  poiPrompt: { x: number; y: number; text: string } | null;
  poiNear: import('./world').Landmark | null;
  hintT: number;
  mobile: boolean;          // true on phones/tablets — never on desktop
  cheat: { god: boolean; infiniteMana: boolean };
  eventT: number;           // world event timer
  realm: { bossId: string; tier: number } | null; // active Ascendant realm fight
  onUIChange?: () => void;
  destroy: () => void;
}

// ---------- math ----------
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const dist = (x1: number, y1: number, x2: number, y2: number) => Math.hypot(x2 - x1, y2 - y1);
export const dist2 = (x1: number, y1: number, x2: number, y2: number) => {
  const dx = x2 - x1, dy = y2 - y1; return dx * dx + dy * dy;
};
export const angTo = (x1: number, y1: number, x2: number, y2: number) => Math.atan2(y2 - y1, x2 - x1);
export const TAU = Math.PI * 2;

export function angDiff(a: number, b: number): number {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

export function circleHit(ax: number, ay: number, ar: number, bx: number, by: number, br: number): boolean {
  const dx = ax - bx, dy = ay - by, rr = ar + br;
  return dx * dx + dy * dy <= rr * rr;
}

// ---------- RNG / noise ----------
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const rand = (a?: number, b?: number): number => {
  if (b !== undefined) return a! + Math.random() * (b - a!);
  if (a !== undefined) return Math.random() * a;
  return Math.random();
};
export const randR = (a: number, b: number) => a + Math.random() * (b - a);
export const randi = (a: number, b: number) => Math.floor(randR(a, b + 1));
export function pick<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)]; }
export const chance = (p: number) => Math.random() < p;

export function hash2(x: number, y: number, seed: number): number {
  let h = seed ^ Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function smooth(t: number): number { return t * t * (3 - 2 * t); }

export function noise2(x: number, y: number, seed: number): number {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = smooth(xf), v = smooth(yf);
  const a = hash2(xi, yi, seed);
  const b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed);
  const d = hash2(xi + 1, yi + 1, seed);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

export function fbm2(x: number, y: number, seed: number, oct = 4): number {
  let sum = 0, amp = 0.5, freq = 1, norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += amp * noise2(x * freq, y * freq, seed + i * 1013);
    norm += amp; amp *= 0.5; freq *= 2;
  }
  return sum / norm;
}
