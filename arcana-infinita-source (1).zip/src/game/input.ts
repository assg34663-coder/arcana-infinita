/* ============================================================
   input.ts — keyboard, mouse, wheel and touch controls.
   Touch: left half = virtual joystick, right side = aim + hold
   to cast, plus action buttons drawn by the HUD.
   ============================================================ */
import type { InputState } from './core';

export function createInput(canvas: HTMLCanvasElement): InputState {
  const keys = new Set<string>();
  const pressed = new Set<string>();
  const st: InputState = {
    keys, pressed,
    mx: 0, my: 0, wx: 0, wy: 0,
    lmb: false, rmb: false, lmbPress: false, rmbPress: false,
    wheel: 0,
    touch: false,
    joyX: 0, joyY: 0, joyActive: false,
    tAimX: 0, tAimY: 0, tCast: false,
    tDodge: false, tParry: false, tPotion: false, tInteract: false,
    update: () => {},
    endFrame: () => {
      pressed.clear();
      st.lmbPress = false; st.rmbPress = false; st.wheel = 0;
      st.tDodge = false; st.tParry = false; st.tPotion = false; st.tInteract = false;
    },
    detach: () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('keyup', onKey);
      canvas.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointermove', onMove);
      canvas.removeEventListener('wheel', onWheel);
      canvas.removeEventListener('contextmenu', onCtx);
    },
    markInteract: (v: boolean) => { st.interactVisible = v; },
    interactVisible: false,
  };

  const gameKeys = new Set([
    'w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright',
    ' ', 'shift', 'e', 'r', 'q', 'f', 'v', 't', 'i', 'c', 'm', 'escape', 'p', 'u',
    '1', '2', '3', '4', '5', '6', '7', '8',
  ]);

  function onKey(e: KeyboardEvent) {
    const k = e.key.toLowerCase();
    if (gameKeys.has(k)) e.preventDefault();
    if (e.type === 'keydown') {
      if (!keys.has(k)) pressed.add(k);
      keys.add(k);
    } else {
      keys.delete(k);
    }
  }

  function toCanvas(e: PointerEvent): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  }

  // touch pointers
  const pointers = new Map<number, { kind: 'joy' | 'aim'; sx: number; sy: number }>();
  let joyId = -1, aimId = -1;
  let joyBaseX = 0, joyBaseY = 0;

  function onDown(e: PointerEvent) {
    const p = toCanvas(e);
    if (e.pointerType === 'touch') {
      st.touch = true;
      if (p.x < canvas.width * 0.42 && joyId === -1) {
        joyId = e.pointerId;
        joyBaseX = p.x; joyBaseY = p.y;
        pointers.set(e.pointerId, { kind: 'joy', sx: p.x, sy: p.y });
        st.joyActive = true; st.joyX = 0; st.joyY = 0;
      } else if (aimId === -1) {
        aimId = e.pointerId;
        pointers.set(e.pointerId, { kind: 'aim', sx: p.x, sy: p.y });
        st.tAimX = p.x; st.tAimY = p.y;
        st.mx = p.x; st.my = p.y;
        st.tCast = true;
      }
    } else {
      if (e.button === 0) { st.lmb = true; st.lmbPress = true; }
      if (e.button === 2) { st.rmb = true; st.rmbPress = true; }
      st.mx = p.x; st.my = p.y;
    }
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointermove', onMove);
  }

  function onUp(e: PointerEvent) {
    if (e.pointerType === 'touch') {
      const p = pointers.get(e.pointerId);
      if (p) {
        if (p.kind === 'joy') {
          joyId = -1; st.joyActive = false; st.joyX = 0; st.joyY = 0;
        } else {
          aimId = -1; st.tCast = false;
        }
        pointers.delete(e.pointerId);
      }
    } else {
      if (e.button === 0) st.lmb = false;
      if (e.button === 2) st.rmb = false;
    }
  }

  function onMove(e: PointerEvent) {
    const p = toCanvas(e);
    if (e.pointerType === 'touch') {
      const rec = pointers.get(e.pointerId);
      if (!rec) return;
      if (rec.kind === 'joy') {
        const dx = p.x - joyBaseX, dy = p.y - joyBaseY;
        const len = Math.hypot(dx, dy);
        const max = 34;
        if (len > 4) {
          st.joyX = (dx / Math.max(len, max)) * Math.min(1, len / max);
          st.joyY = (dy / Math.max(len, max)) * Math.min(1, len / max);
        } else { st.joyX = 0; st.joyY = 0; }
      } else {
        st.tAimX = p.x; st.tAimY = p.y;
        st.mx = p.x; st.my = p.y;
      }
    } else {
      st.mx = p.x; st.my = p.y;
    }
  }

  function onWheel(e: WheelEvent) {
    e.preventDefault();
    st.wheel += Math.sign(e.deltaY);
  }
  function onCtx(e: Event) { e.preventDefault(); }

  window.addEventListener('keydown', onKey);
  window.addEventListener('keyup', onKey);
  canvas.addEventListener('pointerdown', onDown);
  window.addEventListener('pointerup', onUp);
  window.addEventListener('pointermove', onMove);
  canvas.addEventListener('wheel', onWheel, { passive: false });
  canvas.addEventListener('contextmenu', onCtx);

  return st;
}
