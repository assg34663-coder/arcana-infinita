/* ============================================================
   bosses.ts — 8 multi-phase bullet-hell bosses. Elden-Ring
   punishment meets classic danmaku. Telegraphed patterns,
   parryable gold attacks, stagger system, arena gates.

   TASK 7-C OVERHAUL:
   A) POWER — HP x1.45 & damage x1.22 stacked ON TOP of the hard
      mode multipliers, +15-25% bullet counts/speeds everywhere,
      windups -20%, idle gaps -35%, enrage for every boss below
      35% hp (not just the Void), and TWO brand-new named
      patterns per boss (16 total).
   B) VISUALS — every boss is now a fully procedural multi-part
      composite body (no flat sprite): layered silhouettes with
      horns/crowns/halos/capes/tails per theme, dark outlines,
      glowing emissive bits, breathing/hovering idle animation
      driven by a module-level time accumulator, glowing crack
      fracture states from phase 2, an emissive aura + rising
      ember/soul particles in the final phase, and a 1.2s
      disintegration death (pixel-band dissolve, flash, rings).
   TASK 8-B OVERHAUL — TOUHOU BULLET HELL + PRESENCE + ASCENSION:
   C) DANMAKU — every pattern opens with a TELL (gathering motes + inward
      charge ring + element glint on the body, no ground circles), idle
      gaps compressed per phase, CHAINS in phase 2+ (30% chance the next
      pattern follows with only a tell between), rings 24-34 with
      half-offset weaving second rings, spirals 4-6 arms with one
      REVERSED arm, aimed fans 10-16 with per-bullet speed variance,
      2-layer scrolling-gap walls, accelerating screamers, splitter
      volleys that shatter at their predicted flight end, and EDGE
      CROSSFIRE curtains. Per-bullet damage x0.62 (DANMUL) so density
      is fun, not a one-shot; lasers/explosions/melee keep full damage.
      Enraged bosses tell faster (-0.15s) and fire +8% more often.
   D) PRESENCE — drawn at ~2.9x the pre-7c bodies (scale 1.55 on top of
      the 7-c hand-drawn ~1.9x), hitboxes only x1.15, bigger soft
      shadow, idle element aura, intro screen-dim vignette, and a death
      finale: implosion ring + element burst + arena shockwave.
      BOSS_HARD.dmg x1.5, speed 1.24.
   E) ASCENSION — spawnBossAt(G, id, x, y, { asc }) spawns an ASCENDED
      boss for statue realm fights (see statues.ts): hp x(1+0.85t),
      dmg x(1+0.3t), speed x(1+0.09t), r x1.2, +0.18/tier draw scale,
      one extra pattern slot per phase drawn from deeper pools, an
      orbiting ascension crown, and realm rewards handled inside
      finalizeBossKill.
   ============================================================ */
import {
  TAU, clamp, dist, angTo, rand, randR, chance, hash2,
  type Boss, type ElementId, type GameCtx, type Ent,
} from './core';
import { elColor, elColor2 } from './sprites';
import {
  makeBullet, burst, spawnParticle, addTelegraph, explosion, spawnZone,
  spawnPickup, addText, addBeam, addRing, screenFlash, slowmo, shake,
  damagePlayer, damageMinion,
} from './fx';
import { moveWithCollision } from './world';
import { getLocations, BOSSES, SIGILS } from './world';
import { spawnEnemy, gainXp } from './enemies';
import { checkInversion } from './statues';
import { randomUnownedRelicId } from './items';

export interface BossDef {
  id: string; name: string; title: string; sprite: string;
  hp: number; r: number; speed: number;
  el: ElementId; dmg: number; contact: number;
  sigil: string;
  thresholds: number[]; // phase transitions at hp fraction remaining
  patterns: string[][]; // per phase pattern pools
}

// after() scheduler support
export function after(G: GameCtx, delay: number, fn: () => void): void {
  G.sched.push({ t: delay, fn });
}

export function updateSched(G: GameCtx, dt: number): void {
  for (const s of G.sched) s.t -= dt;
  const due = G.sched.filter((s) => s.t <= 0);
  G.sched = G.sched.filter((s) => s.t > 0);
  for (const s of due) {
    try { s.fn(); } catch { /* ignore */ }
  }
}

// ---------- pattern helpers ----------
type BBOpt = {
  dmgMul?: number; r?: number; homing?: number; parryable?: boolean; life?: number;
  kind?: 'bolt' | 'orb' | 'shard' | 'wave' | 'gold'; el?: ElementId;
  destructible?: boolean; hp?: number; accel?: number; passWalls?: boolean; zigzag?: number;
  gravity?: number; spin?: number;
};

// DANMAKU DAMAGE RULE (Task 8-b): patterns run 2-3x denser now, so every
// pattern BULLET hits for ~62% — clipping one stings instead of one-shots.
// Explosions, lasers, zones and melee keep full damage; the graze system
// turns the density into a mana fountain instead of pure death.
const DANMUL = 0.62;

// boss damage: hard mode x Ascension tier x pattern rebate
function bdmg(b: Boss, m = 1, isDan = true): number {
  const asc = 1 + 0.3 * (b.pat.asc ?? 0);
  return BOSS_DEFS[b.defId].dmg * BOSS_HARD.dmg * asc * m * (isDan ? DANMUL : 1);
}

// bullet from an arbitrary world position (mirror clones, rifts, satellites)
function bBAt(G: GameCtx, b: Boss, x: number, y: number, ang: number, speed: number, opts: BBOpt = {}): void {
  const def = BOSS_DEFS[b.defId];
  const el = opts.el ?? def.el;
  makeBullet(G, {
    x, y,
    vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed,
    r: opts.r ?? 4,
    dmg: bdmg(b, opts.dmgMul ?? 1, opts.kind !== 'gold'),
    el, el2: null, team: 'enemy',
    life: opts.life ?? 4, kind: opts.kind === 'gold' ? 'gold' : opts.kind ?? 'bolt',
    color: opts.parryable ? '#ffd75e' : elColor(el), color2: opts.parryable ? '#fff8d8' : elColor2(el),
    parryable: opts.parryable ?? false,
    homing: opts.homing ?? 0, accel: opts.accel ?? 0,
    destructible: opts.destructible ?? false, hp: opts.hp ?? 0,
    passWalls: opts.passWalls ?? false, zigzag: opts.zigzag ?? 0,
    gravity: opts.gravity ?? 0, spin: opts.spin ?? 0,
    trail: 0.5, from: b,
  });
}

function bB(G: GameCtx, b: Boss, ang: number, speed: number, opts: BBOpt = {}): void {
  bBAt(G, b, b.x + Math.cos(ang) * (b.r + 2), b.y + Math.sin(ang) * (b.r + 2), ang, speed, opts);
}

function ring(G: GameCtx, b: Boss, n: number, speed: number, offset = 0, opts: BBOpt = {}): void {
  for (let i = 0; i < n; i++) bB(G, b, offset + (i / n) * TAU, speed, opts);
}

// DOUBLE-OFFSET RING (Task 8-b): a second ring half a step out of phase,
// a beat later, with a serpentine wobble — the classic weave-or-die gap.
function ring2(G: GameCtx, b: Boss, n: number, speed: number, offset = 0, opts: BBOpt = {}): void {
  ring(G, b, n, speed, offset, opts);
  after(G, 0.25, () => {
    if (!b.dead) {
      ring(G, b, n, speed * 0.92, offset + Math.PI / n, { ...opts, zigzag: opts.zigzag ?? 0.3 });
    }
  });
}

function aimed(G: GameCtx, b: Boss, n: number, spread: number, speed: number, opts: BBOpt = {}): void {
  aimedAt(G, b, b.x, b.y, n, spread, speed, opts);
}

// aimed volley fired from an arbitrary point (clones / rifts).
// Per-bullet speed variance (+/-12%) — fans arrive as a wall of threads
// instead of a combed grid.
function aimedAt(G: GameCtx, b: Boss, x: number, y: number, n: number, spread: number, speed: number, opts: BBOpt = {}): void {
  const a = angTo(x, y, G.player.x, G.player.y);
  for (let i = 0; i < n; i++) {
    bBAt(G, b, x, y, a + (i - (n - 1) / 2) * spread, speed * randR(0.88, 1.12), opts);
  }
}

// WALL (Task 8-b): now TWO layers with a SCROLLING gap — the second layer
// arrives a beat later, half a line-width off, its gap two slots away, so
// camping the first gap is exactly how you die to the second layer.
function wall(G: GameCtx, b: Boss, speed: number, opts: BBOpt = {}): void {
  const layer = (gap: number, off: number, spd: number): void => {
    const a = angTo(b.x, b.y, G.player.x, G.player.y);
    const px = Math.cos(a + Math.PI / 2), py = Math.sin(a + Math.PI / 2);
    for (let i = -4; i <= 4; i++) {
      if (i === gap || i === gap + 1) continue;
      bB(G, b, a, spd, { ...opts, r: 5 });
      // reposition last bullet into wall line
      const last = G.bullets[G.bullets.length - 1];
      if (last && last.team === 'enemy') {
        last.x = b.x + px * (i * 26 + off);
        last.y = b.y + py * (i * 26 + off);
      }
    }
  };
  const gap = randi2(0, 4);
  layer(gap, 0, speed);
  after(G, 0.32, () => {
    if (!b.dead) layer((gap + 2) % 5, 13, speed * 1.08);
  });
}

function rain(
  G: GameCtx, b: Boss, n: number, radius: number, dmgMul: number, spacing = 0.22, el?: ElementId,
): void {
  for (let i = 0; i < n; i++) {
    const tx = G.player.x + randR(-radius, radius);
    const ty = G.player.y + randR(-radius, radius);
    after(G, i * spacing, () => {
      addTelegraph(G, {
        kind: 'circle', x: tx, y: ty, r: 18, dur: 0.44, color: elColor(el ?? BOSS_DEFS[b.defId].el), team: 'enemy',
        onDone: () => explosion(G, tx, ty, 24, bdmg(b, dmgMul), el ?? BOSS_DEFS[b.defId].el, 'enemy', {}),
      });
    });
  }
}

function laser(G: GameCtx, b: Boss, ang: number, dmgMul = 1): void {
  const def = BOSS_DEFS[b.defId];
  const LEN = 460;
  addTelegraph(G, {
    kind: 'line', x: b.x, y: b.y, ang, len: LEN, w: 12, dur: 0.6, color: elColor(def.el), team: 'enemy',
    onDone: () => {
      addBeam(G, b.x, b.y, ang, LEN, 14, def.el, 0.3);
      G.audio.sfx('zap', 0.6);
      // damage along line
      const hitLine = (e: Ent) => {
        const t = clamp((e.x - b.x) * Math.cos(ang) + (e.y - b.y) * Math.sin(ang), 0, LEN);
        const px = b.x + Math.cos(ang) * t, py = b.y + Math.sin(ang) * t;
        if (dist(px, py, e.x, e.y) < 10 + e.r) {
          if ('mtype' in e) damageMinion(G, e as never, bdmg(b, dmgMul, false), def.el);
          else damagePlayer(G, bdmg(b, dmgMul, false), def.el);
        }
      };
      hitLine(G.player as unknown as Ent);
      for (const m of G.minions) hitLine(m);
    },
  });
}

function spiral(
  G: GameCtx, b: Boss, dur: number, arms: number, speed: number, dmgMul = 1, rot = 2.2, tick = 0.07,
): void {
  const t0 = b.patT;
  const step = (): void => {
    if (b.state !== 'attack' || b.dead) return;
    const t = b.patT - t0;
    const a0 = t * rot;
    for (let i = 0; i < arms; i++) {
      // the LAST arm winds the OPPOSITE way — crossing arcs to weave through
      const ang = i === arms - 1 ? -a0 + (i / arms) * TAU : a0 + (i / arms) * TAU;
      bB(G, b, ang, speed, { dmgMul });
    }
    if (t < dur) after(G, tick, step);
  };
  step();
}

function cross(
  G: GameCtx, b: Boss, dur: number, speed: number, arms = 4, dmgMul = 1, rot = 1.4, tick = 0.16,
): void {
  const t0 = b.patT;
  const step = (): void => {
    if (b.state !== 'attack' || b.dead) return;
    const t = b.patT - t0;
    const a0 = t * rot;
    for (let i = 0; i < arms; i++) bB(G, b, a0 + (i / arms) * TAU, speed, { dmgMul, r: 4.5 });
    if (t < dur) after(G, tick, step);
  };
  step();
}

function orbs(G: GameCtx, b: Boss, n: number, speed = 66, dmgMul = 1.2): void {
  for (let i = 0; i < n; i++) {
    const a = rand(0, TAU);
    bB(G, b, a, speed, {
      kind: 'orb', r: 8, dmgMul, destructible: true, hp: 30, homing: 1.0, life: 7,
    });
  }
}

function summonAdds(G: GameCtx, b: Boss, kind: string, n: number): void {
  for (let i = 0; i < n; i++) {
    const a = rand(0, TAU);
    spawnEnemy(G, kind, b.x + Math.cos(a) * 40, b.y + Math.sin(a) * 40, bossTier(b), 0);
  }
  burst(G, b.x, b.y, elColor(BOSS_DEFS[b.defId].el), 14, 80);
}

function goldArc(G: GameCtx, b: Boss): void {
  // parryable melee swing — the Elden Ring moment
  const a = angTo(b.x, b.y, G.player.x, G.player.y);
  addTelegraph(G, {
    kind: 'cone', x: b.x, y: b.y, ang: a, len: 70, w: 0.55, dur: 0.44, color: '#ffd75e', team: 'enemy',
    onDone: () => {
      G.audio.sfx('melee', 0.5, 1);
      for (let i = -1; i <= 1; i++) {
        bB(G, b, a + i * 0.3, 225, { parryable: true, kind: 'gold', r: 8, dmgMul: 1.4, life: 0.6, passWalls: true });
      }
    },
  });
}

function charge(G: GameCtx, b: Boss, speed = 345): void {
  const a = angTo(b.x, b.y, G.player.x, G.player.y);
  const sp = speed * BOSS_HARD.speed * (1 + 0.09 * (b.pat.asc ?? 0));
  b.vx = Math.cos(a) * sp; b.vy = Math.sin(a) * sp;
  b.pat.dashT = 0.55;
  G.audio.sfx('dodge', 0.4, 1.2);
}

function pullZone(G: GameCtx, b: Boss, x: number, y: number, r: number, dur: number): void {
  const z = spawnZone(G, { kind: 'field', x, y, r, dur, el: BOSS_DEFS[b.defId].el, team: 'enemy', dmg: bdmg(b, 0.3), tick: 0.5 });
  z.potency = 3;
}

function randi2(a: number, b: number): number {
  return Math.floor(rand(a, b + 1));
}

function bossTier(b: Boss): number {
  return clamp(1 + BOSSES.findIndex((x) => x.id === b.defId), 1, 8);
}

// ---------- NEW PATTERN MACHINERY (Task 7-c) ----------

// ARENA-EDGE CLOSING WALLS: four walls of bullets materialise around the
// player on the cardinal axes and slam inward; one random wall stays open
// (the safe quadrant). Telegraphed as full wall lines.
function convergeWalls(
  G: GameCtx, b: Boss, opts: { speed: number; kind?: 'bolt' | 'wave'; passWalls?: boolean; dmgMul?: number; el?: ElementId },
): void {
  const def = BOSS_DEFS[b.defId];
  const el = opts.el ?? def.el;
  const ba = angTo(b.x, b.y, G.player.x, G.player.y);
  const gap = randi2(0, 3); // one quadrant is always safe
  const segs = 8, spacing = 22, D = 235;
  for (let w = 0; w < 4; w++) {
    if (w === gap) continue;
    const a = ba + w * Math.PI / 2;
    const cx = G.player.x + Math.cos(a) * D, cy = G.player.y + Math.sin(a) * D;
    const pa = a + Math.PI / 2;
    addTelegraph(G, {
      kind: 'line', x: cx, y: cy, ang: pa, len: segs * spacing, w: 12, dur: 0.5, color: elColor(el), team: 'enemy',
      onDone: () => {
        if (b.dead) return;
        G.audio.sfx('melee', 0.7, 0.6);
        for (let i = 0; i < segs; i++) {
          const off = (i - (segs - 1) / 2) * spacing;
          bBAt(G, b, cx + Math.cos(pa) * off, cy + Math.sin(pa) * off, a + Math.PI, opts.speed, {
            kind: opts.kind ?? 'bolt', passWalls: opts.passWalls ?? false, dmgMul: opts.dmgMul ?? 0.9, r: 5,
          });
        }
      },
    });
  }
}

// CHAIN-DETONATING SIGILS: runes ignite one after another — each detonation
// triggers the next with only a split-second to react. Predictable, deadly.
function sigilChain(G: GameCtx, b: Boss, pts: Array<{ x: number; y: number }>, dmgMul: number, boomR: number): void {
  const def = BOSS_DEFS[b.defId];
  const step = (i: number): void => {
    if (b.dead || i >= pts.length) return;
    const p = pts[i];
    addTelegraph(G, {
      kind: 'circle', x: p.x, y: p.y, r: boomR * 0.72, dur: i === 0 ? 0.45 : 0.2, color: elColor(def.el), team: 'enemy',
      onDone: () => {
        if (b.dead) return;
        explosion(G, p.x, p.y, boomR, bdmg(b, dmgMul, false), def.el, 'enemy', {});
        G.audio.sfx('zap', 1.35, 0.5);
        step(i + 1);
      },
    });
  };
  step(0);
}

// ROTATING CROSS LASERS: telegraphed beams sweep around the boss in steps,
// overlapping into a rotating lattice of light.
function rotLasers(G: GameCtx, b: Boss, arms: number, steps: number, stepT: number, rotStep: number, dmgMul = 0.9): void {
  const base = angTo(b.x, b.y, G.player.x, G.player.y);
  const step = (k: number): void => {
    if (b.dead || k >= steps) return;
    for (let i = 0; i < arms; i++) laser(G, b, base + k * rotStep + (i / arms) * TAU, dmgMul);
    after(G, stepT, () => step(k + 1));
  };
  step(0);
}

// MIRROR CLONES THAT CAST ONCE: translucent ghost copies of the boss flare
// into being beside the player, each fires a single volley, then shatters.
interface Ghost { x: number; y: number; defId: string; t: number; dur: number; t0: number; face: number }
let GHOSTS: Ghost[] = [];
function mirrorClones(
  G: GameCtx, b: Boss, off: number, ghostDur: number, cast: (x: number, y: number) => void,
): void {
  const def = BOSS_DEFS[b.defId];
  const a = angTo(b.x, b.y, G.player.x, G.player.y);
  const pa = a + Math.PI / 2;
  for (const s of [-1, 1]) {
    const gx = G.player.x + Math.cos(pa) * off * s;
    const gy = G.player.y + Math.sin(pa) * off * s;
    GHOSTS.push({ x: gx, y: gy, defId: b.defId, t: 0, dur: ghostDur, t0: VT, face: gx >= b.x ? 1 : -1 });
    const cx = gx, cy = gy;
    addTelegraph(G, {
      kind: 'circle', x: cx, y: cy, r: 15, dur: 0.5, color: elColor(def.el), team: 'enemy',
      onDone: () => {
        if (b.dead) return;
        cast(cx, cy);
        burst(G, cx, cy, elColor(def.el), 12, 90, { glow: true });
        addRing(G, cx, cy, 5, 130, elColor(def.el), 0.3, 2);
        G.audio.sfx('blink', 1.2, 0.6);
      },
    });
  }
}

// SPLITTER VOLLEY (Task 8-b): seeds arc out, then SHATTER at the end of
// their flight — each bursts into a shard ring exactly where its flight
// WILL end (pos + v*life). Dodge the seed and you dodge into the shatter.
function splitVolley(G: GameCtx, b: Boss, n: number, speed: number, opts: BBOpt = {}): void {
  const life = opts.life ?? 1.15;
  for (let i = 0; i < n; i++) {
    const a = angTo(b.x, b.y, G.player.x, G.player.y) + randR(-0.95, 0.95);
    const sx = b.x + Math.cos(a) * (b.r + 2), sy = b.y + Math.sin(a) * (b.r + 2);
    const vx = Math.cos(a) * speed, vy = Math.sin(a) * speed;
    bBAt(G, b, sx, sy, a, speed, { ...opts, life });
    after(G, life * 0.94, () => {
      if (b.dead) return;
      const ex = sx + vx * life, ey = sy + vy * life;
      const kids = 6 + Math.floor(rand(0, 5));
      for (let k = 0; k < kids; k++) {
        bBAt(G, b, ex, ey, (k / kids) * TAU + randR(-0.08, 0.08), 118 + randR(-24, 46), { r: 3, life: 1.7 });
      }
      burst(G, ex, ey, elColor(opts.el ?? BOSS_DEFS[b.defId].el), 5, 64, { glow: true });
    });
  }
}

// EDGE CROSSFIRE (Task 8-b): curtains sweep in from four off-arena edges
// (player +/-460 on both axes), all converging inward — every edge carries
// a safe corridor and the corridors rotate between waves. passWalls keeps
// the illusion: the world itself is firing at you.
function edgeCrossfire(G: GameCtx, b: Boss, waves = 2, dmgMul = 1): void {
  const SP = 460, N = 15, SPACING = 64, GAP = 2;
  const step = (w: number): void => {
    if (b.dead || w >= waves) return;
    const base = rand(0, TAU);
    for (let e = 0; e < 4; e++) {
      const ea = base + e * Math.PI / 2;
      const ex = G.player.x + Math.cos(ea) * SP, ey = G.player.y + Math.sin(ea) * SP;
      const pa = ea + Math.PI / 2;
      const gap0 = (w * 3 + e * 2) % (N - GAP);
      for (let i = 0; i < N; i++) {
        if (i >= gap0 && i < gap0 + GAP) continue; // the safe corridor
        const off = (i - (N - 1) / 2) * SPACING;
        const bx = ex + Math.cos(pa) * off, by = ey + Math.sin(pa) * off;
        const aim = angTo(bx, by, G.player.x + randR(-30, 30), G.player.y + randR(-30, 30));
        bBAt(G, b, bx, by, aim, 150, { r: 4, dmgMul, passWalls: true, life: 7 });
      }
    }
    after(G, 1.3, () => step(w + 1));
  };
  step(0);
}

// ORBITING SATELLITES: storm motes circle the boss and snipe at the player.
function tempestOrbit(G: GameCtx, b: Boss, orbs = 4, dur = 2.8): void {
  const t0 = b.patT;
  const tick = (): void => {
    if (b.state !== 'attack' || b.dead) return;
    const t = b.patT - t0;
    if (t > dur) return;
    for (let i = 0; i < orbs; i++) {
      const a = t * 2.2 + (i / orbs) * TAU;
      const ox = b.x + Math.cos(a) * 27, oy = b.y + Math.sin(a) * 27;
      spawnParticle(G, { x: ox, y: oy, vx: 0, vy: 0, life: 0.28, size: 3.4, color: '#fff45e', glow: true });
      bBAt(G, b, ox, oy, angTo(ox, oy, G.player.x, G.player.y), 185, { dmgMul: 0.8, r: 3.5, kind: 'shard' });
    }
    after(G, 0.3, tick);
  };
  tick();
}

// HARD MODE: bosses hit harder, move faster, and don't waste time.
// Task 7-c stacked its overhaul ON TOP (never removed); Task 8-b raises
// damage again (the density rebate makes each bullet softer, so the base
// multiplier climbs to keep total pressure lethal) and speeds up:
//   hp 1.22 * 1.45 (kept) | dmg 1.18 * 1.5 | speed 1.24
export const BOSS_HARD = { hp: 1.22 * 1.45, dmg: 1.18 * 1.5, speed: 1.24 };

// ---------- boss definitions ----------
// Effective stats after multipliers (Task 8-b):
//   hp = def.hp * 1.769 | bullet dmg = def.dmg * 2.07 * 0.62 | full dmg = def.dmg * 2.07
//   ashen  1681 hp | frost  2477 | hollow  3361 | storm 4423
//   maw    5661 hp | tide   7076 | aeon    9199 | void 13268
// Hitbox radii grew only x1.15 (Task 8-b) — the BODIES are what got huge.
export const BOSS_DEFS: Record<string, BossDef> = {
  ashen: {
    id: 'ashen', name: 'Grum, the Ashen Tyrant', title: 'Tyrant of the Burning Deep', sprite: 'boss_ashen',
    hp: 950, r: 20, speed: 46, el: 'fire', dmg: 16, contact: 22, sigil: 'ashen',
    thresholds: [0.66, 0.33],
    patterns: [
      ['aimed6', 'ring14', 'meteor5', 'melee'],
      ['spiral3', 'addsImp', 'wallGap', 'ring18fast', 'meteor7', 'pyreWalls', 'splitterVolley'],
      ['chargeTrail', 'ringBurst', 'meteor7', 'spiral3fast', 'melee', 'emberSigils', 'crossfire'],
    ],
  },
  frost: {
    id: 'frost', name: 'Ylva, Queen of the Frozen Waste', title: 'Her Eternal Winter', sprite: 'boss_frost',
    hp: 1400, r: 17, speed: 52, el: 'frost', dmg: 19, contact: 24, sigil: 'frost',
    thresholds: [0.66, 0.33],
    patterns: [
      ['aimed4', 'ring18slow', 'wallGap', 'melee'],
      ['iceOrbs', 'blizzard10', 'ringIn', 'spiral2', 'mirrorIce', 'splitterVolley'],
      ['spiral4', 'blizzard12', 'iceOrbs', 'ring18fast', 'melee', 'rimeCross', 'crossfire'],
    ],
  },
  hollow: {
    id: 'hollow', name: 'The Hollow King', title: 'He Who Unmakes', sprite: 'boss_hollow',
    hp: 1900, r: 18, speed: 44, el: 'shadow', dmg: 22, contact: 26, sigil: 'hollow',
    thresholds: [0.66, 0.33],
    patterns: [
      ['homing6', 'aimed4', 'soulZone', 'melee'],
      ['addsSkel', 'laserCross', 'pullBurst', 'homing9', 'wispCourt', 'splitterVolley'],
      ['voidZones', 'ring22', 'addsWraith', 'laserCross2', 'melee', 'crownSigils', 'crossfire'],
    ],
  },
  storm: {
    id: 'storm', name: 'Tem Kaa, Stormfather', title: 'Voice of the Endless Sky', sprite: 'boss_storm',
    hp: 2500, r: 17, speed: 62, el: 'lightning', dmg: 25, contact: 26, sigil: 'storm',
    thresholds: [0.66, 0.33],
    patterns: [
      ['laserAimed', 'stormRain7', 'dashStrike', 'ring16'],
      ['cross4', 'ring20double', 'addsDjinn', 'laserAimed', 'skyfallLances', 'crossfire'],
      ['stormRain12', 'cross4fast', 'dashStrike', 'ring20double', 'melee', 'tempestOrbit', 'splitterVolley'],
    ],
  },
  maw: {
    id: 'maw', name: 'The Verdant Maw', title: 'Hunger That Grows', sprite: 'boss_maw',
    hp: 3200, r: 21, speed: 40, el: 'nature', dmg: 27, contact: 28, sigil: 'maw',
    thresholds: [0.66, 0.33],
    patterns: [
      ['rootLines', 'sporeCloud', 'aimed6', 'melee'],
      ['addsShroom', 'pollenRing', 'wallWaves', 'rootLines', 'hungerWells', 'splitterVolley'],
      ['chargeTrail2', 'sporeNova', 'pollenRing', 'aimed6', 'melee', 'thornMaze', 'crossfire'],
    ],
  },
  tide: {
    id: 'tide', name: 'Nerissa, Tide Empress', title: 'The Drowning Song', sprite: 'boss_tide',
    hp: 4000, r: 17, speed: 56, el: 'water', dmg: 29, contact: 28, sigil: 'tide',
    thresholds: [0.66, 0.33],
    patterns: [
      ['waveWalls', 'geyser7', 'homingBubbles', 'melee'],
      ['vortex', 'ring26', 'addsTide', 'waveWalls', 'mirrorTides', 'splitterVolley'],
      ['sweepWalls', 'geyser12', 'dashStrike', 'ring26', 'melee', 'tidalCross', 'crossfire'],
    ],
  },
  aeon: {
    id: 'aeon', name: 'Aeon, the Chrono Warden', title: 'Keeper of the Last Hour', sprite: 'boss_aeon',
    hp: 5200, r: 17, speed: 66, el: 'time', dmg: 31, contact: 30, sigil: 'aeon',
    thresholds: [0.66, 0.33],
    patterns: [
      ['clockSpiral', 'aimed6', 'timeField', 'melee'],
      ['echoBurst', 'cross4', 'delayedRain', 'clockSpiral', 'chronoRifts', 'crossfire'],
      ['hasteSelf', 'rain14', 'spiral4fast', 'goldRing', 'melee', 'clockHands', 'splitterVolley'],
    ],
  },
  void: {
    id: 'void', name: 'The Nameless Void', title: 'What Waits at the End', sprite: 'boss_void',
    hp: 7500, r: 22, speed: 60, el: 'void', dmg: 34, contact: 32, sigil: 'void',
    thresholds: [0.75, 0.5, 0.25],
    patterns: [
      ['blackHole', 'ring22', 'homing7', 'aimed8'],
      ['laserCross', 'doubleWall', 'addsVoid', 'spiral3', 'eventHorizon', 'splitterVolley'],
      ['rain14', 'ringDouble', 'blackHole', 'chargeTrail', 'cross4fast', 'nullSpiral', 'crossfire'],
      ['nightmare', 'spiral5fast', 'rain16', 'goldRing', 'blackHole', 'addsVoid', 'eventHorizon', 'crossfire'],
    ],
  },
};

// ASCENSION EXTRA PATTERNS: an ascended boss gains ONE extra pattern slot
// per phase. Lower phases borrow this boss's deepest list; the final phase
// steals from a sibling boss of the same elemental family (heat: ashen+maw,
// deep: frost+tide, dark: hollow+void, sky: storm+aeon) for variety.
const EL_FAMILY: Record<string, string[]> = {
  ashen: ['maw'], maw: ['ashen'], frost: ['tide'], tide: ['frost'],
  hollow: ['void'], void: ['hollow'], storm: ['aeon'], aeon: ['storm'],
};

function ascExtraPattern(defId: string, phase: number): string {
  const def = BOSS_DEFS[defId];
  const own = def.patterns[def.patterns.length - 1];
  if (phase < def.patterns.length - 1) return own[Math.floor(rand(0, own.length))];
  const sib = EL_FAMILY[defId]?.[0];
  const sibDef = sib ? BOSS_DEFS[sib] : null;
  const list = sibDef ? sibDef.patterns[sibDef.patterns.length - 1] : own;
  return list[Math.floor(rand(0, list.length))];
}

// ---------- pattern executor ----------
function executePattern(G: GameCtx, b: Boss, name: string): void {
  const def = BOSS_DEFS[b.defId];
  // ENRAGE — now for EVERY boss, and much earlier (35% hp, not just the Void's p4)
  const hpFrac = b.hp / b.maxHp;
  const enraged = hpFrac <= 0.35 || (b.defId === 'void' && b.phase >= 4);
  const sp = enraged ? 1.32 : 1.2; // bullet speed: +20% baseline, +10% more when enraged
  b.pat.dur = 1.0;
  switch (name) {
    // ---- aimed fans (Task 8-b: 10-16 wide, per-bullet speed variance,
    //      plus accelerating screamers that start slow and arrive LOUD) ----
    case 'aimed4':
      aimed(G, b, 10, 0.13, 205 * sp);
      after(G, 0.35, () => { if (!b.dead && b.state === 'attack') aimed(G, b, 4, 0.42, 60 * sp, { accel: 330, r: 3.5, life: 1.9 }); });
      b.pat.dur = 0.9; break;
    case 'aimed6':
      aimed(G, b, 13, 0.12, 225 * sp);
      after(G, 0.32, () => { if (!b.dead && b.state === 'attack') aimed(G, b, 5, 0.38, 66 * sp, { accel: 350, r: 3.5, life: 1.9 }); });
      b.pat.dur = 1.0; break;
    case 'aimed8':
      aimed(G, b, 16, 0.11, 245 * sp);
      after(G, 0.3, () => { if (!b.dead && b.state === 'attack') aimed(G, b, 6, 0.2, 150 * sp); });
      b.pat.dur = 1.05; break;
    // ---- rings (Task 8-b: 24-34, double-offset weaving second ring) ----
    case 'ring14': ring2(G, b, 24, 150, rand(0, TAU)); b.pat.dur = 0.95; break;
    case 'ring16': ring2(G, b, 26, 175, rand(0, TAU)); b.pat.dur = 0.95; break;
    case 'ring18slow': ring2(G, b, 28, 105, rand(0, TAU), { r: 4 }); b.pat.dur = 1.05; break;
    case 'ring18fast': ring2(G, b, 30, 205, rand(0, TAU)); b.pat.dur = 0.95; break;
    case 'ring20double':
      ring2(G, b, 26, 175, rand(0, TAU));
      after(G, 0.45, () => { if (!b.dead) ring2(G, b, 26, 190, rand(0, TAU)); });
      b.pat.dur = 1.4; break;
    case 'ring22': ring2(G, b, 28, 190, rand(0, TAU)); b.pat.dur = 1.0; break;
    case 'ring26': ring2(G, b, 32, 160, rand(0, TAU), { r: 4 }); b.pat.dur = 1.15; break;
    case 'ringDouble':
      ring2(G, b, 30, 190, 0);
      after(G, 0.55, () => { if (!b.dead) ring(G, b, 30, 190, Math.PI / 30, { zigzag: 0.3 }); });
      b.pat.dur = 1.4; break;
    case 'ringBurst':
      for (let k = 0; k < 3; k++) {
        after(G, k * 0.42, () => { if (!b.dead) ring2(G, b, 22, 135 + k * 55, rand(0, TAU)); });
      }
      b.pat.dur = 1.7; break;
    case 'ringIn': {
      // converging ring around player (28, with a half-step second wave)
      for (let i = 0; i < 28; i++) {
        const a = (i / 28) * TAU;
        const cx = G.player.x + Math.cos(a) * 220;
        const cy = G.player.y + Math.sin(a) * 220;
        makeBullet(G, {
          x: cx, y: cy, vx: -Math.cos(a) * 150, vy: -Math.sin(a) * 150,
          r: 4, dmg: bdmg(b, 0.85), el: def.el, el2: null, team: 'enemy', life: 2.4,
          kind: 'bolt', color: elColor(def.el), color2: elColor2(def.el), trail: 0.4, from: b,
        });
      }
      after(G, 0.5, () => {
        if (b.dead) return;
        for (let i = 0; i < 28; i++) {
          const a = ((i + 0.5) / 28) * TAU;
          const cx = G.player.x + Math.cos(a) * 240;
          const cy = G.player.y + Math.sin(a) * 240;
          makeBullet(G, {
            x: cx, y: cy, vx: -Math.cos(a) * 165, vy: -Math.sin(a) * 165,
            r: 4, dmg: bdmg(b, 0.85), el: def.el, el2: null, team: 'enemy', life: 2.4,
            kind: 'bolt', color: elColor(def.el), color2: elColor2(def.el), trail: 0.4, from: b,
          });
        }
      });
      b.pat.dur = 1.1; break;
    }
    // ---- rains (+1-2 impacts, faster cadence, -20% telegraph) ----
    case 'meteor5': rain(G, b, 5, 95, 1.1, 0.24); b.pat.dur = 1.8; break;
    case 'meteor7': rain(G, b, 7, 115, 1.1, 0.2); b.pat.dur = 2.2; break;
    case 'blizzard10': rain(G, b, 10, 115, 0.95, 0.16); b.pat.dur = 2.2; break;
    case 'blizzard12': rain(G, b, 12, 135, 0.95, 0.15); b.pat.dur = 2.4; break;
    case 'stormRain7': rain(G, b, 7, 105, 1.0, 0.16, 'lightning'); b.pat.dur = 2.0; break;
    case 'stormRain12': rain(G, b, 12, 135, 1.0, 0.13, 'lightning'); b.pat.dur = 2.4; break;
    case 'geyser7': rain(G, b, 7, 95, 1.0, 0.2); b.pat.dur = 2.0; break;
    case 'geyser12': rain(G, b, 12, 125, 1.0, 0.15); b.pat.dur = 2.6; break;
    case 'rain14': rain(G, b, 14, 145, 0.95, 0.12); b.pat.dur = 2.6; break;
    case 'rain16': rain(G, b, 16, 155, 0.95, 0.11); b.pat.dur = 2.8; break;
    case 'delayedRain': rain(G, b, 10, 145, 1.0, 0.42); b.pat.dur = 3.4; break;
    // ---- spirals & crosses (Task 8-b: 4-6 arms, one REVERSED arm) ----
    case 'spiral2': spiral(G, b, 2.0, 4, 145, 0.85, 2.3); b.pat.dur = 2.6; break;
    case 'spiral3': spiral(G, b, 2.2, 4, 155, 0.85); b.pat.dur = 2.8; break;
    case 'spiral3fast': spiral(G, b, 2.2, 5, 190, 0.85, 3.2); b.pat.dur = 2.8; break;
    case 'spiral4': spiral(G, b, 2.4, 5, 165, 0.85); b.pat.dur = 3.0; break;
    case 'spiral4fast': spiral(G, b, 2.4, 5, 205, 0.85, 3.4); b.pat.dur = 3.0; break;
    case 'spiral5fast': spiral(G, b, 2.6, 6, 210, 0.85, 3.6); b.pat.dur = 3.2; break;
    case 'clockSpiral': spiral(G, b, 2.6, 3, 180, 0.85, 4.6, 0.05); b.pat.dur = 3.0; break;
    case 'cross4': cross(G, b, 2.2, 180, 4, 0.9, 1.7, 0.13); b.pat.dur = 2.8; break;
    case 'cross4fast': cross(G, b, 2.2, 215, 4, 0.9, 2.4, 0.1); b.pat.dur = 2.8; break;
    // ---- lasers (+1-2 beams, tighter cadence, -20% telegraph) ----
    case 'laserAimed': laser(G, b, angTo(b.x, b.y, G.player.x, G.player.y)); b.pat.dur = 1.3; break;
    case 'laserCross':
      for (let i = 0; i < 5; i++) after(G, i * 0.15, () => { if (!b.dead) laser(G, b, angTo(b.x, b.y, G.player.x, G.player.y) + i * Math.PI / 10); });
      b.pat.dur = 2.2; break;
    case 'laserCross2':
      for (let i = 0; i < 7; i++) after(G, i * 0.13, () => { if (!b.dead) laser(G, b, angTo(b.x, b.y, G.player.x, G.player.y) + i * Math.PI / 14); });
      b.pat.dur = 2.6; break;
    // ---- walls (faster) ----
    case 'wallGap': wall(G, b, 135 * sp); b.pat.dur = 1.2; break;
    case 'doubleWall':
      wall(G, b, 135); after(G, 0.6, () => { if (!b.dead) wall(G, b, 150); });
      b.pat.dur = 1.6; break;
    // 'wallWaves' (the Maw) keeps its original case; the Tide's pool name
    // 'waveWalls' previously had NO case (silently fell through to a plain
    // aimed shot) — now it is a real wave-wall pattern of its own.
    case 'waveWalls':
      for (let k = 0; k < 3; k++) after(G, k * 0.6, () => { if (!b.dead) wall(G, b, 140, { kind: 'wave', passWalls: true, r: 6 }); });
      b.pat.dur = 2.4; break;
    case 'wallWaves':
      for (let k = 0; k < 3; k++) after(G, k * 0.7, () => { if (!b.dead) wall(G, b, 125, { kind: 'wave', passWalls: true }); });
      b.pat.dur = 2.6; break;
    case 'sweepWalls':
      for (let k = 0; k < 4; k++) after(G, k * 0.5, () => { if (!b.dead) wall(G, b, 150, { kind: 'wave', passWalls: true }); });
      b.pat.dur = 2.6; break;
    // ---- homing (Task 8-b: fatter salvoes) ----
    case 'homing6': for (let i = 0; i < 8; i++) bB(G, b, rand(0, TAU), 115, { homing: 1.7, kind: 'orb', r: 5, life: 3.5 }); b.pat.dur = 1.2; break;
    case 'homing7': for (let i = 0; i < 9; i++) bB(G, b, rand(0, TAU), 120, { homing: 1.9, kind: 'orb', r: 5, life: 3.5 }); b.pat.dur = 1.2; break;
    case 'homing9': for (let i = 0; i < 12; i++) bB(G, b, rand(0, TAU), 135, { homing: 2.1, kind: 'orb', r: 5, life: 3.5 }); b.pat.dur = 1.3; break;
    case 'homingBubbles': for (let i = 0; i < 10; i++) bB(G, b, rand(0, TAU), 100, { homing: 1.5, kind: 'orb', r: 6, life: 4, zigzag: 0.6 }); b.pat.dur = 1.3; break;
    case 'iceOrbs': orbs(G, b, 6); b.pat.dur = 1.4; break;
    case 'pollenRing':
      ring2(G, b, 24, 95, rand(0, TAU), { r: 3.5, el: 'nature' });
      b.pat.dur = 1.6; break;
    case 'rootLines': {
      for (let i = 0; i < 4; i++) {
        after(G, i * 0.32, () => {
          if (b.dead) return;
          const a = angTo(b.x, b.y, G.player.x, G.player.y) + randR(-0.3, 0.3);
          const tx = G.player.x, ty = G.player.y;
          addTelegraph(G, {
            kind: 'line', x: tx, y: ty - 60, ang: Math.PI / 2, len: 70, w: 14, dur: 0.5, color: '#6ab354', team: 'enemy',
            onDone: () => explosion(G, tx, ty, 26, bdmg(b, 1.15), 'nature', 'enemy', {}),
          });
        });
      }
      b.pat.dur = 2.0; break;
    }
    case 'sporeCloud':
      spawnZone(G, { kind: 'field', x: G.player.x, y: G.player.y, r: 70, dur: 5, el: 'poison', team: 'enemy', dmg: bdmg(b, 0.3), tick: 0.5 });
      b.pat.dur = 1.0; break;
    case 'sporeNova':
      ring(G, b, 30, 140, rand(0, TAU), { el: 'poison', r: 4 });
      spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 90, dur: 3, el: 'poison', team: 'enemy', dmg: bdmg(b, 0.25), tick: 0.5 });
      b.pat.dur = 1.4; break;
    case 'soulZone':
      pullZone(G, b, G.player.x, G.player.y, 55, 3);
      after(G, 2.6, () => { if (!b.dead) explosion(G, G.player.x, G.player.y, 40, bdmg(b, 1.25), 'shadow', 'enemy', {}); });
      b.pat.dur = 2.4; break;
    case 'voidZones':
      for (let i = 0; i < 4; i++) {
        after(G, i * 0.45, () => {
          if (b.dead) return;
          pullZone(G, b, G.player.x + randR(-60, 60), G.player.y + randR(-60, 60), 48, 2.2);
        });
      }
      b.pat.dur = 2.6; break;
    case 'blackHole':
      pullZone(G, b, G.player.x, G.player.y, 70, 3.5);
      after(G, 3.2, () => { if (!b.dead) { ring(G, b, 26, 195, 0); } });
      b.pat.dur = 3.6; break;
    case 'vortex':
      pullZone(G, b, b.x, b.y, 110, 3);
      after(G, 0.6, () => { if (!b.dead) ring(G, b, 24, 130, 0); });
      b.pat.dur = 3.2; break;
    case 'timeField':
      spawnZone(G, { kind: 'field', x: G.player.x, y: G.player.y, r: 55, dur: 4, el: 'time', team: 'enemy', dmg: bdmg(b, 0.2), tick: 0.6 });
      after(G, 1.2, () => { if (!b.dead && b.state === 'attack') aimed(G, b, 8, 0.14, 235); });
      b.pat.dur = 2.0; break;
    case 'echoBurst': {
      for (let k = 0; k < 4; k++) {
        after(G, k * 0.28, () => { if (!b.dead) aimed(G, b, 3, 0.5, 175, { dmgMul: 0.8 }); });
      }
      b.pat.dur = 1.6; break;
    }
    case 'goldRing':
      ring(G, b, 14, 165, rand(0, TAU), { parryable: true, kind: 'gold', r: 7 });
      b.pat.dur = 1.2; break;
    case 'goldArc': goldArc(G, b); b.pat.dur = 1.2; break;
    case 'melee': goldArc(G, b); after(G, 0.9, () => { if (!b.dead && chance(0.5)) aimed(G, b, 4, 0.2, 185); }); b.pat.dur = 1.6; break;
    case 'dashStrike': charge(G, b, 380); b.pat.dur = 1.1; break;
    case 'charge': charge(G, b, 345); b.pat.dur = 1.1; break;
    case 'chargeTrail':
      charge(G, b, 345);
      for (let k = 0; k < 7; k++) {
        after(G, 0.08 + k * 0.09, () => {
          if (b.dead) return;
          spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 24, dur: 2.2, el: def.el, team: 'enemy', dmg: bdmg(b, 0.35), tick: 0.4 });
        });
      }
      b.pat.dur = 1.3; break;
    case 'chargeTrail2':
      charge(G, b, 320);
      for (let k = 0; k < 7; k++) {
        after(G, 0.08 + k * 0.1, () => {
          if (b.dead) return;
          spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 26, dur: 2.2, el: 'nature', team: 'enemy', dmg: bdmg(b, 0.3), tick: 0.4 });
        });
      }
      b.pat.dur = 1.3; break;
    case 'addsImp': summonAdds(G, b, 'imp', 2); b.pat.dur = 1.2; break;
    case 'addsSkel': summonAdds(G, b, 'skel', 3); b.pat.dur = 1.4; break;
    case 'addsWraith': summonAdds(G, b, 'wraith', 2); b.pat.dur = 1.2; break;
    case 'addsDjinn': summonAdds(G, b, 'djinn', 1); b.pat.dur = 1.2; break;
    case 'addsShroom': summonAdds(G, b, 'shroom', 3); b.pat.dur = 1.4; break;
    case 'addsTide': summonAdds(G, b, 'fsprite', 2); b.pat.dur = 1.2; break;
    case 'addsVoid': summonAdds(G, b, 'tendril', 1); summonAdds(G, b, 'cultist', 2); b.pat.dur = 1.6; break;
    case 'hasteSelf':
      b.st.haste = { t: 4, mult: 1.6 };
      b.st.stun = undefined;
      burst(G, b.x, b.y, '#e8c05e', 16, 90);
      b.pat.dur = 0.8; break;
    case 'nightmare':
      ring2(G, b, 30, 175, 0, { r: 4 });
      after(G, 0.4, () => { if (!b.dead && b.state === 'attack') aimed(G, b, 10, 0.12, 245); });
      after(G, 0.85, () => { if (!b.dead && b.state === 'attack') ring(G, b, 30, 175, Math.PI / 30, { r: 4, zigzag: 0.3 }); });
      b.pat.dur = 2.1; break;
    // was referenced by the Hollow King's pool but never had a case — now real:
    // pull burst: three gravity snags around the player, then a punishing ring
    case 'pullBurst': {
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * TAU + rand(0, TAU);
        pullZone(G, b, G.player.x + Math.cos(a) * 55, G.player.y + Math.sin(a) * 55, 42, 1.8);
      }
      after(G, 0.7, () => { if (!b.dead) ring(G, b, 18, 150, rand(0, TAU)); });
      b.pat.dur = 1.8; break;
    }
    /* ================= TASK 8-B: DANMAKU PRESSURE PATTERNS ================= */
    // EDGE CROSSFIRE: four off-arena curtains converge on you, safe
    // corridors rotating between waves — the world itself opens fire
    case 'crossfire':
      edgeCrossfire(G, b, 2);
      b.pat.dur = 3.3; break;
    // SPLITTER VOLLEY: seeds shatter into shard rings at their flight's end
    case 'splitterVolley':
      splitVolley(G, b, 7, 190, { life: 1.2, r: 4.5, passWalls: true });
      b.pat.dur = 2.5; break;

    // GRUM — "PYRE WALLS": arena-edge walls of fire close in from four sides
    case 'pyreWalls':
      convergeWalls(G, b, { speed: 135, dmgMul: 0.9 });
      after(G, 1.1, () => { if (!b.dead) convergeWalls(G, b, { speed: 150, dmgMul: 0.9 }); });
      b.pat.dur = 2.4; break;
    // GRUM — "EMBER SIGILS": a chain of burning runes detonates across the ground
    case 'emberSigils': {
      const la = rand(0, TAU);
      const pts: Array<{ x: number; y: number }> = [];
      for (let i = -2; i <= 2; i++) pts.push({ x: G.player.x + Math.cos(la) * i * 36, y: G.player.y + Math.sin(la) * i * 36 });
      sigilChain(G, b, pts, 1.0, 30);
      b.pat.dur = 0.8; break;
    }
    // YLVA — "MIRROR FROST": two ice reflections flank you and each casts once
    case 'mirrorIce':
      mirrorClones(G, b, 95, 1.7, (cx, cy) => aimedAt(G, b, cx, cy, 4, 0.2, 165, { kind: 'shard', dmgMul: 0.9 }));
      b.pat.dur = 1.4; break;
    // YLVA — "RIME CROSS": a rotating cross of frost lasers sweeps the arena
    case 'rimeCross':
      rotLasers(G, b, 4, 5, 0.16, Math.PI / 4, 0.9);
      b.pat.dur = 2.5; break;
    // THE HOLLOW KING — "WISP COURT": six slow will-o-wisps that refuse to lose you
    case 'wispCourt':
      for (let i = 0; i < 6; i++) {
        bB(G, b, rand(0, TAU), 75, { homing: 1.15, kind: 'orb', r: 5.5, life: 4.6, dmgMul: 0.9 });
        spawnParticle(G, { x: b.x + randR(-10, 10), y: b.y + randR(-10, 10), vy: -18, life: 0.5, size: 2, color: '#b89ad4', glow: true });
      }
      b.pat.dur = 1.3; break;
    // THE HOLLOW KING — "CROWN OF SKULLS": eight sigils ring the player and chain-detonate
    case 'crownSigils': {
      const pts: Array<{ x: number; y: number }> = [];
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU;
        pts.push({ x: G.player.x + Math.cos(a) * 70, y: G.player.y + Math.sin(a) * 70 });
      }
      sigilChain(G, b, pts, 0.95, 27);
      b.pat.dur = 0.8; break;
    }
    // TEM KAA — "SKYFALL LANCES": vertical lightning columns chase your position
    case 'skyfallLances':
      for (let i = 0; i < 6; i++) {
        after(G, i * 0.22, () => {
          if (b.dead) return;
          const tx = G.player.x, ty = G.player.y;
          addTelegraph(G, {
            kind: 'circle', x: tx, y: ty, r: 16, dur: 0.4, color: '#fff45e', team: 'enemy',
            onDone: () => {
              if (b.dead) return;
              addBeam(G, tx, ty - 210, Math.PI / 2, 230, 9, 'lightning', 0.25);
              G.audio.sfx('thunder', randR(0.9, 1.2), 0.6);
              explosion(G, tx, ty, 22, bdmg(b, 0.95), 'lightning', 'enemy', {});
            },
          });
        });
      }
      b.pat.dur = 2.4; break;
    // TEM KAA — "TEMPEST SATELLITES": four storm motes orbit the boss, sniping
    case 'tempestOrbit':
      tempestOrbit(G, b, 4, 2.8);
      b.pat.dur = 3.0; break;
    // THE VERDANT MAW — "GRAVITY OF HUNGER": two hunger wells drag you together
    // while the Maw exhales a pollen ring — pick your poison
    case 'hungerWells':
      pullZone(G, b, G.player.x - 70, G.player.y, 46, 2.6);
      pullZone(G, b, G.player.x + 70, G.player.y, 46, 2.6);
      after(G, 1.4, () => { if (!b.dead) ring(G, b, 20, 115, rand(0, TAU), { el: 'nature', r: 3.5 }); });
      b.pat.dur = 2.2; break;
    // THE VERDANT MAW — "THORN MAZE": four walls of thorns close in from the dark
    case 'thornMaze':
      convergeWalls(G, b, { speed: 125, kind: 'wave', passWalls: true, dmgMul: 0.85, el: 'nature' });
      after(G, 1.1, () => { if (!b.dead) convergeWalls(G, b, { speed: 140, kind: 'wave', passWalls: true, dmgMul: 0.85, el: 'nature' }); });
      b.pat.dur = 2.4; break;
    // NERISSA — "MIRROR TIDES": two water reflections each hurl one wave wall
    case 'mirrorTides':
      mirrorClones(G, b, 110, 1.9, (cx, cy) => {
        const a = angTo(cx, cy, G.player.x, G.player.y);
        const pa = a + Math.PI / 2;
        for (let i = -2; i <= 2; i++) {
          const off = i * 20;
          bBAt(G, b, cx + Math.cos(pa) * off, cy + Math.sin(pa) * off, a, 140, { kind: 'wave', passWalls: true, dmgMul: 0.85, r: 5 });
        }
      });
      b.pat.dur = 1.5; break;
    // NERISSA — "TIDAL CROSS": a counter-rotating cross of water lasers
    case 'tidalCross':
      rotLasers(G, b, 4, 5, 0.16, -Math.PI / 4, 0.9);
      b.pat.dur = 2.5; break;
    // AEON — "CHRONO RIFTS": three time rifts open around you and each fires
    case 'chronoRifts': {
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * TAU + rand(0, TAU);
        const rx = G.player.x + Math.cos(a) * 115, ry = G.player.y + Math.sin(a) * 115;
        addTelegraph(G, {
          kind: 'circle', x: rx, y: ry, r: 14, dur: 0.55, color: '#5ee8d8', team: 'enemy',
          onDone: () => {
            if (b.dead) return;
            burst(G, rx, ry, '#5ee8d8', 10, 85, { glow: true });
            addRing(G, rx, ry, 4, 130, '#5ee8d8', 0.3, 2);
            G.audio.sfx('blink', 0.8, 0.7);
            after(G, 0.12, () => { if (!b.dead) aimedAt(G, b, rx, ry, 3, 0.22, 200, { dmgMul: 0.9 }); });
          },
        });
      }
      b.pat.dur = 1.6; break;
    }
    // AEON — "THE HOUR HANDS": two giant laser hands sweep the arena like a clock
    case 'clockHands':
      rotLasers(G, b, 2, 6, 0.14, Math.PI / 6, 0.95);
      b.pat.dur = 2.7; break;
    // THE NAMELESS VOID — "EVENT HORIZON": a gravity well that spaghettifies —
    // a spiral that reverses direction mid-spin while everything is dragged in
    case 'eventHorizon': {
      pullZone(G, b, b.x, b.y, 130, 4);
      const t0 = b.patT;
      const step = (): void => {
        if (b.state !== 'attack' || b.dead) return;
        const t = b.patT - t0;
        const dir = Math.floor(t / 0.9) % 2 === 0 ? 1 : -1;
        for (let i = 0; i < 5; i++) bB(G, b, t * 2.6 * dir + (i / 5) * TAU, 150, { dmgMul: 0.85, r: 4 });
        if (t < 2.8) after(G, 0.09, step);
      };
      step();
      after(G, 3.4, () => { if (!b.dead) ring(G, b, 26, 200, 0); });
      b.pat.dur = 3.9; break;
    }
    // THE NAMELESS VOID — "NULL SPIRAL": two spirals winding in OPPOSITE directions
    case 'nullSpiral':
      spiral(G, b, 2.2, 4, 165, 0.85, 2.6, 0.08);
      spiral(G, b, 2.2, 4, 165, 0.85, -2.6, 0.08);
      b.pat.dur = 2.8; break;
    default: aimed(G, b, 4, 0.16, 200); break;
  }
}

// ---------- lifecycle ----------
// ---------- TELLS, NOT TELEGRAPHS (Task 8-b) ----------
// Every pattern opens with a short GATHERING TELL instead of a floor circle:
// motes stream into the boss, an inward charge ring collapses, the body
// glints element-bright, a low warp note rises. You read the BOSS, not the
// floor. Ground telegraphs remain only for lasers / rains / melee arcs.
function tellDur(b: Boss): number {
  const hpFrac = b.hp / b.maxHp;
  const enraged = hpFrac <= 0.35 || (b.defId === 'void' && b.phase >= 4);
  const base = b.phase === 0 ? 0.55 : b.phase === 1 ? 0.48 : 0.42;
  return Math.max(0.28, base - (enraged ? 0.15 : 0)); // enrage: -0.15s tells
}

function tell(G: GameCtx, b: Boss): void {
  const def = BOSS_DEFS[b.defId];
  const haste = b.st.haste ? 1.5 : 1;
  const t = tellDur(b);
  b.state = 'windup';
  b.stT = t / haste;
  b.pat.tellT = t; // drawBoss consumes this for the gathering glint
  addRing(G, b.x, b.y, 20 + b.r, -74, elColor(def.el), t * 0.9, 1.5);
  addRing(G, b.x, b.y - 6, 13 + b.r, -48, '#ffffff', t * 0.8, 1);
  G.audio.sfx('blink', 0.55, 0.42);
}

// spawn a boss DIRECTLY at a world position (statue realm fights use this;
// tryStartBoss calls it for arena triggers). opts.asc tiers it into an
// ASCENDED boss: hp x(1+0.85t), dmg x(1+0.3t) (via bdmg), speed x(1+0.09t),
// r x1.2, bigger draw scale, +1 pattern slot per phase, ascension crown.
export function spawnBossAt(G: GameCtx, id: string, x: number, y: number, opts: { asc?: number } = {}): Boss | null {
  const def = BOSS_DEFS[id];
  if (!def) return null;
  const asc = Math.max(0, Math.floor(opts.asc ?? 0));
  const hp = def.hp * BOSS_HARD.hp * (1 + 0.85 * asc);
  const b: Boss = {
    x, y, vx: 0, vy: 0, r: def.r * (asc > 0 ? 1.2 : 1),
    hp, maxHp: hp, team: 'enemy', st: {},
    flash: 0, dead: false, deadT: 0, face: 1, anim: 0,
    defId: def.id, name: asc > 0 ? `ASCENDED ${def.name}` : def.name, title: def.title,
    phase: 0, phaseCount: def.thresholds.length + 1,
    state: 'intro', stT: 1.5, atkIdx: 0, atkT: 0, patT: 0,
    pat: asc > 0 ? { asc } : {}, nextPat: 'aimed4', stagger: 0,
    homeX: x, homeY: y,
    hpBase: def.hp,
  };
  G.boss = b;
  if (asc > 0) {
    G.banner = { title: `ASCENDED ${def.name.toUpperCase()}`, sub: `Ascension ${asc} — ${def.title}`, t: 0, color: elColor(def.el) };
  }
  G.audio.sfx('roar');
  shake(G, 4);
  slowmo(G, 0.5, 0.3);
  G.uiV++;
  return b;
}

export function tryStartBoss(G: GameCtx): void {
  if (G.boss || G.mode !== 'play') return;
  for (const loc of getLocations()) {
    if (loc.kind !== 'boss' || !loc.bossId) continue;
    if (G.prog.bosses.includes(loc.bossId)) continue;
    if (dist(G.player.x, G.player.y, loc.x, loc.y) < loc.r - 20) {
      const def = BOSS_DEFS[loc.bossId];
      spawnBossAt(G, loc.bossId, loc.x, loc.y - 40);
      // gate ring sits OUTSIDE the arena walls (arenas.ts rw ≈ loc.r + 24)
      G.gate = { x: loc.x, y: loc.y, r: loc.r + 46 };
      if (!G.prog.discovered.includes(loc.id)) G.prog.discovered.push(loc.id);
      G.banner = { title: def.name, sub: `THE ${def.title.toUpperCase()}`, t: 0, color: elColor(def.el) };
      return;
    }
  }
}

// rising ember/soul particle color per element (final-phase aura)
const AURA_COLORS: Partial<Record<ElementId, string>> = {
  fire: '#ff8a3e', frost: '#cfeefc', shadow: '#b89ad4', lightning: '#fff45e',
  nature: '#a8e06a', water: '#8ad4de', time: '#5ee8d8', void: '#e85eff',
};

export function updateBoss(G: GameCtx, dt: number): void {
  const b = G.boss;
  if (!b) return;
  const def = BOSS_DEFS[b.defId];
  b.anim += dt;
  b.flash = Math.max(0, b.flash - dt);
  if (b.st.haste) { b.st.haste.t -= dt; if (b.st.haste.t <= 0) delete b.st.haste; }
  const hasteMul = b.st.haste ? 1.5 : 1;

  // statuses
  if (b.st.chill) { b.st.chill.t -= dt; if (b.st.chill.t <= 0) delete b.st.chill; }
  if (b.st.root) { b.st.root.t -= dt; if (b.st.root.t <= 0) delete b.st.root; }
  if (b.st.frozen) {
    // FROZEN boss: locked in ice — free real estate for a shatter
    b.st.frozen.t -= dt;
    if (b.st.frozen.t <= 0) { delete b.st.frozen; burst(G, b.x, b.y, '#cfeefc', 10, 80, { glow: true }); }
    if (b.state === 'attack') { b.state = 'recover'; b.stT = 0.4; }
    b.vx *= 0.85; b.vy *= 0.85;
    const mvF = moveWithCollision(G.world, b.x, b.y, b.vx, b.vy, b.r, dt, true);
    b.x = mvF.x; b.y = mvF.y;
    return;
  }

  // TELL glow timer (drawBoss reads b.pat.tellT for the gathering glint)
  if ((b.pat.tellT ?? 0) > 0) b.pat.tellT = Math.max(0, (b.pat.tellT ?? 0) - dt);

  // ENRAGE: every boss below 35% hp (the Void also keeps its phase-4 enrage).
  // Tells shorten (-0.15s) and fire rate climbs (+8%) on top of the bullets.
  const hpFrac = b.hp / b.maxHp;
  const enraged = hpFrac <= 0.35 || (b.defId === 'void' && b.phase >= 4);

  switch (b.state) {
    case 'intro':
      b.stT -= dt;
      if (b.stT <= 0) { b.state = 'idle'; b.stT = 0.3; }
      break;
    case 'idle': {
      b.stT -= dt;
      // PRESSURE (Task 8-b): the boss always closes — drift toward/past the
      // player with a lateral sway, never park at range
      const d = dist(b.x, b.y, G.player.x, G.player.y);
      const a = angTo(b.x, b.y, G.player.x, G.player.y);
      const want = 112;
      const dir = d > want ? 1 : -0.55;
      const sway = Math.sin(G.time * 1.9) * 0.45;
      const aggro = enraged ? 1.5 : 1;
      const ascSp = 1 + 0.09 * (b.pat.asc ?? 0);
      const dx = Math.cos(a) + Math.cos(a + Math.PI / 2) * sway;
      const dy = Math.sin(a) + Math.sin(a + Math.PI / 2) * sway;
      b.vx += dx * def.speed * BOSS_HARD.speed * dir * dt * 3 * aggro * ascSp;
      b.vy += dy * def.speed * BOSS_HARD.speed * dir * dt * 3 * aggro * ascSp;
      if (b.stT <= 0) {
        // pick the pattern, then open the TELL — the windup IS the tell now
        const base = def.patterns[Math.min(b.phase, def.patterns.length - 1)];
        const asc = b.pat.asc ?? 0;
        const idx = b.atkIdx % (base.length + (asc > 0 ? 1 : 0));
        b.nextPat = idx < base.length ? base[idx] : ascExtraPattern(b.defId, b.phase);
        b.atkIdx++;
        b.pat.chained = 0;
        tell(G, b);
      }
      break;
    }
    case 'windup':
      b.stT -= dt;
      b.vx *= 0.8; b.vy *= 0.8;
      // gathering motes stream INTO the emission points (eyes / hands / crown)
      if (G.frame % 3 === 0) {
        const c = elColor(def.el);
        for (let i = 0; i < 2; i++) {
          const ga = rand(0, TAU), rr = 15 + rand(0, 11);
          spawnParticle(G, {
            x: b.x + Math.cos(ga) * rr, y: b.y + Math.sin(ga) * rr * 0.8 - 5,
            vx: -Math.cos(ga) * 52, vy: -Math.sin(ga) * 52,
            life: 0.32, size: randR(1.4, 2.6),
            color: chance(0.3) ? '#ffffff' : c, glow: true,
          });
        }
      }
      if (b.stT <= 0) {
        b.state = 'attack'; b.patT = 0;
        executePattern(G, b, b.nextPat || 'aimed4');
      }
      break;
    case 'attack': {
      b.patT += dt;
      if (b.pat.dashT !== undefined && b.pat.dashT > 0) {
        b.pat.dashT -= dt;
        // dash trail particles
        if (G.frame % 3 === 0) spawnParticle(G, { x: b.x, y: b.y, vx: randR(-20, 20), vy: randR(-20, 20), life: 0.4, size: 3, color: elColor(def.el), glow: true });
      } else {
        // slight drift while attacking
        b.vx *= 1 - 2 * dt; b.vy *= 1 - 2 * dt;
      }
      if (b.patT >= (b.pat.dur ?? 1)) {
        // CHAIN (Task 8-b): phase 2+ flows — 30% of patterns roll straight
        // into another one with only a tell between. The Weald never blinks.
        if (b.phase >= 1 && !b.pat.chained && chance(0.3)) {
          b.pat.chained = 1;
          const base = def.patterns[Math.min(b.phase, def.patterns.length - 1)];
          let np = base[Math.floor(rand(0, base.length))];
          if (np === b.nextPat && base.length > 1) np = base[(base.indexOf(np) + 1) % base.length];
          if ((b.pat.asc ?? 0) > 0 && chance(0.35)) np = ascExtraPattern(b.defId, b.phase);
          b.nextPat = np;
          b.atkIdx++;
          tell(G, b);
        } else {
          b.state = 'recover'; b.stT = 0.24 / hasteMul;
        }
      }
      break;
    }
    case 'recover': {
      b.stT -= dt;
      b.vx *= 0.9; b.vy *= 0.9;
      // keep drifting through recovery — closing distance is pressure
      const ra = angTo(b.x, b.y, G.player.x, G.player.y);
      const rd = dist(b.x, b.y, G.player.x, G.player.y);
      const rdir = rd > 96 ? 0.55 : -0.3;
      b.vx += Math.cos(ra) * def.speed * BOSS_HARD.speed * rdir * dt * 2.6;
      b.vy += Math.sin(ra) * def.speed * BOSS_HARD.speed * rdir * dt * 2.6;
      // idle gap compressed per phase (0.3 / 0.18 / 0.10); enrage fires +8% faster
      if (b.stT <= 0) {
        const gap = b.phase === 0 ? 0.3 : b.phase === 1 ? 0.18 : 0.1;
        b.state = 'idle';
        b.stT = gap * (enraged ? 0.92 : 1) / hasteMul;
      }
      break;
    }
    case 'stagger':
      b.stT -= dt;
      if (b.stT <= 0) {
        b.state = 'idle'; b.stT = 0.3; b.stagger = 0;
      }
      break;
    case 'dying': {
      // 1.2s DISINTEGRATION: flash + double ring, pixel-band dissolve handled
      // in drawBoss, body burning away into rising embers, then cleanup.
      b.stT += dt;
      if (!b.pat.dBoom) {
        b.pat.dBoom = 1;
        GHOSTS = [];
        addRing(G, b.x, b.y, 6, 280, elColor(def.el), 0.5, 3);
        addRing(G, b.x, b.y, 3, 200, '#ffffff', 0.35, 2);
        screenFlash(G, elColor(def.el), 0.35);
        G.audio.sfx('boom', 0.55, 1);
        shake(G, 5);
        slowmo(G, 0.6, 0.3);
      }
      if (b.stT < 1.05) {
        const c = AURA_COLORS[def.el] ?? elColor(def.el);
        for (let i = 0; i < 3; i++) {
          const a = rand(0, TAU), rr = rand(0, b.r + 8);
          spawnParticle(G, {
            x: b.x + Math.cos(a) * rr, y: b.y + Math.sin(a) * rr * 0.8,
            vx: randR(-14, 14), vy: randR(-64, -20),
            life: randR(0.4, 0.95), size: randR(1.5, 3.4),
            color: chance(0.3) ? '#ffffff' : c, glow: true,
          });
        }
        if (G.frame % 10 === 0) {
          explosion(G, b.x + randR(-20, 20), b.y + randR(-18, 18), randR(10, 20), 0, def.el, 'enemy', { noDmg: true });
        }
      }
      // FINAL IMPLOSION (Task 8-b): the body collapses inward, then the
      // whole arena answers — element burst + white shockwave + shake
      if (!b.pat.dFin && b.stT >= 1.05) {
        b.pat.dFin = 1;
        addRing(G, b.x, b.y, 34, -330, elColor(def.el), 0.42, 3);
        addRing(G, b.x, b.y, 6, 470, '#ffffff', 0.7, 4);
        addRing(G, b.x, b.y, 4, 330, elColor(def.el), 0.95, 2.5);
        burst(G, b.x, b.y, elColor(def.el), 46, 220, { glow: true });
        burst(G, b.x, b.y, '#ffffff', 18, 150, { glow: true });
        explosion(G, b.x, b.y, 30, 0, def.el, 'enemy', { noDmg: true });
        screenFlash(G, '#ffffff', 0.3);
        shake(G, 5);
        G.audio.sfx('boom', 0.7, 0.8);
        G.audio.sfx('grand', 0.9, 0.5);
      }
      if (b.stT >= 1.2) {
        finalizeBossKill(G, b);
      }
      return;
    }
  }

  // phase transitions
  if (b.phase < def.thresholds.length) {
    const frac = b.hp / b.maxHp;
    if (frac <= def.thresholds[b.phase]) {
      b.phase++;
      b.state = 'recover'; b.stT = 1.2;
      ring(G, b, 26, 150, 0, { r: 4.5 });
      addRing(G, b.x, b.y, 8, 210, elColor(def.el), 0.45, 2.5);
      screenFlash(G, elColor(def.el), 0.22);
      G.banner = { title: `PHASE ${b.phase + 1}`, sub: def.name, t: 0, color: elColor(def.el) };
      G.audio.sfx('roar', 1.3, 0.8);
      shake(G, 3);
      burst(G, b.x, b.y, elColor(def.el), 26, 140);
    }
  }

  // stagger decay
  if (b.state !== 'stagger') b.stagger = Math.max(0, b.stagger - dt * 4);

  // contact damage
  const p = G.player;
  if (!p.dead && b.state !== 'intro') {
    const d = dist(b.x, b.y, p.x, p.y);
    if (d < b.r + p.r && (b.pat.contactT ?? 0) <= 0) {
      b.pat.contactT = 0.9;
      damagePlayer(G, def.contact * BOSS_HARD.dmg, def.el, { melee: true, from: b });
      const a2 = angTo(b.x, b.y, p.x, p.y);
      p.vx += Math.cos(a2) * 160; p.vy += Math.sin(a2) * 160;
    }
    b.pat.contactT = Math.max(0, (b.pat.contactT ?? 0) - dt);
  }

  // integrate
  const chill = b.st.chill?.mult ?? 1;
  b.vx *= 1 - clamp(4 * dt, 0, 0.9);
  b.vy *= 1 - clamp(4 * dt, 0, 0.9);
  const mv = moveWithCollision(G.world, b.x, b.y, b.vx * chill, b.vy * chill, b.r, dt, true);
  b.x = mv.x; b.y = mv.y;
  if (Math.abs(b.vx) > 4) b.face = b.vx > 0 ? 1 : -1;

  // FINAL-PHASE AURA: rising ember/soul particles + pulsing enrage ring
  const finalPhase = b.phase >= def.thresholds.length;
  if (!b.dead && (finalPhase || enraged)) {
    const c = AURA_COLORS[def.el] ?? elColor(def.el);
    if (G.frame % (enraged ? 2 : 3) === 0) {
      spawnParticle(G, {
        x: b.x + randR(-16, 16), y: b.y + randR(-4, 16),
        vx: randR(-9, 9), vy: randR(-54, -24),
        life: randR(0.45, 0.95), size: randR(1.4, 3),
        color: G.frame % 6 === 0 ? '#ffffff' : c, glow: true,
      });
    }
    if (enraged && G.frame % 26 === 0) {
      addRing(G, b.x, b.y, b.r + 4, 95, elColor(def.el), 0.5, 1.5);
    }
  }
}

export function bossTakesDamage(G: GameCtx, b: Boss, dmg: number): number {
  // returns adjusted damage (stagger bonus); called from fx.damageBoss
  void G;
  let d = dmg;
  const bb = b as Boss;
  if (bb.state === 'stagger') d *= 1.5;
  return d;
}

export function parryBossHit(G: GameCtx, b: Boss): void {
  b.stagger += 14;
  G.audio.sfx('stagger', 1.2, 0.8);
  burst(G, b.x, b.y, '#ffd75e', 12, 110);
  if (b.stagger >= 100 && b.state !== 'stagger' && b.state !== 'dying' && b.state !== 'intro') {
    b.state = 'stagger'; b.stT = 3.4;
    addText(G, b.x, b.y - 24, 'STAGGERED!', '#ffd75e', 9, true);
    G.audio.sfx('roar', 1.8, 0.6);
    // reward: aether shower
    for (let i = 0; i < 5; i++) spawnPickup(G, 'aether', b.x + randR(-20, 20), b.y + randR(-20, 20), 3 + bossTier(b) * 2);
    shake(G, 3);
  }
}

// ECHO SHARDS (Task 8-b): statue rematch currency — collectible crystals.
// statues.ts updateStatues owns the pickup scan; the effigy ring sits
// around the spawn shrine.
function pushEcho(G: GameCtx, x: number, y: number, n: number): void {
  for (let i = 0; i < n; i++) {
    const a = rand(0, TAU);
    G.pickups.push({
      kind: 'echo', x, y,
      vx: Math.cos(a) * randR(24, 66), vy: Math.sin(a) * randR(24, 66) - 24,
      t: 0, amount: 1, mag: false,
    });
  }
}

function finalizeBossKill(G: GameCtx, b: Boss): void {
  const def = BOSS_DEFS[b.defId];
  b.dead = true;
  G.boss = null;
  G.gate = null;
  GHOSTS = [];
  if (!G.prog.bosses.includes(def.id)) {
    G.prog.bosses.push(def.id);
    G.prog.sigils.push(def.sigil);
  }
  // rewards
  gainXp(G, 180 * (bossTier(b) + 1));
  G.prog.aether += 60 * bossTier(b);
  for (let i = 0; i < 10 + bossTier(b) * 2; i++) {
    spawnPickup(G, 'aether', b.x + randR(-40, 40), b.y + randR(-40, 40), 4 + bossTier(b));
  }
  if (chance(1)) spawnPickup(G, 'vial', b.x + randR(-30, 30), b.y + randR(-30, 30));
  if (chance(1)) spawnPickup(G, 'draught', b.x + randR(-30, 30), b.y + randR(-30, 30));
  if (G.realm) {
    // ---- ASCENDED REALM VICTORY (the effigy ring in statues.ts) ----
    const tier = G.realm.tier;
    G.realm = null;
    // +2 net profit: they paid `tier` to enter — grant tier + 2 as shards
    pushEcho(G, b.x, b.y, tier + 2);
    G.prog.aether += 300 + 220 * tier;
    gainXp(G, 200 + 130 * tier);
    G.prog.ascensions[def.id] = Math.max(G.prog.ascensions[def.id] ?? 0, tier);
    if (tier >= 2) {
      const rid = randomUnownedRelicId(G);
      if (rid) {
        G.pickups.push({
          kind: 'relic', x: b.x, y: b.y - 8,
          vx: randR(-18, 18), vy: -34, t: 0, amount: 1, mag: false, relicId: rid,
        });
      }
    }
    G.banner = {
      title: `ASCENDED ${def.name.toUpperCase()} FALLS`,
      sub: `Ascension ${tier} cleared — the realm closes.`,
      t: 0, color: elColor(def.el),
    };
    // NG+ LAYERS: a full 8-boss sweep at ever-higher tiers inverts the Weald
    checkInversion(G);
  } else {
    // first-kill bounty: Echo Shards to fund statue rematches
    pushEcho(G, b.x, b.y, 1 + Math.floor(bossTier(b) / 2));
    if (!G.prog.fusionUnlocked) {
      G.prog.fusionUnlocked = true;
      G.banner = { title: 'FUSION UNLOCKED', sub: 'Combine spells at Fusion Altars', t: 0, color: '#c95ee8' };
    } else {
      G.banner = { title: 'VANQUISHED', sub: `${def.name} falls. ${SIGILS[def.sigil]?.name} acquired.`, t: 0, color: '#ffd75e' };
    }
  }
  G.audio.sfx('die');
  G.audio.sfx('levelup');
  slowmo(G, 1.2, 0.2);
  shake(G, 5);
  G.uiV++;
  // milestone save: never lose a boss kill
  try {
    const p = G.player;
    G.prog.x = p.x; G.prog.y = p.y;
    G.prog.hp = p.hp; G.prog.mana = p.mana;
    localStorage.setItem('arcana_infinita_save_v1', JSON.stringify(G.prog));
  } catch { /* ignore */ }
}

/* ============================================================
   RENDERING — fully procedural multi-part composite bodies.
   Every boss is drawn in code: layered pixel silhouettes with
   dark outlines, emissive glow bits, idle breathing/hover/sway,
   phase-2 glowing fracture cracks, final-phase aura, and the
   1.2s disintegration. All coordinates integer-snapped.
   Animation is driven by the module-level accumulator VT.
   ============================================================ */

type C2D = CanvasRenderingContext2D;

let VT = 0;          // module-level visual time accumulator (seconds)
let VLAST = -1;      // last performance.now() stamp

// 1x1 "pixel" rect, integer-snapped, centered on (x, y)
function px(ctx: C2D, x: number, y: number, w: number, h: number, col: string): void {
  ctx.fillStyle = col;
  ctx.fillRect(Math.round(x) - (w >> 1), Math.round(y) - (h >> 1), w, h);
}

// pixel-ish ellipse with optional 1px dark outline
function blob(ctx: C2D, x: number, y: number, rx: number, ry: number, col: string, out?: string): void {
  if (out) {
    ctx.fillStyle = out;
    ctx.beginPath();
    ctx.ellipse(Math.round(x), Math.round(y), rx + 1, ry + 1, 0, 0, TAU);
    ctx.fill();
  }
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.ellipse(Math.round(x), Math.round(y), rx, ry, 0, 0, TAU);
  ctx.fill();
}

// pixel limb: a run of small rects along a segment (spider.ts quality bar)
function limb(ctx: C2D, x1: number, y1: number, x2: number, y2: number, col: string, w = 2): void {
  const d = Math.hypot(x2 - x1, y2 - y1);
  const n = Math.max(1, Math.ceil(d / 1.7));
  const o = (w - 1) >> 1;
  ctx.fillStyle = col;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    ctx.fillRect(Math.round(x1 + (x2 - x1) * t) - o, Math.round(y1 + (y2 - y1) * t) - o, w, w);
  }
}

// filled polygon with optional 1px outline (horns, crowns, spikes, shards)
function shape(ctx: C2D, pts: Array<[number, number]>, col: string, out?: string): void {
  const path = (dx: number, dy: number): void => {
    ctx.beginPath();
    ctx.moveTo(Math.round(pts[0][0] + dx), Math.round(pts[0][1] + dy));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(Math.round(pts[i][0] + dx), Math.round(pts[i][1] + dy));
    ctx.closePath();
    ctx.fill();
  };
  if (out) {
    ctx.fillStyle = out;
    path(1, 0); path(-1, 0); path(0, 1); path(0, -1);
  }
  ctx.fillStyle = col;
  path(0, 0);
}

// additive emissive glow: soft halo + hot core
function glow(ctx: C2D, x: number, y: number, r: number, col: string, a = 1): void {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = col;
  ctx.globalAlpha = 0.3 * a;
  ctx.beginPath(); ctx.arc(Math.round(x), Math.round(y), r * 2.4, 0, TAU); ctx.fill();
  ctx.globalAlpha = 0.85 * a;
  ctx.beginPath(); ctx.arc(Math.round(x), Math.round(y), r, 0, TAU); ctx.fill();
  ctx.restore();
}

interface VisDef {
  hover: boolean; // true = floats (hover bob), false = grounded (breathing bob)
  draw: (ctx: C2D, b: Boss, t: number) => void;
}

const BOSS_VIS: Record<string, VisDef> = {
  /* ------------------------------------------------------------
     GRUM, THE ASHEN TYRANT — a hulking horned brute of a tyrant:
     wide shoulders, huge curved bone horns, a lava-cracked chest
     plate, massive fists, a flame crest that flickers, ember eyes.
     ------------------------------------------------------------ */
  ashen: {
    hover: false,
    draw(ctx, b, t) {
      const HIDE = '#4a2618', HIDE2 = '#6b3a22', PLATE = '#8e2f1e', PLATE2 = '#b04a26';
      const EMBER = '#ff8a3e', CORE = '#ffd75e', OUT = '#20100a', BONE = '#cfc0a8';
      const ph = b.phase, wind = b.state === 'windup';
      const br = Math.sin(t * 2.2) * 1.1; // breathing
      const stomp = Math.sin(t * 5.2) * 1.6; // weight shift
      // legs
      limb(ctx, -6, 8 + br, -7 + stomp, 17, OUT, 4);
      blob(ctx, -7 + stomp, 18, 4, 2.5, HIDE, OUT);
      limb(ctx, 6, 8 + br, 7 - stomp, 17, OUT, 4);
      blob(ctx, 7 - stomp, 18, 4, 2.5, HIDE, OUT);
      // smoke cape behind the shoulder
      blob(ctx, -10 + Math.sin(t * 1.3) * 2, 2 + br, 7, 9, '#31201a', OUT);
      // torso + chest plate
      blob(ctx, 0, 2 + br, 13, 11, HIDE, OUT);
      blob(ctx, 1, 3 + br, 8.5, 7, PLATE, OUT);
      // lava cracks (glow faster with each phase)
      const ck = clamp(0.55 + 0.35 * Math.sin(t * (3 + ph * 1.4)), 0, 1);
      ctx.save();
      ctx.globalAlpha = ck;
      limb(ctx, -4, 1 + br, -1, 4 + br, EMBER, 1);
      limb(ctx, -1, 4 + br, 2, 2 + br, EMBER, 1);
      limb(ctx, 3, 6 + br, 5, 2 + br, EMBER, 1);
      limb(ctx, 5, 2 + br, 8, 4 + br, EMBER, 1);
      if (ph >= 1) {
        limb(ctx, -2, -2 + br, 1, -5 + br, EMBER, 1);
        limb(ctx, 6, -1 + br, 9, -3 + br, '#ffb35e', 1);
      }
      ctx.restore();
      // shoulders (shatter jitter at phase 2+)
      const sh = ph >= 1 ? Math.sin(t * 7) * 0.8 : 0;
      blob(ctx, -11, -5 + br + sh, 5.5, 4.5, PLATE2, OUT);
      blob(ctx, 11, -5 + br - sh, 5.5, 4.5, PLATE2, OUT);
      // arms + fists
      const sw = Math.sin(t * 2.6) * 2;
      limb(ctx, -13, -3 + br, -16, 6 + br + sw, OUT, 3);
      blob(ctx, -16, 8 + br + sw, 4.5, 4, HIDE2, OUT);
      limb(ctx, 13, -3 + br, 16, 6 + br - sw, OUT, 3);
      blob(ctx, 16, 8 + br - sw, 4.5, 4, HIDE2, OUT);
      if (wind) { glow(ctx, 16, 8 + br - sw, 3, EMBER, 0.9); glow(ctx, -16, 8 + br + sw, 3, EMBER, 0.9); }
      // head
      blob(ctx, 1, -9 + br, 6.5, 5.5, HIDE2, OUT);
      blob(ctx, 1, -7.5 + br, 4.5, 3, '#3a1c10');
      // huge curved horns
      for (const s of [-1, 1]) {
        limb(ctx, 1 + s * 4, -13 + br, 1 + s * 8, -18 + br, BONE, 3);
        limb(ctx, 1 + s * 8, -18 + br, 1 + s * 13, -21 + br, BONE, 2);
        px(ctx, 1 + s * 14, -22 + br, 2, 2, OUT);
      }
      // flame crest
      for (let i = -1; i <= 1; i++) {
        const fh = 3 + Math.abs(Math.sin(t * 9 + i * 2)) * 3;
        shape(ctx, [[1 + i * 3 - 1.5, -13.5 + br], [1 + i * 3 + 1.5, -13.5 + br], [1 + i * 3, -13.5 - fh + br]], Math.sin(t * 11) > -0.6 ? EMBER : CORE);
      }
      // ember eyes
      const eg = 0.7 + 0.3 * Math.sin(t * 4.4);
      glow(ctx, -1.5, -9.5 + br, 1.4, CORE, eg);
      glow(ctx, 4, -9.5 + br, 1.4, CORE, eg);
    },
  },

  /* ------------------------------------------------------------
     YLVA, FROST QUEEN — a slender floating iceling: tapering
     gown of ice, a crown of three crystal spikes, flowing hair,
     a glowing scepter, three shards orbiting her.
     ------------------------------------------------------------ */
  frost: {
    hover: true,
    draw(ctx, b, t) {
      const GOWN = '#c6ecf6', GOWN2 = '#8ec8dc', DEEP = '#5a9ab4', ICE = '#eafafd';
      const GEM = '#7ce8ff', OUT = '#16323e', HAIR = '#9adcec';
      const ph = b.phase, wind = b.state === 'windup';
      const hv = Math.sin(t * 1.7) * 2.2;
      const sway = Math.sin(t * 1.3) * 2;
      // orbiting shards (behind)
      for (let i = 0; i < 3; i++) {
        const a = t * (0.9 + ph * 0.25) + i * (TAU / 3);
        const sx = Math.cos(a) * 20, sy = Math.sin(a) * 7 - 2 + hv;
        shape(ctx, [[sx, sy - 3], [sx + 2, sy], [sx, sy + 3], [sx - 2, sy]], ICE, OUT);
        if (ph >= 1) glow(ctx, sx, sy, 1.2, GEM, 0.7);
      }
      // gown (tapering stack)
      blob(ctx, sway * 0.4, 2 + hv, 10, 9, GOWN, OUT);
      blob(ctx, sway * 0.6, 8 + hv, 8, 7, GOWN2, OUT);
      blob(ctx, sway * 0.8, 13.5 + hv, 5.5, 5, DEEP, OUT);
      blob(ctx, sway, 17.5 + hv, 3, 3.5, OUT);
      limb(ctx, -3 + sway * 0.5, 3 + hv, -2 + sway * 0.7, 9 + hv, ICE, 1);
      // left arm
      const asw = Math.sin(t * 1.9) * 1.5;
      limb(ctx, -6, -3 + hv, -11, 2 + hv + asw, OUT, 2);
      blob(ctx, -11.5, 3 + hv + asw, 2, 2, GOWN2, OUT);
      // scepter arm + staff
      limb(ctx, 6, -3 + hv, 11, 1 + hv - asw, OUT, 2);
      limb(ctx, 11, 2 + hv - asw, 13, -13 + hv - asw, OUT, 2);
      blob(ctx, 13, -15 + hv - asw, 2.4, 2.8, GEM, OUT);
      if (wind || ph >= 1) glow(ctx, 13, -15 + hv - asw, 2.2, GEM, wind ? 1 : 0.6);
      // hair strands
      for (let i = 0; i < 4; i++) {
        const s2 = i < 2 ? -1 : 1;
        const k = i % 2;
        const hx = s2 * 4, hy = -11 + hv;
        const mx = s2 * (7 + k * 2), my = -6 + hv + Math.sin(t * 2 + i) * 1.5;
        const ex = s2 * (5 + k * 3) + Math.sin(t * 1.5 + i * 1.8) * 2, ey = -1 + hv + k * 3;
        limb(ctx, hx, hy, mx, my, HAIR, 2);
        limb(ctx, mx, my, ex, ey, HAIR, 2);
      }
      // head
      blob(ctx, 0, -11 + hv, 5.2, 5, ICE, OUT);
      blob(ctx, 1.5, -10.5 + hv, 3.4, 3.2, GOWN);
      // crown of ice spikes
      shape(ctx, [[-4, -14 + hv], [-2.6, -14 + hv], [-3.4, -20 + hv]], GEM, OUT);
      shape(ctx, [[-1, -15 + hv], [1, -15 + hv], [0, -22 + hv]], GEM, OUT);
      shape(ctx, [[2.6, -14 + hv], [4, -14 + hv], [3.4, -19 + hv]], GEM, OUT);
      // eyes
      const eg = 0.7 + 0.3 * Math.sin(t * 3.7);
      glow(ctx, -1.8, -11 + hv, 1.1, GEM, eg);
      glow(ctx, 2.6, -11 + hv, 1.1, GEM, eg);
      // ice-fracture cracks at phase 2+
      if (ph >= 1) {
        ctx.save();
        ctx.globalAlpha = 0.5 + 0.3 * Math.sin(t * 4);
        limb(ctx, -5, 0 + hv, -2, 4 + hv, GEM, 1);
        limb(ctx, -2, 4 + hv, 2, 2 + hv, GEM, 1);
        limb(ctx, 4, 8 + hv, 6, 12 + hv, GEM, 1);
        ctx.restore();
      }
    },
  },

  /* ------------------------------------------------------------
     THE HOLLOW KING — a floating skull-lord: an oversized crowned
     skull over a tattered cloak, glowing eye sockets, skeletal
     clawed arms, soul wisps orbiting at phase 2+.
     ------------------------------------------------------------ */
  hollow: {
    hover: true,
    draw(ctx, b, t) {
      const BONE = '#d8d3c0', BONE2 = '#a8a290', CLOAK = '#241c30', CLOAK2 = '#352a48';
      const EYE = '#7ce8ff', OUT = '#0c0812', IRON = '#4a4050';
      const ph = b.phase, wind = b.state === 'windup';
      const hv = Math.sin(t * 1.5) * 2.4;
      void wind;
      // cloak
      blob(ctx, 0, 5 + hv, 12, 10, CLOAK, OUT);
      // tattered hem
      for (let i = -2; i <= 2; i++) {
        const tx = i * 4.6;
        const len = 5 + ((i + 7) % 3) * 2.5 + Math.sin(t * 2.2 + i * 1.4) * 1.4;
        shape(ctx, [[tx - 2, 11 + hv], [tx + 2, 11 + hv], [tx + Math.sin(t * 2.4 + i) * 1.2, 11 + len + hv]], i % 2 ? CLOAK : CLOAK2, OUT);
      }
      limb(ctx, -5, 0 + hv, -6, 8 + hv, CLOAK2, 2);
      limb(ctx, 6, 1 + hv, 7, 9 + hv, CLOAK2, 2);
      // skeletal arms + claws
      const sw = Math.sin(t * 1.8) * 2;
      for (const s of [-1, 1]) {
        limb(ctx, s * 7, -2 + hv, s * 12, 5 + hv + s * sw, BONE2, 2);
        for (let f = -1; f <= 1; f++) limb(ctx, s * 12, 5 + hv + s * sw, s * 14, 7 + hv + s * sw + f * 2, BONE2, 1);
      }
      // skull — bigger than the body, the signature silhouette
      blob(ctx, 0, -8 + hv, 9.5, 8.5, BONE, OUT);
      blob(ctx, 0, -4 + hv, 6.5, 4, BONE);
      blob(ctx, -6, -6 + hv, 2, 2.6, BONE2);
      blob(ctx, 6, -6 + hv, 2, 2.6, BONE2);
      // eye sockets + glow pupils
      blob(ctx, -3.6, -9 + hv, 2.6, 3, OUT);
      blob(ctx, 3.6, -9 + hv, 2.6, 3, OUT);
      const eg = 0.65 + 0.35 * Math.sin(t * 3.2);
      glow(ctx, -3.6, -9 + hv, 1.3, EYE, eg);
      glow(ctx, 3.6, -9 + hv, 1.3, EYE, eg);
      // nasal slit + teeth
      px(ctx, 0, -6 + hv, 1, 2, OUT);
      for (let i = -2; i <= 2; i++) px(ctx, Math.round(i * 2.2), -3.4 + hv, 1, 2, i % 2 ? BONE2 : BONE);
      // iron crown (cracks glow at phase 2+)
      limb(ctx, -5, -15 + hv, -5, -19 + hv, IRON, 2);
      limb(ctx, 0, -16 + hv, 0, -21 + hv, IRON, 2);
      limb(ctx, 5, -15 + hv, 5, -19 + hv, IRON, 2);
      limb(ctx, -6, -15 + hv, 6, -15 + hv, IRON, 2);
      glow(ctx, 0, -21.5 + hv, 1.1, EYE, 0.7);
      if (ph >= 1) {
        ctx.save();
        ctx.globalAlpha = 0.6;
        limb(ctx, -2, -19 + hv, 0, -17 + hv, EYE, 1);
        limb(ctx, 2, -18.5 + hv, 4, -16.5 + hv, EYE, 1);
        ctx.restore();
      }
      // orbiting soul wisps at phase 2+
      if (ph >= 1) {
        const n = 2 + ph;
        for (let i = 0; i < n; i++) {
          const a = t * 1.4 + i * (TAU / n);
          glow(ctx, Math.cos(a) * 17, Math.sin(a) * 6 - 4 + hv, 1.5, EYE, 0.8);
        }
      }
    },
  },

  /* ------------------------------------------------------------
     TEM KAA, STORMFATHER — a living thundercloud djinn: bumpy
     cloud mass, spinning tornado tail, jagged lightning horns,
     orbiting spark motes with trails, electric eyes.
     ------------------------------------------------------------ */
  storm: {
    hover: true,
    draw(ctx, b, t) {
      const CL = '#5e9ab8', CL2 = '#7fb6d4', CD = '#3f6e8a', SPK = '#fff45e', SPK2 = '#ffd75e', OUT = '#142433';
      const ph = b.phase, wind = b.state === 'windup';
      const hv = Math.sin(t * 2.0) * 2.4;
      // tornado tail (spinning funnel)
      for (let i = 0; i < 3; i++) {
        const off = Math.sin(t * 7 + i * 2.1) * (1.5 + i * 0.5);
        blob(ctx, off, 7 + i * 4.5 + hv, 6.5 - i * 1.8, 3.4 - i * 0.5, i % 2 ? CD : CL, OUT);
      }
      const da = t * 6;
      px(ctx, Math.cos(da) * 5, 16 + hv + Math.sin(da) * 1.5, 2, 1, CL2);
      // cloud body (bumpy mass)
      blob(ctx, -8, -3 + hv, 7, 5.5, CD, OUT);
      blob(ctx, 8, -3 + hv, 7, 5.5, CD, OUT);
      blob(ctx, -4, -7 + hv, 6, 5, CL, OUT);
      blob(ctx, 5, -7 + hv, 6, 5, CL, OUT);
      blob(ctx, 0, -1 + hv, 11, 7.5, CL, OUT);
      blob(ctx, 0, -5 + hv, 7, 5, CL2);
      // cloud nub arms
      const sw = Math.sin(t * 2.4) * 2;
      blob(ctx, -13, 1 + hv + sw, 3.5, 3, CL2, OUT);
      blob(ctx, 13, 1 + hv - sw, 3.5, 3, CL2, OUT);
      if (wind) { glow(ctx, -13, 1 + hv + sw, 2.4, SPK, 1); glow(ctx, 13, 1 + hv - sw, 2.4, SPK, 1); }
      // lightning bolt horns (flicker)
      const flick = Math.sin(t * 13 + ph) > -0.4;
      for (const s of [-1, 1]) {
        ctx.save();
        ctx.globalAlpha = flick ? 1 : 0.35;
        limb(ctx, s * 3, -11 + hv, s * 6, -15 + hv, SPK, 2);
        limb(ctx, s * 6, -15 + hv, s * 4, -18 + hv, SPK, 2);
        limb(ctx, s * 4, -18 + hv, s * 7, -22 + hv, SPK, 2);
        ctx.restore();
      }
      // eyes
      const eg = 0.7 + 0.3 * Math.sin(t * 6.1);
      glow(ctx, -3, -3 + hv, 1.4, SPK, eg);
      glow(ctx, 3, -3 + hv, 1.4, SPK, eg);
      limb(ctx, -2, 1 + hv, 2, 1 + hv, OUT, 1);
      // orbiting spark motes with trails
      const n = 3 + ph;
      for (let i = 0; i < n; i++) {
        const a = t * (2.2 + ph * 0.4) + i * (TAU / n);
        const mx = Math.cos(a) * 19, my = Math.sin(a) * 8 - 2 + hv;
        glow(ctx, mx, my, 1.4, i % 2 ? SPK : SPK2, 0.9);
        limb(ctx, mx, my, Math.cos(a - 0.35) * 19, Math.sin(a - 0.35) * 8 - 2 + hv, SPK2, 1);
      }
    },
  },

  /* ------------------------------------------------------------
     THE VERDANT MAW — a carnivorous plant horror: chomping jaw
     with teeth, leaf collar, root legs, three swaying thorned
     vines, a cluster of three sap-glow eyes.
     ------------------------------------------------------------ */
  maw: {
    hover: false,
    draw(ctx, b, t) {
      const LEAF = '#6ab354', LEAF2 = '#4e8e3a', VINE = '#3a6e2c', MAW = '#3a1220';
      const TOOTH = '#e8e4c8', SAP = '#d8ff5e', OUT = '#16240e';
      const ph = b.phase, wind = b.state === 'windup';
      const br = Math.sin(t * 2.0) * 1.2;
      const chomp = (Math.sin(t * 2.3) * 0.5 + 0.5) * 2.2 + (wind ? 2.5 : 0);
      // root legs
      for (const s of [-1, 0, 1]) {
        limb(ctx, s * 5, 12 + br, s * 12, 19, OUT, 3);
        px(ctx, s * 13, 19.6, 3, 1, OUT);
      }
      // vines behind (sway, thorned tips)
      for (let i = 0; i < 3; i++) {
        const s = i - 1;
        const x1 = s * 9, y1 = 4 + br;
        const x2 = s * 15 + Math.sin(t * 1.8 + i * 2) * 3, y2 = 10 + br + i;
        const x3 = s * 17 + Math.sin(t * 1.5 + i * 2.4) * 5, y3 = 2 + br - i * 5;
        limb(ctx, x1, y1, x2, y2, VINE, 2);
        limb(ctx, x2, y2, x3, y3, VINE, 2);
        px(ctx, x3, y3, 2, 2, SAP);
        if (wind) glow(ctx, x3, y3, 1.6, SAP, 0.9);
      }
      // body bulb
      blob(ctx, 0, 4 + br, 12, 10, LEAF2, OUT);
      blob(ctx, -3, 2 + br, 7, 6, LEAF);
      // leaf collar fan
      for (let i = 0; i < 5; i++) {
        const a = Math.PI + (i / 4) * Math.PI;
        blob(ctx, Math.cos(a) * 10, -2 + br + Math.sin(a) * 4, 4.5, 2, i % 2 ? LEAF : LEAF2, OUT);
      }
      // jaws + maw interior
      const uj = -8 - chomp * 0.6 + br;
      blob(ctx, 0, uj, 9.5, 5, LEAF, OUT);
      blob(ctx, 0, -2 + chomp * 0.4 + br, 8.5, 4, LEAF2, OUT);
      blob(ctx, 0, -4.5 + br, 6.8, 2.6 + chomp * 0.3, MAW);
      for (let i = -2; i <= 2; i++) {
        px(ctx, i * 2.6 + 1, uj + 3.6, 1, 2, TOOTH);
        px(ctx, i * 2.6, -4.6 + chomp * 0.4 + br, 1, 2, TOOTH);
      }
      // eye cluster
      const eg = 0.7 + 0.3 * Math.sin(t * 3.9);
      glow(ctx, 4, uj - 2, 1.2, SAP, eg);
      glow(ctx, 7.5, uj - 0.5, 1.1, SAP, eg * 0.9);
      glow(ctx, 1.5, uj - 3.5, 1, SAP, eg * 0.8);
      // spore cracks at phase 2+
      if (ph >= 1) {
        ctx.save();
        ctx.globalAlpha = 0.55 + 0.3 * Math.sin(t * 3.4);
        limb(ctx, -6, 6 + br, -3, 9 + br, SAP, 1);
        limb(ctx, -3, 9 + br, 0, 7 + br, SAP, 1);
        limb(ctx, 5, 9 + br, 8, 11 + br, SAP, 1);
        ctx.restore();
      }
    },
  },

  /* ------------------------------------------------------------
     NERISSA, TIDE EMPRESS — a deep-sea siren: serpent coils below,
     flowing hair strands, a gold crown, a trident, pearl glow.
     ------------------------------------------------------------ */
  tide: {
    hover: true,
    draw(ctx, b, t) {
      const SKIN = '#8ad4de', FIN = '#5eb8c9', FID = '#3a8a9e', HAIR = '#1e4a5a';
      const PEARL = '#eaf8fa', GOLD = '#ffd75e', CORAL = '#ff8a8a', OUT = '#0c222e';
      const ph = b.phase, wind = b.state === 'windup';
      const hv = Math.sin(t * 1.6) * 2.4;
      // serpent coils
      for (let i = 0; i < 3; i++) {
        const off = Math.sin(t * 1.8 + i * 2.2) * 2.4;
        blob(ctx, off, 12 + i * 4 + hv * 0.4, 12 - i * 2, 3.2, i % 2 ? FID : FIN, OUT);
        for (let k = -2; k <= 2; k++) px(ctx, off + k * 4, 9.6 + i * 4 + hv * 0.4, 1, 2, i % 2 ? SKIN : FID);
      }
      // torso + pearl glow
      blob(ctx, 0, -1 + hv, 8, 8.5, SKIN, OUT);
      glow(ctx, 1, 0 + hv, 1.6, PEARL, 0.7 + 0.3 * Math.sin(t * 2.5));
      // hair strands
      for (let i = 0; i < 5; i++) {
        const s = i < 2 ? -1 : i < 4 ? 1 : 0;
        const len = 13 + (i % 3) * 4;
        const x1 = s * 4, y1 = -12 + hv;
        const x2 = s * (8 + (i % 2) * 2) + Math.sin(t * 2 + i * 1.7) * 2, y2 = -7 + hv + len * 0.35;
        const x3 = s * (7 + (i % 2) * 4) + Math.sin(t * 1.6 + i * 2.1) * 3.5, y3 = -4 + hv + len * 0.75;
        const col = i === 4 ? HAIR : i % 2 ? FID : FIN;
        limb(ctx, x1, y1, x2, y2, col, 2);
        limb(ctx, x2, y2, x3, y3, col, 2);
      }
      // head + gold crown
      blob(ctx, 0, -11 + hv, 5.6, 5.4, SKIN, OUT);
      limb(ctx, -4, -15 + hv, -4, -18 + hv, GOLD, 2);
      limb(ctx, 0, -16 + hv, 0, -20 + hv, GOLD, 2);
      limb(ctx, 4, -15 + hv, 4, -18 + hv, GOLD, 2);
      limb(ctx, -5, -15 + hv, 5, -15 + hv, GOLD, 2);
      glow(ctx, 0, -20.6 + hv, 1.1, CORAL, 0.8);
      // eyes
      const eg = 0.7 + 0.3 * Math.sin(t * 3.5);
      glow(ctx, -2, -11 + hv, 1.1, GOLD, eg);
      glow(ctx, 2.6, -11 + hv, 1.1, GOLD, eg);
      // trident arm
      const asw = Math.sin(t * 1.7) * 1.4;
      limb(ctx, 6, -3 + hv, 11, 1 + hv + asw, OUT, 2);
      limb(ctx, 11, 2 + hv + asw, 12, -15 + hv + asw, GOLD, 2);
      limb(ctx, 9.5, -17 + hv + asw, 14.5, -17 + hv + asw, GOLD, 2);
      limb(ctx, 12, -16 + hv + asw, 12, -12.5 + hv + asw, GOLD, 2);
      px(ctx, 9, -17.6 + hv + asw, 1, 2, GOLD);
      px(ctx, 15, -17.6 + hv + asw, 1, 2, GOLD);
      // off arm
      limb(ctx, -6, -3 + hv, -10, 2 + hv - asw, OUT, 2);
      blob(ctx, -10.5, 3 + hv - asw, 2, 2, SKIN, OUT);
      if (wind) glow(ctx, -10.5, 3 + hv - asw, 2.4, FIN, 1);
      // water-fracture cracks at phase 2+
      if (ph >= 1) {
        ctx.save();
        ctx.globalAlpha = 0.5 + 0.3 * Math.sin(t * 3.8);
        limb(ctx, -4, 3 + hv, -1, 6 + hv, PEARL, 1);
        limb(ctx, -1, 6 + hv, 2, 4 + hv, PEARL, 1);
        limb(ctx, 4, 7 + hv, 6, 10 + hv, PEARL, 1);
        ctx.restore();
      }
    },
  },

  /* ------------------------------------------------------------
     AEON, THE CHRONO WARDEN — a brass clockwork sentinel: a clock
     face for a head with moving hands, a tick-marked halo ring,
     orbiting gears, rune-glow core, hovering armor skirt.
     ------------------------------------------------------------ */
  aeon: {
    hover: true,
    draw(ctx, b, t) {
      const BR = '#b8a86e', BR2 = '#8a7a4e', BRD = '#5e5230', RUNE = '#5ee8d8', OUT = '#221b0e';
      const ph = b.phase, wind = b.state === 'windup';
      const hv = Math.sin(t * 1.8) * 2.2;
      const hs = 1 + ph * 0.5; // hands/halo speed per phase
      // halo ring with rotating ticks
      ctx.save();
      ctx.globalAlpha = 0.75;
      ctx.strokeStyle = RUNE;
      ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.arc(0, -6 + hv, 14, 0, TAU); ctx.stroke();
      for (let i = 0; i < 12; i++) {
        const a = t * 0.5 * hs + (i / 12) * TAU;
        px(ctx, Math.cos(a) * 14, -6 + hv + Math.sin(a) * 14, 1, 1, RUNE);
      }
      if (ph >= 1) {
        ctx.globalAlpha = 0.35;
        ctx.beginPath(); ctx.arc(0, -6 + hv, 17.5, 0, TAU); ctx.stroke();
      }
      ctx.restore();
      // orbiting gears
      for (let i = 0; i < 2; i++) {
        const a = t * 1.1 * hs + i * Math.PI;
        const gx = Math.cos(a) * 17, gy = hv + Math.sin(a) * 6;
        blob(ctx, gx, gy, 3, 3, BR2, OUT);
        for (let k = 0; k < 4; k++) {
          const ga = a * 2 + k * (TAU / 4);
          px(ctx, gx + Math.cos(ga) * 3.6, gy + Math.sin(ga) * 3.6, 1, 1, BR2);
        }
      }
      // skirt plates
      for (let i = -1; i <= 1; i++) blob(ctx, i * 5, 12 + hv + Math.abs(i) * 1.5, 3.4, 3.8, i === 0 ? BR2 : BRD, OUT);
      // torso + rune core
      blob(ctx, 0, 3 + hv, 9.5, 9, BR, OUT);
      blob(ctx, 0, 4 + hv, 6, 5.5, BR2);
      glow(ctx, 0, 4 + hv, 1.8, RUNE, 0.65 + 0.35 * Math.sin(t * 2.8));
      // pauldrons
      blob(ctx, -8.5, -3 + hv, 4.6, 4, BR2, OUT);
      blob(ctx, 8.5, -3 + hv, 4.6, 4, BR2, OUT);
      px(ctx, -8.5, -4 + hv, 1, 1, RUNE);
      px(ctx, 8.5, -4 + hv, 1, 1, RUNE);
      // arms + gauntlets
      const sw = Math.sin(t * 1.9) * 1.6;
      limb(ctx, -10, 0 + hv, -13, 6 + hv + sw, OUT, 2);
      blob(ctx, -13.5, 8 + hv + sw, 3, 3.2, BRD, OUT);
      limb(ctx, 10, 0 + hv, 13, 6 + hv - sw, OUT, 2);
      blob(ctx, 13.5, 8 + hv - sw, 3, 3.2, BRD, OUT);
      if (wind) { glow(ctx, -13.5, 8 + hv + sw, 2, RUNE, 1); glow(ctx, 13.5, 8 + hv - sw, 2, RUNE, 1); }
      // clock head with moving hands
      blob(ctx, 0, -9 + hv, 6.8, 6.6, BRD, OUT);
      blob(ctx, 0, -9 + hv, 5.2, 5.2, '#e8dcae');
      const ma = t * 1.7 * hs, ha = t * 0.32 * hs;
      limb(ctx, 0, -9 + hv, Math.cos(ma) * 4.2, -9 + hv + Math.sin(ma) * 4.2, OUT, 1);
      limb(ctx, 0, -9 + hv, Math.cos(ha) * 2.8, -9 + hv + Math.sin(ha) * 2.8, RUNE, 1);
      glow(ctx, 0, -9 + hv, 1, RUNE, 0.9);
      // crown fins
      shape(ctx, [[-5, -14 + hv], [-3, -14 + hv], [-4.4, -18 + hv]], BR2, OUT);
      shape(ctx, [[3, -14 + hv], [5, -14 + hv], [4.4, -18 + hv]], BR2, OUT);
      // gold fractures at phase 2+
      if (ph >= 1) {
        ctx.save();
        ctx.globalAlpha = 0.55 + 0.3 * Math.sin(t * 4.2);
        limb(ctx, -7, 6 + hv, -4, 9 + hv, RUNE, 1);
        limb(ctx, -4, 9 + hv, -1, 7 + hv, RUNE, 1);
        limb(ctx, 5, 9 + hv, 8, 11 + hv, RUNE, 1);
        ctx.restore();
      }
    },
  },

  /* ------------------------------------------------------------
     THE NAMELESS VOID — a tear in reality: a dark core with a
     single huge blinking eye, broken halo arcs rotating in
     mismatched directions, orbiting void shards, hanging tendrils.
     ------------------------------------------------------------ */
  void: {
    hover: true,
    draw(ctx, b, t) {
      const VD = '#170d22', VEIL = '#4e2a66', VEL = '#8a4aa8', REND = '#e85eff', RD2 = '#b83eff';
      const OUT = '#07040c', STAR = '#ffffff';
      const ph = b.phase, wind = b.state === 'windup';
      const hv = Math.sin(t * 1.4) * 2.6;
      const enrage = ph >= 3;
      const spin = t * (0.8 + ph * 0.3) * (enrage ? 1.7 : 1);
      // tendrils below
      for (let i = 0; i < 4; i++) {
        const s = (i - 1.5) * 4.5;
        const sway = Math.sin(t * 1.7 + i * 1.9) * 3;
        limb(ctx, s * 0.6, 8 + hv, s * 0.8 + sway * 0.4, 15 + hv, VEIL, 2);
        limb(ctx, s * 0.8 + sway * 0.4, 15 + hv, s + sway, 21 + hv - Math.abs(s) * 0.3, i % 2 ? VEIL : VEL, 2);
        glow(ctx, s + sway, 21.5 + hv - Math.abs(s) * 0.3, 0.9, REND, 0.7);
      }
      // broken halo arcs (rotating, partial, mixed directions)
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const arcs = 2 + Math.min(2, ph);
      for (let i = 0; i < arcs; i++) {
        const rr = 14 + i * 3.5;
        const a0 = spin * (i % 2 ? -1 : 1) + i * 2.1;
        ctx.globalAlpha = 0.5 - i * 0.08;
        ctx.strokeStyle = i === 1 ? REND : VEL;
        ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(0, hv, rr, a0, a0 + TAU * 0.62); ctx.stroke();
      }
      ctx.restore();
      // orbiting fragments
      const frags = 5 + ph * 2 + (enrage ? 2 : 0);
      for (let i = 0; i < frags; i++) {
        const a = spin * (1 + (i % 3) * 0.25) + i * (TAU / frags);
        const rr = 18 + (i % 4) * 2.6;
        const fx = Math.cos(a) * rr, fy = hv + Math.sin(a) * rr * 0.55;
        px(ctx, fx, fy, i % 3 === 0 ? 3 : 2, i % 3 === 0 ? 3 : 2, i % 2 ? VEL : RD2);
        if (i % 3 === 0) glow(ctx, fx, fy, 1.1, REND, 0.8);
      }
      // core — a tear in reality
      blob(ctx, 0, hv, 11, 10.5, VD, OUT);
      blob(ctx, 0, hv, 8, 7.6, '#0e0716');
      // the EYE: glowing slit + white pupil, slow blink
      const bk = clamp((Math.sin(t * 0.5) - 0.93) * 14, 0, 1);
      const ey = (1 - bk) * (wind ? 1.35 : 1);
      glow(ctx, 0, hv, 4.2 * ey + 0.4, REND, 0.75 + 0.25 * Math.sin(t * 3.1));
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = REND;
      ctx.beginPath();
      ctx.ellipse(Math.round(0), Math.round(hv), 4.6 * ey, 1.7 * ey + 0.3, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
      px(ctx, 0, hv, 1, Math.max(1, Math.round(3 * ey)), STAR);
      if (enrage) glow(ctx, 0, hv, 1.6, STAR, 0.9);
      // rend cracks at phase 2+
      if (ph >= 1) {
        ctx.save();
        ctx.globalAlpha = 0.5 + 0.3 * Math.sin(t * 5);
        limb(ctx, -9, -3 + hv, -5, -6 + hv, REND, 1);
        limb(ctx, -5, -6 + hv, -2, -4 + hv, REND, 1);
        limb(ctx, 8, 4 + hv, 11, 2 + hv, REND, 1);
        ctx.restore();
      }
    },
  },
};

// DRAW SCALE (Task 8-b): 7-c hand-drew the bodies at ~1.9x the old sprites;
// this multiplier pushes total presence to ~2.9x. Ascended bosses grow again
// (+0.18 per tier ≈ +0.35 total). Hitboxes did NOT follow — r only x1.15.
function drawScale(b: Boss): number {
  return 1.55 + 0.18 * (b.pat.asc ?? 0);
}

// ---------- rendering entry ----------
export function drawBoss(G: GameCtx): void {
  const b = G.boss;
  if (!b) return;
  const def = BOSS_DEFS[b.defId];
  const ctx = G.ctx;

  // module-level time accumulator drives every idle animation
  const now = performance.now();
  if (VLAST < 0) VLAST = now;
  const vdt = Math.min(0.05, (now - VLAST) / 1000);
  VLAST = now;
  VT += vdt;
  for (const g of GHOSTS) g.t += vdt;
  GHOSTS = GHOSTS.filter((g) => g.t < g.dur);

  const vis = BOSS_VIS[b.defId];
  const dying = b.state === 'dying';
  const dieK = dying ? clamp(b.stT / 1.2, 0, 1) : 0;
  const finalPhase = b.phase >= def.thresholds.length;
  const S = drawScale(b);

  // mirror clones: translucent ghost copies of the real body beneath it
  for (const g of GHOSTS) {
    if (g.defId !== b.defId) continue;
    ctx.save();
    ctx.translate(Math.round(g.x), Math.round(g.y));
    if (g.face < 0) ctx.scale(-1, 1);
    ctx.scale(S, S);
    ctx.globalAlpha = 0.42 * (1 - g.t / g.dur) * (0.85 + 0.15 * Math.sin(VT * 9));
    vis.draw(ctx, b, g.t0);
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  ctx.save();
  ctx.translate(Math.round(b.x), Math.round(b.y));
  ctx.scale(S, S);
  // bigger soft shadow — the body blocks the sun now
  ctx.globalAlpha = 0.34;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(0, 21, 17, 5, 0, 0, TAU);
  ctx.fill();
  ctx.globalAlpha = 1;
  if (b.face < 0) ctx.scale(-1, 1);
  if (b.state === 'stagger') ctx.rotate(Math.sin(G.time * 20) * 0.08);
  const wind = b.state === 'windup';
  if (wind) {
    // the body inflates as it gathers power
    const pu = 1 + 0.05 * Math.sin(G.time * 26);
    ctx.scale(pu, 2 - pu);
  }
  // death: pixel-band dissolve clip (dissolves top-down, jittered per band)
  if (dying) {
    ctx.beginPath();
    const bands = 18, bh = 60 / bands;
    for (let i = 0; i < bands; i++) {
      if (hash2(i * 7 + 3, bossTier(b) * 31, 909) < dieK) continue;
      ctx.rect(-80, -32 + i * bh, 160, bh + 0.6);
    }
    ctx.clip();
  }
  const fade = dying ? clamp(1.3 - dieK * 1.25, 0, 1) : 1;
  ctx.globalAlpha = fade;
  // hover for floaters, breathing bob for grounded colossi
  ctx.translate(0, vis.hover ? Math.sin(VT * 1.7 + 1) * 2.5 : Math.sin(VT * 2.2) * 1.2);
  const drawBody = (comp: GlobalCompositeOperation, alpha: number): void => {
    ctx.globalCompositeOperation = comp;
    ctx.globalAlpha = alpha * fade;
    vis.draw(ctx, b, VT);
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = fade;
  };
  drawBody('source-over', 1);
  if (wind) drawBody('lighter', 0.3 + 0.2 * Math.sin(G.time * 26));
  if (b.flash > 0) drawBody('lighter', clamp(b.flash * 6, 0, 1));
  if (dying && b.stT < 0.2) drawBody('lighter', 0.9); // death flash
  ctx.globalAlpha = 1;
  // IDLE AURA (Task 8-b): a slow element-colored pulse that breathes under
  // the boss at all times — it is NEVER not radiating
  if (!dying) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const c = elColor(def.el);
    const pu = 0.5 + 0.5 * Math.sin(VT * 2.2);
    ctx.globalAlpha = (0.1 + 0.06 * pu) * fade;
    ctx.fillStyle = c;
    ctx.beginPath(); ctx.arc(0, 0, 26 + pu * 4, 0, TAU); ctx.fill();
    ctx.restore();
    ctx.globalAlpha = 1;
  }
  // TELL GLINT (Task 8-b): the element-colored gathering glow while a
  // pattern winds up — collapses inward, flickers faster the closer to fire
  const tellT = b.pat.tellT ?? 0;
  if (tellT > 0 && !dying) {
    const k = clamp(tellT / 0.55, 0, 1); // 1 at open → 0 at fire
    const c = elColor(def.el);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const urg = 0.6 + 0.4 * Math.sin(G.time * 30);
    glow(ctx, 0, -6, (3.2 + (1 - k) * 3.4) * urg, c, 0.8);
    ctx.globalAlpha = 0.55 * (1 - k) + 0.15;
    ctx.strokeStyle = c;
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(0, 0, 10 + 20 * k, 0, TAU); ctx.stroke();
    ctx.restore();
    ctx.globalAlpha = 1;
  }
  // ASCENSION CROWN (Task 8-b): three orbiting element shards + a halo ring
  const asc = b.pat.asc ?? 0;
  if (asc > 0 && !dying) {
    const c = elColor(def.el);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.75;
    ctx.strokeStyle = c;
    ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.arc(0, -15, 13, 0, TAU); ctx.stroke();
    ctx.restore();
    for (let i = 0; i < 3; i++) {
      const a = VT * (1.5 + asc * 0.3) + (i / 3) * TAU;
      const sx = Math.cos(a) * 15, sy = -13 + Math.sin(a) * 5;
      shape(ctx, [[sx, sy - 3], [sx + 2, sy], [sx, sy + 3], [sx - 2, sy]], i === 0 ? '#ffffff' : c, '#100a18');
      glow(ctx, sx, sy, 1.5, c, 0.8);
    }
  }
  // idle polish: a tiny star flare crosses the crown/weapons every few seconds
  if (!dying && b.state !== 'intro') {
    const gp = VT % 3.4;
    if (gp < 0.16) {
      const gx = (hash2(bossTier(b) * 13, 7, 55) - 0.5) * 26;
      const gy = -15 - hash2(bossTier(b) * 5, 3, 77) * 8;
      const k2 = Math.sin((gp / 0.16) * Math.PI);
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = k2 * fade;
      px(ctx, gx, gy, 1, 5, '#ffffff');
      px(ctx, gx, gy, 5, 1, '#ffffff');
      ctx.restore();
      ctx.globalAlpha = 1;
    }
  }
  ctx.globalAlpha = fade;
  // final-phase emissive aura: two counter-rotating rune arcs
  if (finalPhase && !dying) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const c = elColor(def.el);
    ctx.globalAlpha = 0.28 + 0.12 * Math.sin(VT * 3);
    ctx.strokeStyle = c;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, 24 + Math.sin(VT * 2.4) * 2, VT * 0.9, VT * 0.9 + 4.2); ctx.stroke();
    ctx.globalAlpha = 0.16;
    ctx.beginPath(); ctx.arc(0, 0, 29, -VT * 0.62, -VT * 0.62 + 3.4); ctx.stroke();
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  if (b.state === 'stagger') {
    ctx.strokeStyle = '#ffd75e';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, b.r + 10, 0, TAU); ctx.stroke();
  }
  if (b.state === 'intro') {
    ctx.globalAlpha = 0.7 + 0.3 * Math.sin(G.time * 10);
    ctx.strokeStyle = elColor(def.el);
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, b.r + 14, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.restore();

  // INTRO VIGNETTE (Task 8-b): the world dims and a hole of light centers on
  // the boss — drawn here so game.ts needs no changes. The hole breathes.
  if (b.state === 'intro') {
    const camL = G.cam.x + G.cam.shX - G.W / 2;
    const camT = G.cam.y + G.cam.shY - G.H / 2;
    const cy2 = b.y - 10 + Math.sin(VT * 2.6) * 3;
    ctx.save();
    const vg = ctx.createRadialGradient(b.x, cy2, 46, b.x, cy2, 235);
    vg.addColorStop(0, 'rgba(2,0,10,0)');
    vg.addColorStop(0.55, 'rgba(2,0,10,0.3)');
    vg.addColorStop(1, 'rgba(2,0,10,0.64)');
    ctx.fillStyle = vg;
    ctx.fillRect(camL - 6, camT - 6, G.W + 12, G.H + 12);
    ctx.restore();
  }
}
