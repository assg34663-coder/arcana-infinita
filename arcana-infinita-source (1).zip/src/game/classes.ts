/* ============================================================
   classes.ts — CLASSES & THE SKILL TREE.
   Leveling grants SKILL POINTS. You invest them wherever you
   want: deep into one school, across several, or into the
   universal arts (vitality, focus, alacrity, reflex, warding,
   intellect). Your class decides where you START — not where
   you finish. A Summoner can become a Pyromancer; the Weald
   does not care.
   ============================================================ */
import type { ElementId } from './core';

export type UniversalId = 'vit' | 'focus' | 'alacrity' | 'reflex' | 'warding' | 'intellect';

export const UNIVERSAL_IDS: UniversalId[] = ['vit', 'focus', 'alacrity', 'reflex', 'warding', 'intellect'];

export const UNIVERSAL_MAX = 6;

export interface UniversalDef {
  id: UniversalId;
  name: string;
  desc: string;
  color: string;
  glyph: string;
}

export const UNIVERSALS: Record<UniversalId, UniversalDef> = {
  vit: { id: 'vit', name: 'Vitality', desc: '+15 max HP per rank', color: '#ff8a9e', glyph: '♥' },
  focus: { id: 'focus', name: 'Focus', desc: '+12 max mana, +0.35 regen per rank', color: '#5ee8c9', glyph: '✦' },
  alacrity: { id: 'alacrity', name: 'Alacrity', desc: '+3% move speed per rank', color: '#9ee8c8', glyph: '»' },
  reflex: { id: 'reflex', name: 'Reflex', desc: '-5% dash cost & cooldown, +0.015s i-frames per rank', color: '#9ee8ff', glyph: '≈' },
  warding: { id: 'warding', name: 'Warding', desc: '+0.006s parry window, -0.06s whiff penalty per rank', color: '#ffd75e', glyph: '♃' },
  intellect: { id: 'intellect', name: 'Intellect', desc: '+3.5% spell damage per rank', color: '#c95ee8', glyph: '✱' },
};

export interface ClassDef {
  id: string;
  name: string;
  title: string;
  blurb: string;
  passive: string;
  color: string;
  start: Partial<Record<ElementId, number>>; // starting SCHOOL LEVELS
}

export const CLASSES: Record<string, ClassDef> = {
  summoner: {
    id: 'summoner', name: 'Summoner', title: 'the Hordeheart',
    blurb: 'Why fight when the dead and the wild will fight for you? Start deep in Necromancy with Nature and Beast allies at your side.',
    passive: 'Minions deal +25% damage and last +30% longer.',
    color: '#9ee8d8',
    start: { death: 7, nature: 3, beast: 3 },
  },
  pyromancer: {
    id: 'pyromancer', name: 'Pyromancer', title: 'the Ash Saint',
    blurb: 'Fire answers every question. Start with a burning arsenal and the Arcane mana engine to keep casting it.',
    passive: 'Burns deal +30% damage and cling longer.',
    color: '#ff7a3e',
    start: { fire: 7, arcane: 3 },
  },
  elementalist: {
    id: 'elementalist', name: 'Elementalist', title: 'the Sixfold Weave',
    blurb: 'A foot in every element — fire, frost, lightning, water, wind, earth. Trade depth for total adaptability.',
    passive: 'All spell damage +12%.',
    color: '#9ee8ff',
    start: { fire: 3, frost: 3, lightning: 3, water: 3, wind: 3, earth: 3 },
  },
  necromancer: {
    id: 'necromancer', name: 'Necromancer', title: 'the Grave Chorister',
    blurb: 'The purest pact with death. Your army grows faster, your thralls outnumber the living.',
    passive: 'Auto-raise chance +10%, and you command +2 extra minions.',
    color: '#a8b0a0',
    start: { death: 9 },
  },
  stormcaller: {
    id: 'stormcaller', name: 'Storm Caller', title: 'the Skytongue',
    blurb: 'Lightning in one hand, gales in the other, thunder to speak with. Chains that never know when to stop.',
    passive: 'Chain lightning gains +1 jump and hits +25% harder.',
    color: '#f2e35e',
    start: { lightning: 7, wind: 5, sound: 3 },
  },
  shadowblade: {
    id: 'shadowblade', name: 'Shadow Blade', title: 'the Silken Death',
    blurb: 'Dread and whirling steel. You never stop moving — dodging is how you breathe.',
    passive: 'Dodging refunds 15 mana.',
    color: '#7a5ea8',
    start: { shadow: 5, metal: 5 },
  },
  ritualist: {
    id: 'ritualist', name: 'Blood Ritualist', title: 'the Crimson Ledger',
    blurb: 'Every spell is written in red. Blood magic costs you less, and gives back more.',
    passive: 'Blood price reduced 25%; blood heals +50% more.',
    color: '#d94e5e',
    start: { blood: 7, bone: 3 },
  },
  chronomancer: {
    id: 'chronomancer', name: 'Chronomancer', title: 'the Unhurried',
    blurb: 'Time, gravity, and reflections bend around you. You dodge between the seconds.',
    passive: 'Dodge i-frames +0.08s; TIME STOP charges at 2 instead of 3.',
    color: '#e8c05e',
    start: { time: 7, gravity: 3, mirror: 3 },
  },
};

export const CLASS_IDS = Object.keys(CLASSES);

export function classOf(G: { prog: { cls: string } }): ClassDef | null {
  return CLASSES[G.prog.cls] ?? null;
}

export function universalRank(G: { prog: { universal: Record<string, number> } }, id: UniversalId): number {
  return G.prog.universal[id] ?? 0;
}
