/* ============================================================
   statues.ts — THE EFFIGY RING (Task 8-b)
   Eight boss statues in a circle around the Wayfarer Shrine.
   Each statue is DORMANT until its boss has fallen once, then
   AWAKE: element-lit crystal, glowing eyes, breathing aura.
   Interacting with an awake statue spends Echo Shards to open a
   REALM FIGHT against the ASCENDED boss (bigger, meaner, one
   extra pattern per phase, crowned in orbiting element shards).
   Clearing realms raises prog.ascensions; a full 8-boss sweep
   at ever-higher tiers INVERTS THE WEALD (NG+ layers).

   Exports:
     initStatues(anchorX, anchorY, world?)   build the ring (statue 0 = north)
     statueNear(G)                            interact scan (<= 20px)
     statuePromptText(G, bossId)              interact prompt string
     tryInteractStatue(G)                     full E-press handler
     nextRealmTier(G, bossId)                 suggested challenge tier
     tryStartRealm(G, bossId, tier)           open the realm fight
     updateStatues(G, dt)                     realm exit + ambience + echo pickups
     statueDrawItems(G)                       y-sortable world draw list
     drawStatues(G)                           simple non-sorted fallback
     drawRealmOverlay(G)                      screen-space "another place" wash
     checkInversion(G)                        NG+ layer check (called on realm wins)
   ============================================================ */
import {
  TAU, dist, randR, chance, hash2,
  type GameCtx, type World,
} from './core';
import { elColor } from './sprites';
import { BOSSES, getLocations } from './world';
import { spawnParticle, burst, addText, screenFlash, slowmo, shake } from './fx';
import { BOSS_DEFS, spawnBossAt } from './bosses';
import { arenaForBoss } from './arenas';

type C2D = CanvasRenderingContext2D;

// ---------- tiny pixel helpers (mirrors of the bosses.ts primitives) ----------
function px(ctx: C2D, x: number, y: number, w: number, h: number, col: string): void {
  ctx.fillStyle = col;
  ctx.fillRect(Math.round(x) - (w >> 1), Math.round(y) - (h >> 1), w, h);
}

function blob(ctx: C2D, x: number, y: number, rx: number, ry: number, col: string, out?: string): void {
  if (out) {
    ctx.fillStyle = out;
    ctx.beginPath();
    ctx.ellipse(Math.round(x), Math.round(y), rx + 1, ry + 1, 0, 0, TAU);
    ctx.fill();
  }
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.ellipse(Math.round(x), Math.round(y), rx, ry, 0, 0, TAU);
  ctx.fill();
}

function limb(ctx: C2D, x1: number, y1: number, x2: number, y2: number, col: string, w = 2): void {
  const d = Math.hypot(x2 - x1, y2 - y1);
  const n = Math.max(1, Math.ceil(d / 1.7));
  const o = (w - 1) >> 1;
  ctx.fillStyle = col;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    ctx.fillRect(Math.round(x1 + (x2 - x1) * t) - o, Math.round(y1 + (y2 - y1) * t) - o, w, w);
  }
}

function shape(ctx: C2D, pts: Array<[number, number]>, col: string, out?: string): void {
  const path = (dx: number, dy: number): void => {
    ctx.beginPath();
    ctx.moveTo(Math.round(pts[0][0] + dx), Math.round(pts[0][1] + dy));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(Math.round(pts[i][0] + dx), Math.round(pts[i][1] + dy));
    ctx.closePath();
    ctx.fill();
  };
  if (out) {
    ctx.fillStyle = out;
    path(1, 0); path(-1, 0); path(0, 1); path(0, -1);
  }
  ctx.fillStyle = col;
  path(0, 0);
}

function glow(ctx: C2D, x: number, y: number, r: number, col: string, a = 1): void {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = col;
  ctx.globalAlpha = 0.3 * a;
  ctx.beginPath(); ctx.arc(Math.round(x), Math.round(y), r * 2.4, 0, TAU); ctx.fill();
  ctx.globalAlpha = 0.85 * a;
  ctx.beginPath(); ctx.arc(Math.round(x), Math.round(y), r, 0, TAU); ctx.fill();
  ctx.restore();
}

// ---------- module state ----------
interface Statue {
  bossId: string;
  x: number; y: number; // pedestal base center (world)
}

let STATUES: Statue[] = [];
let ANCHOR = { x: 0, y: 0 };
// where the CURRENT realm fight is hosted (arena center) — null = legacy shrine ring
let REALM_C: { x: number; y: number; r: number } | null = null;

export const REALM_RADIUS = 118; // the effigy ring; realms collapse past x1.4

// statue i sits at angle i*(TAU/8) - PI/2 → statue 0 is NORTH of the shrine
export function initStatues(anchorX: number, anchorY: number, world?: World): void {
  ANCHOR = { x: anchorX, y: anchorY };
  STATUES = BOSSES.map((b, i) => {
    const a = i * (TAU / 8) - Math.PI / 2;
    let x = anchorX + Math.cos(a) * REALM_RADIUS;
    let y = anchorY + Math.sin(a) * REALM_RADIUS;
    if (world) {
      // effigies do not stand in the sea — nudge toward the anchor until free
      for (let k = 0; k < 14 && world.solidAt(x, y); k++) {
        x += (anchorX - x) * 0.18;
        y += (anchorY - y) * 0.18;
      }
    }
    return { bossId: b.id, x, y };
  });
}

// ---------- interaction ----------
export function statueNear(G: GameCtx): { bossId: string; x: number; y: number } | null {
  for (const s of STATUES) {
    if (dist(G.player.x, G.player.y, s.x, s.y) < 20) {
      return { bossId: s.bossId, x: s.x, y: s.y };
    }
  }
  return null;
}

// the challenge is always your next uncleared tier — each Inversion raises it
export function nextRealmTier(G: GameCtx, bossId: string): number {
  const asc = G.prog.ascensions[bossId] ?? 0;
  return asc + 1 + G.prog.ngPlus;
}

export function statuePromptText(G: GameCtx, bossId: string): string {
  const def = BOSS_DEFS[bossId];
  if (!G.prog.bosses.includes(bossId)) return 'The effigy sleeps...';
  const t = nextRealmTier(G, bossId);
  return `E — Challenge ${def?.name ?? bossId} · Ascension ${t} (${t} Echo Shard${t === 1 ? '' : 's'})`;
}

// returns true when an effigy consumed the interact press (game.ts: call
// this FIRST inside doInteract, before the shrine/fusion altar checks)
export function tryInteractStatue(G: GameCtx): boolean {
  const st = statueNear(G);
  if (!st) return false;
  if (!G.prog.bosses.includes(st.bossId)) {
    G.audio.sfx('ui', 0.7, 0.5);
    G.toasts.push({ text: 'The effigy sleeps. Fell the one it portrays, and it will wake.', t: 0, color: '#9a92a8' });
    return true;
  }
  const res = tryStartRealm(G, st.bossId, nextRealmTier(G, st.bossId));
  if (!res.ok) {
    G.audio.sfx('whiff', 0.9, 0.5);
    G.toasts.push({ text: res.msg, t: 0, color: '#e2a25e' });
  }
  return true;
}

// ---------- realm fights ----------
export function tryStartRealm(G: GameCtx, bossId: string, tier: number): { ok: boolean; msg: string } {
  const def = BOSS_DEFS[bossId];
  if (!def || !STATUES.length) return { ok: false, msg: 'The statues are silent.' };
  if (!BOSSES.some((x) => x.id === bossId)) return { ok: false, msg: 'No such effigy.' };
  if (!G.prog.bosses.includes(bossId)) return { ok: false, msg: 'The effigy sleeps — defeat it in the Weald first.' };
  if (G.player.dead) return { ok: false, msg: 'You are in no shape to answer a challenge.' };
  if (G.boss) return { ok: false, msg: 'A hunt is already underway.' };
  if (G.realm) return { ok: false, msg: 'The realm is already open.' };
  const t = Math.max(1, Math.floor(tier));
  if (G.prog.echoes < t) {
    return { ok: false, msg: `Requires ${t} Echo Shard${t === 1 ? '' : 's'} — you carry ${G.prog.echoes}.` };
  }
  G.prog.echoes -= t;
  // sweep the field and pull the mage through the tear — INTO THE ARENA
  G.enemies = []; G.bullets = []; G.zones = []; G.teles = []; G.sched = []; G.minions = [];
  G.boss = null; G.gate = null; G.spider = null;
  const p = G.player;
  const arenaLoc = getLocations().find((l) => l.kind === 'boss' && l.bossId === bossId);
  const ar = arenaForBoss(bossId);
  let bx: number, by: number;
  if (arenaLoc && ar) {
    // materialize just inside the entrance; the boss holds the center
    p.x = arenaLoc.x + Math.cos(ar.gapA) * ar.rf * 0.62;
    p.y = arenaLoc.y + Math.sin(ar.gapA) * ar.rf * 0.62;
    bx = arenaLoc.x;
    by = arenaLoc.y;
    G.gate = { x: arenaLoc.x, y: arenaLoc.y, r: ar.rw + 30 };
    REALM_C = { x: arenaLoc.x, y: arenaLoc.y, r: ar.rw + 30 };
  } else {
    p.x = ANCHOR.x; p.y = ANCHOR.y + 66;
    bx = ANCHOR.x; by = ANCHOR.y - 48;
    REALM_C = null;
  }
  G.cam.x = p.x; G.cam.y = p.y;
  // never materialize inside a wall/water — walk the landing point home
  for (let k = 0; k < 12 && G.world.solidAt(p.x, p.y); k++) {
    p.x += (bx - p.x) * 0.22;
    p.y += (by - p.y) * 0.22;
  }
  for (let k = 0; k < 12 && G.world.solidAt(bx, by); k++) {
    bx += (p.x - bx) * 0.22;
    by += (p.y - by) * 0.22;
  }
  p.iframes = 1.4;
  G.realm = { bossId, tier: t };
  spawnBossAt(G, bossId, bx, by, { asc: t });
  screenFlash(G, elColor(def.el), 0.4);
  slowmo(G, 0.4, 0.35);
  shake(G, 4);
  burst(G, p.x, p.y, elColor(def.el), 26, 120, { glow: true });
  G.audio.sfx('blink', 0.5, 0.7);
  G.toasts.push({ text: `The realm tears open — you stand in ${def.name.split(',')[0]}'s own arena. Ascension ${t}.`, t: 0, color: elColor(def.el) });
  G.mode = 'play';
  G.uiV++;
  // milestone save: never lose a paid entry
  try {
    G.prog.x = p.x; G.prog.y = p.y;
    localStorage.setItem('arcana_infinita_save_v1', JSON.stringify(G.prog));
  } catch { /* ignore */ }
  return { ok: true, msg: `Ascension ${t} — ${def.name} awaits.` };
}

export function updateStatues(G: GameCtx, dt: number): void {
  // ---- leaving the realm collapses it (the boss unravels, unpaid) ----
  if (G.realm && !G.player.dead) {
    const bossBusy = G.boss && !G.boss.dead && G.boss.state !== 'dying';
    const rc = REALM_C ?? { x: ANCHOR.x, y: ANCHOR.y, r: REALM_RADIUS };
    if (bossBusy && dist(G.player.x, G.player.y, rc.x, rc.y) > rc.r * 1.25) {
      const bid = G.realm.bossId;
      G.realm = null;
      if (G.boss && G.boss.defId === bid) {
        burst(G, G.boss.x, G.boss.y, elColor(BOSS_DEFS[bid]?.el ?? 'arcane'), 30, 160, { glow: true });
        G.boss = null;
      }
      G.bullets = []; G.teles = []; G.sched = [];
      G.toasts.push({ text: 'The realm closes.', t: 0, color: '#b8a8e8' });
      G.audio.sfx('blink', 0.6, 0.5);
      G.uiV++;
    }
  }
  if (!STATUES.length) return;
  // ---- awake effigies breathe: gentle element motes ----
  for (let i = 0; i < STATUES.length; i++) {
    const s = STATUES[i];
    if (!G.prog.bosses.includes(s.bossId)) continue;
    if (dist(G.player.x, G.player.y, s.x, s.y) > 640) continue;
    if ((G.frame + i * 9) % 38 === 0) {
      const el = BOSS_DEFS[s.bossId]?.el ?? 'arcane';
      spawnParticle(G, {
        x: s.x + randR(-7, 7), y: s.y - 14 + randR(-4, 4),
        vx: randR(-5, 5), vy: randR(-26, -12),
        life: randR(0.7, 1.3), size: randR(1.2, 2.2),
        color: chance(0.25) ? '#ffffff' : elColor(el), glow: true,
      });
    }
  }
  // ---- echo shard pickups: statues.ts owns the echo economy (collect them
  // BEFORE fx.updatePickups mistakes them for draughts — wire updateStatues
  // earlier in step() than updatePickups) ----
  if (G.pickups.some((it) => it.kind === 'echo')) {
    const p = G.player;
    let got = 0;
    G.pickups = G.pickups.filter((it) => {
      if (it.kind !== 'echo' || it.t > 0.25) return true;
      if (dist(it.x, it.y, p.x, p.y) > 16) return true;
      got += it.amount;
      burst(G, it.x, it.y, '#8ee8ff', 5, 60, { glow: true });
      return false;
    });
    if (got > 0) {
      G.prog.echoes += got;
      addText(G, p.x, p.y - 18, `+${got} Echo Shard${got > 1 ? 's' : ''}`, '#8ee8ff', 6, true);
      G.audio.sfx('aether', 1.4, 0.7);
      G.uiV++;
    }
  }
  void dt;
}

// ---------- NG+ — THE WEALD INVERTS ----------
// Every full 8-boss sweep at tier >= ngPlus+1 grants another inversion layer.
export function checkInversion(G: GameCtx): void {
  const ids = BOSSES.map((b) => b.id);
  let inv = 0;
  while (ids.every((id) => (G.prog.ascensions[id] ?? 0) >= inv + 1)) inv++;
  if (inv <= G.prog.ngPlus) return;
  G.prog.ngPlus = inv;
  G.banner = {
    title: 'THE WEALD INVERTS',
    sub: `Inversion ${inv} — every foe grows stronger. The statues hunger for higher tiers.`,
    t: 0, color: '#e85eff',
  };
  G.toasts.push({
    text: `All foes now fight one tier stronger (Inversion ${inv}). Statue realms ascend too — tier +${inv}.`,
    t: 0, color: '#e85eff',
  });
  G.audio.sfx('roar', 0.7, 0.6);
  G.audio.sfx('grand', 1, 0.4);
  screenFlash(G, '#e85eff', 0.5);
  shake(G, 5);
  slowmo(G, 0.5, 0.4);
  G.uiV++;
}

/* ============================================================
   RENDERING — stone pedestals + procedural effigies.
   DORMANT: cold gray stone, cracked, eyes dark, crystal dim.
   AWAKE: element-lit crystal, glowing eyes, breathing ground aura.
   ============================================================ */

// 12-16px stylized silhouette per boss — stone-carved, element accents
function drawEffigy(ctx: C2D, id: string, x: number, y: number, t: number, awake: boolean, col: string): void {
  const S1 = awake ? '#7c7590' : '#4c4656'; // stone light
  const S2 = awake ? '#5e5870' : '#39343f'; // stone dark
  const OUT = '#141019';
  const ACC = awake ? col : '#3a3442'; // element accent (eyes / gems / horns)
  switch (id) {
    case 'ashen': { // horned brute
      blob(ctx, x, y - 5, 5.5, 5, S2, OUT);
      blob(ctx, x, y - 11, 3.6, 3.2, S1, OUT);
      limb(ctx, x - 3, y - 13, x - 5.5, y - 17, S1, 2);
      limb(ctx, x + 3, y - 13, x + 5.5, y - 17, S1, 2);
      blob(ctx, x - 6, y - 5, 2.2, 2.2, S2, OUT);
      blob(ctx, x + 6, y - 5, 2.2, 2.2, S2, OUT);
      px(ctx, x - 2, y - 11, 1, 1, ACC);
      px(ctx, x + 1, y - 11, 1, 1, ACC);
      break;
    }
    case 'frost': { // iceling queen
      shape(ctx, [[x - 4.5, y], [x + 4.5, y], [x, y - 9]], S1, OUT);
      blob(ctx, x, y - 11, 3, 3, S1, OUT);
      for (const s of [-1, 0, 1]) px(ctx, x + s * 2, y - 15 + Math.abs(s), 1, 2, ACC);
      px(ctx, x - 1, y - 11, 1, 1, ACC);
      px(ctx, x + 1, y - 11, 1, 1, ACC);
      break;
    }
    case 'hollow': { // crowned skull on a cloak
      shape(ctx, [[x - 5, y], [x + 5, y], [x + 2, y - 6], [x - 2, y - 6]], S2, OUT);
      blob(ctx, x, y - 9.5, 4.2, 3.8, S1, OUT);
      px(ctx, x - 2, y - 10, 1, 2, OUT);
      px(ctx, x + 1, y - 10, 1, 2, OUT);
      if (awake) {
        glow(ctx, x - 1.5, y - 9.5, 0.9, col, 0.9);
        glow(ctx, x + 1.5, y - 9.5, 0.9, col, 0.9);
      }
      limb(ctx, x - 3, y - 13, x - 3, y - 16, S1, 1);
      limb(ctx, x, y - 13.5, x, y - 17, S1, 1);
      limb(ctx, x + 3, y - 13, x + 3, y - 16, S1, 1);
      break;
    }
    case 'storm': { // cloud djinn
      blob(ctx, x, y - 9, 5.5, 3.8, S1, OUT);
      blob(ctx, x - 4, y - 7.5, 3, 2.6, S2, OUT);
      blob(ctx, x + 4, y - 7.5, 3, 2.6, S2, OUT);
      limb(ctx, x, y - 6, x + Math.sin(t * 2) * 1.5, y, S2, 2);
      limb(ctx, x - 2, y - 12.5, x - 1, y - 15, ACC, 1);
      limb(ctx, x + 2, y - 12.5, x + 1, y - 15, ACC, 1);
      px(ctx, x - 2, y - 9, 1, 1, ACC);
      px(ctx, x + 1, y - 9, 1, 1, ACC);
      break;
    }
    case 'maw': { // plant horror with a chomping jaw
      blob(ctx, x, y - 4.5, 5, 4.5, S2, OUT);
      blob(ctx, x, y - 10.5, 4, 3, S1, OUT);
      px(ctx, x - 2, y - 8.4, 1, 1, awake ? '#e8e4c8' : OUT);
      px(ctx, x, y - 8.4, 1, 1, awake ? '#e8e4c8' : OUT);
      px(ctx, x + 2, y - 8.4, 1, 1, awake ? '#e8e4c8' : OUT);
      limb(ctx, x - 4, y - 6, x - 7, y - 12, S2, 1);
      limb(ctx, x + 4, y - 6, x + 7, y - 12, S2, 1);
      px(ctx, x + 2, y - 12, 1, 1, ACC);
      break;
    }
    case 'tide': { // serpent siren with a trident
      limb(ctx, x - 1, y - 1, x + 2, y - 4, S2, 3);
      limb(ctx, x + 2, y - 4, x - 1.5, y - 7, S1, 3);
      blob(ctx, x, y - 9, 3, 3.4, S1, OUT);
      limb(ctx, x - 3, y - 11, x - 4.5, y - 7, S2, 1);
      limb(ctx, x + 3, y - 11, x + 4.5, y - 7, S2, 1);
      limb(ctx, x + 4.5, y - 6, x + 4.5, y - 14, ACC, 1);
      limb(ctx, x + 3, y - 14, x + 6, y - 14, ACC, 1);
      px(ctx, x - 1, y - 9.5, 1, 1, ACC);
      px(ctx, x + 1, y - 9.5, 1, 1, ACC);
      break;
    }
    case 'aeon': { // clockwork sentinel
      blob(ctx, x, y - 4.5, 4.2, 4, S2, OUT);
      blob(ctx, x, y - 11, 3.8, 3.8, S1, OUT);
      const hA = t * 1.2;
      px(ctx, x + Math.cos(hA) * 2, y - 11 + Math.sin(hA) * 2, 1, 1, ACC);
      ctx.save();
      ctx.globalAlpha = awake ? 0.8 : 0.4;
      ctx.strokeStyle = ACC;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(x, y - 11, 6, 0, TAU); ctx.stroke();
      ctx.restore();
      px(ctx, x, y - 4.5, 1, 1, ACC);
      break;
    }
    case 'void': { // the tear in reality
      blob(ctx, x, y - 8, 4.6, 4.4, '#1a1220', OUT);
      if (awake) {
        glow(ctx, x, y - 8, 1.8, col, 0.85);
        ctx.fillStyle = col;
        ctx.beginPath(); ctx.ellipse(x, y - 8, 2.4, 0.9, 0, 0, TAU); ctx.fill();
        px(ctx, x, y - 8, 1, 2, '#ffffff');
      } else {
        px(ctx, x, y - 8, 2, 1, OUT);
      }
      ctx.save();
      ctx.globalAlpha = awake ? 0.7 : 0.3;
      ctx.strokeStyle = awake ? col : S2;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(x, y - 8, 7, t * 0.6, t * 0.6 + 4); ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y - 8, 7, t * 0.6 + Math.PI, t * 0.6 + Math.PI + 2.4); ctx.stroke();
      ctx.restore();
      limb(ctx, x - 2, y - 4, x - 2.5, y, S2, 1);
      limb(ctx, x + 2, y - 4, x + 2.5, y, S2, 1);
      break;
    }
    default: { // fallback monolith
      blob(ctx, x, y - 6, 3.4, 6, S2, OUT);
      px(ctx, x, y - 9, 1, 1, ACC);
      break;
    }
  }
}

function drawStatue(G: GameCtx, s: Statue): void {
  const ctx = G.ctx;
  const def = BOSS_DEFS[s.bossId];
  const col = elColor(def?.el ?? 'arcane');
  const awake = G.prog.bosses.includes(s.bossId);
  const t = G.time;
  const STONE = awake ? '#8a8494' : '#565060';
  const STONE2 = awake ? '#6e6878' : '#3c3744';
  const OUT = '#17141f';
  const bob = awake ? Math.sin(t * 1.4 + hash2(Math.round(s.x), Math.round(s.y), 3) * TAU) * 1.1 : 0;
  // pedestal: base slab, column, capital
  blob(ctx, s.x, s.y + 9, 13, 4.5, STONE2, OUT);
  blob(ctx, s.x, s.y + 4, 10.5, 4, STONE, OUT);
  px(ctx, s.x, s.y - 2, 7, 11, STONE2);
  blob(ctx, s.x, s.y - 8, 9, 3.5, STONE, OUT);
  // dormant statues are cracked through
  if (!awake) {
    ctx.save();
    ctx.globalAlpha = 0.85;
    limb(ctx, s.x - 4, s.y + 2, s.x - 2, s.y + 6, OUT, 1);
    limb(ctx, s.x + 3, s.y - 1, s.x + 5, s.y + 5, OUT, 1);
    limb(ctx, s.x - 1, s.y - 8, s.x + 2, s.y - 5, OUT, 1);
    ctx.restore();
  }
  // the effigy itself
  drawEffigy(ctx, s.bossId, s.x, s.y - 10 + bob, t, awake, col);
  // element crystal set into the pedestal front
  const gemY = s.y + 3;
  shape(ctx, [[s.x - 2.4, gemY - 2.6], [s.x + 2.4, gemY - 2.6], [s.x, gemY + 3.2]], awake ? col : '#453f4e', OUT);
  if (awake) {
    glow(ctx, s.x, gemY, 2 + Math.sin(t * 2.2) * 0.8, col, 0.85);
    // breathing ground aura
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.15 + 0.08 * Math.sin(t * 1.8);
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(s.x, s.y + 9, 17 + Math.sin(t * 1.8) * 2, 6, 0, 0, TAU);
    ctx.stroke();
    ctx.restore();
  } else {
    glow(ctx, s.x, gemY, 0.8, '#2c2833', 0.5);
  }
}

// individually y-sorted, culled to the camera (~700px)
export function statueDrawItems(G: GameCtx): Array<{ y: number; f: () => void }> {
  const items: Array<{ y: number; f: () => void }> = [];
  for (const s of STATUES) {
    if (Math.abs(s.x - G.cam.x) > 720 || Math.abs(s.y - G.cam.y) > 520) continue;
    items.push({ y: s.y, f: () => drawStatue(G, s) });
  }
  return items;
}

// simple fallback (no y-sort) — prefer statueDrawItems in the draw list
export function drawStatues(G: GameCtx): void {
  for (const it of statueDrawItems(G)) it.f();
}

// ---------- realm overlay: unmistakably another place ----------
// screen-space; wire AFTER the world transform is popped, BEFORE drawVignette
export function drawRealmOverlay(G: GameCtx): void {
  if (!G.realm) return;
  const ctx = G.ctx;
  const def = BOSS_DEFS[G.realm.bossId];
  const col = elColor(def?.el ?? 'void');
  const W = G.W, H = G.H;
  const t = G.time;
  ctx.save();
  // element wash
  ctx.globalAlpha = 0.16;
  ctx.fillStyle = col;
  ctx.fillRect(0, 0, W, H);
  // rising debris motes (deterministic — no per-frame state)
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 26; i++) {
    const sp = 14 + hash2(i, 1, 7) * 26;
    const y = H - ((t * sp + hash2(i, 2, 7) * H * 2) % (H + 20));
    const x = hash2(i, 3, 7) * W + Math.sin(t * 0.7 + i) * 9;
    const sz = 1 + hash2(i, 4, 7) * 2;
    ctx.globalAlpha = 0.22 + 0.18 * Math.sin(t * 2 + i * 1.7);
    ctx.fillStyle = i % 5 === 0 ? '#ffffff' : col;
    ctx.fillRect(Math.round(x), Math.round(y), Math.round(sz), Math.round(sz));
  }
  // distant star/petal twinkles
  for (let i = 0; i < 12; i++) {
    const x = Math.round(hash2(i, 8, 13) * W);
    const y = Math.round(hash2(i, 9, 13) * H);
    const tw = Math.sin(t * (1.1 + hash2(i, 10, 13)) + i * 2.4);
    if (tw > 0.55) {
      ctx.globalAlpha = (tw - 0.55) * 1.6;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, y, 1, 1);
      ctx.globalAlpha = (tw - 0.55) * 0.7;
      ctx.fillRect(x - 1, y, 3, 1);
      ctx.fillRect(x, y - 1, 1, 3);
    }
  }
  ctx.restore();
  // vignette border
  ctx.save();
  const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.36, W / 2, H / 2, Math.max(W, H) * 0.72);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, 'rgba(4,0,10,0.5)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}
