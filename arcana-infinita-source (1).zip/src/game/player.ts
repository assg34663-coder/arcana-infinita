/* ============================================================
   player.ts — the unbound mage: movement, dodge roll with
   i-frames, the parry window, staff melee, potions, wards,
   recall channeling, and rendering.
   ============================================================ */
import {
  TAU, clamp, angTo, dist, randR,
  type GameCtx, type PlayerState, type ElementId, type Ent, type Bullet,
} from './core';
import { elColor, SPR } from './sprites';
import {
  burst, spawnParticle, addText, damageEnemy, damagePlayer, slowmo, shake,
  addRing, bumpCombo, screenFlash, explosion, spawnZone,
} from './fx';
import { moveWithCollision } from './world';
import { tileSpeedMult } from './fx';
import { castSpell } from './casting';
import { spellDef, attuneSlots, spellDamage } from './magic';
import { parryBossHit } from './bosses';
import { damageBoss as fxDamageBoss } from './fx';
import { universalRank } from './classes';
import { relicVal } from './items';
import type { SpellDef } from './core';

export function createPlayer(x: number, y: number): PlayerState {
  return {
    x, y, vx: 0, vy: 0, r: 6,
    hp: 100, maxHp: 100, team: 'player', st: {},
    flash: 0, dead: false, deadT: 0, face: 1, anim: 0,
    lvl: 1, xp: 0,
    mana: 60, maxMana: 60, manaRegenT: 0,
    stam: 100, maxStam: 100, stamRegenT: 0,
    dodgeT: 0, dodgeCd: 0, ddX: 0, ddY: 0, dashed: false,
    parryT: 0, parryCd: 0, parryFlash: 0, perfectT: 0,
    castCd: 0, meleeCd: 0, meleeT: 0, potionCd: 0,
    ward: null, enchant: null, buffHaste: 0,
    history: [], activeSlot: 0,
    recallT: 0, recallCd: 0,
    iframes: 0, hurtCd: 0, stunT: 0,
    castAnimT: 0, parryReflT: 0, parryHits: 0,
  };
}

// element of the currently attuned spell — colors the dash
function activeElement(G: GameCtx): ElementId {
  const id = G.prog.loadout[G.player.activeSlot];
  const def = id ? spellDef(id) : null;
  return def ? def.el : 'arcane';
}

// ---------- dash afterimage ghosts ----------
const ghostCache = new Map<string, HTMLCanvasElement>();
function ghostSprite(frame: number, el: ElementId): HTMLCanvasElement {
  const key = `${frame}|${el}`;
  let cv = ghostCache.get(key);
  if (!cv) {
    const src = [SPR.player_walk0, SPR.player_walk1, SPR.player_walk2, SPR.player_walk3][frame] ?? SPR.player_idle;
    cv = document.createElement('canvas');
    cv.width = src.width; cv.height = src.height;
    const g = cv.getContext('2d')!;
    g.drawImage(src, 0, 0);
    g.globalCompositeOperation = 'source-atop';
    g.fillStyle = elColor(el);
    g.globalAlpha = 0.92;
    g.fillRect(0, 0, cv.width, cv.height);
    ghostCache.set(key, cv);
  }
  return cv;
}

export function updateGhosts(G: GameCtx, dt: number): void {
  let w = 0;
  for (const g of G.ghosts) { g.t += dt; if (g.t < g.dur) G.ghosts[w++] = g; }
  G.ghosts.length = w;
}

export function drawGhosts(G: GameCtx): void {
  if (!G.ghosts.length) return;
  const ctx = G.ctx;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const g of G.ghosts) {
    const k = 1 - g.t / g.dur;
    const spr = ghostSprite(g.frame, g.el);
    const flip = g.face < 0;
    // chromatic aberration pair (magenta / cyan ghosts offset)
    ctx.globalAlpha = 0.14 * k;
    ctx.save();
    ctx.translate(Math.round(g.x + 1.8), Math.round(g.y));
    if (flip) ctx.scale(-1, 1);
    ctx.drawImage(spr, -spr.width / 2, -spr.height / 2 - 2);
    ctx.restore();
    ctx.globalAlpha = 0.14 * k;
    ctx.save();
    ctx.translate(Math.round(g.x - 1.8), Math.round(g.y));
    if (flip) ctx.scale(-1, 1);
    ctx.drawImage(spr, -spr.width / 2, -spr.height / 2 - 2);
    ctx.restore();
    // tinted silhouette + white-hot core streak
    ctx.globalAlpha = 0.5 * k;
    ctx.save();
    ctx.translate(Math.round(g.x), Math.round(g.y));
    if (flip) ctx.scale(-1, 1);
    ctx.drawImage(spr, -spr.width / 2, -spr.height / 2 - 2);
    ctx.restore();
    ctx.globalAlpha = 0.3 * k;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.ellipse(g.x, g.y, 5 + 6 * k, 2, 0, 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

// ============================================================
// PARRY = COUNTER. Enemy projectiles are sent BACK at their
// owners as gleaming golden counter-shots. The direction you
// are moving (or dodging) steers where your counter flies.
// ============================================================
function reflectBullet(G: GameCtx, b: Bullet): void {
  const p = G.player;
  const spd = Math.max(160, Math.hypot(b.vx, b.vy) * 1.3);
  // base: straight back where it came from
  let dir = Math.atan2(-b.vy, -b.vx);
  // your movement steers the counter: dodge/move direction bends it up to ~77deg
  let mvx = p.vx, mvy = p.vy;
  if (p.dodgeT > 0) { mvx = p.ddX * 200; mvy = p.ddY * 200; }
  const mvSpd = Math.hypot(mvx, mvy);
  if (mvSpd > 24) {
    const moveAng = Math.atan2(mvy, mvx);
    let diff = ((moveAng - dir + Math.PI * 3) % TAU) - Math.PI;
    dir += clamp(diff, -1.35, 1.35) * 0.72;
  } else {
    // standing still: snap toward the nearest foe for a satisfying auto-counter
    let best: Ent | null = null, bd = 280 * 280;
    for (const e of G.enemies) {
      if (e.dead) continue;
      const d = (e.x - b.x) ** 2 + (e.y - b.y) ** 2;
      if (d < bd) { bd = d; best = e; }
    }
    if (G.boss && !G.boss.dead) {
      const d = (G.boss.x - b.x) ** 2 + (G.boss.y - b.y) ** 2;
      if (d < bd) { bd = d; best = G.boss; }
    }
    if (best) {
      const want = angTo(b.x, b.y, best.x, best.y);
      let diff = ((want - dir + Math.PI * 3) % TAU) - Math.PI;
      if (Math.abs(diff) < 1.0) dir += diff * 0.85;
    }
  }
  b.team = 'player';
  b.reflected = true;
  b.parryable = false;
  b.hit.clear();
  b.vx = Math.cos(dir) * spd; b.vy = Math.sin(dir) * spd;
  b.dmg *= 2.6;
  b.pierce = Math.max(b.pierce, 2);
  b.life = Math.max(b.life - b.t, 1.15);
  b.color = '#ffd75e'; b.color2 = '#fff8d8';
  b.trail = 0.85;
  b.from = p;
}

export function updatePlayer(G: GameCtx, dt: number): void {
  const p = G.player;
  const inp = G.input;
  p.anim += dt;
  p.flash = Math.max(0, p.flash - dt);
  p.iframes = Math.max(0, p.iframes - dt);
  p.stunT = Math.max(0, p.stunT - dt);
  p.castCd = Math.max(0, p.castCd - dt);
  p.meleeCd = Math.max(0, p.meleeCd - dt);
  p.meleeT = Math.max(0, p.meleeT - dt);
  p.potionCd = Math.max(0, p.potionCd - dt);
  p.dodgeCd = Math.max(0, p.dodgeCd - dt);
  p.parryCd = Math.max(0, p.parryCd - dt);
  p.parryFlash = Math.max(0, p.parryFlash - dt);
  p.recallCd = Math.max(0, p.recallCd - dt);
  p.buffHaste = Math.max(0, p.buffHaste - dt);
  p.castAnimT = Math.max(0, p.castAnimT - dt);
  p.parryReflT = Math.max(0, p.parryReflT - dt);
  if (p.enchant) { p.enchant.t -= dt; if (p.enchant.t <= 0) p.enchant = null; }

  // history for chrono rewind
  p.history.push({ x: p.x, y: p.y });
  if (p.history.length > 170) p.history.shift();

  if (p.dead) return;

  // ---- ward tick ----
  if (p.ward) {
    p.ward.t -= dt;
    if (p.ward.t <= 0) {
      burst(G, p.x, p.y, elColor(p.ward.el), 8, 50);
      p.ward = null;
    } else {
      if (p.ward.el === 'radiant') p.hp = Math.min(p.maxHp, p.hp + 1.6 * dt);
      if (p.ward.el === 'time') {
        for (const b of G.bullets) {
          if (b.team === 'enemy' && dist(b.x, b.y, p.x, p.y) < 58) {
            b.vx *= 1 - 2.4 * dt; b.vy *= 1 - 2.4 * dt;
          }
        }
      }
    }
  }

  // ---- movement input ----
  let mx = 0, my = 0;
  if (inp.keys.has('a') || inp.keys.has('arrowleft')) mx -= 1;
  if (inp.keys.has('d') || inp.keys.has('arrowright')) mx += 1;
  if (inp.keys.has('w') || inp.keys.has('arrowup')) my -= 1;
  if (inp.keys.has('s') || inp.keys.has('arrowdown')) my += 1;
  if (inp.touch && inp.joyActive) { mx += inp.joyX; my += inp.joyY; }
  const ml = Math.hypot(mx, my);
  if (ml > 1) { mx /= ml; my /= ml; }

  const chilled = p.st.chill ? p.st.chill.mult : 1;
  const rooted = p.st.root ? 0 : 1;
  const tileMul = tileSpeedMult(G, p.x, p.y);
  // ALACRITY ranks: +3% move speed each · RELIC: thief-moon greaves
  const alacrity = universalRank(G, 'alacrity');
  const baseSpeed = 118 * chilled * rooted * tileMul * (1 + 0.03 * alacrity) * (1 + clamp(relicVal(G, 'moveSpeed'), 0, 0.15));

  // ---- dodge roll — THE FEELING. Ghosts, speed lines, zoom punch, ----
  // ---- an elemental trail that bites, and a landing that lands.   ----
  const wantDodge = inp.pressed.has(' ') || inp.pressed.has('shift') || inp.tDodge;
  if (wantDodge && p.dodgeT <= 0 && p.dodgeCd <= 0 && p.stunT <= 0) {
    const reflex = universalRank(G, 'reflex');
    // RELIC: the wind's debt — the gale owes you a favor
    const cost = Math.max(12, Math.round((G.prog.sigils.includes('aeon') ? 19 : 27) * (1 - 0.05 * reflex)) - Math.round(relicVal(G, 'dashStam')));
    if (p.stam >= cost) {
      p.stam -= cost;
      p.stamRegenT = 0.55;
      p.dodgeT = 0.34;
      p.dashed = true;
      p.dodgeCd = 0.12 * (1 - 0.05 * reflex);
      if (ml > 0.1) { p.ddX = mx / Math.max(ml, 0.001); p.ddY = my / Math.max(ml, 0.001); }
      else {
        const a = angTo(p.x, p.y, inp.wx, inp.wy);
        p.ddX = Math.cos(a); p.ddY = Math.sin(a);
      }
      const dashEl = activeElement(G);
      const dc = elColor(dashEl);
      // SHADOW BLADE: dodging is breathing — mana pours back
      if (G.prog.cls === 'shadowblade') {
        p.mana = Math.min(p.maxMana, p.mana + 15);
        addText(G, p.x, p.y - 20, '+15 mp', '#7a5ea8', 4);
      }
      G.audio.sfx('dodge');
      G.audio.sfx('dashBoost', randR(0.9, 1.15), 0.55);
      // zoom punch — the world flinches
      G.kickZoom = Math.max(G.kickZoom, 0.055);
      // speed lines tearing backwards
      for (let i = 0; i < 12; i++) {
        const spread = randR(-0.55, 0.55);
        const sa = Math.atan2(-p.ddY, -p.ddX) + spread;
        spawnParticle(G, {
          x: p.x + Math.cos(sa) * randR(4, 14), y: p.y + randR(-6, 6) + Math.sin(sa) * randR(4, 14),
          vx: Math.cos(sa) * randR(160, 300), vy: Math.sin(sa) * randR(160, 300),
          life: randR(0.12, 0.26), size: randR(1.4, 2.6), color: i % 3 === 0 ? '#ffffff' : dc, glow: true,
        });
      }
      // elemental ignition at the takeoff point
      burst(G, p.x, p.y, dc, 10, 110, { glow: true, life: 0.35 });
      addRing(G, p.x, p.y, 3, 190, dc, 0.28, 1.6);
    }
  }

  if (p.dodgeT > 0) {
    p.dodgeT -= dt;
    const k = clamp(p.dodgeT / 0.34, 0, 1);
    const speed = 90 + 230 * k;
    const reflex = universalRank(G, 'reflex');
    const bonusIframe = 0.015 * reflex + (G.prog.cls === 'chronomancer' ? 0.08 : 0);
    p.iframes = Math.max(p.iframes, p.dodgeT > 0.34 - 0.27 ? 0.02 : p.iframes);
    if (p.dodgeT > 0.34 - 0.27) p.iframes = Math.max(p.iframes, 0.27 - (0.34 - p.dodgeT) + bonusIframe);
    const mv = moveWithCollision(G.world, p.x, p.y, p.ddX * speed, p.ddY * speed, p.r, dt);
    p.x = mv.x; p.y = mv.y;
    // AFTERIMAGES: light echoes of you, everywhere you were
    if (G.frame % 2 === 0) {
      G.ghosts.push({
        x: p.x, y: p.y, face: p.ddX >= 0 ? 1 : -1,
        frame: Math.floor(p.anim * 14) % 4, t: 0, dur: 0.42,
        el: activeElement(G), walk: true,
      });
    }
    // elemental embers curling off the dash
    const dc = elColor(activeElement(G));
    if (G.frame % 2 === 0) {
      spawnParticle(G, {
        x: p.x + randR(-4, 4), y: p.y + randR(-2, 6),
        vx: -p.ddX * randR(30, 80) + randR(-16, 16), vy: -p.ddY * randR(30, 80) + randR(-16, 16) - 14,
        life: randR(0.25, 0.5), size: randR(1.6, 2.8), color: Math.random() > 0.4 ? dc : '#ffffff', glow: true,
      });
    }
  } else if (p.dashed) {
    // LANDING: the world feels you arrive
    p.dashed = false;
    const dc = elColor(activeElement(G));
    burst(G, p.x, p.y + 3, '#9e968a', 7, 60, { life: 0.3, size: 2 });
    burst(G, p.x, p.y, dc, 8, 90, { glow: true, life: 0.35 });
    shake(G, 0.7);
    // the elemental trail BITES: a burning wake of your attuned school
    if (!p.dead) {
      const slotId = G.prog.loadout[p.activeSlot];
      const def = slotId ? spellDef(slotId) : null;
      if (def) {
        const trailEl = activeElement(G);
        spawnZone(G, {
          kind: 'field', x: p.x, y: p.y, r: 15, dur: 0.6, el: trailEl, team: 'player',
          dmg: spellDamage(G, def) * 0.3, tick: 0.2, owner: p,
        });
      }
    }
  } else {
    // normal movement
    p.vx += mx * baseSpeed * dt * 9;
    p.vy += my * baseSpeed * dt * 9;
    p.vx *= 1 - clamp(10 * dt, 0, 0.9);
    p.vy *= 1 - clamp(10 * dt, 0, 0.9);
    const sp = Math.hypot(p.vx, p.vy);
    const maxS = baseSpeed;
    if (sp > maxS) { p.vx = (p.vx / sp) * maxS; p.vy = (p.vy / sp) * maxS; }
    if (p.stunT <= 0) {
      const mv = moveWithCollision(G.world, p.x, p.y, p.vx, p.vy, p.r, dt);
      p.x = mv.x; p.y = mv.y;
    }
    if (ml > 0.1) p.face = mx !== 0 ? (mx > 0 ? 1 : -1) : p.face;
  }

  // ---- parry (SOULCRYST HARD RULES) ----
  // PERFECT (the first ~0.045s): negate everything, reflect bullets, dopamine.
  // NORMAL (the rest of the ~0.10s window): you BLOCK — the shot dies, but
  //   chip damage bleeds through and nothing is reflected.
  // WHIFF: a long, exhausted recovery. Every attempt costs stamina; spam F
  //   and you will be standing naked in a bullet sea.
  const warding = universalRank(G, 'warding');
  const wantParry = inp.rmbPress || inp.pressed.has('f') || inp.tParry;
  if (wantParry && p.parryCd <= 0 && p.stunT <= 0) {
    const parryCost = Math.max(2, 8 - Math.round(relicVal(G, 'parryStam'))); // RELIC: the quiet edge
    if (p.stam >= parryCost) {
      p.stam -= parryCost;
      p.stamRegenT = 0.5;
      p.parryT = 0.10 + 0.006 * warding;
      p.parryCd = 0.30;          // fast retry — IF you connect
      p.perfectT = 0.042 + 0.003 * warding;   // the frame-perfect core
      p.parryHits = 0;
      G.audio.sfx('ui', 1.6, 0.35);
    } else {
      // too exhausted to even raise the blade
      p.parryCd = 0.55;
      addText(G, p.x, p.y - 12, 'exhausted', '#8a8098', 4);
      G.audio.sfx('whiff', 0.8, 0.4);
    }
  }
  if (p.parryT > 0) {
    p.parryT -= dt;
    p.perfectT -= dt;
    p.parryFlash = 0.1;
    // COUNTER: deflect bullets that are basically touching you
    for (const b of G.bullets) {
      if (b.team !== 'enemy' || b.dead || b.reflected) continue;
      if (dist(b.x, b.y, p.x, p.y) < 24 + b.r) {
        const wasParryable = b.parryable;
        const perfect = p.perfectT > 0;
        const bx = b.x, by = b.y;
        if (perfect) {
          // ---- PERFECT: reflect, dopamine, punish ----
          reflectBullet(G, b);
          p.parryHits++;
          p.parryReflT = 0.18;
          addRing(G, bx, by, 4, 190, '#ffd75e', 0.3, 2.5);
          burst(G, bx, by, '#ffd75e', 14, 150, { glow: true });
          if (wasParryable) {
            G.hitstop = Math.max(G.hitstop, 0.07);
            slowmo(G, 0.34, 0.3);
            screenFlash(G, '#fff8d8', 0.3);
            G.audio.sfx('reflect', 1);
            G.audio.sfx('parry', 1.9, 0.9);
            addText(G, p.x, p.y - 16, 'PERFECT PARRY!', '#ffd75e', 8, true);
            bumpCombo(G);
            shake(G, 2.4);
            p.mana = Math.min(p.maxMana, p.mana + 14);
            addRing(G, p.x, p.y - 1, 8, 260, '#fff8d8', 0.35, 3);
            // golden counter-nova: everything nearby gets punished
            explosion(G, p.x, p.y, 46, 16 + G.prog.lvl * 1.4, 'radiant', 'player', { from: p });
            p.buffHaste = Math.max(p.buffHaste, 1.2);
            b.dmg *= 1.7;
            addText(G, p.x, p.y - 26, '+FLOW', '#fff8d8', 4);
            burst(G, p.x, p.y, '#fff8d8', 22, 180, { glow: true });
            const boss = G.boss;
            if (boss && !boss.dead && dist(boss.x, boss.y, p.x, p.y) < 340) {
              parryBossHit(G, boss);
            }
          } else {
            G.audio.sfx('parry', 1.4, 0.5);
            addText(G, p.x, p.y - 16, 'COUNTER', '#fff8d8', 4);
          }
        } else {
          // ---- NORMAL: a guarded block — chip bleeds through, no reflect ----
          b.dead = true;
          b.hit.add(p);
          p.parryHits++;
          p.parryReflT = 0.1;
          burst(G, bx, by, '#d8d2c0', 10, 100, { glow: true });
          addRing(G, bx, by, 3, 120, '#d8d2c0', 0.22, 1.6);
          G.audio.sfx('clang', 1.1, 0.7);
          addText(G, p.x, p.y - 14, 'BLOCKED', '#c9c2b0', 5);
          p.mana = Math.min(p.maxMana, p.mana + 5);
          damagePlayer(G, Math.max(3, b.dmg * 0.35), b.el);
        }
      }
    }
    if (p.parryT <= 0 && p.parryHits === 0) {
      // WHIFF — a long, punishable recovery + the stamina is gone for nothing
      p.stam = Math.max(0, p.stam - 6);
      p.parryCd = Math.max(p.parryCd, Math.max(0.85, 1.25 - 0.07 * warding));
      G.audio.sfx('whiff', 1, 0.8);
      addText(G, p.x, p.y - 14, 'whiff', '#8a8098', 4);
      burst(G, p.x, p.y - 6, '#8a8098', 5, 50, { life: 0.3 });
    }
  }

  // ---- melee (staff) ----
  if ((inp.pressed.has('v') || (inp.touch && inp.tCast && false)) && p.meleeCd <= 0 && p.stunT <= 0) {
    p.meleeCd = 0.42;
    p.meleeT = 0.18;
    G.audio.sfx('melee');
    const a = angTo(p.x, p.y, inp.wx, inp.wy);
    const dmg = 12 + G.prog.lvl * 0.9;
    let hitAny = false;
    const hitOne = (e: Ent, isBoss: boolean): void => {
      if (dist(p.x, p.y, e.x, e.y) < 34 + e.r) {
        const da = Math.abs(((angTo(p.x, p.y, e.x, e.y) - a + Math.PI * 3) % TAU) - Math.PI);
        if (da < 0.75) {
          hitAny = true;
          if (isBoss) return; // boss melee handled via bullet-less path below
          if (p.enchant) {
            damageEnemy(G, e as never, dmg * 2.2, p.enchant.el, { from: p });
          } else {
            damageEnemy(G, e as never, dmg, null, { from: p });
          }
          const ka = angTo(p.x, p.y, e.x, e.y);
          e.vx += Math.cos(ka) * 180; e.vy += Math.sin(ka) * 180;
        }
      }
    };
    for (const e of G.enemies) { if (!e.dead) hitOne(e, false); }
    const boss = G.boss;
    if (boss && !boss.dead && boss.state !== 'intro') {
      if (dist(p.x, p.y, boss.x, boss.y) < 40 + boss.r) {
        const da = Math.abs(((angTo(p.x, p.y, boss.x, boss.y) - a + Math.PI * 3) % TAU) - Math.PI);
        if (da < 0.8) {
          hitAny = true;
          fxDamageBoss(G, boss as unknown as Ent & { hp: number }, dmg * (p.enchant ? 2.2 : 1), p.enchant?.el ?? null, false);
        }
      }
    }
    if (hitAny) shake(G, 0.8);
  }

  // ---- potion (HARD MODE: vials mend less) ----
  if ((inp.pressed.has('r') || inp.tPotion) && p.potionCd <= 0) {
    if (G.prog.vials > 0 && p.hp < p.maxHp) {
      G.prog.vials--;
      p.potionCd = 1;
      p.hp = Math.min(p.maxHp, p.hp + 34);
      addText(G, p.x, p.y - 14, '+34', '#8effa8', 6);
      burst(G, p.x, p.y - 4, '#ff8a9e', 8, 50, { dir: -Math.PI / 2, spread: 0.9 });
      G.audio.sfx('potion');
      G.uiV++;
    } else if (G.prog.draughts > 0 && p.mana < p.maxMana) {
      G.prog.draughts--;
      p.potionCd = 0.6;
      p.mana = Math.min(p.maxMana, p.mana + 40);
      addText(G, p.x, p.y - 14, '+40 mp', '#5ee8c9', 5);
      G.audio.sfx('potion', 1.3);
      G.uiV++;
    }
  }

  // ---- recall (return to shrine) ----
  if (inp.pressed.has('t') && p.recallCd <= 0 && !G.gate) {
    p.recallT = 1.2;
    addText(G, p.x, p.y - 20, 'recalling...', '#b8a8e8', 5);
  }
  if (p.recallT > 0) {
    p.recallT -= dt;
    p.vx = 0; p.vy = 0;
    if (G.frame % 6 === 0) spawnParticle(G, { x: p.x + randR(-8, 8), y: p.y + randR(-8, 8), vy: -30, life: 0.6, size: 2, color: '#b8a8e8', glow: true });
    if (p.recallT <= 0) {
      p.x = G.prog.shrineX; p.y = G.prog.shrineY;
      p.iframes = 1;
      p.recallCd = 30;
      burst(G, p.x, p.y, '#b8a8e8', 16, 90);
      G.audio.sfx('blink', 0.6);
    }
  }

  // ---- casting ----
  const wantCast = inp.lmb || inp.lmbPress || inp.tCast;
  if (wantCast && p.castCd <= 0 && p.stunT <= 0 && p.recallT <= 0) {
    const slots = attuneSlots(G);
    if (p.activeSlot >= slots) p.activeSlot = 0;
    const id = G.prog.loadout[p.activeSlot];
    if (id) {
      const def = spellDef(id);
      if (def) castSpell(G, def, inp.wx, inp.wy);
    }
  }

  // ---- regen (HARD MODE: slower wells; FOCUS ranks widen them) ----
  p.manaRegenT = Math.max(0, p.manaRegenT - dt);
  if (p.manaRegenT <= 0) {
    const mult = G.prog.sigils.includes('tide') ? 1.35 : 1;
    p.mana = Math.min(p.maxMana, p.mana + (G.cheat.infiniteMana ? 999 : 3.8 + 0.35 * universalRank(G, 'focus')) * mult * dt + relicVal(G, 'manaRegen') * dt);
  }
  p.stamRegenT = Math.max(0, p.stamRegenT - dt);
  if (p.stamRegenT <= 0) p.stam = Math.min(p.maxStam, p.stam + 30 * (1 + relicVal(G, 'stamRegen')) * dt);
  // RELIC: the hollow lantern — grief, burned as fuel
  const hpr = relicVal(G, 'hpRegen');
  if (hpr > 0) p.hp = Math.min(p.maxHp, p.hp + hpr * dt);
}

// ---------- rendering ----------
export function drawPlayer(G: GameCtx): void {
  const p = G.player;
  const ctx = G.ctx;
  if (p.dead) return;
  const walking = Math.hypot(p.vx, p.vy) > 14 || p.dodgeT > 0;
  let spr: HTMLCanvasElement;
  let bob = 0;
  if (walking) {
    const f = Math.floor(p.anim * 9) % 4;
    spr = [SPR.player_walk0, SPR.player_walk1, SPR.player_walk2, SPR.player_walk3][f];
    bob = [0, -1, 0, -1][f];
  } else {
    spr = SPR.player_idle;
    bob = Math.floor(p.anim * 1.8) % 2; // subtle idle breathing
  }
  const flip = p.face < 0;

  // dodge afterimages
  if (p.dodgeT > 0) {
    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.translate(Math.round(p.x - p.ddX * 12), Math.round(p.y - p.ddY * 12));
    ctx.drawImage(flip ? SPR.player_idle_flip : SPR.player_idle, -6, -8);
    ctx.restore();
  }

  ctx.save();
  ctx.translate(Math.round(p.x), Math.round(p.y) + bob);
  // shadow
  ctx.globalAlpha = 0.3; ctx.fillStyle = '#000';
  ctx.beginPath(); ctx.ellipse(0, 7 - bob, 6, 2.2, 0, 0, TAU); ctx.fill();
  ctx.globalAlpha = p.iframes > 0 && Math.sin(G.time * 30) > 0 ? 0.4 : 1;
  if (flip) ctx.scale(-1, 1);
  ctx.drawImage(spr, -spr.width / 2, -spr.height / 2 - 2);
  if (p.flash > 0) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(p.flash * 5, 0, 1);
    ctx.drawImage(spr, -spr.width / 2, -spr.height / 2 - 2);
    ctx.globalCompositeOperation = 'source-over';
  }
  ctx.restore();

  // staff toward aim
  const inp = G.input;
  const a = angTo(p.x, p.y, inp.wx, inp.wy);
  const sx = p.x + Math.cos(a) * 9, sy = p.y - 2 + Math.sin(a) * 9;
  ctx.strokeStyle = '#5a4a30';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(p.x + Math.cos(a) * 3, p.y - 1 + Math.sin(a) * 3);
  ctx.lineTo(sx, sy);
  ctx.stroke();
  const activeId = G.prog.loadout[p.activeSlot];
  const activeDef = activeId ? spellDef(activeId) : null;
  const orbCol = activeDef ? elColor(p.enchant?.el ?? activeDef.el) : '#b8a8e8';
  const casting = p.castAnimT > 0;
  const orbR = 2.2 + Math.sin(G.time * 6) * 0.6 + (casting ? p.castAnimT * 22 : 0);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = orbCol;
  ctx.globalAlpha = 0.85;
  ctx.beginPath(); ctx.arc(sx, sy, orbR, 0, TAU); ctx.fill();
  if (casting) {
    // muzzle flare while the spell leaves the staff
    ctx.globalAlpha = clamp(p.castAnimT * 4, 0, 0.8);
    ctx.strokeStyle = orbCol;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(sx, sy, orbR + 3 + (0.22 - p.castAnimT) * 40, 0, TAU); ctx.stroke();
  }
  ctx.restore();

  // ward bubble
  if (p.ward) {
    const c = elColor(p.ward.el);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.25 + 0.1 * Math.sin(G.time * 5);
    ctx.strokeStyle = c;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(p.x, p.y - 1, 13 + Math.sin(G.time * 4) * 1.2, 0, TAU); ctx.stroke();
    ctx.globalAlpha = 0.08;
    ctx.fillStyle = c;
    ctx.beginPath(); ctx.arc(p.x, p.y - 1, 13, 0, TAU); ctx.fill();
    // ward hp arc
    ctx.globalAlpha = 0.85;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(p.x, p.y - 1, 15, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(p.ward.amt / p.ward.maxAmt, 0, 1));
    ctx.stroke();
    ctx.restore();
  }

  // parry flash — a tight double arc: outer gold, inner white while the
  // frame-perfect core is still live
  if (p.parryFlash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(p.parryFlash * 8, 0, 1);
    ctx.strokeStyle = '#ffd75e';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(p.x, p.y - 1, 14 + (0.22 - p.parryT) * 60, 0, TAU); ctx.stroke();
    if (p.perfectT > 0) {
      ctx.globalAlpha = clamp(p.perfectT * 16, 0, 1);
      ctx.strokeStyle = '#fff8d8';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(p.x, p.y - 1, 9, 0, TAU); ctx.stroke();
    }
    ctx.restore();
  }

  // counter flash: golden slash arc when a bullet is sent back
  if (p.parryReflT > 0) {
    const a2 = angTo(p.x, p.y, inp.wx, inp.wy);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(p.parryReflT * 6, 0, 1);
    ctx.strokeStyle = '#fff8d8';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(p.x, p.y - 1, 19, a2 - 1.1, a2 + 1.1);
    ctx.stroke();
    ctx.globalAlpha = clamp(p.parryReflT * 4, 0, 0.6);
    ctx.strokeStyle = '#ffd75e';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(p.x, p.y - 1, 15, a2 - 0.7, a2 + 0.7);
    ctx.stroke();
    ctx.restore();
  }

  // melee arc
  if (p.meleeT > 0) {
    const a2 = angTo(p.x, p.y, inp.wx, inp.wy);
    ctx.save();
    ctx.globalAlpha = clamp(p.meleeT * 6, 0, 1);
    ctx.strokeStyle = p.enchant ? elColor(p.enchant.el) : '#e8e4d4';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(p.x, p.y - 1, 26, a2 - 0.7, a2 + 0.7);
    ctx.stroke();
    ctx.restore();
  }
}

// crosshair
export function drawCrosshair(G: GameCtx): void {
  if (G.input.touch) return;
  const ctx = G.ctx;
  const { mx, my } = G.input;
  const activeId = G.prog.loadout[G.player.activeSlot];
  const def = activeId ? spellDef(activeId) : null;
  const c = def ? elColor(def.el) : '#e8e4d4';
  ctx.save();
  ctx.strokeStyle = c;
  ctx.globalAlpha = 0.9;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(mx - 5, my); ctx.lineTo(mx - 2, my);
  ctx.moveTo(mx + 2, my); ctx.lineTo(mx + 5, my);
  ctx.moveTo(mx, my - 5); ctx.lineTo(mx, my - 2);
  ctx.moveTo(mx, my + 2); ctx.lineTo(mx, my + 5);
  ctx.stroke();
  ctx.globalAlpha = 0.35;
  ctx.beginPath(); ctx.arc(mx, my, 1.5, 0, TAU); ctx.stroke();
  ctx.restore();
}
