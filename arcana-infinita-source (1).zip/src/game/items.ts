/* ============================================================
   items.ts — RELICS OF THE WEALD (Task 8-d)
   Passive trinkets found in the deep places: boss hoards,
   barrow delves, elite corpses, statue realms, village peddlers.
   Equip up to three. Effects are data-driven: each relic carries
   a `vals` map of stat keys; hook sites in fx / casting / player /
   enemies call relicVal(G, key) and sum across EQUIPPED relics.

   Echo Shards — pale fragments the dead leave behind — are the
   statue-ring currency (statues.ts).
   ============================================================ */
import { randR, chance, type GameCtx } from './core';

export interface RelicDef {
  id: string;
  name: string;
  desc: string;
  rarity: 'common' | 'rare' | 'cursed' | 'mythic';
  color: string;
  glyph: string;
  vals?: Record<string, number>;
}

export const RELICS: Record<string, RelicDef> = {
  // ---------- common ----------
  lens: {
    id: 'lens', name: 'Arcane Lens', glyph: '◈', rarity: 'common', color: '#c9b0f2',
    desc: 'Spells strike 8% harder.', vals: { spellDmg: 0.08 },
  },
  lantern: {
    id: 'lantern', name: 'The Hollow Lantern', glyph: '☼', rarity: 'common', color: '#ffd75e',
    desc: 'A flame that mourns. Mends 0.8 HP/s.', vals: { hpRegen: 0.8 },
  },
  greaves: {
    id: 'greaves', name: 'Thief-Moon Greaves', glyph: '»', rarity: 'common', color: '#9ee8b0',
    desc: 'Move 8% faster.', vals: { moveSpeed: 0.08 },
  },
  coil: {
    id: 'coil', name: 'Serpent Coil Ring', glyph: '§', rarity: 'common', color: '#e2552e',
    desc: '4% of spell damage returns as life.', vals: { lifesteal: 0.04 },
  },
  toll: {
    id: 'toll', name: 'The Toll Collector', glyph: '¤', rarity: 'common', color: '#ffd75e',
    desc: '+15% aether from the slain.', vals: { aetherGain: 0.15 },
  },
  sash: {
    id: 'sash', name: 'Sash of Nine Pockets', glyph: '≡', rarity: 'common', color: '#c9a06e',
    desc: 'Foes drop more vials and draughts.', vals: { lootLuck: 1 },
  },
  lodestone: {
    id: 'lodestone', name: 'Lodestone Heart', glyph: '◉', rarity: 'common', color: '#9a92a8',
    desc: 'Pickups seek you from 30px further.', vals: { magnet: 1 },
  },
  quiet: {
    id: 'quiet', name: 'The Quiet Edge', glyph: '⚔', rarity: 'common', color: '#e8e4d4',
    desc: 'Parries cost 3 less stamina.', vals: { parryStam: 3 },
  },
  skull: {
    id: 'skull', name: "Sage's Hollow Skull", glyph: '☠', rarity: 'common', color: '#c9c2b0',
    desc: '+8% experience from every kill.', vals: { scholar: 0.08 },
  },
  censer: {
    id: 'censer', name: 'Moth-Wing Censer', glyph: 'Ψ', rarity: 'common', color: '#b8a8e8',
    desc: 'A slow smoke. +1.5 mana/s.', vals: { manaRegen: 1.5 },
  },
  // ---------- rare ----------
  unsworn: {
    id: 'unsworn', name: 'Sigil of the Unsworn', glyph: '✶', rarity: 'rare', color: '#c95ee8',
    desc: 'Spell cooldowns shortened by 8%.', vals: { cdMult: 0.08 },
  },
  gear: {
    id: 'gear', name: 'The Unwound Gear', glyph: '⚙', rarity: 'rare', color: '#9ee8ff',
    desc: 'Spells cost 12% less mana.', vals: { manaCost: 0.12 },
  },
  chalice: {
    id: 'chalice', name: 'The Cracked Chalice', glyph: 'Y', rarity: 'rare', color: '#ff8a9e',
    desc: '12% chance a cast refunds its mana.', vals: { manaRefund: 0.12 },
  },
  scales: {
    id: 'scales', name: 'Scales of the Kindly One', glyph: '⚖', rarity: 'rare', color: '#8effa8',
    desc: 'Take 8% less damage.', vals: { damageReduction: 0.08 },
  },
  aegis: {
    id: 'aegis', name: 'The Gossamer Aegis', glyph: '❖', rarity: 'rare', color: '#ffe8f7',
    desc: '8% chance a wound raises a 2s ward.', vals: { wardOnHit: 1 },
  },
  thread: {
    id: 'thread', name: 'Threadneedle Charm', glyph: '✂', rarity: 'rare', color: '#ffd75e',
    desc: 'Grazes grant +0.5 mana.', vals: { grazeMana: 0.5 },
  },
  tooth: {
    id: 'tooth', name: "Salamander's Tooth", glyph: 'Δ', rarity: 'rare', color: '#ff9e4e',
    desc: 'Your burns burn 15% hotter.', vals: { burnAmp: 0.15 },
  },
  tithe: {
    id: 'tithe', name: 'The Grey Tithe', glyph: '†', rarity: 'rare', color: '#b8b0c0',
    desc: 'Every kill mends 2 HP.', vals: { healOnKill: 2 },
  },
  // ---------- mythic ----------
  prism: {
    id: 'prism', name: 'The Infinite Prism', glyph: '◇', rarity: 'mythic', color: '#ffe8f7',
    desc: 'Spells strike 12% harder. Stacks with lesser lenses.', vals: { spellDmg: 0.12 },
  },
  godshard: {
    id: 'godshard', name: 'Echo of a Dead God', glyph: '☄', rarity: 'mythic', color: '#e85eff',
    desc: '6% chance kills weep echo shards.', vals: { echoLuck: 1 },
  },
  winddebt: {
    id: 'winddebt', name: "The Wind's Debt", glyph: '≈', rarity: 'mythic', color: '#9ee8d8',
    desc: 'Dodges cost 3 less stamina.', vals: { dashStam: 3 },
  },
  girdle: {
    id: 'girdle', name: 'Storm-Knot Girdle', glyph: 'Ω', rarity: 'mythic', color: '#ffd75e',
    desc: '+25% stamina regeneration.', vals: { stamRegen: 0.25 },
  },
};

export const RARITY_COLOR: Record<string, string> = {
  common: '#c9c2b0',
  rare: '#8ee8ff',
  cursed: '#e85eff',
  mythic: '#ffd75e',
};

export const RARITY_LABEL: Record<string, string> = {
  common: 'Common',
  rare: 'Rare',
  cursed: 'Cursed',
  mythic: 'Mythic',
};

// sum of the named stat across all EQUIPPED relics (0 when none match)
export function relicVal(G: GameCtx, key: string): number {
  let v = 0;
  for (const id of G.prog.equipped) {
    if (!id) continue;
    const def = RELICS[id];
    if (def?.vals && typeof def.vals[key] === 'number') v += def.vals[key];
  }
  return v;
}

export function equippedRelics(G: GameCtx): RelicDef[] {
  const out: RelicDef[] = [];
  for (const id of G.prog.equipped) {
    if (id && RELICS[id]) out.push(RELICS[id]);
  }
  return out;
}

// grant into the collection; auto-equip into the first free slot
export function grantRelic(G: GameCtx, id: string): void {
  const def = RELICS[id];
  if (!def) return;
  if (!G.prog.relics.includes(id)) G.prog.relics.push(id);
  const slot = G.prog.equipped.findIndex((s) => s === null);
  if (slot >= 0) G.prog.equipped[slot] = id;
  G.uiV++;
}

// equip from the satchel panel: validates ownership, moves (never duplicates)
export function equipRelic(G: GameCtx, slot: number, id: string | null): void {
  if (slot < 0 || slot >= G.prog.equipped.length) return;
  if (id) {
    if (!G.prog.relics.includes(id)) return;
    const prev = G.prog.equipped.indexOf(id);
    if (prev >= 0) G.prog.equipped[prev] = G.prog.equipped[slot];
  }
  G.prog.equipped[slot] = id;
  G.uiV++;
}

// weighted rarity roll: common .6 / rare .3 / mythic .1 — unowned only
export function randomUnownedRelicId(G: GameCtx): string | null {
  const pool = Object.values(RELICS).filter((r) => !G.prog.relics.includes(r.id));
  if (!pool.length) return null;
  const roll = Math.random();
  const want = roll < 0.6 ? 'common' : roll < 0.9 ? 'rare' : 'mythic';
  let candidates = pool.filter((r) => r.rarity === want);
  if (!candidates.length) candidates = pool;
  return candidates[Math.floor(Math.random() * candidates.length)].id;
}

// a relic drops! (falls back to 3 echo shards when everything is owned)
export function spawnRelicDrop(G: GameCtx, x: number, y: number, forcedId?: string): void {
  const rid = forcedId ?? randomUnownedRelicId(G);
  if (!rid) {
    spawnEchoDrop(G, x, y, 3);
    return;
  }
  G.pickups.push({
    kind: 'relic', x, y, vx: randR(-20, 20), vy: -34, t: 0, amount: 1, mag: false, relicId: rid,
  });
}

// echo shard drops (statue rematch currency)
export function spawnEchoDrop(G: GameCtx, x: number, y: number, n = 1): void {
  for (let i = 0; i < n; i++) {
    G.pickups.push({
      kind: 'echo', x: x + randR(-6, 6), y: y + randR(-4, 4),
      vx: randR(-24, 24), vy: randR(-44, -12), t: 0, amount: 1, mag: false,
    });
  }
}

// village peddler stock + shop pricing (wired into the shop panel)
export const SHOP_STOCK: Array<{ id: string; cost: number }> = [
  { id: 'lens', cost: 70 },
  { id: 'quiet', cost: 60 },
  { id: 'censer', cost: 80 },
];

export function buyRelicFromShop(G: GameCtx, id: string, cost: number): boolean {
  if (!RELICS[id]) return false;
  if (G.prog.aether < cost) return false;
  G.prog.aether -= cost;
  grantRelic(G, id);
  return true;
}

// rare gated cheat helper
export function cheatRelic(G: GameCtx): void {
  const rid = randomUnownedRelicId(G);
  if (rid) grantRelic(G, rid);
  G.prog.echoes += 3;
  void chance;
}
