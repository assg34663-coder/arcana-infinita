/* ============================================================
   minibosses.ts — FOUR Weaver-grade mini-bosses. Each is a
   unique mechanical identity, all parts are puppet Enemies
   pushed into G.enemies so the ENTIRE damage pipeline works:

   THE CINDER MAW   — a low-slung molten behemoth (salamander /
     tortoise build). Charge-jumps from a crouch tell, shells
     up (80% frontal damage ricochets off, back hits are full)
     and belches magma when flanked. Open maw = 2x weak point.
   THE STORM ROC    — colossal hawk that never lands. Soars a
     banking orbit overhead, dive-bombs along a shortened line
     after a wing-tense tell, fans 9-13 feathers and wind-lance
     crescents. Clip its wings and it crashes for a +50%
     damage thrash window.
   THE BONE CHOIR   — an anatomical bone horror: a real skull
     on a ghostly spine inside a rib aureole. Its hum drags you
     in, its chorus rotates twin beam spokes (the skulls
     snapping to the axis IS the tell), and its core is WARDED
     while 3+ skulls hum. Break the ring and the jaw opens —
     but they regrow.
   THE VAULT MIMIC  — a real treasure-chest predator. Sleeps
     disguised as cache decor, springs at 60px, tongue-grabs
     from behind a keyhole glint, sprays ricocheting coins,
     box-slams — and below 40% HP it turns itself out on
     rib-legs.

   Attacks are Touhou-tight: every strike is preceded by a
   0.4-0.55s SIGN (a glint + gathering motes + a pose shift),
   not a big ground telegraph.

   Singleton state (module-level `active`) — the world only
   ever hosts one mini-boss at a time. Spawn clock, biome
   gating and rewards mirror spider.ts (THE WEAVER).
   ============================================================ */
import {
  TAU, clamp, lerp, dist, angTo, rand, randR, chance,
  type GameCtx, type Enemy, type ElementId, type BiomeId,
} from './core';
import {
  burst, spawnParticle, addText, addRing, addTelegraph, explosion,
  spawnZone, spawnPickup, shake, slowmo, screenFlash, damagePlayer,
  makeBullet,
} from './fx';
import { moveWithCollision, getLocations } from './world';
import { DIFF, tierOfDistance, gainXp, KINDS } from './enemies';
import { SPR } from './sprites';

// ---------- palette ----------
const EMBER = '#ff7a3e';
const EMBER_HI = '#ffd75e';
const OBSIDIAN = '#1c1a24';
const OBSIDIAN_HI = '#3a3648';
const TOAD_SKIN = '#8a3220';
const TOAD_DK = '#5a1e14';
const TOAD_BELLY = '#c98a4e';
const FEATHER = '#e8e4f0';
const ROC_BODY = '#5a6478';
const ROC_DK = '#38404e';
const ROC_WING = '#4a5464';
const STORM_EYE = '#bfe8ff';
const BONE = '#d8d4c8';
const BONE_DK = '#8a8678';
const BONE_OUT = '#26241e';
const VIOLET = '#c9b0f2';
const VIOLET_DK = '#7a5ea8';
const MAW_GLOW = '#ff5a5e';
const GOLD = '#ffd75e';
const WOOD = '#6a4a2a';
const WOOD_DK = '#3e2a16';
const BRASS = '#c9a84e';
const MEAT = '#8e2430';
const TONGUE = '#e87a8e';
const IRON = '#3a3a44';

// ---------- types ----------
export type MiniBossId = 'maw' | 'roc' | 'choir' | 'mimic';

interface MawState {
  which: 'maw';
  body: Enemy;
  facing: number;
  mode: 'prowl' | 'crouch' | 'leap';
  modeT: number;
  jumpCd: number;
  landings: number;
  z: number;
  lx0: number; ly0: number; lx1: number; ly1: number;
  leapT: number; leapDur: number;
  markX: number; markY: number;
  shellT: number;
  behindT: number;
  lastHp: number;
  shellSfxT: number;
  tongueCd: number;
  spitCd: number;
  mouthT: number;
  tAng: number; tLen: number;
  grabT: number;
  bitten: boolean;
  contactT: number;
  signT: number;
  signKind: 'jump' | 'tongue' | 'spit' | 'belch';
  landT: number;
  intro: number;
  dead: boolean;
}

interface RocWing { e: Enemy; side: number; grieved: boolean; }
interface Crescent { x: number; y: number; vx: number; vy: number; t: number; life: number; r: number; dmg: number; }
interface RocState {
  which: 'roc';
  body: Enemy;
  wings: RocWing[];
  orbitAng: number;
  cx: number; cy: number;
  z: number;
  mode: 'orbit' | 'hover' | 'dive' | 'grounded' | 'rise';
  modeT: number;
  crashing: boolean;
  diveAng: number;
  diveHit: boolean;
  atkCd: number;
  thrashT: number;
  contactT: number;
  signT: number;
  pendAtk: 'fan' | 'lance' | '';
  pendAim: number;
  crescents: Crescent[];
  intro: number;
  dead: boolean;
}

interface ChoirSkull { e: Enemy; angOff: number; spd: number; regrowT: number; grieved: boolean; holdR: number; holdSide: number; }
interface ChoirState {
  which: 'choir';
  core: Enemy;
  skulls: ChoirSkull[];
  beam: { t: number; dur: number; ang: number; spin: number; dmgT: number } | null;
  atkCd: number;
  signT: number;
  pendAng: number;
  wardTxtT: number;
  contactT: number;
  intro: number;
  dead: boolean;
}

interface Coin { x: number; y: number; z: number; vz: number; vx: number; vy: number; t: number; bounced: boolean; dmg: number; }
interface Lure { x: number; y: number; t: number; dmg: number; }
interface MimicState {
  which: 'mimic';
  body: Enemy;
  asleep: boolean;
  facing: number;
  mode: 'lurk' | 'hop' | 'slam';
  hopN: number;
  hx0: number; hy0: number; hx1: number; hy1: number;
  hopT: number; hopDur: number;
  z: number;
  atkCd: number;
  coinCd: number;
  tongueT: number;
  tAng: number; tLen: number;
  grabT: number;
  bitten: boolean;
  inverted: boolean;
  lureDropped: boolean;
  contactT: number;
  signT: number;
  pend: 'tongue' | 'coins' | '';
  awakeT: number;
  coins: Coin[];
  lures: Lure[];
  intro: number;
  dead: boolean;
}

type MbState = MawState | RocState | ChoirState | MimicState;

// ---------- singleton state ----------
let active: MbState | null = null;
let mbClock = 80; // the weaver ambushes first; these come later

// biome homes (ambient spawns only)
const MB_BIOMES: Record<MiniBossId, BiomeId[]> = {
  maw: ['volcanic', 'desert', 'wastes'],
  roc: ['grass', 'desert', 'beach', 'tundra'],
  choir: ['wastes', 'darkwood', 'arcane'],
  mimic: ['grass', 'forest', 'darkwood', 'swamp'],
};

const BIOME_ROLL: Partial<Record<BiomeId, Array<[MiniBossId, number]>>> = {
  volcanic: [['maw', 0.7], ['choir', 0.3]],
  desert: [['maw', 0.4], ['roc', 0.4], ['choir', 0.2]],
  wastes: [['choir', 0.45], ['maw', 0.3], ['roc', 0.25]],
  darkwood: [['mimic', 0.45], ['choir', 0.35], ['roc', 0.2]],
  forest: [['mimic', 0.55], ['roc', 0.45]],
  grass: [['roc', 0.45], ['mimic', 0.35], ['choir', 0.2]],
  tundra: [['roc', 0.6], ['choir', 0.4]],
  swamp: [['mimic', 0.6], ['choir', 0.4]],
  beach: [['roc', 0.7], ['mimic', 0.3]],
  arcane: [['choir', 0.6], ['roc', 0.4]],
};

// ---------- exported API ----------
export function miniBossAlive(_G: GameCtx): boolean {
  return !!active;
}

// y-sort key for the orchestrator's y-sorted draw list (like G.spider.body.y)
export function miniBossSortY(_G: GameCtx): number {
  if (!active) return -9999;
  switch (active.which) {
    case 'choir': return active.core.y;
    default: return active.body.y;
  }
}

// which mini-boss fits the ground you're standing on (ambient spawn picker)
export function pickMiniBossForBiome(G: GameCtx): MiniBossId | null {
  const biome = G.world.biomeAt(G.player.x, G.player.y);
  const table = BIOME_ROLL[biome];
  if (!table || table.length === 0) return null;
  let total = 0;
  for (const [, w] of table) total += w;
  let roll = Math.random() * total;
  for (const [id, w] of table) {
    roll -= w;
    if (roll <= 0) return id;
  }
  return table[0][0];
}

export function trySpawnMiniBoss(G: GameCtx, which: MiniBossId, force = false): boolean {
  if (active || G.boss || G.spider || G.player.dead) return false;
  // natural ambushers need live play; the cheat console spawns from 'cheat' mode
  if (G.mode !== 'play' && !(force && G.mode === 'cheat')) return false;
  const tier = tierOfDistance(G, G.player.x, G.player.y);
  const biome = G.world.biomeAt(G.player.x, G.player.y);
  if (!force) {
    if (tier < 2) return false;
    if (!MB_BIOMES[which].includes(biome)) return false;
    // shrines are sanctuaries
    for (const loc of getLocations()) {
      if (loc.kind === 'shrine' && dist(G.player.x, G.player.y, loc.x, loc.y) < 250) return false;
    }
  }
  const spot = findSpot(G);
  const t = Math.min(9, tier);
  switch (which) {
    case 'maw': return spawnMaw(G, spot.x, spot.y, t);
    case 'roc': return spawnRoc(G, spot.x, spot.y, t);
    case 'choir': return spawnChoir(G, spot.x, spot.y, t);
    case 'mimic': return spawnMimic(G, spot.x, spot.y, t, force);
  }
}

// ---------- per-frame update (includes the ambient spawn clock) ----------
export function updateMiniBosses(G: GameCtx, dt: number): void {
  if (!active) {
    // ambush clock — mirrors the weaver's 110-190s cadence
    if (G.mode === 'play' && !G.boss && !G.spider && !G.player.dead) {
      mbClock -= dt;
      if (mbClock <= 0) {
        mbClock = randR(110, 190);
        const which = pickMiniBossForBiome(G);
        if (which) trySpawnMiniBoss(G, which);
      }
    }
    return;
  }
  // the enemy list was wiped under us (death / boss teleport) — abandon quietly
  if (!partsPresent(G, active)) { active = null; return; }
  switch (active.which) {
    case 'maw': updateMaw(G, active, dt); break;
    case 'roc': updateRoc(G, active, dt); break;
    case 'choir': updateChoir(G, active, dt); break;
    case 'mimic': updateMimic(G, active, dt); break;
  }
}

export function drawMiniBosses(G: GameCtx): void {
  if (!active) return;
  switch (active.which) {
    case 'maw': drawMaw(G, active); break;
    case 'roc': drawRoc(G, active); break;
    case 'choir': drawChoir(G, active); break;
    case 'mimic': drawMimic(G, active); break;
  }
}

// ---------- shared helpers ----------
function partsPresent(G: GameCtx, s: MbState): boolean {
  switch (s.which) {
    case 'maw': return G.enemies.includes(s.body);
    case 'roc': return G.enemies.includes(s.body);
    case 'choir': return G.enemies.includes(s.core);
    case 'mimic': return G.enemies.includes(s.body);
  }
}

function makePart(G: GameCtx, kindId: string, x: number, y: number, tier: number, hp: number, passWalls = false): Enemy {
  const k = KINDS[kindId];
  const e: Enemy = {
    x, y, vx: 0, vy: 0, r: k.r,
    hp, maxHp: hp, team: 'enemy', st: {},
    flash: 0, dead: false, deadT: 0, face: 1, anim: rand(0, 9),
    kind: k, tier, elite: null, state: 'chase', aiT: 0, atkT: 0, windup: 0,
    roamX: x, roamY: y, dmgMul: 1, hpMul: 1, contactT: 0, spawnGuard: 0.9,
    puppet: true,
  };
  if (passWalls) e.passWalls = true;
  G.enemies.push(e);
  return e;
}

// the weaver's forgiving landing search — space must never be the reason
// the ambush fails. pass 1: open ground ring; pass 2: any non-ocean; pass 3: hard fallback.
function findSpot(G: GameCtx): { x: number; y: number } {
  const nonOcean = (x: number, y: number) => G.world.biomeAt(x, y) !== 'ocean';
  const nudgeToFree = (x: number, y: number): { x: number; y: number } | null => {
    for (let rr = 0; rr <= 3; rr++) {
      const steps = rr === 0 ? 1 : rr * 8;
      for (let i = 0; i < steps; i++) {
        const a = (i / steps) * TAU;
        const px = x + Math.cos(a) * rr * 8;
        const py = y + Math.sin(a) * rr * 8;
        if (!G.world.solidAt(px, py)) return { x: px, y: py };
      }
    }
    return null;
  };
  for (let i = 0; i < 48; i++) {
    const a = rand(0, TAU);
    const d = randR(150, 260);
    const x = G.player.x + Math.cos(a) * d;
    const y = G.player.y + Math.sin(a) * d;
    if (!nonOcean(x, y)) continue;
    const p = nudgeToFree(x, y);
    if (p) return p;
  }
  for (let i = 0; i < 64; i++) {
    const a = rand(0, TAU);
    const d = randR(90, 420);
    const x = G.player.x + Math.cos(a) * d;
    const y = G.player.y + Math.sin(a) * d;
    if (nonOcean(x, y)) return { x, y };
  }
  return { x: G.player.x + 46, y: G.player.y - 64 };
}

function sched(G: GameCtx, delay: number, fn: () => void): void {
  G.sched.push({ t: delay, fn });
}

function angleLerp(a: number, b: number, t: number): number {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return a + d * t;
}

function segDist(px: number, py: number, x1: number, y1: number, x2: number, y2: number): number {
  const dx = x2 - x1, dy = y2 - y1;
  const l2 = dx * dx + dy * dy;
  if (l2 <= 0.0001) return dist(px, py, x1, y1);
  let t = ((px - x1) * dx + (py - y1) * dy) / l2;
  t = clamp(t, 0, 1);
  return dist(px, py, x1 + dx * t, y1 + dy * t);
}

// the big reward — copied from spider.ts (xp/aether shower + vial + draught + milestone save)
function finale(G: GameCtx, body: Enemy, title: string, sub: string, color: string, el: ElementId, extraAether: number): void {
  const t = body.tier;
  const p = G.player;
  G.banner = { title, sub, t: 0, color };
  gainXp(G, 160 + t * 70);
  G.prog.kills++;
  for (let i = 0; i < 12; i++) {
    spawnPickup(G, 'aether', body.x + randR(-42, 42), body.y + randR(-42, 42), 3 + t);
  }
  for (let i = 0; i < extraAether; i++) {
    spawnPickup(G, 'aether', body.x + randR(-30, 30), body.y + randR(-30, 30), 2 + t);
  }
  spawnPickup(G, 'vial', body.x + randR(-20, 20), body.y + randR(-20, 20));
  spawnPickup(G, 'draught', body.x + randR(-20, 20), body.y + randR(-20, 20));
  explosion(G, body.x, body.y, 60, 0, el, 'enemy', { noDmg: true });
  screenFlash(G, '#1a0a22', 0.5);
  slowmo(G, 0.9, 0.25);
  shake(G, 4);
  G.audio.sfx('die', 0.7);
  G.audio.sfx('roar', 0.5, 0.7);
  G.uiV++;
  try {
    G.prog.x = p.x; G.prog.y = p.y;
    localStorage.setItem('arcana_infinita_save_v1', JSON.stringify(G.prog));
  } catch { /* ignore */ }
}

// ============================================================
// 1) THE CINDER MAW — giant magma toad
// ============================================================
function spawnMaw(G: GameCtx, sx: number, sy: number, t: number): boolean {
  const tScale = 1 + 0.32 * (t - 1);
  const bodyHp = Math.round(680 * tScale * DIFF.hp);
  const body = makePart(G, 'mb_maw', sx, sy + 34, t, bodyHp);
  const s: MawState = {
    which: 'maw', body, facing: angTo(sx, sy, G.player.x, G.player.y),
    mode: 'prowl', modeT: 0, jumpCd: randR(1.3, 2.1), landings: 0, z: 0,
    lx0: 0, ly0: 0, lx1: 0, ly1: 0, leapT: 0, leapDur: 0.5,
    markX: sx, markY: sy, shellT: 0, behindT: 0, lastHp: body.hp, shellSfxT: 0,
    tongueCd: randR(2.8, 4.4), spitCd: randR(2, 3.2), mouthT: 0,
    tAng: 0, tLen: 170, grabT: 0, bitten: false, contactT: 0,
    signT: 0, signKind: 'jump', landT: 0,
    intro: 0.9, dead: false,
  };
  active = s;
  G.banner = { title: 'THE CINDER MAW', sub: 'Something vast croaks beneath the ash', t: 0, color: EMBER };
  G.audio.sfx('roar', 0.62, 1);
  G.audio.sfx('boom', 0.55, 0.9);
  shake(G, 3);
  slowmo(G, 0.5, 0.35);
  burst(G, sx, sy + 10, '#5a4668', 16, 90, { glow: false });
  addRing(G, sx, sy, 8, 170, EMBER, 0.4, 2.5);
  G.uiV++;
  return true;
}

function lobGlob(G: GameCtx, from: Enemy, tx: number, ty: number, tier: number, dmgMul = 1, T = randR(0.7, 0.95)): void {
  const vx = (tx - from.x) / T;
  const vy = (ty - from.y) / T - 0.5 * 170 * T; // gravity compensation
  makeBullet(G, {
    x: from.x, y: from.y, vx, vy, r: 4.5,
    dmg: (8 + tier * 1.8) * DIFF.dmg * dmgMul, el: 'fire', el2: null, team: 'enemy',
    life: T, kind: 'orb', color: EMBER, color2: EMBER_HI, trail: 0.55, from,
    gravity: 170, boomR: 24, boomDmg: (7 + tier * 1.6) * DIFF.dmg * dmgMul,
  });
  addTelegraph(G, { kind: 'circle', x: tx, y: ty, r: 22, dur: T, color: EMBER, team: 'enemy', onDone: () => {} });
  // the glob leaves burning ground where it lands
  sched(G, T + 0.08, () => {
    if (!active || active.which !== 'maw' || active.body !== from) return;
    spawnZone(G, { kind: 'field', x: tx, y: ty, r: 26, dur: 2.6, el: 'fire', el2: null, team: 'enemy', dmg: (4 + tier * 1.4) * DIFF.dmg, tick: 0.5, owner: from });
  });
}

// ---- maw attack executions (fired when the SIGN expires) ----
function fireTongueLash(G: GameCtx, s: MawState): void {
  const body = s.body;
  const p = G.player;
  if (p.dead || s.shellT > 0) return;
  s.tAng = angTo(body.x, body.y, p.x, p.y);
  s.tLen = 180;
  s.mouthT = Math.max(s.mouthT, 0.6);
  addTelegraph(G, {
    kind: 'line', x: body.x, y: body.y, ang: s.tAng, len: s.tLen, w: 9, dur: 0.42, color: TONGUE, team: 'enemy',
    onDone: () => {
      if (active !== s || s.body.dead || p.dead) return;
      s.mouthT = Math.max(s.mouthT, 0.25);
      G.audio.sfx('melee', 0.85, 1);
      const ex = s.body.x + Math.cos(s.tAng) * s.tLen;
      const ey = s.body.y + Math.sin(s.tAng) * s.tLen;
      if (segDist(p.x, p.y, s.body.x, s.body.y, ex, ey) < 15 + p.r) {
        s.grabT = 0.5;
        s.bitten = false;
        addText(G, p.x, p.y - 14, 'GRABBED!', TONGUE, 6, true);
      } else {
        burst(G, ex, ey, TONGUE, 5, 70, { glow: false });
      }
    },
  });
}

function fireSpit(G: GameCtx, s: MawState): void {
  const p = G.player;
  if (p.dead) return;
  s.mouthT = Math.max(s.mouthT, 0.55);
  // 5 lobbed globs (2 added at 65% dmg) — pressure, not a one-shot
  for (let i = 0; i < 5; i++) {
    const jitter = i === 0 ? 0 : randR(26, 48);
    const a = rand(0, TAU);
    lobGlob(G, s.body, p.x + Math.cos(a) * jitter, p.y + Math.sin(a) * jitter, s.body.tier, i < 3 ? 1 : 0.65);
  }
  G.audio.sfx('cast', 0.7, 0.7);
}

function fireBelch(G: GameCtx, s: MawState): void {
  const body = s.body;
  const t = body.tier;
  const n = 18 + Math.floor(rand(0, 5)); // 18-22 globs at two speeds (was 12)
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU + randR(-0.08, 0.08);
    const near = i % 2 === 0; // two speeds: fast close arcs + slow far lobs
    const dd = near ? randR(80, 140) : randR(150, 215);
    lobGlob(G, body, body.x + Math.cos(a) * dd, body.y + Math.sin(a) * dd, t,
      i < 12 ? 1 : 0.65, near ? randR(0.55, 0.68) : randR(0.85, 1.0));
  }
  G.audio.sfx('boom', 0.6, 0.8);
}

function updateMaw(G: GameCtx, s: MawState, dt: number): void {
  const p = G.player;
  const body = s.body;
  const t = body.tier;

  // player fled very far: the maw burrows away
  if (dist(body.x, body.y, p.x, p.y) > 1400) { body.dead = true; active = null; return; }

  // death → the finale
  if (body.dead) {
    if (!s.dead) {
      s.dead = true;
      finale(G, body, 'THE CINDER MAW FELLED', 'The marsh stops boiling', EMBER, 'fire', 0);
      active = null;
    }
    return;
  }

  s.contactT -= dt;
  s.shellSfxT -= dt;
  if (s.mouthT > 0) s.mouthT -= dt;
  if (s.grabT > 0) s.grabT -= dt;
  if (s.shellT > 0) s.shellT -= dt;
  s.jumpCd -= dt;
  s.tongueCd -= dt;
  s.spitCd -= dt;
  s.landT -= dt;

  // ---- intro: it erupts from the ground ----
  if (s.intro > 0) {
    s.intro -= dt;
    const k = clamp(1 - s.intro / 0.9, 0, 1);
    body.y = s.markY + 34 * (1 - k) * (1 - k);
    if (G.frame % 3 === 0) {
      spawnParticle(G, { x: body.x + randR(-16, 16), y: body.y + randR(-4, 10), vy: -30, life: 0.5, size: 2.4, color: '#5a4668', glow: false });
    }
    if (s.intro <= 0) {
      body.y = s.markY;
      explosion(G, body.x, body.y + 6, 36, 0, 'fire', 'enemy', { noDmg: true });
      shake(G, 2.6);
    }
    s.lastHp = body.hp;
    return;
  }

  // ---- attack signs: glint + gathering embers at the maw, then the strike ----
  if (s.signT > 0) {
    s.signT -= dt;
    const smx = body.x + Math.cos(s.facing) * 14, smy = body.y + Math.sin(s.facing) * 14;
    if (G.frame % 4 === 0) signFlow(G, smx, smy, s.signKind === 'belch' ? EMBER : EMBER_HI);
    if (s.signT <= 0) {
      if (s.signKind === 'tongue') fireTongueLash(G, s);
      else if (s.signKind === 'spit') fireSpit(G, s);
      else if (s.signKind === 'belch') fireBelch(G, s);
    }
  }

  const stunned = !!body.st.stun || !!body.st.frozen;

  // ---- tongue grab: pull + bite ----
  if (s.grabT > 0 && !p.dead) {
    const a = angTo(p.x, p.y, body.x, body.y);
    p.vx = Math.cos(a) * 340; p.vy = Math.sin(a) * 340;
    if (!s.bitten && dist(p.x, p.y, body.x, body.y) < body.r + p.r + 6) {
      s.bitten = true;
      damagePlayer(G, (16 + t * 3.2) * DIFF.dmg, 'fire');
      const a2 = angTo(body.x, body.y, p.x, p.y);
      p.vx = Math.cos(a2) * 250; p.vy = Math.sin(a2) * 250;
      shake(G, 3);
      G.audio.sfx('melee', 0.55, 1);
      addText(G, p.x, p.y - 16, 'CHOMP!', EMBER, 7, true);
      burst(G, body.x + Math.cos(angTo(body.x, body.y, p.x, p.y)) * 10, body.y, EMBER_HI, 8, 90, { glow: true });
    }
    if (s.grabT <= 0) { p.vx *= 0.4; p.vy *= 0.4; }
  }

  // ---- shell bookkeeping: 80% of FRONTAL damage ricochets off ----
  if (s.shellT > 0) {
    const delta = s.lastHp - body.hp;
    if (delta > 0) {
      const rel = Math.cos(angTo(body.x, body.y, p.x, p.y) - s.facing);
      if (rel > 0.25 && !p.dead && s.mouthT <= 0) {
        // frontal hit on the carapace: refund 80%, spray harmless ricochet sparks
        body.hp = Math.min(body.maxHp, body.hp + delta * 0.8);
        const ia = angTo(body.x, body.y, p.x, p.y);
        const ix = body.x + Math.cos(ia) * body.r, iy = body.y + Math.sin(ia) * body.r;
        burst(G, ix, iy, GOLD, 6, 130, { dir: ia, spread: 0.7, glow: true, life: 0.3 });
        if (s.shellSfxT <= 0) {
          s.shellSfxT = 0.16;
          G.audio.sfx('clang', 1.15, 0.55);
          if (chance(0.3)) addText(G, ix, iy - 8, 'DEFLECTED', '#c9c2a8', 4);
        }
      } else if (rel < -0.15 && chance(0.25)) {
        addText(G, body.x, body.y - 30, 'CRACKED!', EMBER_HI, 5, true);
      }
    }
    // impatience: a player camping behind the shell gets a MAGMA BELCH
    const rel2 = Math.cos(angTo(body.x, body.y, p.x, p.y) - s.facing);
    if (rel2 < -0.15 && !p.dead) s.behindT += dt;
    else s.behindT = Math.max(s.behindT, 0) - dt * 2;
    if (s.behindT > 1.6 && s.signT <= 0) {
      s.behindT = -3; // grace before the next tantrum
      s.signKind = 'belch';
      s.signT = 0.5; // it inhales: the swell is the tell
      s.mouthT = 1.1;
      addText(G, body.x, body.y - 34, 'MAGMA BELCH', EMBER, 7, true);
      G.audio.sfx('castBig', 0.7, 1);
      shake(G, 2);
    }
    if (s.shellT <= 0) {
      addText(G, body.x, body.y - 30, 'SHELL CRACKS', EMBER_HI, 6, true);
      addRing(G, body.x, body.y, 10, 140, OBSIDIAN_HI, 0.35, 2);
      burst(G, body.x, body.y, OBSIDIAN_HI, 12, 90, { glow: false });
      G.audio.sfx('hit', 0.5, 0.9);
    }
  }
  s.lastHp = body.hp;

  // open mouth = weak point: 2x damage while spitting / lashing / belching
  if (s.mouthT > 0) body.st.amp = { t: 0.5, mult: 2 };

  // ---- facing ----
  const wantFace = angTo(body.x, body.y, p.x, p.y);
  s.facing = angleLerp(s.facing, wantFace, clamp((s.shellT > 0 ? 0.9 : 2.8) * dt, 0, 1));

  // ---- crouch before a leap: the pose itself is the warning ----
  if (s.mode === 'crouch') {
    s.modeT -= dt;
    body.vx *= 0.7; body.vy *= 0.7;
    // the mark tracks you through the crouch — no ground marker, just the tell
    if (!p.dead) {
      s.markX = lerp(s.markX, p.x, clamp(5 * dt, 0, 1));
      s.markY = lerp(s.markY, p.y, clamp(5 * dt, 0, 1));
    }
    if (G.frame % 4 === 0) signFlow(G, body.x + Math.cos(s.facing) * 12, body.y + Math.sin(s.facing) * 12, EMBER_HI);
    if (s.modeT <= 0) {
      s.mode = 'leap';
      s.leapT = 0;
      s.lx0 = body.x; s.ly0 = body.y;
      s.lx1 = s.markX; s.ly1 = s.markY;
      G.audio.sfx('dodge', 0.5, 1);
    }
    return;
  }

  // ---- airborne: arc through the leap (still hittable) ----
  if (s.mode === 'leap') {
    s.leapT += dt;
    const k = clamp(s.leapT / s.leapDur, 0, 1);
    body.x = lerp(s.lx0, s.lx1, k);
    body.y = lerp(s.ly0, s.ly1, k);
    s.z = Math.sin(k * Math.PI) * 46;
    if (!p.dead && body.spawnGuard <= 0 && s.contactT <= 0 && dist(body.x, body.y, p.x, p.y) < body.r + p.r) {
      s.contactT = 0.8;
      damagePlayer(G, (12 + t * 2.2) * DIFF.contact * DIFF.dmg, 'fire');
      const a2 = angTo(body.x, body.y, p.x, p.y);
      p.vx += Math.cos(a2) * 200; p.vy += Math.sin(a2) * 200;
    }
    if (k >= 1) {
      // LANDING: shockwave + shake
      s.mode = 'prowl'; s.z = 0;
      explosion(G, body.x, body.y, 38, (11 + t * 2.2) * DIFF.dmg, 'fire', 'enemy', { from: body });
      addRing(G, body.x, body.y, 8, 220, EMBER, 0.4, 3);
      burst(G, body.x, body.y + 6, '#5a4668', 14, 80, { glow: false });
      shake(G, 3);
      G.audio.sfx('boom', 0.75, 1);
      s.landT = 0.3;
      s.landings++;
      if (s.landings % 2 === 0 && s.shellT <= 0) {
        // SHELLS UP: cracked obsidian carapace
        s.shellT = 3.5;
        s.behindT = 0;
        addText(G, body.x, body.y - 34, 'SHELLS UP', '#c9c2a8', 7, true);
        addRing(G, body.x, body.y, 12, 120, OBSIDIAN_HI, 0.4, 2.5);
        G.audio.sfx('clang', 0.6, 1);
      }
    }
    return;
  }

  // ---- grounded prowling: crawl toward the player ----
  if (!stunned && s.shellT <= 0) {
    const d = dist(body.x, body.y, p.x, p.y);
    const a = angTo(body.x, body.y, p.x, p.y);
    const spd = 26 + t * 2.4;
    if (d > 60) {
      body.vx += Math.cos(a) * spd * dt * 3.4;
      body.vy += Math.sin(a) * spd * dt * 3.4;
    }
    // charge-jump: crouch tell (no ground marker), then arc to the tracked mark
    if (s.jumpCd <= 0 && !p.dead && s.signT <= 0) {
      s.jumpCd = randR(2.7, 4.2);
      s.mode = 'crouch';
      s.modeT = 0.5;
      s.signKind = 'jump';
      s.markX = p.x; s.markY = p.y;
      G.audio.sfx('cast', 0.5, 0.7);
    }
  } else {
    // shelled (or stunned): it tucks and slides to a stop
    body.vx *= 1 - clamp(6 * dt, 0, 0.9);
    body.vy *= 1 - clamp(6 * dt, 0, 0.9);
  }
  const drag = 1 - clamp(5 * dt, 0, 0.9);
  body.vx *= drag; body.vy *= drag;
  if (!stunned) {
    const mv = moveWithCollision(G.world, body.x, body.y, body.vx, body.vy, body.r, dt);
    body.x = mv.x; body.y = mv.y;
  }

  // ---- TONGUE LASH: maw-glint tell, then a shortened line grab ----
  if (s.tongueCd <= 0 && s.shellT <= 0 && !stunned && !p.dead && s.grabT <= 0 && s.signT <= 0) {
    const d = dist(body.x, body.y, p.x, p.y);
    if (d < 200) {
      s.tongueCd = randR(4.4, 6.8);
      s.signKind = 'tongue';
      s.signT = 0.45;
      s.mouthT = 1.0; // mouth hangs open through the tell — the weak point
      addText(G, body.x, body.y - 36, 'WEAK POINT', GOLD, 5, true);
    }
  }

  // ---- SPIT: inhale tell (body swells, maw glows), then 5 lobbed globs ----
  if (s.spitCd <= 0 && s.shellT <= 0 && !stunned && !p.dead && s.signT <= 0) {
    const d = dist(body.x, body.y, p.x, p.y);
    if (d > 110 && d < 360) {
      s.spitCd = randR(3.6, 5.6);
      s.signKind = 'spit';
      s.signT = 0.45;
      s.mouthT = Math.max(s.mouthT, 0.9);
      G.audio.sfx('cast', 0.6, 0.8);
    }
  }

  // ---- grounded contact ----
  if (!p.dead && body.spawnGuard <= 0 && s.contactT <= 0 && dist(body.x, body.y, p.x, p.y) < body.r + p.r) {
    s.contactT = 0.9;
    damagePlayer(G, (13 + t * 2.2) * DIFF.contact * DIFF.dmg, 'fire');
    const a2 = angTo(body.x, body.y, p.x, p.y);
    p.vx += Math.cos(a2) * 170; p.vy += Math.sin(a2) * 170;
  }
}

function drawMaw(G: GameCtx, s: MawState): void {
  const ctx = G.ctx;
  const body = s.body;
  const shelled = s.shellT > 0;
  const crouch = s.mode === 'crouch';
  const airborne = s.mode === 'leap';
  const z = s.z;
  const bx = Math.round(body.x);
  const by = Math.round(body.y - z);
  const fa = s.facing;
  const p = G.player;

  // ---- under-shadow (shrinks while airborne) ----
  ctx.globalAlpha = 0.32 * (1 - z / 90);
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(body.x, body.y + 8, 21 - z * 0.08, 9 - z * 0.03, 0, 0, TAU);
  ctx.fill();
  ctx.globalAlpha = 1;

  // ---- layered render in the beast's facing frame (+x = forward) ----
  const breathe = 1 + Math.sin(G.time * 2.1) * 0.03;
  const inhale = s.signT > 0 && (s.signKind === 'belch' || s.signKind === 'spit')
    ? 1 + 0.07 * Math.sin(clamp(1 - s.signT / 0.5, 0, 1) * Math.PI) : 1;
  const stretch = airborne ? 1.07 : 1;
  const lower = (crouch ? 0.88 : 1) * (shelled ? 0.9 : 1);
  const openK = clamp(s.mouthT / 0.5, 0, 1);
  const la = clamp(angDiff(fa, angTo(body.x, body.y, p.x, p.y)), -0.9, 0.9);

  ctx.save();
  ctx.translate(bx, by);
  ctx.rotate(fa);
  ctx.scale(breathe * inhale * stretch * lower, (breathe * inhale * lower) / stretch);

  // TAIL: 3 tapering segments that sway behind the mass
  for (let i = 0; i < 3; i++) {
    const sway = Math.sin(G.time * 2.6 + i * 1.15) * (1.2 + i * 1.3);
    const tx = -19 - i * 5.5;
    const tr = 5.5 - i * 1.4;
    drawBlob(ctx, tx, sway, tr, tr * 0.72, TOAD_DK);
    drawBlob(ctx, tx, sway - 0.8, tr * 0.8, tr * 0.5, TOAD_SKIN);
    ctx.fillStyle = shelled ? OBSIDIAN : '#6e2a1a';
    ctx.fillRect(Math.round(tx) - 1, Math.round(sway - tr * 0.6), 2, 2);
  }
  glowDot(ctx, -32.5, Math.sin(G.time * 2.6 + 3.45) * 5, 1.6, EMBER, 0.5 + 0.3 * Math.sin(G.time * 5));

  // LEGS: 4 stout 2-segment limbs with 3 planted clawed toes each
  const moving = Math.hypot(body.vx, body.vy) > 6;
  const step = moving ? Math.sin(body.anim * 7) : 0;
  const splay = s.landT > 0 ? 2.2 : 0;
  const legPairs: Array<[number, number, number]> = [
    [9, 7, 17], [9, 7, -17], [-9, -13, 18], [-9, -13, -18],
  ];
  for (let i = 0; i < 4; i++) {
    const hx = legPairs[i][0];
    const side = legPairs[i][2] > 0 ? 1 : -1;
    const bob = moving ? step * (i < 2 ? 2 : -2) : 0;
    const footX = legPairs[i][1] + bob - (airborne ? 7 : 0);
    const footY = side * (Math.abs(legPairs[i][2]) + splay);
    const hipY = side * 6;
    const knee = solveIK(hx, hipY, footX, footY, 8.5, 9.5, side);
    const legCol = shelled ? '#4e2016' : TOAD_DK;
    drawLimb(ctx, hx, hipY, knee.x, knee.y, legCol);
    drawLimb(ctx, knee.x, knee.y, footX, footY, legCol);
    ctx.fillStyle = '#3c150e';
    ctx.fillRect(Math.round(knee.x) - 1, Math.round(knee.y) - 1, 2, 2);
    for (let tn = -1; tn <= 1; tn++) {
      const ta = Math.atan2(footY - knee.y, footX - knee.x) + tn * 0.38 * side;
      ctx.fillStyle = '#2a0d08';
      ctx.fillRect(Math.round(footX + Math.cos(ta) * 3) - 1, Math.round(footY + Math.sin(ta) * 3) - 1, 2, 2);
    }
  }

  // TORSO: wide heavy body, layered with under-side shading
  drawBlob(ctx, 0, 0, 16, 11, TOAD_SKIN);
  drawBlob(ctx, -3, 0, 12, 8.6, TOAD_DK);
  drawBlob(ctx, 7, 0, 8, 7.4, TOAD_BELLY);
  drawBlob(ctx, 9.5, 0, 4.5, 4.6, '#dca45e');
  ctx.fillStyle = 'rgba(90,30,20,0.5)';
  ctx.fillRect(-8, -6, 10, 1.6);
  ctx.fillRect(-8, 4.4, 10, 1.6);

  // DORSAL PLATES: overlapping rounded triangles, ember glow in the gaps
  const plateCol = shelled ? OBSIDIAN : '#5e2416';
  const plateEdge = shelled ? OBSIDIAN_HI : '#7a3420';
  for (let i = 0; i < 6; i++) {
    const px = 11 - i * 5;
    const ry = (shelled ? 6.6 : 5.4) - i * 0.42;
    const rx = (shelled ? 3.6 : 3) - i * 0.18;
    ctx.fillStyle = plateCol;
    ctx.beginPath();
    ctx.moveTo(px + rx + 1.2, 0);
    ctx.quadraticCurveTo(px + rx * 0.4, -ry, px - rx, -ry * 0.3);
    ctx.quadraticCurveTo(px - rx - 1.4, 0, px - rx, ry * 0.3);
    ctx.quadraticCurveTo(px + rx * 0.4, ry, px + rx + 1.2, 0);
    ctx.fill();
    ctx.fillStyle = plateEdge;
    ctx.fillRect(Math.round(px + rx * 0.4), Math.round(-ry * 0.55), 1, 1);
    ctx.fillRect(Math.round(px + rx * 0.4), Math.round(ry * 0.55) - 1, 1, 1);
    if (i < 5) glowDot(ctx, px - rx - 1.6, 0, 1.4, EMBER, 0.4 + 0.3 * Math.sin(G.time * 4 + i));
  }

  // SHELL-UP: the plates rise and interlock into a closed, seamed dome
  if (shelled) {
    drawBlob(ctx, -1, 0, 15.5, 11.5, 'rgba(28,26,36,0.45)');
    ctx.strokeStyle = OBSIDIAN_HI;
    ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.ellipse(-1, 0, 15.5, 11.5, 0, 0, TAU); ctx.stroke();
    ctx.strokeStyle = '#14121c';
    ctx.lineWidth = 1;
    for (let i = 0; i < 4; i++) {
      const sxp = 8 - i * 5.4;
      ctx.beginPath();
      ctx.moveTo(sxp, -9.5);
      ctx.quadraticCurveTo(sxp - 1.5, 0, sxp, 9.5);
      ctx.stroke();
    }
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = EMBER;
    ctx.globalAlpha = 0.55 + 0.3 * Math.sin(G.time * 9);
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < 3; i++) {
      const cxp = 6 - i * 6;
      ctx.moveTo(cxp, -4);
      ctx.lineTo(cxp - 2, 0);
      ctx.lineTo(cxp + 1, 3.5);
      ctx.lineTo(cxp - 1, 7);
    }
    ctx.stroke();
    ctx.restore();
  }

  // HEAD: heavy skull with brow horns, tracking ember eyes, hinged jaw
  drawBlob(ctx, 14, 0, 6.2, 6.6, TOAD_SKIN);
  drawBlob(ctx, 20.5, 0, 7.4, 7, TOAD_SKIN);
  drawBlob(ctx, 18.5, 0, 5, 5.6, TOAD_DK);
  for (const side of [-1, 1]) {
    ctx.fillStyle = OBSIDIAN;
    ctx.beginPath();
    ctx.moveTo(21, side * 4.4);
    ctx.quadraticCurveTo(25.5, side * 6.4, 27.5, side * 8.4);
    ctx.quadraticCurveTo(24.4, side * 5.2, 23, side * 3.6);
    ctx.closePath();
    ctx.fill();
    glowDot(ctx, 27.2, side * 8.1, 1, EMBER, 0.5);
  }
  // eyes in dark sockets — they TRACK the player
  for (const side of [-1, 1]) {
    ctx.fillStyle = '#240b06';
    ctx.beginPath(); ctx.ellipse(22.5, side * 3.4, 2.2, 1.9, side * 0.3, 0, TAU); ctx.fill();
    glowDot(ctx, 22.5 + Math.cos(la) * 1.1, side * 3.4 + Math.sin(la) * 1.1, 1.3, EMBER_HI, crouch ? 1 : 0.85);
    glowDot(ctx, 22.5 + Math.cos(la) * 1.1, side * 3.4 + Math.sin(la) * 1.1, 0.6, '#fff2c0', 0.9);
  }
  ctx.fillStyle = '#2a0d08';
  ctx.fillRect(26.5, -1.6, 1, 1);
  ctx.fillRect(26.5, 0.6, 1, 1);

  // JAW: opens for spit / belch / lash — glowing maw interior + teeth
  const mawX = 25.5;
  if (openK > 0.05) {
    const mry = 4.2 * openK + 1.6;
    drawBlob(ctx, mawX - 1, 0, 4.6 * openK + 2, mry, '#2a0d08');
    drawBlob(ctx, mawX - 1, 0, 3 * openK + 1.4, mry * 0.62, EMBER);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.55 + 0.35 * Math.sin(G.time * 14);
    ctx.fillStyle = EMBER_HI;
    ctx.fillRect(Math.round(mawX - 2), -1.4, 3, 2.8);
    ctx.restore();
    for (let i = -1; i <= 1; i++) {
      drawTooth(ctx, mawX - 1 + i * 2.2, -mry * 0.8, Math.PI / 2, 2.2, BONE);
      drawTooth(ctx, mawX - 1 + i * 2.2, mry * 0.8, -Math.PI / 2, 2.2, BONE);
    }
    drawBlob(ctx, mawX + 1.5, 0, 2.6, mry * 0.7, TOAD_DK);
  } else {
    // closed: heavy lip seam
    ctx.strokeStyle = '#3c150e';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(28.5, 0);
    ctx.quadraticCurveTo(24, 2.6, 19, 1.8);
    ctx.stroke();
  }

  // rim highlights along the flanks
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.2;
  ctx.strokeStyle = EMBER_HI;
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.ellipse(0, 0, 15.4, 10.4, 0, -2.2, -0.9); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(0, 0, 15.4, 10.4, 0, 0.9, 2.2); ctx.stroke();
  ctx.restore();

  // attack signs: the glint rides the crouch (jump) or burns at the maw
  if (crouch) drawGlint(ctx, 26, 0, clamp(1 - s.modeT / 0.5, 0, 1), EMBER_HI);
  else if (s.signT > 0) drawGlint(ctx, 26, 0, clamp(1 - s.signT / 0.5, 0, 1), s.signKind === 'belch' ? EMBER : EMBER_HI);

  ctx.restore();

  // tongue during the lash — tapered, glistening, reaches for its mark
  if (s.mouthT > 0.25 && s.grabT > 0) {
    const mxw = bx + Math.cos(fa) * 24, myw = by + Math.sin(fa) * 24;
    const reach = clamp(1 - s.grabT / 0.5, 0, 1);
    const ex2 = lerp(mxw, p.x, reach), ey2 = lerp(myw, p.y, reach);
    taperRun(ctx, mxw, myw, ex2, ey2, 3, 1.4, TONGUE);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.4;
    taperRun(ctx, mxw, myw + 1, ex2, ey2 + 1, 1, 0.5, '#ffd7e0');
    ctx.restore();
    drawBlob(ctx, ex2, ey2, 2.4, 2.4, TONGUE);
  }

  // hit flash
  if (body.flash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(body.flash * 6, 0, 1);
    drawBlobR(ctx, bx, by, 16, 11, fa, '#ffffff');
    drawBlobR(ctx, bx + Math.cos(fa) * 20, by + Math.sin(fa) * 20, 7.4, 7, fa, '#ffffff');
    ctx.restore();
  }

  // shelled wobble hint (the tantrum is coming)
  if (shelled && Math.abs(s.behindT) < 0.1) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.22 + 0.15 * Math.sin(G.time * 6);
    ctx.strokeStyle = '#c9c2a8';
    ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.arc(bx, by, 20, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  drawMbBar(
    G, bx, by - 34, 'THE CINDER MAW', EMBER, body,
    [body.hp / body.maxHp > 0.75, body.hp / body.maxHp > 0.5, body.hp / body.maxHp > 0.25, body.hp > 0], EMBER_HI,
  );
}

// ============================================================
// 2) THE STORM ROC — colossal hawk that never lands
// ============================================================
function spawnRoc(G: GameCtx, sx: number, sy: number, t: number): boolean {
  const tScale = 1 + 0.32 * (t - 1);
  const wScale = 1 + 0.24 * (t - 1);
  const bodyHp = Math.round(560 * tScale * DIFF.hp);
  const body = makePart(G, 'mb_roc', sx, sy, t, bodyHp);
  const wings: RocWing[] = [];
  for (let i = 0; i < 2; i++) {
    const side = i === 0 ? -1 : 1;
    const wingHp = Math.round(120 * wScale * DIFF.hp);
    const e = makePart(G, 'mb_roc_wing', sx + side * 16, sy, t, wingHp);
    wings.push({ e, side, grieved: false });
  }
  const s: RocState = {
    which: 'roc', body, wings,
    orbitAng: angTo(G.player.x, G.player.y, sx, sy),
    cx: G.player.x, cy: G.player.y,
    z: 150, mode: 'orbit', modeT: 0, crashing: false,
    diveAng: 0, diveHit: false, atkCd: randR(1.8, 2.9), thrashT: 0.5,
    signT: 0, pendAtk: '', pendAim: 0,
    contactT: 0, crescents: [], intro: 0.9, dead: false,
  };
  active = s;
  G.banner = { title: 'THE STORM ROC', sub: 'The sky above you is not empty', t: 0, color: STORM_EYE };
  G.audio.sfx('roar', 1.3, 1);
  G.audio.sfx('thunder', 0.9, 0.8);
  shake(G, 2.4);
  slowmo(G, 0.5, 0.35);
  G.uiV++;
  return true;
}

function featherBullet(G: GameCtx, from: Enemy, ang: number, speed: number, tier: number, dmgMul = 1): void {
  makeBullet(G, {
    x: from.x + Math.cos(ang) * 10, y: from.y + Math.sin(ang) * 10,
    vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed,
    r: 3.5, dmg: (6 + tier * 1.5) * DIFF.dmg * dmgMul, el: 'lightning', el2: null, team: 'enemy',
    life: 2.2, kind: 'shard', color: FEATHER, color2: STORM_EYE, trail: 0.35, from,
    parryable: true, spin: 6,
  });
}

function updateRoc(G: GameCtx, s: RocState, dt: number): void {
  const p = G.player;
  const body = s.body;
  const t = body.tier;

  // player fled very far: it rides the thermal away
  if (dist(body.x, body.y, p.x, p.y) > 1400) {
    body.dead = true;
    for (const w of s.wings) w.e.dead = true;
    active = null;
    return;
  }

  // wing deaths → grief + crash
  for (const w of s.wings) {
    if (w.e.dead && !w.grieved) {
      w.grieved = true;
      burst(G, w.e.x, w.e.y, FEATHER, 14, 110, { glow: false });
      burst(G, w.e.x, w.e.y, STORM_EYE, 8, 90, { glow: true });
      addText(G, w.e.x, w.e.y - 10, 'WING CLIPPED', STORM_EYE, 6, true);
      addRing(G, w.e.x, w.e.y, 5, 130, STORM_EYE, 0.35, 2);
      shake(G, 1.6);
      G.audio.sfx('hit', 0.55, 1);
      if (s.mode !== 'grounded') {
        s.mode = 'grounded';
        s.modeT = 4;
        s.crashing = s.z > 1;
        s.thrashT = 0.6;
      }
    }
  }

  // body death → the finale
  if (body.dead) {
    if (!s.dead) {
      s.dead = true;
      for (const w of s.wings) if (!w.e.dead) { burst(G, w.e.x, w.e.y, FEATHER, 10, 90, { glow: false }); w.e.dead = true; }
      finale(G, body, 'THE STORM ROC FELLED', 'The sky empties', STORM_EYE, 'lightning', 0);
      active = null;
    }
    return;
  }

  body.anim += dt;
  s.contactT -= dt;
  s.atkCd -= dt;

  // ---- intro: stoop out of the sky ----
  if (s.intro > 0) {
    s.intro -= dt;
    const k = clamp(1 - s.intro / 0.9, 0, 1);
    s.z = lerp(150, 16, k * k);
    if (s.intro <= 0) {
      s.z = 16;
      addRing(G, body.x, body.y, 10, 200, STORM_EYE, 0.4, 2);
      burst(G, body.x, body.y, STORM_EYE, 12, 90, { glow: true });
      G.audio.sfx('boom', 1.4, 0.5);
      shake(G, 1.6);
    }
    positionWings(s);
    return;
  }

  const stunned = !!body.st.stun || !!body.st.frozen;
  const deadWings = s.wings.filter((w) => w.e.dead).length;
  const speedMul = Math.pow(0.5, deadWings); // orbit speed halves per dead wing

  // the orbit center eases toward the player
  s.cx = lerp(s.cx, p.x, clamp(3 * dt, 0, 1));
  s.cy = lerp(s.cy, p.y, clamp(3 * dt, 0, 1));

  // ---- grounded thrash phase (from a clipped wing) ----
  if (s.mode === 'grounded') {
    body.st.amp = { t: 0.5, mult: 1.5 }; // +50% damage taken
    if (s.crashing) {
      s.z = Math.max(0, s.z - 300 * dt);
      if (s.z <= 0) {
        s.crashing = false;
        crashImpact(G, s);
      }
    }
    s.modeT -= dt;
    s.thrashT -= dt;
    if (!stunned && s.thrashT <= 0) {
      s.thrashT = 1.15;
      gustNova(G, s, 8, 130, (6 + t * 1.2) * DIFF.dmg);
      G.audio.sfx('cast', 1.5, 0.5);
      shake(G, 1);
    }
    if (s.modeT <= 0 && !s.crashing) {
      // it struggles back into the air with the remaining wings
      s.mode = 'rise';
      s.modeT = 0.8;
      s.orbitAng = angTo(s.cx, s.cy, body.x, body.y);
      addText(G, body.x, body.y - 26, 'AIRBORNE AGAIN', STORM_EYE, 5, true);
      burst(G, body.x, body.y, '#8a92a8', 12, 90, { glow: false });
      G.audio.sfx('dodge', 0.4, 1);
    }
    positionWings(s);
    updateCrescents(G, s, dt);
    return;
  }

  if (s.mode === 'rise') {
    s.modeT -= dt;
    s.z = lerp(0, 16, clamp(1 - s.modeT / 0.8, 0, 1));
    if (s.modeT <= 0) { s.mode = 'orbit'; s.z = 16; }
  }

  // ---- hover before the dive (shadow shrinks) ----
  if (s.mode === 'hover') {
    s.modeT -= dt;
    s.z = lerp(16, 30, clamp(1 - s.modeT / 0.55, 0, 1));
    if (s.modeT <= 0) s.mode = 'orbit'; // the telegraph's onDone launches the dive
    positionWings(s);
    updateCrescents(G, s, dt);
    return;
  }

  // ---- the plunge ----
  if (s.mode === 'dive') {
    s.modeT -= dt;
    s.z = Math.max(0, s.z - 260 * dt);
    body.x += Math.cos(s.diveAng) * 560 * dt;
    body.y += Math.sin(s.diveAng) * 560 * dt;
    if (G.frame % 2 === 0) {
      spawnParticle(G, { x: body.x + randR(-6, 6), y: body.y + randR(-4, 8), vx: 0, vy: 0, life: 0.3, size: 2, color: STORM_EYE, glow: true });
    }
    if (!s.diveHit && !p.dead && body.spawnGuard <= 0 && dist(body.x, body.y, p.x, p.y) < body.r + p.r + 4) {
      s.diveHit = true;
      damagePlayer(G, (15 + t * 2.6) * DIFF.dmg, 'lightning');
      p.vx += Math.cos(s.diveAng) * 300; p.vy += Math.sin(s.diveAng) * 300;
      shake(G, 2.5);
      G.audio.sfx('melee', 0.5, 1);
    }
    if (s.modeT <= 0) {
      // feather shrapnel burst on exit
      for (let i = 0; i < 8; i++) {
        featherBullet(G, body, s.diveAng + Math.PI + randR(-1.2, 1.2), randR(120, 190), t);
      }
      burst(G, body.x, body.y, '#8a92a8', 12, 90, { glow: false });
      addRing(G, body.x, body.y, 6, 160, STORM_EYE, 0.3, 2);
      shake(G, 1.6);
      G.audio.sfx('thunder', 1.6, 0.4);
      s.mode = 'rise';
      s.modeT = 0.55;
      s.orbitAng = angTo(s.cx, s.cy, body.x, body.y);
    }
    positionWings(s);
    updateCrescents(G, s, dt);
    return;
  }

  // ---- orbit: never touches the ground ----
  s.orbitAng += 1.15 * speedMul * dt;
  const R = 150;
  const tx = s.cx + Math.cos(s.orbitAng) * R;
  const ty = s.cy + Math.sin(s.orbitAng) * R;
  body.x = lerp(body.x, tx, clamp(6 * dt, 0, 1));
  body.y = lerp(body.y, ty, clamp(6 * dt, 0, 1));
  if (s.mode === 'orbit') s.z = 16 + Math.sin(body.anim * 2.2) * 4; // rising keeps its own z

  // storm sparks
  if (G.frame % 7 === 0) {
    spawnParticle(G, {
      x: body.x + randR(-20, 20), y: body.y - s.z + randR(-8, 8),
      vx: randR(-14, 14), vy: randR(-10, 4), life: 0.3, size: 1.5, color: STORM_EYE, glow: true,
    });
  }

  // ---- attacks: wing-tense SIGN first, then the strike ----
  if (s.signT > 0) {
    s.signT -= dt;
    if (G.frame % 4 === 0) signFlow(G, body.x + Math.cos(s.pendAim) * 13, body.y + Math.sin(s.pendAim) * 13, STORM_EYE);
    if (s.signT <= 0) {
      const base = angTo(body.x, body.y, p.x, p.y);
      if (s.pendAtk === 'fan') {
        // FEATHER FAN: 9-13 aimed parryable feathers (added ones at 65% dmg)
        const n = 9 + (chance(0.5) ? 2 : 0) + (chance(0.35) ? 2 : 0);
        for (let i = 0; i < n; i++) {
          featherBullet(G, body, base + (i - (n - 1) / 2) * 0.19, randR(165, 195), t, i < 7 ? 1 : 0.65);
        }
        G.audio.sfx('zap', 0.9, 0.8);
      } else if (s.pendAtk === 'lance') {
        // WIND LANCE: 4-5 crescents at two speeds (added ones at 65% dmg)
        const n = 4 + (chance(0.5) ? 1 : 0);
        for (let i = 0; i < n; i++) {
          const a = base + (i - (n - 1) / 2) * 0.24;
          const spd = i % 2 === 0 ? 185 : 130;
          s.crescents.push({
            x: body.x, y: body.y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd,
            t: 0, life: 1.5, r: 15, dmg: (8 + t * 1.7) * DIFF.dmg * (i < 3 ? 1 : 0.65),
          });
        }
        G.audio.sfx('cast', 1.4, 0.6);
      }
    }
  } else if (s.atkCd <= 0 && !stunned && !p.dead && s.mode === 'orbit') {
    s.atkCd = randR(2.9, 4.5) * (deadWings > 0 ? 0.75 : 1);
    const roll = Math.random();
    s.pendAim = angTo(body.x, body.y, p.x, p.y);
    if (roll < 0.4) {
      // FEATHER FAN sign: wings tense, beak glints
      s.pendAtk = 'fan';
      s.signT = 0.45;
      G.audio.sfx('cast', 0.7, 1.1);
    } else if (roll < 0.74) {
      // WIND LANCE sign: wings tense, gale gathers at the beak
      s.pendAtk = 'lance';
      s.signT = 0.45;
      G.audio.sfx('cast', 0.7, 0.9);
    } else {
      // DIVE BOMB: the hover IS the sign (wings sweep, talons drop) — shortened line
      s.mode = 'hover';
      s.modeT = 0.55;
      s.diveAng = angTo(body.x, body.y, p.x, p.y);
      G.audio.sfx('cast', 0.7, 0.7);
      addTelegraph(G, {
        kind: 'line', x: body.x, y: body.y, ang: s.diveAng, len: 320, w: 12, dur: 0.38, color: STORM_EYE, team: 'enemy',
        onDone: () => {
          if (active !== s || s.body.dead || s.mode !== 'hover') return;
          s.mode = 'dive';
          s.modeT = 0.42;
          s.diveHit = false;
          G.audio.sfx('thunder', 1.2, 0.7);
        },
      });
    }
  }

  positionWings(s);
  updateCrescents(G, s, dt);
}

function positionWings(s: RocState): void {
  const body = s.body;
  const travel = s.orbitAng + Math.PI / 2; // direction of motion around the orbit
  for (const w of s.wings) {
    if (w.e.dead) continue;
    const wa = travel + w.side * 1.5;
    w.e.x = body.x + Math.cos(wa) * 17;
    w.e.y = body.y + Math.sin(wa) * 17;
  }
}

function crashImpact(G: GameCtx, s: RocState): void {
  const body = s.body;
  const t = body.tier;
  explosion(G, body.x, body.y, 34, (9 + t * 1.8) * DIFF.dmg, 'wind', 'enemy', { from: body });
  addRing(G, body.x, body.y, 8, 210, STORM_EYE, 0.4, 2.5);
  burst(G, body.x, body.y, '#8a92a8', 16, 100, { glow: false });
  shake(G, 3);
  G.audio.sfx('boom', 0.9, 1);
  gustNova(G, s, 10, 150, (7 + t * 1.3) * DIFF.dmg);
}

// radial gust: crescents fly outward + shove the player
function gustNova(G: GameCtx, s: RocState, n: number, speed: number, dmg: number): void {
  const body = s.body;
  const p = G.player;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU + randR(-0.08, 0.08);
    s.crescents.push({
      x: body.x, y: body.y, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed,
      t: 0, life: 0.9, r: 12, dmg,
    });
  }
  if (!p.dead) {
    const d = dist(body.x, body.y, p.x, p.y);
    if (d < 110) {
      const a = angTo(body.x, body.y, p.x, p.y);
      p.vx += Math.cos(a) * 190; p.vy += Math.sin(a) * 190;
    }
  }
}

function updateCrescents(G: GameCtx, s: RocState, dt: number): void {
  const p = G.player;
  for (const c of s.crescents) {
    if (c.t >= c.life) continue;
    c.t += dt;
    c.x += c.vx * dt;
    c.y += c.vy * dt;
    if (G.frame % 3 === 0) {
      spawnParticle(G, { x: c.x, y: c.y, vx: randR(-6, 6), vy: randR(-6, 6), life: 0.3, size: 1.6, color: '#9ee8c8', glow: true });
    }
    if (!p.dead && dist(c.x, c.y, p.x, p.y) < c.r + p.r) {
      c.t = c.life;
      damagePlayer(G, c.dmg, 'wind');
      const a = Math.atan2(c.vy, c.vx);
      p.vx += Math.cos(a) * 260; p.vy += Math.sin(a) * 260;
      burst(G, c.x, c.y, '#9ee8c8', 6, 80, { glow: true });
    }
  }
  s.crescents = s.crescents.filter((c) => c.t < c.life);
}

function drawRoc(G: GameCtx, s: RocState): void {
  const ctx = G.ctx;
  const body = s.body;
  const z = s.z;
  const bx = Math.round(body.x);
  const by = Math.round(body.y - z);
  const p = G.player;
  const grounded = s.mode === 'grounded';
  const diving = s.mode === 'dive';
  const hover = s.mode === 'hover';
  const swept = diving || hover;
  const signK = s.signT > 0;

  // soaring drop-shadow on the ground (shrinks before the dive)
  const shK = clamp(1 - z / 70, 0.25, 1);
  ctx.globalAlpha = 0.3 * shK;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(body.x, body.y + 5, 15 * shK + 3, 5 * shK + 1.4, 0, 0, TAU);
  ctx.fill();
  ctx.globalAlpha = 1;

  // travel angle + a banking soar (it leans into the orbit)
  let moveA = s.orbitAng + Math.PI / 2;
  if (swept) moveA = s.diveAng;
  const flap = signK ? 0.34 : grounded ? 0.18 : swept ? -0.55 : Math.sin(body.anim * 5.2);

  ctx.save();
  ctx.translate(bx, by);
  ctx.rotate(moveA + (grounded ? 0 : 0.12));
  const breathe = 1 + Math.sin(body.anim * 2.4) * 0.03;
  ctx.scale(breathe, breathe);

  // tail: fanned feather quads (slot together when diving)
  const tailFan = swept ? 0.1 : signK ? 0.14 : 0.24;
  for (let i = -2; i <= 2; i++) {
    drawFeather(ctx, -8, 0, Math.PI + i * tailFan, 12 - Math.abs(i) * 1.6, 2.4, ROC_DK, '#c8ccd8');
  }

  // wings: articulated 3-segment arms (shoulder→elbow→wrist→tip) + primary feathers
  for (const w of s.wings) {
    const side = w.side;
    if (w.e.dead) {
      // torn stub + dangling broken feathers
      const sa = side * 1.9;
      const stX = 2 + Math.cos(sa) * 5, stY = side * 2.5 + Math.sin(sa) * 5;
      drawBlob(ctx, stX, stY, 3, 2.2, ROC_DK);
      for (let i = 0; i < 2; i++) {
        const da = sa + side * (0.5 + i * 0.35) + Math.sin(G.time * 3 + i) * 0.06;
        drawFeather(ctx, stX, stY, da, 6 - i * 1.5, 1.4, '#b8b4c4', '#8a8698');
      }
      continue;
    }
    // banking soar: the inner wing (toward the orbit center) leads the stroke
    const bankOff = grounded ? 0 : side === 1 ? -0.12 : 0.12;
    const a1 = side * (1.62 - flap * 0.4 - (signK ? 0.55 : 0) + bankOff);
    const a2 = side * (2.05 - flap * 0.62 - (signK ? 0.4 : 0));
    const a3 = side * (2.42 - flap * 0.78 - (signK ? 0.3 : 0) + Math.sin(body.anim * 5.2 - 0.9) * 0.12);
    const shX = 2, shY = side * 2.5;
    const elX = shX + Math.cos(a1) * 9, elY = shY + Math.sin(a1) * 9;
    const wrX = elX + Math.cos(a2) * 10, wrY = elY + Math.sin(a2) * 10;
    const tiX = wrX + Math.cos(a3) * 9, tiY = wrY + Math.sin(a3) * 9;
    drawLimb(ctx, shX, shY, elX, elY, ROC_WING);
    drawLimb(ctx, elX, elY, wrX, wrY, ROC_WING);
    drawLimb(ctx, wrX, wrY, tiX, tiY, ROC_WING);
    // coverts + joints
    drawBlobR(ctx, (shX + elX + wrX) / 3, (shY + elY + wrY) / 3, 4.4, 2.6, a2, ROC_WING);
    ctx.fillStyle = ROC_DK;
    ctx.fillRect(Math.round(elX) - 1, Math.round(elY) - 1, 2, 2);
    ctx.fillRect(Math.round(wrX) - 1, Math.round(wrY) - 1, 2, 2);
    // primary feathers: fan apart on the beat, slot together when swept
    const sep = signK ? 0 : swept ? 0.1 : clamp(flap, 0, 1) * 0.55 + 0.25;
    for (let i = 0; i < 5; i++) {
      const fa2 = a3 + side * (i - 2) * 0.13 * (0.5 + sep);
      const fl = 10.5 - Math.abs(i - 2) * 1.3;
      drawFeather(ctx, wrX + Math.cos(a3) * 2, wrY + Math.sin(a3) * 2, fa2, fl, 1.7, FEATHER, '#ffffff');
    }
    if (w.e.flash > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = clamp(w.e.flash * 6, 0, 1);
      drawLimb(ctx, shX, shY, elX, elY, '#ffffff');
      drawLimb(ctx, elX, elY, wrX, wrY, '#ffffff');
      drawLimb(ctx, wrX, wrY, tiX, tiY, '#ffffff');
      ctx.restore();
    }
  }

  // body: tapered torso with keel shading + rim light
  drawBlob(ctx, 0, 0, 10.5, 6.6, ROC_BODY);
  drawBlob(ctx, 3, 0, 6.4, 5.6, '#6a7488');
  drawBlob(ctx, -6, 0, 5.5, 3.8, ROC_BODY);
  ctx.fillStyle = 'rgba(40,46,60,0.55)';
  ctx.fillRect(-9, -1, 16, 2);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.25;
  ctx.strokeStyle = '#dce8f4';
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.ellipse(1, 0, 9.6, 5.8, 0, -2.1, -1.05); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(1, 0, 9.6, 5.8, 0, 1.05, 2.1); ctx.stroke();
  ctx.restore();

  // legs: scaled, 3 taloned toes — tucked in flight, claws out when stooping
  if (swept || grounded) {
    for (const side of [-1, 1]) {
      const kx = 7, ky = side * 2.6;
      const fx2 = 14.5, fy2 = side * 4.6;
      drawLimb(ctx, 2, side * 2, kx, ky, GOLD);
      drawLimb(ctx, kx, ky, fx2, fy2, GOLD);
      ctx.fillStyle = '#8a6a1e';
      ctx.fillRect(Math.round(kx) - 1, Math.round(ky) - 1, 2, 2);
      ctx.fillStyle = '#e8e4d8';
      for (let tn = -1; tn <= 1; tn++) {
        const ta = Math.atan2(fy2 - ky, fx2 - kx) + tn * 0.4;
        ctx.fillRect(Math.round(fx2 + Math.cos(ta) * 2.6) - 1, Math.round(fy2 + Math.sin(ta) * 2.6) - 1, 1.6, 1.6);
      }
    }
  } else {
    // tucked in flight
    for (const side of [-1, 1]) {
      drawLimb(ctx, -2, side * 2.6, -6, side * 3.8, GOLD);
      ctx.fillStyle = '#e8e4d8';
      ctx.fillRect(-7, Math.round(side * 3.8) - 1, 1.6, 1.6);
    }
  }

  // head + hooked beak + cere, aimed at the player
  const headAim = clamp(angDiff(moveA, angTo(body.x, body.y, p.x, p.y)), -0.85, 0.85);
  ctx.save();
  ctx.translate(10.5, 0);
  ctx.rotate(headAim * 0.55);
  drawBlob(ctx, 0.5, 0, 4.6, 4.1, ROC_BODY);
  drawBlob(ctx, -1.5, 0, 3, 3.4, '#4e5868');
  ctx.fillStyle = '#c9902e';
  ctx.fillRect(3.4, -1.4, 1.4, 2.8);
  ctx.fillStyle = GOLD;
  ctx.beginPath();
  ctx.moveTo(4.2, -1.5);
  ctx.quadraticCurveTo(9.4, -1, 9.8, 0.2);
  ctx.quadraticCurveTo(9.2, 1.4, 7.4, 1.1);
  ctx.quadraticCurveTo(7.9, 0.4, 7, 0.5);
  ctx.quadraticCurveTo(5.5, 1.7, 4.2, 1.6);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#8a6a1e';
  ctx.fillRect(6.4, -0.6, 2.4, 1);
  // angry forward-facing eyes: dark sockets + small storm-white glow (not googly)
  for (const side of [-1, 1]) {
    ctx.fillStyle = '#20242e';
    ctx.beginPath(); ctx.ellipse(1.6, side * 2.1, 1.5, 1.2, 0, 0, TAU); ctx.fill();
    glowDot(ctx, 2 + Math.cos(headAim) * 0.6, side * 2.1 + Math.sin(headAim) * 0.6, 0.9, '#ffffff', 0.95);
    glowDot(ctx, 2 + Math.cos(headAim) * 0.6, side * 2.1 + Math.sin(headAim) * 0.6, 1.8, STORM_EYE, 0.3);
  }
  // the strike tell: the beak glints
  if (signK) drawGlint(ctx, 9.4, 0, clamp(1 - s.signT / 0.45, 0, 1), STORM_EYE);
  ctx.restore();

  ctx.restore();

  // storm streaks on the plunge
  if (diving) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.4;
    ctx.strokeStyle = STORM_EYE;
    ctx.lineWidth = 1;
    const oa = moveA + Math.PI;
    for (let i = 0; i < 3; i++) {
      const off = (i - 1) * 4;
      ctx.beginPath();
      ctx.moveTo(bx + Math.cos(oa) * (6 + i * 4) + Math.cos(oa + Math.PI / 2) * off, by + Math.sin(oa) * (6 + i * 4) + Math.sin(oa + Math.PI / 2) * off);
      ctx.lineTo(bx + Math.cos(oa) * (16 + i * 7) + Math.cos(oa + Math.PI / 2) * off, by + Math.sin(oa) * (16 + i * 7) + Math.sin(oa + Math.PI / 2) * off);
      ctx.stroke();
    }
    ctx.restore();
  }

  // hit flash
  if (body.flash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(body.flash * 6, 0, 1);
    drawBlobR(ctx, bx, by, 10.5, 6.6, moveA, '#ffffff');
    drawBlobR(ctx, bx + Math.cos(moveA) * 10.5, by + Math.sin(moveA) * 10.5, 4.6, 4.1, moveA, '#ffffff');
    ctx.restore();
  }

  // grounded thrash glow (+50% damage window)
  if (grounded) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.3 + 0.25 * Math.sin(G.time * 16);
    ctx.strokeStyle = '#ff9e4e';
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(bx, by, 18 + Math.sin(G.time * 13) * 2, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  // wind crescents
  for (const c of s.crescents) {
    if (c.t >= c.life) continue;
    const k = 1 - c.t / c.life;
    const a = Math.atan2(c.vy, c.vx);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(k, 0, 0.85);
    ctx.strokeStyle = '#9ee8c8';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.arc(Math.round(c.x), Math.round(c.y), c.r, a - 1.1, a + 1.1);
    ctx.stroke();
    ctx.strokeStyle = '#e2fff2';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(Math.round(c.x), Math.round(c.y), c.r - 3, a - 0.9, a + 0.9);
    ctx.stroke();
    ctx.restore();
  }

  drawMbBar(
    G, bx, by - 28, 'THE STORM ROC', STORM_EYE, body,
    [!s.wings[0].e.dead, !s.wings[1].e.dead], GOLD,
  );
}

// ============================================================
// 3) THE BONE CHOIR — ancient floating skull ring
// ============================================================
function spawnChoir(G: GameCtx, sx: number, sy: number, t: number): boolean {
  const tScale = 1 + 0.32 * (t - 1);
  const sScale = 1 + 0.24 * (t - 1);
  const coreHp = Math.round(470 * tScale * DIFF.hp);
  const core = makePart(G, 'mb_choir', sx, sy, t, coreHp, true);
  const skulls: ChoirSkull[] = [];
  for (let i = 0; i < 4; i++) {
    const skullHp = Math.round(70 * sScale * DIFF.hp);
    const e = makePart(G, 'mb_choir_skull', sx, sy, t, skullHp, true);
    skulls.push({
      e, angOff: (i / 4) * TAU, spd: (0.55 + i * 0.09) * (i % 2 === 0 ? 1 : -1),
      regrowT: 0, grieved: false, holdR: 42 + (i % 2) * 26, holdSide: i % 2 === 0 ? 1 : -1,
    });
  }
  const s: ChoirState = {
    which: 'choir', core, skulls, beam: null,
    atkCd: randR(2.4, 3.6), signT: 0, pendAng: 0, wardTxtT: 0, contactT: 0, intro: 0.9, dead: false,
  };
  active = s;
  G.banner = { title: 'THE BONE CHOIR', sub: 'They sing so you cannot think', t: 0, color: VIOLET };
  G.audio.sfx('grand', 0.9, 1);
  G.audio.sfx('summon', 0.7, 0.9);
  shake(G, 2.4);
  slowmo(G, 0.5, 0.35);
  burst(G, sx, sy, BONE, 18, 110, { glow: false });
  addRing(G, sx, sy, 8, 150, VIOLET, 0.45, 2.5);
  G.uiV++;
  return true;
}

function updateChoir(G: GameCtx, s: ChoirState, dt: number): void {
  const p = G.player;
  const core = s.core;
  const t = core.tier;

  // player fled very far: the choir falls silent and scatters
  if (dist(core.x, core.y, p.x, p.y) > 1400) {
    core.dead = true;
    for (const sk of s.skulls) sk.e.dead = true;
    active = null;
    return;
  }

  // skull grief + regrowth
  for (const sk of s.skulls) {
    if (sk.e.dead && !sk.grieved) {
      sk.grieved = true;
      sk.regrowT = 8;
      burst(G, sk.e.x, sk.e.y, BONE, 12, 100, { glow: false });
      burst(G, sk.e.x, sk.e.y, VIOLET, 6, 80, { glow: true });
      addText(G, sk.e.x, sk.e.y - 10, 'SKULL SHATTERED', BONE, 5, true);
      addRing(G, sk.e.x, sk.e.y, 4, 110, VIOLET, 0.3, 1.5);
      G.audio.sfx('hit', 1.5, 0.8);
    } else if (sk.e.dead) {
      // regrow after 8s — but never while the core is in its open window
      const alive = s.skulls.filter((o) => !o.e.dead).length;
      if (alive >= 3) {
        sk.regrowT -= dt;
        if (sk.regrowT <= 0) {
          sk.e.dead = false;
          sk.e.deadT = 0;
          sk.e.hp = sk.e.maxHp;
          sk.e.flash = 0;
          sk.e.st = {};
          sk.grieved = false;
          sk.angOff = angTo(core.x, core.y, p.x, p.y) + randR(-0.6, 0.6);
          burst(G, core.x, core.y, BONE, 10, 130, { glow: false });
          burst(G, sk.e.x, sk.e.y, BONE, 8, 70, { glow: false });
          addText(G, sk.e.x, sk.e.y - 12, 'THE CHOIR SWELLS', VIOLET, 5, true);
          addRing(G, sk.e.x, sk.e.y, 4, 100, VIOLET, 0.35, 1.5);
          G.audio.sfx('summon', 0.9, 0.8);
        }
      }
    }
  }
  const aliveN = s.skulls.filter((sk) => !sk.e.dead).length;
  const open = aliveN <= 2;

  // core death: refused while warded (>= 3 skulls humming), real when the jaw is open
  if (core.dead) {
    if (open) {
      if (!s.dead) {
        s.dead = true;
        for (const sk of s.skulls) if (!sk.e.dead) { burst(G, sk.e.x, sk.e.y, BONE, 10, 90, { glow: false }); sk.e.dead = true; }
        finale(G, core, 'THE BONE CHOIR FALLS SILENT', 'Only dust remembers the song', VIOLET, 'death', 0);
        active = null;
      }
      return;
    }
    // WARDED: the ring reknits the bone
    core.dead = false;
    core.deadT = 0;
    core.hp = core.maxHp;
    core.st = {};
    burst(G, core.x, core.y, VIOLET, 10, 110, { glow: true });
    addRing(G, core.x, core.y, 8, 140, VIOLET, 0.35, 2);
    if (s.wardTxtT <= 0) {
      s.wardTxtT = 0.9;
      addText(G, core.x, core.y - 26, 'WARDED', VIOLET, 6, true);
    }
    G.audio.sfx('clang', 1.6, 0.5);
  }
  s.wardTxtT -= dt;

  // phase rule: warded core is untouchable; open jaw takes 2x
  if (!open) {
    core.hp = core.maxHp; // bullets sparkle off — the ward drinks every point
  } else {
    core.st.amp = { t: 0.5, mult: 2 };
  }

  core.anim += dt;
  s.contactT -= dt;

  // ---- intro: the ring assembles ----
  if (s.intro > 0) {
    s.intro -= dt;
    const k = clamp(1 - s.intro / 0.9, 0, 1);
    for (const sk of s.skulls) {
      const a = sk.angOff + (1 - k) * 3;
      const rr = lerp(140, 46, k);
      sk.e.x = core.x + Math.cos(a) * rr;
      sk.e.y = core.y + Math.sin(a) * rr;
    }
    if (s.intro <= 0) addRing(G, core.x, core.y, 12, 170, VIOLET, 0.4, 2.5);
    return;
  }

  const stunned = !!core.st.stun || !!core.st.frozen;

  // ---- the core drifts after you (ghost bone, passes walls) ----
  if (!stunned) {
    const dc = dist(core.x, core.y, p.x, p.y);
    if (dc > 80) {
      const a = angTo(core.x, core.y, p.x, p.y);
      core.vx += Math.cos(a) * (22 + t * 1.6) * dt * 3;
      core.vy += Math.sin(a) * (22 + t * 1.6) * dt * 3;
    }
    const drag = 1 - clamp(3 * dt, 0, 0.9);
    core.vx *= drag; core.vy *= drag;
    const mv = moveWithCollision(G.world, core.x, core.y, core.vx, core.vy, core.r, dt, true);
    core.x = mv.x; core.y = mv.y;
  }

  // ---- THE SING: the hum drags you toward the center ----
  const auraR = 140;
  if (!p.dead && dist(p.x, p.y, core.x, core.y) < auraR) {
    const a = angTo(p.x, p.y, core.x, core.y);
    p.vx += Math.cos(a) * 62 * dt;
    p.vy += Math.sin(a) * 62 * dt;
    // fear-flavored wisps stream from you into the ring
    if (G.frame % 5 === 0) {
      spawnParticle(G, {
        x: p.x + randR(-8, 8), y: p.y + randR(-8, 8),
        vx: Math.cos(a) * randR(20, 44), vy: Math.sin(a) * randR(20, 44) - 8,
        life: 0.7, size: 2, color: VIOLET_DK, glow: true,
      });
    }
  }

  // ---- CHORUS BEAM: skulls align, twin spokes rotate ----
  if (s.beam) {
    const b = s.beam;
    b.t += dt;
    b.ang += b.spin * dt;
    b.dmgT -= dt;
    if (b.dmgT <= 0 && !p.dead) {
      const L = 250;
      const ex = core.x + Math.cos(b.ang) * L, ey = core.y + Math.sin(b.ang) * L;
      const fx = core.x - Math.cos(b.ang) * L, fy = core.y - Math.sin(b.ang) * L;
      if (segDist(p.x, p.y, core.x, core.y, ex, ey) < 7 + p.r || segDist(p.x, p.y, core.x, core.y, fx, fy) < 7 + p.r) {
        b.dmgT = 0.4;
        damagePlayer(G, (9 + t * 1.9) * DIFF.dmg, 'death');
      }
    }
    if (G.frame % 3 === 0) {
      const d = chance(0.5) ? 1 : -1;
      const dd = randR(30, 230);
      spawnParticle(G, {
        x: core.x + Math.cos(b.ang) * dd * d, y: core.y + Math.sin(b.ang) * dd * d,
        vx: randR(-10, 10), vy: randR(-10, 10), life: 0.3, size: 1.6, color: VIOLET, glow: true,
      });
    }
    if (b.t >= b.dur) s.beam = null;
  } else {
    s.atkCd -= dt;
    if (s.atkCd <= 0 && aliveN >= 1 && !stunned && !p.dead && s.signT <= 0) {
      s.atkCd = randR(5.2, 7.6);
      s.pendAng = angTo(core.x, core.y, p.x, p.y) + randR(-0.4, 0.4);
      s.signT = 0.55;
      // the skulls snap onto the coming beam axis — the formation itself is the tell
      let i2 = 0;
      for (const sk of s.skulls) {
        if (sk.e.dead) continue;
        sk.holdSide = i2 % 2 === 0 ? 1 : -1;
        sk.holdR = 40 + Math.floor(i2 / 2) * 30;
        i2++;
      }
      G.audio.sfx('castBig', 1.2, 0.8);
    }
  }
  if (s.signT > 0) {
    s.signT -= dt;
    if (G.frame % 3 === 0) signFlow(G, core.x, core.y, VIOLET);
    if (s.signT <= 0) {
      s.beam = { t: 0, dur: 2.6, ang: s.pendAng, spin: chance(0.5) ? 0.45 : -0.45, dmgT: 0 };
      G.audio.sfx('thunder', 1.4, 0.7);
      shake(G, 1.5);
    }
  }

  positionSkulls(s, dt);

  // ---- contact (core + humming skulls) ----
  if (!p.dead && core.spawnGuard <= 0 && s.contactT <= 0) {
    if (dist(core.x, core.y, p.x, p.y) < core.r + p.r) {
      s.contactT = 0.9;
      damagePlayer(G, (10 + t * 2) * DIFF.contact * DIFF.dmg, 'death');
      const a2 = angTo(core.x, core.y, p.x, p.y);
      p.vx += Math.cos(a2) * 160; p.vy += Math.sin(a2) * 160;
    } else {
      for (const sk of s.skulls) {
        if (sk.e.dead) continue;
        if (dist(sk.e.x, sk.e.y, p.x, p.y) < sk.e.r + p.r) {
          s.contactT = 0.8;
          damagePlayer(G, (6 + t * 1.2) * DIFF.dmg, 'death');
          const a2 = angTo(sk.e.x, sk.e.y, p.x, p.y);
          p.vx += Math.cos(a2) * 140; p.vy += Math.sin(a2) * 140;
          break;
        }
      }
    }
  }
}

// skulls orbit the core; while the beam lives (or its tell runs) they hold the beam axis
function positionSkulls(s: ChoirState, dt: number): void {
  const core = s.core;
  const holdAng = s.beam ? s.beam.ang : s.signT > 0 ? s.pendAng : null;
  for (const sk of s.skulls) {
    if (sk.e.dead) continue;
    sk.e.anim += dt;
    if (holdAng !== null) {
      const a = holdAng + (sk.holdSide > 0 ? 0 : Math.PI);
      sk.e.x = core.x + Math.cos(a) * sk.holdR;
      sk.e.y = core.y + Math.sin(a) * sk.holdR;
    } else {
      sk.angOff += sk.spd * dt;
      const bob = Math.sin(sk.e.anim * 3 + sk.holdR) * 3;
      sk.e.x = core.x + Math.cos(sk.angOff) * 46;
      sk.e.y = core.y + Math.sin(sk.angOff) * 46 + bob;
    }
  }
}

function drawChoir(G: GameCtx, s: ChoirState): void {
  const ctx = G.ctx;
  const core = s.core;
  const p = G.player;
  const aliveN = s.skulls.filter((sk) => !sk.e.dead).length;
  const open = aliveN <= 2;
  const beamK = !!s.beam || s.signT > 0; // jaws hang open on (and before) the beam
  const bx = Math.round(core.x);
  const by = Math.round(core.y - 8 - Math.sin(core.anim * 2) * 4);

  // THE SING aura: pulsing rune ring
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.05 + 0.04 * Math.sin(G.time * 2.2);
  ctx.strokeStyle = VIOLET;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(core.x, core.y, 140, 0, TAU); ctx.stroke();
  ctx.globalAlpha = 0.1 + 0.06 * Math.sin(G.time * 2.2 + 1);
  ctx.beginPath(); ctx.arc(core.x, core.y, 90 + Math.sin(G.time * 1.4) * 8, 0, TAU); ctx.stroke();
  ctx.restore();

  // chorus beam (rotating twin spokes)
  if (s.beam) {
    const b = s.beam;
    const k = clamp(1 - Math.abs(b.t - b.dur * 0.5) / (b.dur * 0.6), 0.35, 1);
    for (const side of [1, -1]) {
      const ex = core.x + Math.cos(b.ang) * 250 * side;
      const ey = core.y + Math.sin(b.ang) * 250 * side;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = k * 0.85;
      ctx.strokeStyle = VIOLET;
      ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(core.x, core.y); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = VIOLET_DK;
      ctx.lineWidth = 11;
      ctx.globalAlpha = k * 0.4;
      ctx.beginPath(); ctx.moveTo(core.x, core.y); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.2;
      ctx.globalAlpha = k;
      ctx.beginPath(); ctx.moveTo(core.x, core.y); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.restore();
    }
  }

  // ribcage aureole: curved rib arcs orbiting the core at a tilt
  for (let i = 0; i < 5; i++) {
    const ph = G.time * 0.65 + (i / 5) * TAU;
    const rr = 21 + (i % 2) * 4;
    const depth = 0.45 + 0.4 * Math.sin(ph); // front ribs read brighter
    ctx.save();
    ctx.translate(bx, by);
    ctx.rotate(ph);
    ctx.strokeStyle = BONE_DK;
    ctx.globalAlpha = depth * 0.55;
    ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(0, 0, rr, -0.75, 0.75); ctx.stroke();
    ctx.strokeStyle = BONE;
    ctx.globalAlpha = depth;
    ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.arc(0, 0, rr, -0.7, 0.7); ctx.stroke();
    ctx.restore();
  }

  // cervical vertebrae trailing beneath like a ghostly spine
  let vx2 = bx, vy2 = by + 11;
  for (let i = 0; i < 5; i++) {
    const nx2 = bx + Math.sin(G.time * 1.7 + i * 0.9) * (2.5 + i * 1.1);
    const ny2 = by + 11 + i * 4.4;
    drawLimb(ctx, vx2, vy2, nx2, ny2, BONE_DK);
    drawBlob(ctx, nx2, ny2, 3.1 - i * 0.28, 2.2 - i * 0.16, BONE);
    ctx.fillStyle = BONE_DK;
    ctx.fillRect(Math.round(nx2) - 1, Math.round(ny2) - 1, 2, 2);
    vx2 = nx2; vy2 = ny2;
  }

  // lesser skulls: real skulls rotated to face outward, bobbing on their orbits
  for (const sk of s.skulls) {
    if (sk.e.dead) continue;
    const sx2 = sk.e.x;
    const sy2 = sk.e.y - 5 - Math.sin(sk.e.anim * 3) * 2;
    const out = angTo(core.x, core.y, sk.e.x, sk.e.y);
    drawSkull(ctx, sx2, sy2, out - Math.PI / 2, 0.85,
      beamK ? 0.85 : 0.15 + 0.1 * Math.sin(G.time * 3 + sk.holdR), VIOLET, G.time, sk.holdR);
    if (sk.e.flash > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = clamp(sk.e.flash * 6, 0, 1);
      drawBlob(ctx, sx2, sy2, 6.5, 6.5, '#ffffff');
      ctx.restore();
    }
  }

  // the ancient core skull — cranium, brow horns, tracking sockets, hinged jaw
  const coreRot = clamp(angDiff(Math.PI / 2, angTo(core.x, core.y, p.x, p.y)), -0.6, 0.6) * 0.35;
  const jawOpen = beamK ? 0.9 + Math.sin(G.time * 6) * 0.1 : open ? 0.6 + Math.sin(G.time * 6) * 0.15 : 0.12;
  const la = angDiff(coreRot, angTo(core.x, core.y, p.x, p.y));
  ctx.save();
  ctx.translate(bx, by);
  ctx.rotate(coreRot);
  ctx.scale(2.1, 2.1);
  // under-shading
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath(); ctx.ellipse(0, 1.4, 6, 5, 0, 0, TAU); ctx.fill();
  // cranium dome + crown highlight
  drawBlob(ctx, 0, -0.6, 6.2, 5.6, BONE);
  drawBlob(ctx, -1.6, -2.2, 3.8, 3, '#e8e4d8');
  // crown horns
  ctx.fillStyle = BONE;
  for (const side of [-1, 1]) {
    ctx.beginPath();
    ctx.moveTo(side * 4.6, -4);
    ctx.quadraticCurveTo(side * 6.4, -6.4, side * 5.4, -7.6);
    ctx.quadraticCurveTo(side * 5.6, -5.6, side * 3.6, -4.6);
    ctx.closePath();
    ctx.fill();
    ctx.fillRect(side * 6.8 - 0.5, -4.6, 1, 1.8);
  }
  // brow ridge + deep sockets
  ctx.fillStyle = BONE_DK;
  ctx.fillRect(-4.4, -1.7, 8.8, 1);
  ctx.fillStyle = BONE_OUT;
  ctx.beginPath(); ctx.ellipse(-2.6, 0.1, 2, 1.7, 0.12, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(2.6, 0.1, 2, 1.7, -0.12, 0, TAU); ctx.fill();
  // violet (or burning) flame inside the sockets — it tracks you
  const glowCol = open || beamK ? MAW_GLOW : VIOLET;
  for (const side of [-1, 1]) {
    glowDot(ctx, side * 2.6 + Math.cos(la) * 0.9, 0.1 + Math.sin(la) * 0.9, 1.1, glowCol, 0.7 + 0.25 * Math.sin(G.time * (open ? 11 : 4) + side));
    glowDot(ctx, side * 2.6 + Math.cos(la) * 0.9, 0.1 + Math.sin(la) * 0.9, 0.5, '#ffffff', 0.5);
  }
  // nasal cavity
  ctx.fillStyle = BONE_OUT;
  ctx.beginPath();
  ctx.moveTo(0, 1.4);
  ctx.lineTo(-1, 3.2);
  ctx.quadraticCurveTo(0, 3.8, 1, 3.2);
  ctx.closePath();
  ctx.fill();
  // old-bone cracks
  ctx.strokeStyle = BONE_DK;
  ctx.lineWidth = 0.5;
  ctx.beginPath();
  ctx.moveTo(-4.4, -1); ctx.lineTo(-5.4, 0.6);
  ctx.moveTo(4.4, -1); ctx.lineTo(5.2, 0.8);
  ctx.moveTo(-1, -5.8); ctx.lineTo(-0.4, -4.6);
  ctx.stroke();
  // maxilla teeth
  for (let i = -2; i <= 2; i++) drawTooth(ctx, i * 1.9, 4.1, Math.PI / 2, 1.5, '#e8e4d8');
  // hinged jawbone (drops open in the vulnerable window — a glowing maw)
  const jo = jawOpen * 2.6;
  drawBlob(ctx, 0, 4.4 + jo, 5, 1.7, BONE);
  ctx.fillStyle = BONE_DK;
  ctx.fillRect(-4.6, 4.2 + jo, 9.2, 0.7);
  for (let i = -1; i <= 1; i++) drawTooth(ctx, i * 2.4, 3.7 + jo, -Math.PI / 2, 1.4, '#e8e4d8');
  if (jawOpen > 0.3) {
    drawBlob(ctx, 0, 3 + jo * 0.5, 3.4, 1.6, '#3a0d12');
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.5 + 0.3 * Math.sin(G.time * 14);
    ctx.fillStyle = MAW_GLOW;
    drawBlob(ctx, 0, 3 + jo * 0.5, 2.2, 1, MAW_GLOW);
    ctx.restore();
  }
  ctx.restore();

  // ward shimmer while protected
  if (!open) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.16 + 0.1 * Math.sin(G.time * 5);
    ctx.strokeStyle = VIOLET;
    ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(bx, by, 22 + Math.sin(G.time * 3) * 2, 0, TAU); ctx.stroke();
    ctx.restore();
  }
  // beam tell: the glint gathers at the core
  if (s.signT > 0) drawGlint(ctx, bx, by - 4, clamp(1 - s.signT / 0.55, 0, 1), VIOLET);
  // hit flash
  if (core.flash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(core.flash * 6, 0, 1);
    drawBlob(ctx, bx, by - 2, 13, 11.5, '#ffffff');
    ctx.restore();
  }

  drawMbBar(
    G, bx, by - 34, 'THE BONE CHOIR', VIOLET, core,
    s.skulls.map((sk) => !sk.e.dead), BONE,
  );
}

// ============================================================
// 4) THE VAULT MIMIC — ambush chest
// ============================================================
function spawnMimic(G: GameCtx, sx: number, sy: number, t: number, force: boolean): boolean {
  const tScale = 1 + 0.32 * (t - 1);
  const bodyHp = Math.round(600 * tScale * DIFF.hp);
  const body = makePart(G, 'mb_mimic', sx, sy, t, bodyHp);
  const s: MimicState = {
    which: 'mimic', body, asleep: !force, facing: 0,
    mode: 'lurk', hopN: 0, hx0: 0, hy0: 0, hx1: 0, hy1: 0, hopT: 0, hopDur: 0.42, z: 0,
    atkCd: randR(0.95, 1.6), coinCd: randR(2, 3.2),
    tongueT: 0, tAng: 0, tLen: 150, grabT: 0, bitten: false,
    inverted: false, lureDropped: false, contactT: 0, coins: [], lures: [],
    signT: 0, pend: '', awakeT: 0,
    intro: force ? 0.7 : 0, dead: false,
  };
  active = s;
  if (force) {
    // the cheat console wakes it immediately — full ambush intro
    springMimic(G, s);
    s.intro = 0.7;
  }
  // natural spawn: SILENT. It is just a chest on the ground... until you touch it.
  return true;
}

function springMimic(G: GameCtx, s: MimicState): void {
  const body = s.body;
  s.asleep = false;
  G.banner = { title: 'THE VAULT MIMIC', sub: 'Not every treasure wants to be found', t: 0, color: GOLD };
  G.audio.sfx('roar', 1.35, 0.9);
  G.audio.sfx('clang', 0.7, 1);
  shake(G, 3);
  slowmo(G, 0.5, 0.35);
  burst(G, body.x, body.y - 8, GOLD, 16, 120, { glow: true });
  burst(G, body.x, body.y - 8, '#8a6a2e', 10, 90, { glow: false });
  addRing(G, body.x, body.y, 6, 160, GOLD, 0.4, 2);
  G.uiV++;
  s.atkCd = 1;
  s.coinCd = 2.2;
}

function dropCoin(G: GameCtx, s: MimicState, x: number, y: number, ang: number, speed: number, tier: number, dmgMul = 1): void {
  s.coins.push({
    x, y, z: 12, vz: randR(80, 130),
    vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed,
    t: 0, bounced: false, dmg: (5 + tier * 1.1) * DIFF.dmg * dmgMul,
  });
}

function coinSpray(G: GameCtx, s: MimicState): void {
  const body = s.body;
  const t = body.tier;
  const p = G.player;
  const base = angTo(body.x, body.y, p.x, p.y);
  const n = 6 + Math.floor(rand(0, 4));
  for (let i = 0; i < n; i++) {
    const spread = s.inverted ? TAU : 1.4;
    const a = s.inverted ? (i / n) * TAU : base + (i - (n - 1) / 2) * (spread / Math.max(1, n - 1));
    dropCoin(G, s, body.x, body.y - 6, a, randR(120, 190), t);
  }
  // plus a tight fan of 3 ricochet coins straight at the mark (65% dmg)
  for (let i = 0; i < 3; i++) {
    dropCoin(G, s, body.x, body.y - 6, base + (i - 1) * 0.26, randR(175, 205), t, 0.65);
  }
  G.audio.sfx('pickup', 1.3, 0.5);
  G.audio.sfx('aether', 1.1, 0.4);
}

function dropLure(G: GameCtx, s: MimicState, x: number, y: number): void {
  if (s.lures.length >= 3) s.lures.shift();
  s.lures.push({ x, y, t: 0, dmg: (10 + s.body.tier * 2) * DIFF.dmg });
  spawnParticle(G, { x, y, vy: -20, life: 0.5, size: 2, color: '#5ee8d8', glow: true });
}

function updateMimic(G: GameCtx, s: MimicState, dt: number): void {
  const p = G.player;
  const body = s.body;
  const t = body.tier;

  // player fled very far: the mimic shuts and waits for the next mark
  if (dist(body.x, body.y, p.x, p.y) > 1400) { body.dead = true; active = null; return; }

  // death → the finale (a small fortune spills out)
  if (body.dead) {
    if (!s.dead) {
      s.dead = true;
      finale(G, body, 'THE VAULT MIMIC PLUNDERED', 'Its hoard is yours now', GOLD, 'shadow', 6);
      active = null;
    }
    return;
  }

  // ---- ambush trigger ----
  if (s.asleep) {
    const near = !p.dead && dist(body.x, body.y, p.x, p.y) < 60;
    const struck = body.hp < body.maxHp - 0.5;
    if (near || struck) {
      springMimic(G, s);
    } else {
      return; // it is furniture. it is patient.
    }
  }

  body.anim += dt;
  s.awakeT += dt;
  s.facing = angleLerp(s.facing, angTo(body.x, body.y, p.x, p.y), clamp(4 * dt, 0, 1));
  s.contactT -= dt;
  s.atkCd -= dt;
  s.coinCd -= dt;
  if (s.tongueT > 0) s.tongueT -= dt;
  if (s.grabT > 0) s.grabT -= dt;

  // ---- intro spring (force-spawned awake) ----
  if (s.intro > 0) {
    s.intro -= dt;
    if (s.intro <= 0) {
      burst(G, body.x, body.y, GOLD, 10, 100, { glow: true });
      addRing(G, body.x, body.y, 5, 130, GOLD, 0.3, 2);
    }
    updateMimicProj(G, s, dt);
    return;
  }

  // ---- attack signs: glint + gathering motes at the keyhole, then the strike ----
  if (s.signT > 0) {
    s.signT -= dt;
    const smx = body.x + Math.cos(s.facing) * 10, smy = body.y + Math.sin(s.facing) * 10;
    if (G.frame % 4 === 0) signFlow(G, smx, smy, s.pend === 'tongue' ? TONGUE : GOLD);
    if (s.signT <= 0) {
      if (s.pend === 'tongue') {
        s.tAng = angTo(body.x, body.y, p.x, p.y);
        s.tLen = 150;
        addTelegraph(G, {
          kind: 'line', x: body.x, y: body.y, ang: s.tAng, len: s.tLen, w: 8, dur: 0.35, color: TONGUE, team: 'enemy',
          onDone: () => {
            if (active !== s || s.body.dead || p.dead) return;
            s.tongueT = 0.55;
            G.audio.sfx('melee', 0.9, 0.9);
            const ex = s.body.x + Math.cos(s.tAng) * s.tLen;
            const ey = s.body.y + Math.sin(s.tAng) * s.tLen;
            if (segDist(p.x, p.y, s.body.x, s.body.y, ex, ey) < 13 + p.r) {
              s.grabT = 0.5;
              s.bitten = false;
              addText(G, p.x, p.y - 14, 'CAUGHT!', TONGUE, 6, true);
            } else {
              burst(G, ex, ey, TONGUE, 5, 60, { glow: false });
            }
          },
        });
      } else if (s.pend === 'coins') {
        coinSpray(G, s);
      }
      s.pend = '';
    }
  }

  // ---- INVERSION: below 40% HP it turns itself out ----
  if (!s.inverted && body.hp < body.maxHp * 0.4) {
    s.inverted = true;
    screenFlash(G, '#3a0a18', 0.5);
    shake(G, 4);
    slowmo(G, 0.6, 0.3);
    addText(G, body.x, body.y - 34, 'IT TURNS ITSELF OUT', MEAT, 8, true);
    burst(G, body.x, body.y, MEAT, 20, 120, { glow: false });
    burst(G, body.x, body.y, GOLD, 10, 100, { glow: true });
    addRing(G, body.x, body.y, 8, 180, MEAT, 0.45, 3);
    G.audio.sfx('die', 1.1, 0.8);
    G.audio.sfx('roar', 0.6, 0.9);
  }
  if (s.inverted) body.st.amp = { t: 0.5, mult: s.tongueT > 0 ? 2 : 1.15 };

  // extended tongue = exposed weak point (2x)
  if (s.tongueT > 0 && !s.inverted) body.st.amp = { t: 0.5, mult: 2 };

  // ---- tongue grab pull + bite ----
  if (s.grabT > 0 && !p.dead) {
    const a = angTo(p.x, p.y, body.x, body.y);
    p.vx = Math.cos(a) * 360; p.vy = Math.sin(a) * 360;
    if (!s.bitten && dist(p.x, p.y, body.x, body.y) < body.r + p.r + 6) {
      s.bitten = true;
      damagePlayer(G, (18 + t * 3) * DIFF.dmg, 'shadow');
      const a2 = angTo(body.x, body.y, p.x, p.y);
      p.vx = Math.cos(a2) * 260; p.vy = Math.sin(a2) * 260;
      shake(G, 3);
      G.audio.sfx('melee', 0.5, 1);
      addText(G, p.x, p.y - 16, 'SWALLOWED WHOLE!', MEAT, 7, true);
    }
    if (s.grabT <= 0) { p.vx *= 0.4; p.vy *= 0.4; }
  }

  // ---- hop / slam travel ----
  if (s.mode === 'hop' || s.mode === 'slam') {
    s.hopT += dt;
    const k = clamp(s.hopT / s.hopDur, 0, 1);
    body.x = lerp(s.hx0, s.hx1, k);
    body.y = lerp(s.hy0, s.hy1, k);
    s.z = Math.sin(k * Math.PI) * (s.mode === 'slam' ? 26 : 14);
    if (s.inverted && k > 0.92 && !s.lureDropped) {
      s.lureDropped = true;
      dropLure(G, s, s.hx0, s.hy0); // a "forgotten" coinpur behind it
    }
    if (k >= 1) {
      const slam = s.mode === 'slam';
      s.mode = 'lurk';
      s.z = 0;
      if (slam) {
        // BOX SLAM: shockwave + loose coins everywhere
        explosion(G, body.x, body.y, 44, (12 + t * 2.4) * DIFF.dmg, 'shadow', 'enemy', { from: body });
        addRing(G, body.x, body.y, 8, 200, GOLD, 0.4, 2.5);
        burst(G, body.x, body.y + 6, WOOD_DK, 12, 90, { glow: false });
        shake(G, 2.5);
        G.audio.sfx('boom', 0.9, 1);
        const n = 6 + Math.floor(rand(0, 4));
        for (let i = 0; i < n; i++) {
          const a = (i / n) * TAU + randR(-0.1, 0.1);
          dropCoin(G, s, body.x, body.y, a, randR(90, 160), t);
        }
      } else {
        burst(G, body.x, body.y + 4, '#5a4a38', 6, 50, { glow: false });
        G.audio.sfx('dodge', 0.7, 0.5);
      }
      s.atkCd = randR(s.inverted ? 0.64 : 0.95, s.inverted ? 1.28 : 2.1);
    }
    updateMimicProj(G, s, dt);
    return;
  }

  // ---- attacks from the lurk ----
  if (s.atkCd <= 0 && !p.dead && s.grabT <= 0 && s.tongueT <= 0 && s.signT <= 0) {
    const d = dist(body.x, body.y, p.x, p.y);
    if (d < 160 && chance(0.55)) {
      // TONGUE GRAB: keyhole glint tell, then a shortened line
      s.atkCd = randR(s.inverted ? 1.8 : 2.7, s.inverted ? 2.9 : 4.3);
      s.pend = 'tongue';
      s.signT = 0.45;
      s.tAng = angTo(body.x, body.y, p.x, p.y);
      G.audio.sfx('cast', 0.5, 1.2);
    } else if (d < 300) {
      // hop-chase; every 3rd hop is a SLAM
      s.hopN++;
      const slam = s.hopN % 3 === 0;
      s.mode = slam ? 'slam' : 'hop';
      s.hopT = 0;
      s.lureDropped = false;
      s.hopDur = slam ? 0.5 : 0.42;
      s.hx0 = body.x; s.hy0 = body.y;
      const a = angTo(body.x, body.y, p.x, p.y) + randR(-0.35, 0.35);
      const dd = (slam ? 95 : 70) * (s.inverted ? 1.2 : 1);
      // never hop into a wall: sweep nearby arcs for open ground
      let hx1 = body.x + Math.cos(a) * dd, hy1 = body.y + Math.sin(a) * dd;
      if (G.world.solidAt(hx1, hy1)) {
        let found = false;
        for (let k2 = 1; k2 <= 6 && !found; k2++) {
          for (const sgn of [-1, 1]) {
            const a2 = a + sgn * k2 * 0.4;
            const cx2 = body.x + Math.cos(a2) * dd * (1 - k2 * 0.08);
            const cy2 = body.y + Math.sin(a2) * dd * (1 - k2 * 0.08);
            if (!G.world.solidAt(cx2, cy2)) { hx1 = cx2; hy1 = cy2; found = true; break; }
          }
        }
        if (!found) { hx1 = body.x + Math.cos(a) * dd * 0.4; hy1 = body.y + Math.sin(a) * dd * 0.4; }
      }
      s.hx1 = hx1; s.hy1 = hy1;
      G.audio.sfx('dodge', slam ? 0.4 : 0.6, 0.7);
    } else {
      s.atkCd = 0.5;
    }
  }

  // ---- COIN SPRAY: lid-rattle tell, then bouncing coins + a 3-coin fan ----
  if (s.coinCd <= 0 && !p.dead && s.signT <= 0) {
    s.coinCd = randR(3.2, 5.2) * (s.inverted ? 0.7 : 1);
    s.pend = 'coins';
    s.signT = 0.4;
    G.audio.sfx('pickup', 1.6, 0.8);
  }

  updateMimicProj(G, s, dt);

  // ---- contact ----
  if (!p.dead && body.spawnGuard <= 0 && s.contactT <= 0 && dist(body.x, body.y, p.x, p.y) < body.r + p.r) {
    s.contactT = 0.9;
    damagePlayer(G, (10 + t * 2) * DIFF.contact * DIFF.dmg, 'shadow');
    const a2 = angTo(body.x, body.y, p.x, p.y);
    p.vx += Math.cos(a2) * 150; p.vy += Math.sin(a2) * 150;
  }
}

// coins + lure projectiles
function updateMimicProj(G: GameCtx, s: MimicState, dt: number): void {
  const p = G.player;
  for (const c of s.coins) {
    c.t += dt;
    c.x += c.vx * dt;
    c.y += c.vy * dt;
    c.z += c.vz * dt;
    c.vz -= 320 * dt;
    if (c.z <= 0 && c.vz < 0) {
      if (!c.bounced) {
        // ricochet off the ground once
        c.bounced = true;
        c.z = 0;
        c.vz *= -0.45;
        c.vx *= 0.6; c.vy *= 0.6;
        spawnParticle(G, { x: c.x, y: c.y, vy: -14, life: 0.3, size: 1.4, color: GOLD, glow: true });
        G.audio.sfx('pickup', 1.6, 0.25);
      } else {
        c.t = 99;
      }
    }
    if (c.t > 2.6) c.t = 99;
    if (!p.dead && c.z < 14 && dist(c.x, c.y, p.x, p.y) < 5 + p.r) {
      c.t = 99;
      damagePlayer(G, c.dmg, 'arcane');
      burst(G, c.x, c.y, GOLD, 5, 80, { glow: true });
    }
  }
  s.coins = s.coins.filter((c) => c.t < 90);
  for (const l of s.lures) {
    l.t += dt;
    if (!p.dead && dist(l.x, l.y, p.x, p.y) < 13 + p.r) {
      // the "aether" bites
      l.t = 99;
      explosion(G, l.x, l.y, 32, l.dmg, 'shadow', 'enemy', {});
      addText(G, l.x, l.y - 14, 'SNAP!', MEAT, 6, true);
      G.audio.sfx('melee', 0.5, 1);
    }
    if (l.t > 7) l.t = 99;
    if (G.frame % 14 === 0 && l.t < 90) {
      spawnParticle(G, { x: l.x, y: l.y - 4, vy: -14, life: 0.5, size: 1.6, color: '#5ee8d8', glow: true });
    }
  }
  s.lures = s.lures.filter((l) => l.t < 90);
}

function drawMimic(G: GameCtx, s: MimicState): void {
  const ctx = G.ctx;
  const body = s.body;
  const bx = Math.round(body.x);
  const by = Math.round(body.y - s.z);
  const p = G.player;

  // asleep: it IS the cache — draw the real chest sprite, perfectly still
  if (s.asleep) {
    const spr = SPR.chest;
    if (spr) {
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = '#000';
      ctx.beginPath(); ctx.ellipse(bx, by - 1, 8, 2.4, 0, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
      ctx.drawImage(spr, bx - Math.floor(spr.width / 2), by - spr.height + 2);
      // the only tell, and only when you are already too close
      if (dist(body.x, body.y, G.player.x, G.player.y) < 90) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = 0.25 + 0.2 * Math.sin(G.time * 9);
        ctx.fillStyle = MAW_GLOW;
        ctx.fillRect(bx - 3, by - 8, 6, 1);
        ctx.restore();
      }
    }
    return;
  }

  // ground shadow
  ctx.globalAlpha = 0.3 * (1 - s.z / 70);
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(body.x, body.y + 6, 13 - s.z * 0.05, 4 - s.z * 0.015, 0, 0, TAU);
  ctx.fill();
  ctx.globalAlpha = 1;

  const inverted = s.inverted;
  const fa = s.facing;
  const openK = clamp(body.anim * 2, 0, 1);
  const tongueSign = s.signT > 0 && s.pend === 'tongue';
  const coinSign = s.signT > 0 && s.pend === 'coins';
  const hopK = s.mode === 'hop' || s.mode === 'slam' ? clamp(s.hopT / s.hopDur, 0, 1) : 1;
  const squashK = hopK < 0.2 ? 1 - (0.2 - hopK) * 0.5 : 1; // anticipation crouch before a hop
  const breathe = 1 + Math.sin(body.anim * 2.2) * (inverted ? 0.05 : 0.02);
  const baseCol = inverted ? MEAT : WOOD;
  const baseDk = inverted ? '#4a0e16' : WOOD_DK;
  const toothCol = inverted ? '#f0ead8' : BONE;

  ctx.save();
  ctx.translate(bx, by);
  ctx.rotate(fa);
  ctx.scale(breathe * squashK, breathe * squashK);

  // inverted: rib-legs push the chest along (2-segment bone limbs with joints)
  if (inverted) {
    const legs = [
      { hx: -2, hy: 6, fx: -4, fy: 13 },
      { hx: -2, hy: -6, fx: -4, fy: -13 },
      { hx: -7, hy: 0, fx: -14, fy: 0 },
    ];
    for (let i = 0; i < legs.length; i++) {
      const L = legs[i];
      const st = Math.sin(body.anim * 11 + i * 2.4) * 2;
      const knee = solveIK(L.hx, L.hy, L.fx + st, L.fy, 6, 7, i === 2 ? 1 : L.fy > 0 ? 1 : -1);
      drawLimb(ctx, L.hx, L.hy, knee.x, knee.y, BONE_DK);
      drawLimb(ctx, knee.x, knee.y, L.fx + st, L.fy, BONE);
      ctx.fillStyle = '#e8e4d8';
      ctx.fillRect(Math.round(knee.x) - 1, Math.round(knee.y) - 1, 2, 2);
      ctx.fillStyle = '#f0ead8';
      ctx.fillRect(Math.round(L.fx + st) - 1, Math.round(L.fy) - 1, 2, 2);
    }
  }

  // lid thrown open behind (hinge at the back edge); rattles before a coin spray
  const lidJit = coinSign ? Math.sin(G.time * 34) * 0.06 : 0;
  const lidAng = -0.15 - 1.85 * openK - (inverted ? 0.3 : 0) + lidJit;
  ctx.save();
  ctx.translate(-9.5, 0);
  ctx.rotate(lidAng);
  ctx.fillStyle = baseDk;
  ctx.fillRect(0, -8.2, 10.5, 16.4);
  ctx.fillStyle = inverted ? '#6e1420' : baseCol;
  ctx.fillRect(1, -7.2, 8.8, 14.4);
  // iron bands across the lid + rivets
  ctx.fillStyle = IRON;
  ctx.fillRect(0, -8.2, 10.5, 1.8);
  ctx.fillRect(0, 6.4, 10.5, 1.8);
  ctx.fillStyle = BRASS;
  for (let i = 0; i < 3; i++) {
    ctx.fillRect(1.6 + i * 3.4, -7.7, 1, 1);
    ctx.fillRect(1.6 + i * 3.4, 6.9, 1, 1);
  }
  // jagged teeth lining the lid's inner edge (the upper jaw)
  for (let i = -2; i <= 2; i++) {
    drawTooth(ctx, 9.2, i * 2.6, 0, 2.6 + (i % 2 === 0 ? 0.8 : 0), toothCol);
  }
  if (inverted) {
    ctx.fillStyle = MEAT;
    for (let i = -3; i <= 3; i++) ctx.fillRect(9.6, i * 2.2 - 0.6, 1.6, 1.2);
  }
  ctx.restore();

  // chest base: wood planks, seams, iron corner bands, rivets, keyhole plate
  ctx.fillStyle = baseDk;
  ctx.fillRect(-10, -8.6, 20.5, 17.2);
  ctx.fillStyle = baseCol;
  ctx.fillRect(-9, -7.6, 18.5, 15.2);
  ctx.fillStyle = baseDk;
  ctx.fillRect(-9, -2.6, 18.5, 0.8);
  ctx.fillRect(-9, 3.4, 18.5, 0.8);
  ctx.fillRect(-1.5, -7.6, 0.8, 5);
  ctx.fillRect(3.5, 4.2, 0.8, 3.4);
  ctx.fillStyle = IRON;
  ctx.fillRect(-10, -8.6, 3, 4.6);
  ctx.fillRect(-10, -8.6, 4.6, 3);
  ctx.fillRect(-10, 4, 3, 4.6);
  ctx.fillRect(-10, 1.6, 4.6, 3);
  ctx.fillRect(7, -8.6, 3, 4.6);
  ctx.fillRect(5.4, -8.6, 4.6, 3);
  ctx.fillRect(7, 4, 3, 4.6);
  ctx.fillRect(5.4, 1.6, 4.6, 3);
  ctx.fillStyle = BRASS;
  ctx.fillRect(-8.6, -7.9, 1, 1);
  ctx.fillRect(-8.6, 6.9, 1, 1);
  ctx.fillRect(7.6, -7.9, 1, 1);
  ctx.fillRect(7.6, 6.9, 1, 1);
  ctx.fillRect(0.4, -8.1, 1, 1);
  ctx.fillRect(0.4, 7.1, 1, 1);
  ctx.fillRect(9.4, -2, 1.8, 4);
  ctx.fillStyle = '#1a1208';
  ctx.fillRect(9.9, -1.2, 0.9, 2.4);
  ctx.fillRect(9.75, -1.5, 1.2, 1.2);
  if (inverted) {
    // glowing veins through the exposed meat
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.5 + 0.25 * Math.sin(G.time * 7);
    ctx.strokeStyle = MAW_GLOW;
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    for (let i = 0; i < 3; i++) {
      const vy3 = -4 + i * 4;
      ctx.moveTo(-8, vy3);
      ctx.quadraticCurveTo(-3, vy3 + 1.6, 1, vy3 - 1);
      ctx.quadraticCurveTo(4, vy3 + 0.6, 8, vy3 + 1);
    }
    ctx.stroke();
    ctx.restore();
  }

  // the maw: dark throat between the tooth rows
  drawBlob(ctx, 6.5, 0, 4.6, 6.4, '#1a0508');
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.45 + 0.25 * Math.sin(G.time * 8);
  ctx.fillStyle = inverted ? MAW_GLOW : '#8a5a1e';
  drawBlob(ctx, 6, 0, 3, 4.4, inverted ? MAW_GLOW : '#8a5a1e');
  ctx.restore();
  for (let i = -2; i <= 2; i++) {
    drawTooth(ctx, 8.4, i * 2.5, 0, 2.4 + (i % 2 === 0 ? 0.7 : 0), toothCol);
  }

  // the single large eye — wakes, then tracks you with a slit pupil
  const eyeOpen = clamp(s.awakeT * 2.4, 0, 1);
  const la = clamp(angDiff(fa, angTo(body.x, body.y, p.x, p.y)), -0.8, 0.8);
  const ex2 = 4.2 + Math.cos(la) * 1.1;
  const ey2 = Math.sin(la) * 2.2;
  drawBlob(ctx, 4, 0, 4.2, 3.6 * eyeOpen + 0.4, inverted ? '#5e0e1a' : '#3a2410');
  ctx.save();
  ctx.translate(ex2, ey2);
  ctx.scale(1, Math.max(0.12, eyeOpen));
  drawBlob(ctx, 0, 0, 3.1, 2.7, '#e8d8b0');
  drawBlob(ctx, 0.4, 0, 2, 1.9, inverted ? '#d8b04e' : GOLD);
  ctx.fillStyle = '#1a0a08';
  ctx.fillRect(-0.45, -1.7, 0.9, 3.4);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-1.4, -1.4, 0.9, 0.9);
  ctx.restore();
  if (eyeOpen < 1) {
    ctx.fillStyle = baseDk;
    ctx.fillRect(0.5, -3.9, 7.5, 3.7 * (1 - eyeOpen) + 0.2);
  }
  if (inverted) {
    // red veins crawl around the socket
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.4;
    ctx.strokeStyle = MAW_GLOW;
    ctx.lineWidth = 0.7;
    for (let i = 0; i < 4; i++) {
      const va = i * 1.6 + 0.4;
      ctx.beginPath();
      ctx.moveTo(4 + Math.cos(va) * 3.4, Math.sin(va) * 3);
      ctx.lineTo(4 + Math.cos(va) * 5.4, Math.sin(va) * 4.6);
      ctx.stroke();
    }
    ctx.restore();
  }

  // attack tells
  if (tongueSign) drawGlint(ctx, 10.5, 0, clamp(1 - s.signT / 0.45, 0, 1), GOLD);
  else if (coinSign) drawGlint(ctx, -6, -9, clamp(1 - s.signT / 0.4, 0, 1), '#ffce4e');

  ctx.restore();

  // tongue — tapered, glistening, reaches for its mark (the 2x window)
  if (s.tongueT > 0 || s.grabT > 0 || tongueSign) {
    const mxw = bx + Math.cos(fa) * 9, myw = by + Math.sin(fa) * 9;
    let len = 14;
    if (tongueSign) {
      len = 10 + Math.sin(G.time * 20) * 3; // it licks its lips
    } else if (s.grabT > 0) {
      len = lerp(s.tLen, 20, clamp(s.grabT / 0.5, 0, 1));
    } else {
      len = Math.min(s.tLen, 26 + (0.55 - s.tongueT) * 220);
    }
    const ex3 = bx + Math.cos(s.tAng) * len, ey3 = by + Math.sin(s.tAng) * len;
    const tcol = inverted ? '#c25a6e' : TONGUE;
    taperRun(ctx, mxw, myw, ex3, ey3, 3.4, 1.4, tcol);
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.45;
    taperRun(ctx, mxw, myw - 0.6, ex3, ey3 - 0.6, 1.1, 0.5, '#ffe2ea');
    ctx.restore();
    drawBlob(ctx, ex3, ey3, 2.2, 2.2, tcol);
  }

  // hit flash
  if (body.flash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(body.flash * 6, 0, 1);
    drawBlobR(ctx, bx, by, 12, 9.5, fa, '#ffffff');
    ctx.restore();
  }

  // inversion menace ring
  if (inverted) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.2 + 0.15 * Math.sin(G.time * 9);
    ctx.strokeStyle = MEAT;
    ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(bx, by, 18 + Math.sin(G.time * 11) * 2, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  // bouncing coins
  for (const c of s.coins) {
    if (c.t > 90) continue;
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = '#000';
    ctx.fillRect(Math.round(c.x) - 1, Math.round(c.y), 2, 1);
    ctx.globalAlpha = 1;
    const cy = Math.round(c.y - c.z);
    ctx.fillStyle = BRASS;
    ctx.beginPath(); ctx.arc(Math.round(c.x), cy, 2.6, 0, TAU); ctx.fill();
    ctx.fillStyle = GOLD;
    ctx.beginPath(); ctx.arc(Math.round(c.x) - 0.5, cy - 0.5, 1.6, 0, TAU); ctx.fill();
  }

  // fake aether lures (they bite)
  for (const l of s.lures) {
    if (l.t > 90) continue;
    const pulse = 1 + Math.sin(l.t * 8) * 0.2;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.75;
    ctx.fillStyle = '#5ee8d8';
    ctx.beginPath();
    ctx.moveTo(Math.round(l.x), Math.round(l.y - 7 * pulse));
    ctx.lineTo(Math.round(l.x) + 3, Math.round(l.y));
    ctx.lineTo(Math.round(l.x), Math.round(l.y + 3));
    ctx.lineTo(Math.round(l.x) - 3, Math.round(l.y));
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 0.3;
    ctx.beginPath(); ctx.arc(Math.round(l.x), Math.round(l.y - 2), 6 * pulse, 0, TAU); ctx.fill();
    ctx.restore();
  }

  drawMbBar(
    G, bx, by - 30, inverted ? 'THE VAULT MIMIC — INSIDE OUT' : 'THE VAULT MIMIC', GOLD, body,
    [body.hp / body.maxHp > 0.75, body.hp / body.maxHp > 0.5, body.hp / body.maxHp > 0.25, body.hp > 0], MEAT,
  );
}

// ---------- drawing helpers (pixel-style, from spider.ts idiom) ----------
function drawMbBar(G: GameCtx, x: number, y: number, name: string, color: string, e: Enemy, pips: boolean[], pipColor: string): void {
  const ctx = G.ctx;
  const w = 46;
  const bx = Math.round(x), by = Math.round(y);
  ctx.fillStyle = 'rgba(10,8,16,0.8)';
  ctx.fillRect(bx - w / 2 - 1, by, w + 2, 5);
  ctx.fillStyle = '#2a1030';
  ctx.fillRect(bx - w / 2, by + 1, w, 3);
  ctx.fillStyle = color;
  ctx.fillRect(bx - w / 2, by + 1, w * clamp(e.hp / e.maxHp, 0, 1), 3);
  for (let i = 0; i < pips.length; i++) {
    const px = bx - w / 2 + i * (w / pips.length);
    ctx.fillStyle = pips[i] ? pipColor : '#3a2030';
    ctx.fillRect(px, by + 5, w / pips.length - 1, 1.6);
  }
  ctx.fillStyle = 'rgba(232,228,212,0.75)';
  ctx.font = '4px monospace';
  ctx.textAlign = 'center';
  ctx.fillText(name, bx, by - 2);
  ctx.textAlign = 'left';
}

// pixel-y limb: a run of 2px rects along the segment (spider idiom)
function drawLimb(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number, col: string): void {
  const d = dist(x1, y1, x2, y2);
  const n = Math.max(2, Math.ceil(d / 1.8));
  ctx.fillStyle = col;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const px = Math.round(lerp(x1, x2, t));
    const py = Math.round(lerp(y1, y2, t));
    ctx.fillRect(px - 1, py - 1, 2, 2);
  }
}

// filled blob (pixel-ish ellipse)
function drawBlob(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, col: string): void {
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.ellipse(Math.round(x), Math.round(y), rx, ry, 0, 0, TAU);
  ctx.fill();
}

// rotated filled blob
function drawBlobR(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, rot: number, col: string): void {
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.ellipse(Math.round(x), Math.round(y), rx, ry, rot, 0, TAU);
  ctx.fill();
}

// shortest signed angle from a to b
function angDiff(a: number, b: number): number {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

// two-bone IK: returns the joint position (the weaver's idiom)
function solveIK(ax: number, ay: number, bx: number, by: number, l1: number, l2: number, bend: number): { x: number; y: number } {
  let d = dist(ax, ay, bx, by);
  d = clamp(d, Math.abs(l1 - l2) + 0.5, l1 + l2 - 0.5);
  const a1 = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1));
  const base = Math.atan2(by - ay, bx - ax);
  const ka = base + a1 * bend;
  return { x: ax + Math.cos(ka) * l1, y: ay + Math.sin(ka) * l1 };
}

// tapered run of rects (tongues, flesh)
function taperRun(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number, w1: number, w2: number, col: string): void {
  const d = dist(x1, y1, x2, y2);
  const n = Math.max(2, Math.ceil(d / 1.8));
  ctx.fillStyle = col;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const w = Math.max(1, lerp(w1, w2, t));
    ctx.fillRect(Math.round(lerp(x1, x2, t)) - w / 2, Math.round(lerp(y1, y2, t)) - w / 2, w, w);
  }
}

// a single feather / tail quad: tapered shaft with a pale tip
function drawFeather(ctx: CanvasRenderingContext2D, x: number, y: number, ang: number, len: number, w: number, col: string, tipCol: string): void {
  const tx = x + Math.cos(ang) * len, ty = y + Math.sin(ang) * len;
  const px = Math.cos(ang + Math.PI / 2) * w, py = Math.sin(ang + Math.PI / 2) * w;
  const mx = x + Math.cos(ang) * len * 0.55, my = y + Math.sin(ang) * len * 0.55;
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.moveTo(x + px * 0.35, y + py * 0.35);
  ctx.lineTo(mx + px, my + py);
  ctx.lineTo(tx, ty);
  ctx.lineTo(mx - px, my - py);
  ctx.closePath();
  ctx.fill();
  const tx2 = x + Math.cos(ang) * len * 0.78, ty2 = y + Math.sin(ang) * len * 0.78;
  ctx.fillStyle = tipCol;
  ctx.beginPath();
  ctx.moveTo(tx2 + px * 0.6, ty2 + py * 0.6);
  ctx.lineTo(tx, ty);
  ctx.lineTo(tx2 - px * 0.6, ty2 - py * 0.6);
  ctx.closePath();
  ctx.fill();
}

// a single tooth: small triangle rooted at (x, y), pointing along ang
function drawTooth(ctx: CanvasRenderingContext2D, x: number, y: number, ang: number, len: number, col: string): void {
  const px = Math.cos(ang + Math.PI / 2), py = Math.sin(ang + Math.PI / 2);
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.moveTo(x + px * 1.3, y + py * 1.3);
  ctx.lineTo(x - px * 1.3, y - py * 1.3);
  ctx.lineTo(x + Math.cos(ang) * len, y + Math.sin(ang) * len);
  ctx.closePath();
  ctx.fill();
}

// additive glow dot ('lighter' composite)
function glowDot(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, col: string, a: number): void {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = clamp(a, 0, 1);
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.arc(Math.round(x), Math.round(y), r, 0, TAU);
  ctx.fill();
  ctx.restore();
}

// SIGN tell, update side: motes gather INWARD toward the emission point
function signFlow(G: GameCtx, x: number, y: number, col: string): void {
  const a = rand(0, TAU);
  const r = randR(10, 16);
  spawnParticle(G, {
    x: x + Math.cos(a) * r, y: y + Math.sin(a) * r,
    vx: -Math.cos(a) * randR(26, 44), vy: -Math.sin(a) * randR(26, 44),
    life: 0.26, size: 1.6, color: col, glow: true,
  });
}

// SIGN tell, draw side: a bright 4-ray glint that swells then snaps shut
function drawGlint(ctx: CanvasRenderingContext2D, x: number, y: number, k: number, col: string): void {
  const a = Math.sin(clamp(k, 0, 1) * Math.PI);
  const r = Math.max(1, 1.2 + 2.2 * a);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = col;
  ctx.globalAlpha = 0.5 + 0.5 * a;
  ctx.fillRect(Math.round(x - r / 2), Math.round(y - r / 2), Math.round(r), Math.round(r));
  ctx.strokeStyle = col;
  ctx.lineWidth = 1;
  const L = 3 + 5 * a;
  ctx.beginPath();
  for (let i = 0; i < 4; i++) {
    const ra = i * Math.PI / 2 + k * 1.4;
    ctx.moveTo(Math.round(x + Math.cos(ra) * 1.5), Math.round(y + Math.sin(ra) * 1.5));
    ctx.lineTo(Math.round(x + Math.cos(ra) * L), Math.round(y + Math.sin(ra) * L));
  }
  ctx.stroke();
  ctx.restore();
}

// a real small skull: cranium, brow, glowing sockets, nasal cavity, hinged jaw.
// drawn facing +y (chin toward +y); rotate the frame to aim it.
function drawSkull(ctx: CanvasRenderingContext2D, x: number, y: number, rot: number, sc: number, jawOpen: number, glowCol: string, t: number, seed: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(sc, sc);
  // under-shading
  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.beginPath(); ctx.ellipse(0, 1.4, 5, 4, 0, 0, TAU); ctx.fill();
  // cranium + crown highlight
  drawBlob(ctx, 0, -0.6, 4.8, 4.4, BONE);
  drawBlob(ctx, -1.2, -1.8, 2.8, 2.2, '#e8e4d8');
  // brow ridge
  ctx.fillStyle = BONE_DK;
  ctx.fillRect(-3.4, -1.3, 6.8, 0.8);
  // sockets
  ctx.fillStyle = BONE_OUT;
  ctx.beginPath(); ctx.ellipse(-2, 0.2, 1.5, 1.3, 0.12, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(2, 0.2, 1.5, 1.3, -0.12, 0, TAU); ctx.fill();
  glowDot(ctx, -2, 0.2, 0.9, glowCol, 0.55 + 0.3 * Math.sin(t * 5 + seed));
  glowDot(ctx, 2, 0.2, 0.9, glowCol, 0.55 + 0.3 * Math.sin(t * 5 + seed + 1.3));
  // nasal cavity
  ctx.fillStyle = BONE_OUT;
  ctx.beginPath();
  ctx.moveTo(0, 1.2);
  ctx.lineTo(-0.7, 2.4);
  ctx.lineTo(0.7, 2.4);
  ctx.closePath();
  ctx.fill();
  // maxilla teeth
  ctx.fillStyle = '#e8e4d8';
  for (let i = -1; i <= 1; i++) ctx.fillRect(i * 1.6 - 0.5, 2.9, 1, 1.1);
  // hinged jaw
  const jo = 0.6 + jawOpen * 2.2;
  drawBlob(ctx, 0, 3.2 + jo, 3.6, 1.3, BONE);
  ctx.fillStyle = '#e8e4d8';
  for (let i = -1; i <= 1; i++) ctx.fillRect(i * 1.8 - 0.4, 2.6 + jo * 0.85, 0.9, 1);
  ctx.restore();
}
