/* ============================================================
   game.ts — the orchestrator: loop, camera, HUD, minimap,
   interactions, shrines, save/load, and the React API bridge.
   ============================================================ */
import {
  TILE, CHUNK_PX, TAU, clamp, lerp, dist, mulberry32, ELEMENT_IDS, rand, randR, randi, pick, chance, hash2,
  type GameCtx, type Progress, type UIMode, type ElementId, type SpellDef,
} from './core';
import { SPR, initSprites, elColor, LUX_TILES, ARENA_FLOORS, EDGE_TILES, FAMILY_RANK, type EdgeSide } from './sprites';
import { createAudio } from './audio';
import { createInput } from './input';
import {
  createWorld, setLocations, getLocations, buildLocations,
  T_LAVA, T_SHALLOW, T_WATER, T_WALL, T_FLOOR_BASE, bossOfFloorTile, rebuildRoads,
  landmarksNear, LANDMARK_SPRITE, type Landmark, type LandmarkKind,
} from './world';
import {
  updateBullets, drawBullets, updateZones, drawZones, updateBeams, drawBeams,
  updateTeles, drawTeles, updateFx, drawParticles, drawTexts, drawRings,
  burst, addText, updatePickups, drawPickups, spawnPickup, addRing,
  updateCorpses, drawCorpses, envHazardTick, damagePlayer, spawnParticle, shake, spawnZone,
  addTelegraph, explosion,
} from './fx';
import {
  updateEnemies, drawEnemies, updateSpawner, updateMinions, drawMinions,
  handleEnemyDeath, tierOfDistance, KINDS, gainXp, spawnEnemy,
} from './enemies';
import {
  tryStartBoss, updateBoss, drawBoss, updateSched, BOSS_DEFS, after,
} from './bosses';
import { updatePlayer, drawPlayer, drawCrosshair, createPlayer, updateGhosts, drawGhosts } from './player';
import { updateSpider, drawSpider, trySpawnWeaver } from './spider';
import { updateMiniBosses, drawMiniBosses, miniBossAlive, miniBossSortY, trySpawnMiniBoss, pickMiniBossForBiome } from './minibosses';
import { CLASSES, UNIVERSALS, UNIVERSAL_IDS, UNIVERSAL_MAX } from './classes';
import {
  ELEMENTS, ALL_SPELL_IDS, spellDef, checkUnlocks, attuneSlots,
  schoolXpNeed, charXpNeed, spellXpNeed, canFuse, FUSE_COST,
} from './magic';
import { SIGILS } from './world';
import { initVillages, villages, villageShopNear, updateVillagers, villagerDrawItems, villageDrawItems } from './villages';
import { initStatues, statueNear, statuePromptText, tryInteractStatue, tryStartRealm, updateStatues, statueDrawItems, drawRealmOverlay, nextRealmTier } from './statues';
import { initArenas, updateArenas, arenaDrawItems, drawGateBarrier } from './arenas';
import { updateAmbient, ambientDrawItems } from './ambient';
import { RELICS, RARITY_COLOR, RARITY_LABEL, SHOP_STOCK, grantRelic, equipRelic as equipRelicItem, spawnRelicDrop, cheatRelic } from './items';
import { questTick, registerXpHandler, trackRest, trackBoss, trackDiscover, type QuestPool } from './quests';

// ---------- mobile detection (phones/tablets only — never desktop) ----------
function detectMobile(): boolean {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  const uaMobile = /Android|iPhone|iPad|iPod|IEMobile|Opera Mini|Mobile/i.test(ua) && !/iPad|Tablet/i.test(ua) === false ? /Android|iPhone|iPad|iPod|IEMobile|Opera Mini|Mobile/i.test(ua) : false;
  const coarse = window.matchMedia?.('(pointer: coarse)')?.matches ?? false;
  const fine = window.matchMedia?.('(pointer: fine)')?.matches ?? true;
  const touch = (navigator.maxTouchPoints ?? 0) > 1;
  // a phone/tablet: coarse primary pointer with no fine pointer, or UA says mobile with multi-touch
  return (coarse && !fine) || (uaMobile && touch);
}

const SAVE_KEY = 'arcana_infinita_save_v1';

// ---------- default progress ----------
function defaultProgress(x: number, y: number, seed: number): Progress {
  const schools: Record<string, { lvl: number; xp: number }> = {};
  for (const el of ELEMENT_IDS) schools[el] = { lvl: 1, xp: 0 };
  const spells: Record<string, { lvl: number; xp: number }> = {
    'fire.bolt': { lvl: 1, xp: 0 },
    'frost.bolt': { lvl: 1, xp: 0 },
    'arcane.bolt': { lvl: 1, xp: 0 },
    'death.bolt': { lvl: 1, xp: 0 },
  };
  return {
    v: 1,
    seed,
    x, y,
    lvl: 1, xp: 0,
    hp: 100, mana: 60,
    schools, spells,
    loadout: ['fire.bolt', 'frost.bolt', null, null, null, null, null, null],
    slotsExtra: 0,
    aether: 0,
    vials: 3, draughts: 2,
    fused: [],
    sigils: [],
    bosses: [],
    shrineX: x, shrineY: y,
    discovered: ['shrine_spawn'],
    kills: 0, deaths: 0, playtime: 0,
    fusionUnlocked: false,
    muted: false,
    quests: [], questsDone: 0,
    questSeed: Math.floor(Math.random() * 1e6),
    poiDone: [],
    elKills: {}, eliteKills: 0,
    cls: '', points: 0, universal: {}, pointsEarned: 0,
    echoes: 0, relics: [], equipped: [null, null, null],
    ascensions: {}, ngPlus: 0,
  };
}

// ---------- snapshot for React ----------
export interface UISnapshot {
  mode: UIMode;
  lvl: number; xp: number; xpNeed: number;
  hp: number; maxHp: number; mana: number; maxMana: number;
  aether: number; vials: number; draughts: number;
  slots: number; activeSlot: number;
  loadout: (string | null)[];
  schools: Array<{ id: ElementId; name: string; school: string; lvl: number; xp: number; need: number; color: string }>;
  spellCount: number;
  knownSpells: string[];
  allSpells: Array<{
    id: string; name: string; el: ElementId; el2: ElementId | null; form: string;
    lvl: number; xp: number; need: number; dmg: number; mana: number; cd: number;
    known: boolean; unlock: number; desc: string; fused: boolean;
  }>;
  fused: string[];
  sigils: Array<{ id: string; name: string; desc: string; owned: boolean }>;
  bosses: string[];
  bossList: Array<{ id: string; name: string; killed: boolean }>;
  fusionUnlocked: boolean;
  kills: number; deaths: number; playtime: number;
  tier: number;
  muted: boolean;
  hasSave: boolean;
  // v2
  quests: Array<{ id: string; title: string; have: number; need: number; done: boolean; reward: number; kind: string }>;
  questsDone: number;
  landmarksFound: number;
  overdrive: number;
  combo: number;
  // v3
  mobile: boolean;
  cheatGod: boolean;
  cheatMana: boolean;
  // v3.1: classes + skill tree
  cls: string;
  clsName: string | null;
  clsTitle: string | null;
  clsBlurb: string | null;
  clsPassive: string | null;
  clsColor: string;
  points: number;
  pointsEarned: number;
  universal: Record<string, number>;
  universalDefs: Array<{ id: string; name: string; desc: string; color: string; glyph: string; max: number }>;
  // v4: relics + echoes + ascension
  echoes: number;
  relics: Array<{ id: string; name: string; desc: string; color: string; glyph: string; rarity: string; owned: boolean; equipped: number }>;
  shopStock: Array<{ id: string; name: string; desc: string; color: string; glyph: string; rarity: string; cost: number; owned: boolean }>;
  atVillage: boolean;
  ngPlus: number;
  ascensions: Record<string, number>;
}

// ---------- create ----------
export function createGame(canvas: HTMLCanvasElement): { G: GameCtx; api: GameApi } {
  initSprites();
  const ctx = canvas.getContext('2d')!;
  const audio = createAudio();

  // reuse the saved world seed so CONTINUE returns to the same world
  let saveSeed: number | null = null;
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const d = JSON.parse(raw) as { seed?: number };
      if (typeof d.seed === 'number') saveSeed = d.seed;
    }
  } catch { /* ignore */ }
  const world = createWorld(saveSeed ?? Math.floor(Math.random() * 1e9));
  const spawn = world.findLand(0, 0);
  const locs = buildLocations(world.findLand);
  setLocations(locs);
  const spawnShrine = locs.find((l) => l.id === 'shrine_spawn')!;
  // villages, the effigy ring and the boss arenas are anchored to this world
  initVillages(world.seed, world.findLand, world.biomeAt,
    locs.filter((l) => l.kind === 'boss').map((l) => ({ x: l.x, y: l.y, r: 220 })));
  initStatues(spawnShrine.x, spawnShrine.y, world);
  initArenas();
  rebuildRoads();

  const G: GameCtx = {
    canvas, ctx,
    W: 640, H: 360, vw: 0, vh: 0, scale: 3,
    time: 0, frame: 0,
    hitstop: 0, slowmo: null,
    cam: { x: spawn.x, y: spawn.y, shake: 0, shX: 0, shY: 0 },
    player: createPlayer(spawnShrine.x, spawnShrine.y + 20),
    enemies: [], minions: [], bullets: [], zones: [],
    beams: [], teles: [], rings: [], parts: [], texts: [],
    corpses: [], pickups: [], stain: null,
    boss: null,
    spider: null,
    spiderT: 55,
    ghosts: [],
    kickZoom: 0,
    screenFlash: null,
    combo: { n: 0, t: 0 },
    overdrive: 0, odFlash: 0, corpseBonus: 0,
    world,
    prog: defaultProgress(spawnShrine.x, spawnShrine.y + 20, world.seed),
    mode: 'title',
    uiV: 0,
    banner: null,
    toasts: [],
    audio,
    input: null as unknown as GameCtx['input'],
    spawnT: 3.5, saveT: 0,
    running: true,
    cb: {
      enemyHit: () => {},
      enemyDie: (e, el) => handleEnemyDeath(G, e, el),
      minionHit: () => {},
      minionDie: () => {},
      playerHit: () => {},
      bossHit: () => {},
      bossDie: () => {},
      spellCast: () => {},
      spellHit: () => {},
      overdrive: () => {},
    },
    sched: [],
    gate: null,
    interactPrompt: null,
    fuseAltarNear: false,
    shrineNear: false,
    poiPrompt: null,
    poiNear: null,
    hintT: 0,
    mobile: detectMobile(),
    cheat: { god: false, infiniteMana: false },
    eventT: 150,
    realm: null,
    destroy: () => {
      G.running = false;
      G.input?.detach();
    },
  };

  G.input = createInput(canvas);
  resize();
  window.addEventListener('resize', resize);

  // ---------- quests & landmarks ----------
  const questPool: QuestPool = {
    kinds: Object.values(KINDS).filter((k) => !k.id.startsWith('weaver_') && !k.id.startsWith('mb_')).map((k) => ({ id: k.id, name: k.name, tier: k.tier })),
  };
  registerXpHandler(gainXp);
  const isLand = (x: number, y: number): boolean => world.biomeAt(x, y) !== 'ocean';
  const campTriggered = new Set<string>();
  let lastBossCount = 0;

  const LM_GLOW: Record<LandmarkKind, string> = {
    camp: '#ff9e4e', tower: '#9ee8ff', obelisk: '#c95ee8', cache: '#ffd75e', grove: '#5ee8c9',
    dungeon: '#e2552e', merchant: '#f2c96e', geyser: '#7ab8ff',
  };

  // per-landmark cooldowns / dungeon delve state
  const groveCd = new Map<string, number>();
  const merchantCd = new Map<string, number>();
  const geyserCd = new Map<string, number>();
  const delveWave = new Map<string, number>();

  function spawnDelveWave(lm: Landmark, wave: number): void {
    const t = Math.min(9, lm.tier);
    const biome = world.biomeAt(lm.x, lm.y);
    const pool = Object.values(KINDS).filter((k) => k.biomes.includes(biome) && k.tier <= Math.min(3, 1 + Math.floor(t / 2)));
    const usePool = pool.length ? pool : [KINDS.slime];
    const n = (wave === 3 ? 3 : 4) + Math.floor(t / 2);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + wave;
      spawnEnemy(G, pick(usePool).id, lm.x + Math.cos(a) * randR(30, 90), lm.y + Math.sin(a) * randR(30, 90), t, 0.1);
    }
    if (wave === 3) {
      // the barrow lord rises for the final wave
      const wk = pick(usePool);
      const w = spawnEnemy(G, wk.id, lm.x, lm.y - 10, Math.min(9, t + 1), 0);
      w.elite = 'titan';
      w.scale = 1.45; w.r = wk.r * 1.45;
      w.hp = wk.hp * (1 + 0.4 * (Math.min(9, t + 1) - 1)) * 3.2;
      w.maxHp = w.hp;
      addText(G, lm.x, lm.y - 30, 'THE BARROW LORD RISES', '#e2552e', 7, true);
    }
    G.banner = { title: `DELVE — WAVE ${wave}/3`, sub: lm.name, t: 0, color: '#e2552e' };
    G.audio.sfx('roar', 1.5, 0.55);
    shake(G, 2);
  }

  function finishDelve(lm: Landmark): void {
    const p = G.player;
    const amt = Math.round((46 + lm.tier * 26) * (1 + G.prog.lvl * 0.05));
    G.prog.aether += amt;
    G.prog.poiDone.push(lm.id);
    gainXp(G, 70 + lm.tier * 20);
    for (let i = 0; i < 6; i++) spawnPickup(G, 'aether', lm.x + randR(-20, 20), lm.y + randR(-20, 20), Math.round(amt / 7));
    if (chance(0.7)) spawnPickup(G, 'vial', lm.x + randR(-14, 14), lm.y);
    if (chance(0.5)) spawnPickup(G, 'draught', lm.x - randR(0, 14), lm.y);
    // the deep places hoard relics
    if (chance(0.35)) spawnRelicDrop(G, lm.x, lm.y - 6);
    G.banner = { title: 'BARROW PLUNDERED', sub: `${lm.name} cleared  ·  +${amt} aether`, t: 0, color: '#ffd75e' };
    burst(G, lm.x, lm.y, '#ffd75e', 24, 130);
    addRing(G, lm.x, lm.y, 8, 240, '#ffd75e', 0.5, 3);
    G.audio.sfx('levelup');
    G.uiV++;
    void p;
  }

  function spawnCampGuards(lm: Landmark): void {
    const biome = world.biomeAt(lm.x, lm.y);
    const pool = Object.values(KINDS).filter((k) => k.biomes.includes(biome) && k.tier <= Math.min(3, 1 + Math.floor(lm.tier / 2)));
    const usePool = pool.length ? pool : [KINDS.slime];
    const n = 3 + Math.min(3, Math.floor(lm.tier / 2));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      spawnEnemy(G, pick(usePool).id, lm.x + Math.cos(a) * randR(24, 64), lm.y + Math.sin(a) * randR(24, 64), Math.min(9, lm.tier), 0.08);
    }
    // the warden: a titan elite
    const wk = pick(usePool);
    const w = spawnEnemy(G, wk.id, lm.x, lm.y - 8, Math.min(9, lm.tier + 1), 0);
    w.elite = 'titan';
    w.scale = 1.5; w.r = wk.r * 1.5;
    w.hp = wk.hp * (1 + 0.4 * (Math.min(9, lm.tier + 1) - 1)) * 3 * 1.5;
    w.maxHp = w.hp;
    G.banner = { title: 'AMBUSH!', sub: `${lm.name} guards close in`, t: 0, color: '#ff8a5e' };
    G.audio.sfx('roar', 1.4, 0.7);
    shake(G, 2.5);
  }

  function poiLabel(lm: Landmark): string {
    const done = G.prog.poiDone.includes(lm.id);
    switch (lm.kind) {
      case 'cache': return done ? '' : 'E — Open the Cache';
      case 'tower': return done ? '' : 'E — Study the Tower';
      case 'obelisk': return done ? '' : 'E — Touch the Obelisk';
      case 'grove': return (groveCd.get(lm.id) ?? 0) > G.time ? '' : 'E — Drink from the Spring';
      case 'dungeon': {
        if (done) return '';
        const w = delveWave.get(lm.id) ?? 0;
        if (w > 0) return `Delve wave ${w}/3 — slay them all!`;
        return 'E — Enter the Depths (3 waves)';
      }
      case 'merchant': {
        const cd = merchantCd.get(lm.id) ?? 0;
        if (cd > G.time) return `The peddler is packing up... ${Math.ceil(cd - G.time)}s`;
        return `E — Trade secrets (${20 + lm.tier * 8} aether)`;
      }
      case 'geyser': return (geyserCd.get(lm.id) ?? 0) > G.time ? '' : 'E — Crack the Vent open';
      case 'camp': {
        if (done) return '';
        if (!campTriggered.has(lm.id)) return 'E — Investigate the Camp';
        const foesNear = G.enemies.some((e) => !e.dead && dist(e.x, e.y, lm.x, lm.y) < 140);
        return foesNear ? 'Clear the camp guards...' : 'E — Loot the Camp';
      }
    }
  }

  function poiInteract(lm: Landmark): void {
    const p = G.player;
    const done = G.prog.poiDone.includes(lm.id);
    switch (lm.kind) {
      case 'cache': {
        if (done) { toast('The cache is empty.'); return; }
        const amt = Math.round((20 + lm.tier * 14) * (1 + G.prog.lvl * 0.04));
        G.prog.aether += amt;
        addText(G, p.x, p.y - 18, `+${amt} aether`, '#ffd75e', 7, true);
        if (chance(0.4)) spawnPickup(G, 'vial', p.x + 10, p.y);
        if (chance(0.3)) spawnPickup(G, 'draught', p.x - 10, p.y);
        burst(G, lm.x, lm.y, '#ffd75e', 16, 100);
        addRing(G, lm.x, lm.y, 6, 160, '#ffd75e', 0.4, 2);
        G.audio.sfx('levelup', 1.1, 0.8);
        G.prog.poiDone.push(lm.id);
        toast(`Opened: ${lm.name}`, '#ffd75e');
        G.uiV++;
        break;
      }
      case 'tower': {
        if (done) { toast('The archmage has already shared their secrets.'); return; }
        const els = ELEMENT_IDS.filter((e) => (G.prog.schools[e]?.lvl ?? 1) < 40);
        if (els.length) {
          const el = pick(els);
          G.prog.schools[el].lvl++;
          addText(G, p.x, p.y - 22, `${ELEMENTS[el].school} +1 Lv`, elColor(el), 6, true);
        }
        const amt = Math.round(15 + lm.tier * 10);
        G.prog.aether += amt;
        G.prog.poiDone.push(lm.id);
        G.banner = { title: 'ARCANE LORE', sub: `${lm.name} shares its secrets  ·  +${amt} aether`, t: 0, color: '#9ee8ff' };
        G.audio.sfx('unlock');
        burst(G, lm.x, lm.y - 12, '#9ee8ff', 22, 120, { glow: true });
        addRing(G, lm.x, lm.y, 8, 200, '#9ee8ff', 0.5, 2.5);
        G.uiV++;
        break;
      }
      case 'obelisk': {
        if (done) { toast('The obelisk hums quietly.'); return; }
        let revealed = 0;
        for (const near of landmarksNear(world.seed, lm.x, lm.y, 2600, isLand)) {
          if (!G.prog.discovered.includes(near.id)) { G.prog.discovered.push(near.id); revealed++; }
        }
        gainXp(G, 40);
        G.prog.poiDone.push(lm.id);
        G.banner = { title: 'THE OBELISK ECHOES', sub: `${revealed} landmarks revealed on your map`, t: 0, color: '#c95ee8' };
        G.audio.sfx('unlock', 0.8);
        burst(G, lm.x, lm.y, '#c95ee8', 24, 140, { glow: true });
        addRing(G, lm.x, lm.y, 8, 340, '#c95ee8', 0.6, 3);
        G.uiV++;
        break;
      }
      case 'grove': {
        if ((groveCd.get(lm.id) ?? 0) > G.time) { toast('The spring is resting.'); return; }
        p.hp = p.maxHp; p.mana = p.maxMana; p.stam = p.maxStam;
        p.buffHaste = Math.max(p.buffHaste, 20);
        groveCd.set(lm.id, G.time + 90);
        addText(G, p.x, p.y - 18, 'RESTORED', '#5ee8c9', 7, true);
        burst(G, p.x, p.y - 4, '#9ee8d8', 18, 90, { dir: -Math.PI / 2, spread: 1.2, glow: true });
        G.audio.sfx('heal');
        G.uiV++;
        break;
      }
      case 'dungeon': {
        if (done) { toast('This barrow has been plundered.'); return; }
        const w = delveWave.get(lm.id) ?? 0;
        if (w === 0) {
          delveWave.set(lm.id, 1);
          spawnDelveWave(lm, 1);
        } else {
          toast('The depths are already open. Finish the delve!');
        }
        return;
      }
      case 'merchant': {
        const cost = 20 + lm.tier * 8;
        if ((merchantCd.get(lm.id) ?? 0) > G.time) { toast('The peddler wants nothing more to do with you today.'); return; }
        if (G.prog.aether < cost) { toast(`The peddler sneers. You need ${cost} aether.`); return; }
        G.prog.aether -= cost;
        merchantCd.set(lm.id, G.time + 75);
        const roll = randi(0, 4);
        if (roll === 0) {
          const els = ELEMENT_IDS.filter((e) => (G.prog.schools[e]?.lvl ?? 1) < 40);
          const el = pick(els);
          G.prog.schools[el].lvl++;
          toast(`The peddler teaches you a trick: ${ELEMENTS[el].school} +1 Lv`, elColor(el));
        } else if (roll === 1) {
          const known = Object.keys(G.prog.spells).filter((id) => (G.prog.spells[id]?.lvl ?? 1) < 10);
          if (known.length) {
            const id = pick(known);
            G.prog.spells[id].lvl++;
            toast(`${spellDef(id)?.name ?? 'A spell'} rises to Lv ${G.prog.spells[id].lvl}`, '#c9b0f2');
          } else {
            G.prog.aether += cost * 2;
            toast('Nothing left to teach — he refunds you double.', '#ffd75e');
          }
        } else if (roll === 2) {
          const win = Math.round(cost * randR(1.8, 3));
          G.prog.aether += win;
          toast(`LUCKY TRADE — the peddler pays out ${win} aether!`, '#ffd75e');
        } else if (roll === 3) {
          G.prog.vials = Math.min(9, G.prog.vials + 2);
          G.prog.draughts = Math.min(9, G.prog.draughts + 2);
          toast('He slips you 2 vials and 2 draughts under the table.', '#ff8a9e');
        } else {
          let revealed = 0;
          for (const near of landmarksNear(world.seed, lm.x, lm.y, 2200, isLand)) {
            if (!G.prog.discovered.includes(near.id)) { G.prog.discovered.push(near.id); revealed++; }
          }
          toast(`He unrolls a stolen map — ${revealed} landmarks revealed.`, '#9ee8ff');
        }
        G.audio.sfx('pickup');
        burst(G, lm.x, lm.y - 6, '#f2c96e', 10, 70);
        G.uiV++;
        break;
      }
      case 'geyser': {
        if ((geyserCd.get(lm.id) ?? 0) > G.time) { toast('The vent is sealed again.'); return; }
        geyserCd.set(lm.id, G.time + 120);
        const t = Math.min(9, lm.tier);
        toast('The vent SINGS — aether pours out!', '#7ab8ff');
        addRing(G, lm.x, lm.y, 6, 200, '#7ab8ff', 0.5, 2.5);
        for (let i = 0; i < 5; i++) {
          after(G, i * 0.9, () => {
            for (let j = 0; j < 2; j++) spawnPickup(G, 'aether', lm.x + randR(-30, 30), lm.y + randR(-30, 30), 2 + t);
            burst(G, lm.x, lm.y - 4, '#9ee8ff', 10, 110, { glow: true });
            G.audio.sfx('aether', 1.2, 0.6);
          });
        }
        // risk: the earth resents being cracked
        if (chance(0.35)) {
          after(G, 2.2, () => {
            if (G.mode !== 'play') return;
            toast('The vent WAILS — something answers.', '#e2552e');
            const biome = world.biomeAt(lm.x, lm.y);
            const pool = Object.values(KINDS).filter((k) => k.biomes.includes(biome) && k.tier <= Math.min(3, 1 + Math.floor(t / 2)));
            const usePool = pool.length ? pool : [KINDS.slime];
            for (let i = 0; i < 2 + Math.floor(t / 3); i++) {
              const a = rand(0, TAU);
              spawnEnemy(G, pick(usePool).id, lm.x + Math.cos(a) * 120, lm.y + Math.sin(a) * 120, t, 0.12);
            }
          });
        }
        G.uiV++;
        break;
      }
      case 'camp': {
        if (done) { toast('This camp is already cleared.'); return; }
        if (!campTriggered.has(lm.id)) {
          campTriggered.add(lm.id);
          spawnCampGuards(lm);
          return;
        }
        const foesNear = G.enemies.some((e) => !e.dead && dist(e.x, e.y, lm.x, lm.y) < 140);
        if (foesNear) { toast('The guards are still standing!'); return; }
        const amt = Math.round((26 + lm.tier * 16) * (1 + G.prog.lvl * 0.04));
        G.prog.aether += amt;
        G.prog.poiDone.push(lm.id);
        gainXp(G, 30 + lm.tier * 12);
        addText(G, p.x, p.y - 18, `+${amt} aether`, '#ffd75e', 7, true);
        G.banner = { title: 'CAMP CLEARED', sub: `${lm.name} looted  ·  +${amt} aether`, t: 0, color: '#ff9e4e' };
        burst(G, lm.x, lm.y, '#ff9e4e', 20, 110);
        for (let i = 0; i < 4; i++) spawnPickup(G, 'aether', lm.x + randR(-18, 18), lm.y + randR(-18, 18), Math.round(amt / 5));
        if (chance(0.6)) spawnPickup(G, 'vial', lm.x, lm.y);
        G.audio.sfx('levelup');
        G.uiV++;
        break;
      }
    }
  }

  // ---------- save / load ----------
  function saveGame(): void {
    try {
      const p = G.player;
      G.prog.x = p.x; G.prog.y = p.y;
      G.prog.hp = p.hp; G.prog.mana = p.mana;
      localStorage.setItem(SAVE_KEY, JSON.stringify(G.prog));
    } catch { /* storage unavailable */ }
  }

  function loadGame(): boolean {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw) as Progress;
      if (!data || data.v !== 1 || typeof data.seed !== 'number' || data.seed !== world.seed) return false;
      // merge v2 fields so old saves keep working
      G.prog = {
        ...data,
        quests: Array.isArray(data.quests) ? data.quests : [],
        questsDone: data.questsDone ?? 0,
        questSeed: data.questSeed ?? Math.floor(Math.random() * 1e6),
        poiDone: Array.isArray(data.poiDone) ? data.poiDone : [],
        elKills: data.elKills ?? {},
        eliteKills: data.eliteKills ?? 0,
      };
      G.player = createPlayer(data.x, data.y);
      G.player.lvl = data.lvl;
      G.player.maxHp = 100 + 6 * (data.lvl - 1);
      G.player.maxMana = 60 + 4 * (data.lvl - 1);
      G.player.hp = clamp(data.hp || G.player.maxHp, 1, G.player.maxHp);
      G.player.mana = clamp(data.mana || G.player.maxMana, 0, G.player.maxMana);
      G.cam.x = data.x; G.cam.y = data.y;
      // migration: older saves predate some schools — grant them at level 1
      for (const el of ELEMENT_IDS) if (!G.prog.schools[el]) G.prog.schools[el] = { lvl: 1, xp: 0 };
      // migration: v3 classes + skill tree
      if (typeof G.prog.cls !== 'string') G.prog.cls = '';
      if (typeof G.prog.points !== 'number') G.prog.points = 0;
      if (typeof G.prog.pointsEarned !== 'number') G.prog.pointsEarned = 0;
      if (!G.prog.universal || typeof G.prog.universal !== 'object') G.prog.universal = {};
      // migration: v4 relics + echoes + ascension
      if (typeof G.prog.echoes !== 'number') G.prog.echoes = 0;
      if (!Array.isArray(G.prog.relics)) G.prog.relics = [];
      if (!Array.isArray(G.prog.equipped)) G.prog.equipped = [null, null, null];
      if (!G.prog.ascensions || typeof G.prog.ascensions !== 'object') G.prog.ascensions = {};
      if (typeof G.prog.ngPlus !== 'number') G.prog.ngPlus = 0;
      // legacy saves get a respectful welcome kit: the Elementalist path + a few points
      if (!G.prog.cls) {
        G.prog.cls = 'elementalist';
        G.prog.points += 2;
        G.prog.pointsEarned += 2;
      }
      applyUniversalStats();
      if (data.muted) audio.setMuted(true);
      return true;
    } catch {
      return false;
    }
  }

  function hasSave(): boolean {
    try { return !!localStorage.getItem(SAVE_KEY); } catch { return false; }
  }

  // ---------- api ----------
  // universal skill-node stat application (Vitality/Focus)
  function applyUniversalStats(): void {
    const p = G.player;
    p.maxHp = 100 + 6 * (G.prog.lvl - 1) + 15 * (G.prog.universal.vit ?? 0);
    p.maxMana = 60 + 4 * (G.prog.lvl - 1) + 12 * (G.prog.universal.focus ?? 0);
    p.hp = Math.min(p.hp, p.maxHp);
    p.mana = Math.min(p.mana, p.maxMana);
  }

  const api: GameApi = {
    startNew(clsId?: string) {
      G.prog = defaultProgress(spawnShrine.x, spawnShrine.y + 20, world.seed);
      const cls = clsId && CLASSES[clsId] ? clsId : '';
      G.prog.cls = cls;
      if (cls) {
        // class starting school levels (rank math: invest points from here)
        for (const [el, lvl] of Object.entries(CLASSES[cls].start)) {
          G.prog.schools[el] = { lvl: Math.max(1, lvl as number), xp: 0 };
        }
      }
      // starting loadout follows the class fantasy: one bolt per starting school
      const startEls = cls ? Object.keys(CLASSES[cls].start) as ElementId[] : ['fire', 'frost'];
      G.prog.loadout[0] = `${startEls[0]}.bolt`;
      if (startEls[1]) G.prog.loadout[1] = `${startEls[1]}.bolt`;
      else G.prog.loadout[1] = null;
      for (const id of G.prog.loadout) if (id && !G.prog.spells[id]) G.prog.spells[id] = { lvl: 1, xp: 0 };
      checkUnlocks(G);
      G.player = createPlayer(spawnShrine.x, spawnShrine.y + 20);
      applyUniversalStats();
      G.cam.x = G.player.x; G.cam.y = G.player.y;
      G.mode = 'play';
      G.audio.sfx('shrine');
      const cname = cls ? `You walk the Weald as ${CLASSES[cls].name} ${CLASSES[cls].title}. ` : '';
      toast(`${cname}The Weald awaits. (I grimoire · K skills · J bounties · M map)`);
      G.banner = { title: 'ARCANA INFINITA', sub: cls ? `${CLASSES[cls].name} — ${CLASSES[cls].passive}` : 'No quest. No chains. Twenty-four schools. One rule: survive.', t: 0, color: CLASSES[cls]?.color ?? '#c9b0f2' };
      G.uiV++;
      saveGame();
    },
    continueGame() {
      if (loadGame()) {
        G.mode = 'play';
        toast('The shrine remembers you.');
      } else {
        api.startNew();
      }
      G.uiV++;
    },
    investSkill(kind: 'school' | 'universal', id: string): boolean {
      if (G.prog.points <= 0) { toast('No skill points to spend — level up or keep casting.', '#c95ee8'); return false; }
      if (kind === 'school') {
        const s = G.prog.schools[id];
        if (!s || s.lvl >= 40) return false;
        s.lvl = Math.min(40, s.lvl + 2); // one point = +2 school levels
        G.prog.points--;
        const unlocked = checkUnlocks(G);
        const fav = unlocked.length === 1 ? spellDef(unlocked[0]) : null;
        toast(`${ELEMENTS[id as ElementId].school} studied — now Lv ${s.lvl}${fav ? ` · ${fav.name} learned!` : ''}`, elColor(id as ElementId));
        burst(G, G.player.x, G.player.y - 4, elColor(id as ElementId), 14, 90, { glow: true });
        addRing(G, G.player.x, G.player.y, 6, 160, elColor(id as ElementId), 0.4, 2);
        G.audio.sfx('unlock', 1.1, 0.7);
      } else {
        const cur = G.prog.universal[id] ?? 0;
        if (cur >= UNIVERSAL_MAX) return false;
        G.prog.universal[id] = cur + 1;
        G.prog.points--;
        applyUniversalStats();
        toast(`${UNIVERSALS[id]?.name ?? id} ${cur + 1}/${UNIVERSAL_MAX} — ${UNIVERSALS[id]?.desc ?? ''}`, '#ffd75e');
        burst(G, G.player.x, G.player.y - 4, '#ffd75e', 14, 90, { glow: true });
        G.audio.sfx('unlock', 1.1, 0.7);
      }
      G.uiV++;
      saveGame();
      return true;
    },
    respawn() {
      const p = G.player;
      // death stain
      G.stain = { x: p.x, y: p.y, amount: G.prog.aether };
      G.prog.aether = 0;
      p.dead = false;
      p.hp = p.maxHp;
      p.mana = p.maxMana;
      p.stam = p.maxStam;
      p.x = G.prog.shrineX; p.y = G.prog.shrineY + 18;
      p.iframes = 1.5;
      p.st = {};
      p.ward = null; p.enchant = null;
      G.enemies = []; G.bullets = []; G.zones = []; G.minions = [];
      G.boss = null; G.gate = null; G.teles = []; G.sched = [];
      G.spider = null;
      G.realm = null; // dying closes the realm — the effigy keeps its shards
      campTriggered.clear(); // camps re-ambush after a death
      G.cam.x = p.x; G.cam.y = p.y;
      G.mode = 'play';
      G.audio.sfx('shrine');
      burst(G, p.x, p.y, '#b8a8e8', 20, 90);
      G.uiV++;
      saveGame();
    },
    setMode(m: UIMode) {
      G.mode = m;
      G.uiV++;
    },
    attune(slot: number, spellId: string | null) {
      const slots = attuneSlots(G);
      if (slot < 0 || slot >= slots) return;
      G.prog.loadout[slot] = spellId;
      if (G.player.activeSlot === slot && !spellId) G.player.activeSlot = 0;
      G.audio.sfx('ui');
      G.uiV++;
    },
    buy(item: 'vial' | 'draught' | 'slot'): boolean {
      const costs = { vial: 12, draught: 10, slot: 90 + G.prog.slotsExtra * 60 };
      const cost = costs[item];
      if (G.prog.aether < cost) return false;
      if (item === 'vial') { if (G.prog.vials >= 9) return false; G.prog.vials++; }
      if (item === 'draught') { if (G.prog.draughts >= 9) return false; G.prog.draughts++; }
      if (item === 'slot') { if (attuneSlots(G) >= 8) return false; G.prog.slotsExtra++; }
      G.prog.aether -= cost;
      G.audio.sfx('pickup');
      G.uiV++;
      return true;
    },
    slotCost(): number { return 90 + G.prog.slotsExtra * 60; },
    rest() {
      const p = G.player;
      p.hp = p.maxHp; p.mana = p.maxMana; p.stam = p.maxStam;
      // HARD MODE: shrines are stingier
      G.prog.vials = Math.max(3, G.prog.vials);
      G.prog.draughts = Math.max(2, G.prog.draughts);
      G.prog.shrineX = p.x; G.prog.shrineY = p.y;
      // clear nearby foes
      for (const e of G.enemies) if (dist(e.x, e.y, p.x, p.y) < 320) e.dead = true;
      G.audio.sfx('shrine');
      burst(G, p.x, p.y - 6, '#ffd75e', 18, 80, { dir: -Math.PI / 2, spread: 1.4 });
      toast('The shrine remembers you. Respawn point set.');
      trackRest(G);
      G.uiV++;
      saveGame();
    },
    canFusePair(idA: string, idB: string) {
      return canFuse(G, idA, idB);
    },
    fuse(idA: string, idB: string): { ok: boolean; msg: string } {
      const res = canFuse(G, idA, idB);
      if (!res.ok) return { ok: false, msg: res.reason };
      if (G.prog.aether < FUSE_COST) return { ok: false, msg: `Requires ${FUSE_COST} aether.` };
      G.prog.aether -= FUSE_COST;
      const id = res.result!.id;
      G.prog.fused.push(id);
      G.prog.spells[id] = { lvl: 1, xp: 0 };
      G.audio.sfx('unlock');
      G.banner = { title: res.result!.name.toUpperCase(), sub: 'A new spell is born.', t: 0, color: elColor(res.result!.el) };
      G.uiV++;
      saveGame();
      return { ok: true, msg: `${res.result!.name} created!` };
    },
    saveNow() { saveGame(); },
    quitToTitle() {
      saveGame();
      G.mode = 'title';
      G.uiV++;
    },
    toggleMute() {
      audio.setMuted(!audio.isMuted());
      G.prog.muted = audio.isMuted();
      G.uiV++;
    },
    touchBtn(name: 'dodge' | 'parry' | 'potion' | 'interact', v: boolean) {
      const inp = G.input;
      if (name === 'dodge') inp.tDodge = v;
      if (name === 'parry') inp.tParry = v;
      if (name === 'potion') inp.tPotion = v;
      if (name === 'interact') inp.tInteract = v;
    },
    cheat(action: string, arg?: string) {
      const p = G.player;
      switch (action) {
        case 'god':
          G.cheat.god = !G.cheat.god;
          if (G.cheat.god) { p.iframes = 0; }
          toast(`GOD MODE ${G.cheat.god ? 'ON' : 'OFF'}`, '#ffd75e');
          break;
        case 'mana':
          G.cheat.infiniteMana = !G.cheat.infiniteMana;
          if (G.cheat.infiniteMana) p.mana = p.maxMana;
          toast(`INFINITE MANA ${G.cheat.infiniteMana ? 'ON' : 'OFF'}`, '#5ee8c9');
          break;
        case 'level':
          gainXp(G, charXpNeed(G.prog.lvl));
          toast('LEVEL UP', '#ffd75e');
          break;
        case 'level5':
          for (let i = 0; i < 5; i++) gainXp(G, charXpNeed(G.prog.lvl));
          toast('+5 LEVELS', '#ffd75e');
          break;
        case 'aether':
          G.prog.aether += 1000;
          toast('+1000 AETHER', '#ffd75e');
          break;
        case 'unlockAll':
          for (const el of ELEMENT_IDS) G.prog.schools[el] = { lvl: 40, xp: 0 };
          for (const id of ALL_SPELL_IDS) if (!G.prog.spells[id]) G.prog.spells[id] = { lvl: 10, xp: 0 };
          checkUnlocks(G);
          toast('THE ENTIRE GRIMOIRE — ALL 24 SCHOOLS MAXED (384 SPELLS)', '#c95ee8');
          G.audio.sfx('unlock');
          break;
        case 'points':
          G.prog.points += 3;
          G.prog.pointsEarned += 3;
          toast('+3 SKILL POINTS — press K to spend', '#c95ee8');
          break;
        case 'heal':
          p.hp = p.maxHp; p.mana = p.maxMana; p.stam = p.maxStam; p.st = {};
          toast('RESTORED', '#8effa8');
          break;
        case 'potions':
          G.prog.vials = 9; G.prog.draughts = 9;
          toast('SATCHEL FULL', '#ff8a9e');
          break;
        case 'fusion':
          G.prog.fusionUnlocked = true;
          toast('FUSION UNBOUND', '#c95ee8');
          break;
        case 'sigils':
          for (const s of Object.keys(SIGILS)) if (!G.prog.sigils.includes(s)) G.prog.sigils.push(s);
          toast('ALL SIGILS CLAIMED', '#ffd75e');
          break;
        case 'overdrive':
          G.overdrive = 6; G.odFlash = 0.5;
          G.audio.sfx('overdrive');
          break;
        case 'spawnElite': {
          const tier = tierOfDistance(G, p.x, p.y);
          const biome = world.biomeAt(p.x, p.y);
          const pool = Object.values(KINDS).filter((k) => k.biomes.includes(biome) && k.tier <= Math.min(3, 1 + Math.floor(tier / 2)));
          const k = pool.length ? pick(pool) : KINDS.slime;
          const a = rand(0, TAU);
          const e = spawnEnemy(G, k.id, p.x + Math.cos(a) * 260, p.y + Math.sin(a) * 260, Math.min(9, tier + 1), 0);
          e.elite = pick(['titan', 'frenzied', 'volatile', 'arcane'] as const);
          if (e.elite === 'titan') { e.scale = 1.4; e.r = k.r * 1.4; e.hp = k.hp * 3.4; e.maxHp = e.hp; }
          toast(`SUMMONED: ${e.elite} ${k.name}`, '#ff5a5a');
          break;
        }
        case 'killAll':
          for (const e of [...G.enemies]) if (!e.dead) handleEnemyDeath(G, e, 'arcane');
          G.boss = null; G.gate = null;
          toast('THE WEALD FALLS SILENT', '#e8e4d4');
          break;
        case 'spawnWeaver': {
          if (G.spider) { toast('The Weaver is already here.', '#c95ee8'); break; }
          const wasCheat = G.mode === 'cheat';
          const okSpawn = trySpawnWeaver(G, true);
          if (!okSpawn) toast(G.boss ? 'A boss already holds this ground — deal with it first.' : 'The Weaver cannot come here right now.', '#c95ee8');
          else if (wasCheat) { G.mode = 'play'; G.uiV++; }
          break;
        }
        case 'spawnMiniBoss': {
          const which = (arg ?? pickMiniBossForBiome(G) ?? 'maw') as 'maw' | 'roc' | 'choir' | 'mimic';
          if (G.spider || miniBossAlive(G)) { toast('Something personal is already hunting you.', '#c95ee8'); break; }
          const wasCheat2 = G.mode === 'cheat';
          const okMb = trySpawnMiniBoss(G, which, true);
          if (!okMb) toast(G.boss ? 'A boss already holds this ground.' : 'It cannot come here right now.', '#c95ee8');
          else if (wasCheat2) { G.mode = 'play'; G.uiV++; }
          break;
        }
        case 'refundSkills': {
          const spentSchools = 0; // school levels stay — refunding full trees would break unlock math
          void spentSchools;
          const spentU = UNIVERSAL_IDS.reduce((acc, u) => acc + (G.prog.universal[u] ?? 0), 0);
          for (const u of UNIVERSAL_IDS) delete G.prog.universal[u];
          G.prog.points += spentU;
          applyUniversalStats();
          toast(`Universal arts reset — ${spentU} point${spentU === 1 ? '' : 's'} refunded (school levels kept).`, '#c95ee8');
          break;
        }
        case 'tpShrine':
          p.x = G.prog.shrineX; p.y = G.prog.shrineY + 18;
          G.cam.x = p.x; G.cam.y = p.y;
          toast('RETURNED TO SHRINE', '#b8a8e8');
          break;
        case 'spawnBoss': {
          const id = arg ?? 'ashen';
          const loc = getLocations().find((l) => l.kind === 'boss' && l.bossId === id);
          if (!loc) { toast('Unknown boss.'); break; }
          G.prog.bosses = G.prog.bosses.filter((b) => b !== id);
          p.x = loc.x; p.y = loc.y + loc.r - 40;
          G.enemies = []; G.bullets = []; G.zones = []; G.teles = []; G.sched = [];
          G.boss = null; G.gate = null;
          G.cam.x = p.x; G.cam.y = p.y;
          G.mode = 'play';
          toast(`${BOSS_DEFS[id]?.name ?? id} awaits — step into the ring`, '#e2552e');
          break;
        }
        case 'relic':
          cheatRelic(G);
          toast('A RELIC MATERIALIZES + 3 ECHO SHARDS — press B for the satchel', '#ffd75e');
          break;
        case 'wipe':
          try { localStorage.removeItem(SAVE_KEY); } catch { /* ignore */ }
          toast('SAVE WIPED — reload the page for a fresh world', '#ff5a5a');
          return;
      }
      G.uiV++;
      saveGame();
    },
    getSnapshot() {
      return buildSnapshot();
    },
    buyRelic(id: string): boolean {
      const entry = SHOP_STOCK.find((s) => s.id === id);
      const def = RELICS[id];
      if (!entry || !def) return false;
      if (G.prog.relics.includes(id)) { toast('You already carry that relic.', '#c9b0f2'); return false; }
      if (G.prog.aether < entry.cost) { toast(`The peddler wants ${entry.cost} aether.`, '#ffd75e'); return false; }
      G.prog.aether -= entry.cost;
      grantRelic(G, id);
      toast(`${RARITY_LABEL[def.rarity]} relic acquired: ${def.name}`, def.color);
      G.audio.sfx('levelup', 1.1, 0.8);
      G.uiV++;
      saveGame();
      return true;
    },
    equipRelic(slot: number, id: string | null): void {
      equipRelicItem(G, slot, id);
      G.audio.sfx('ui', 1.2, 0.5);
      G.uiV++;
      saveGame();
    },
  };

  function toast(text: string, color = '#e8e4d4'): void {
    G.toasts.push({ text, t: 0, color });
    if (G.toasts.length > 4) G.toasts.shift();
  }

  // ---------- world events: the Weald is alive ----------
  function runWorldEvent(): void {
    const p = G.player;
    const tier = tierOfDistance(G, p.x, p.y);
    const roll = randi(0, 2);
    if (roll === 0) {
      // FALLING STAR: a spectacle and free loot a short sprint away
      toast('A star falls in the distance...', '#ffd75e');
      const a = rand(0, TAU);
      const d = randR(220, 420);
      const tx = p.x + Math.cos(a) * d, ty = p.y + Math.sin(a) * d;
      after(G, 1.6, () => {
        addTelegraph(G, {
          kind: 'circle', x: tx, y: ty, r: 34, dur: 1.1, color: '#ff9e4e', team: 'player',
          onDone: () => {
            explosion(G, tx, ty, 60, 0, 'fire', 'player', { noDmg: true });
            addRing(G, tx, ty, 10, 320, '#ffd75e', 0.6, 3);
            for (let i = 0; i < 6; i++) spawnPickup(G, 'aether', tx + randR(-26, 26), ty + randR(-26, 26), 3 + tier * 2);
            if (chance(0.35)) spawnPickup(G, 'vial', tx, ty);
            toast('THE STAR SHATTERED — claim its core!', '#ffd75e');
            G.audio.sfx('thunder');
            shake(G, 3);
          },
        });
      });
    } else if (roll === 1) {
      // ELITE HUNT: something old and angry has your scent
      G.banner = { title: 'AN ELITE STALKS YOU', sub: 'It comes with the smell of iron and rot', t: 0, color: '#ff5a5a' };
      G.audio.sfx('roar', 1.2, 0.8);
      const biome = world.biomeAt(p.x, p.y);
      const pool = Object.values(KINDS).filter((k) => k.biomes.includes(biome) && k.tier <= Math.min(3, 1 + Math.floor(tier / 2)));
      const k = pool.length ? pick(pool) : KINDS.slime;
      const a = rand(0, TAU);
      const e = spawnEnemy(G, k.id, p.x + Math.cos(a) * 380, p.y + Math.sin(a) * 380, Math.min(9, tier + 1), 0);
      e.elite = chance(0.5) ? 'titan' : 'frenzied';
      if (e.elite === 'titan') { e.scale = 1.4; e.r = k.r * 1.4; e.hp = k.hp * 3.4 * (1 + 0.4 * tier); e.maxHp = e.hp; }
    } else {
      // AETHER STORM: a roaming mana well
      toast('An AETHER STORM surrounds you — mana flows free', '#c95ee8');
      spawnZone(G, { kind: 'field', x: p.x, y: p.y, r: 150, dur: 30, el: 'arcane', team: 'player', dmg: 0, tick: 0.4 });
      burst(G, p.x, p.y, '#c95ee8', 20, 140, { glow: true });
      G.audio.sfx('unlock', 0.7, 0.6);
    }
  }

  // ---------- resize ----------
  function resize(): void {
    G.vw = window.innerWidth;
    G.vh = window.innerHeight;
    G.scale = Math.max(2, Math.min(5, Math.floor(Math.min(G.vw / 420, G.vh / 260))));
    G.W = Math.ceil(G.vw / G.scale);
    G.H = Math.ceil(G.vh / G.scale);
    canvas.width = G.W;
    canvas.height = G.H;
    canvas.style.width = `${G.vw}px`;
    canvas.style.height = `${G.vh}px`;
  }

  // ---------- input actions ----------
  let cheatBuf = '';
  function handleModeKeys(): void {
    const inp = G.input;
    const pressed = inp.pressed;
    // CHEAT CONSOLE: press ` (backtick) — or whisper the forbidden word
    if (pressed.has('`')) {
      cheatBuf = '';
      G.mode = G.mode === 'cheat' ? 'play' : 'cheat';
      G.uiV++;
      audio.sfx('ui');
      return;
    }
    for (const k of pressed) {
      if (k.length === 1 && k >= 'a' && k <= 'z') {
        cheatBuf = (cheatBuf + k).slice(-8);
        if (cheatBuf.endsWith('idkfa')) {
          cheatBuf = '';
          G.mode = 'cheat';
          G.uiV++;
          audio.sfx('unlock');
          return;
        }
      }
    }
    if (G.mode === 'play') {
      if (pressed.has('i')) { G.mode = 'grimoire'; G.uiV++; audio.sfx('ui'); }
      else if (pressed.has('c')) { G.mode = 'character'; G.uiV++; audio.sfx('ui'); }
      else if (pressed.has('j')) { G.mode = 'journal'; G.uiV++; audio.sfx('ui'); }
      else if (pressed.has('k')) { G.mode = 'skills'; G.uiV++; audio.sfx('ui'); }
      else if (pressed.has('b')) { G.mode = 'relics'; G.uiV++; audio.sfx('ui'); }
      else if (pressed.has('m')) { G.mode = 'map'; G.uiV++; audio.sfx('ui'); }
      else if (pressed.has('escape') || pressed.has('p')) { G.mode = 'pause'; G.uiV++; audio.sfx('ui'); }
      else if (pressed.has('u')) { api.toggleMute(); }
      else if (pressed.has('e') || inp.tInteract) { doInteract(); }
      // slot selection
      for (let i = 0; i < 8; i++) {
        if (pressed.has(String(i + 1))) {
          if (i < attuneSlots(G)) { G.player.activeSlot = i; audio.sfx('ui', 1.4, 0.3); }
        }
      }
      if (pressed.has('q')) {
        const slots = attuneSlots(G);
        G.player.activeSlot = (G.player.activeSlot + 1) % slots;
        audio.sfx('ui', 1.4, 0.3);
      }
      if (inp.wheel !== 0) {
        const slots = attuneSlots(G);
        G.player.activeSlot = (G.player.activeSlot + (inp.wheel > 0 ? 1 : slots - 1)) % slots;
      }
    } else if (['grimoire', 'character', 'map', 'pause', 'shop', 'fusion', 'help', 'journal', 'cheat', 'skills', 'statues', 'relics'].includes(G.mode)) {
      if (pressed.has('escape') || pressed.has(G.mode === 'map' ? 'm' : G.mode === 'grimoire' ? 'i' : G.mode === 'character' ? 'c' : G.mode === 'journal' ? 'j' : G.mode === 'skills' ? 'k' : G.mode === 'relics' ? 'b' : 'x')) {
        G.mode = 'play'; G.uiV++; audio.sfx('ui');
      }
    }
  }

  function doInteract(): void {
    const p = G.player;
    // statues first — an effigy under your feet owns this E press
    if (tryInteractStatue(G)) return;
    // village market: opens the same trading panel as a shrine
    const vs = villageShopNear(p.x, p.y);
    if (vs) {
      G.mode = 'shop';
      G.uiV++;
      G.audio.sfx('ui');
      return;
    }
    // shrine: open shrine panel (rest + shop)
    if (G.shrineNear) {
      G.mode = 'shop';
      G.uiV++;
      audio.sfx('ui');
      return;
    }
    if (G.fuseAltarNear) {
      if (G.prog.fusionUnlocked) {
        G.mode = 'fusion'; G.uiV++;
        audio.sfx('ui');
      } else {
        toast('The altar is sealed. Defeat a boss or reach level 10 to unbind fusion.', '#c95ee8');
      }
      return;
    }
    if (G.poiNear) {
      poiInteract(G.poiNear);
      return;
    }
  }

  // ---------- interactions scan ----------
  function scanInteractions(): void {
    const p = G.player;
    G.shrineNear = false;
    G.fuseAltarNear = false;
    G.interactPrompt = null;
    G.poiNear = null;
    G.poiPrompt = null;
    for (const loc of getLocations()) {
      const d = dist(p.x, p.y, loc.x, loc.y);
      if (d < 46) {
        if (loc.kind === 'shrine') {
          G.shrineNear = true;
          G.interactPrompt = { x: loc.x, y: loc.y - 26, text: 'E — Rest at Shrine' };
        } else if (loc.bossId && G.prog.bosses.includes(loc.bossId)) {
          G.fuseAltarNear = true;
          G.interactPrompt = { x: loc.x, y: loc.y - 26, text: 'E — Fusion Altar' };
        } else if (loc.bossId) {
          G.interactPrompt = { x: loc.x, y: loc.y - 26, text: 'A dark altar... it hungers' };
        }
        if (!G.prog.discovered.includes(loc.id)) G.prog.discovered.push(loc.id);
      }
    }
    // the effigy ring — statues speak when you stand before them
    const st = statueNear(G);
    if (st && !G.interactPrompt) {
      G.interactPrompt = { x: st.x, y: st.y - 32, text: statuePromptText(G, st.bossId) };
    }
    // village market stall
    const vs = villageShopNear(p.x, p.y);
    if (vs && !G.interactPrompt) {
      G.interactPrompt = { x: vs.x, y: vs.y - 30, text: `E — Trade at ${vs.name}` };
    }
    // village discovery
    for (const v of villages()) {
      const d = dist(p.x, p.y, v.x, v.y);
      if (d < 300 && !G.prog.discovered.includes(v.id)) {
        G.prog.discovered.push(v.id);
        toast(`Discovered: ${v.name}`, '#ffb05e');
        gainXp(G, 20);
        G.audio.sfx('quest', 1.1, 0.5);
        G.uiV++;
      }
    }
    // landmarks: discovery + interaction (wide scan so camps can ambush from afar)
    const lms = landmarksNear(world.seed, p.x, p.y, 280, isLand);
    for (const lm of lms) {
      const d = dist(p.x, p.y, lm.x, lm.y);
      if (d < 140 && !G.prog.discovered.includes(lm.id)) {
        G.prog.discovered.push(lm.id);
        toast(`Discovered: ${lm.name}`, '#9ee8ff');
        gainXp(G, 15 + lm.tier * 5);
        trackDiscover(G);
        G.audio.sfx('quest', 1.2, 0.5);
        G.uiV++;
      }
      if (lm.kind === 'camp' && !campTriggered.has(lm.id) && !G.prog.poiDone.includes(lm.id) && d < 200) {
        campTriggered.add(lm.id);
        spawnCampGuards(lm);
      }
      if (d < 42 && !G.poiNear) {
        const label = poiLabel(lm);
        if (label) {
          G.poiNear = lm;
          G.poiPrompt = { x: lm.x, y: lm.y - 24, text: label };
        }
      }
    }
    // stain auto pickup
    if (G.stain && dist(p.x, p.y, G.stain.x, G.stain.y) < 22) {
      G.prog.aether += G.stain.amount;
      addText(G, p.x, p.y - 16, `+${G.stain.amount} aether recovered`, '#ffd75e', 6, true);
      G.audio.sfx('levelup', 1.2, 0.7);
      burst(G, G.stain.x, G.stain.y, '#ffd75e', 14, 80);
      G.stain = null;
      G.uiV++;
    }
    // delve progression: current wave dead → next wave / plunder
    if (delveWave.size > 0) {
      for (const [id, wv] of [...delveWave]) {
        if (G.prog.poiDone.includes(id)) { delveWave.delete(id); continue; }
        const lm = landmarksNear(world.seed, G.player.x, G.player.y, 3000, isLand).find((l) => l.id === id);
        if (!lm) continue;
        const nearFoes = G.enemies.some((e) => !e.dead && dist(e.x, e.y, lm.x, lm.y) < 260);
        if (!nearFoes && dist(p.x, p.y, lm.x, lm.y) < 460) {
          if (wv >= 3) { delveWave.delete(id); finishDelve(lm); }
          else { delveWave.set(id, wv + 1); spawnDelveWave(lm, wv + 1); }
        }
      }
    }
    // fusion unlock at level
    if (!G.prog.fusionUnlocked && G.prog.lvl >= 10) {
      G.prog.fusionUnlocked = true;
      G.banner = { title: 'FUSION UNLOCKED', sub: 'Spell fusion is now possible at altars', t: 0, color: '#c95ee8' };
      G.audio.sfx('unlock');
    }
  }

  // ---------- spell unlock notifications ----------
  let unlockCheckT = 0;
  function checkNewUnlocks(dt: number): void {
    unlockCheckT -= dt;
    if (unlockCheckT > 0) return;
    unlockCheckT = 0.8;
    const unlocked = checkUnlocks(G);
    if (unlocked.length > 0) {
      const def = spellDef(unlocked[0])!;
      G.banner = {
        title: unlocked.length > 1 ? `${unlocked.length} NEW SPELLS` : def.name.toUpperCase(),
        sub: unlocked.length > 1 ? 'New spells learned — open the Grimoire (I)' : `${ELEMENTS[def.el].school} — press I to attune`,
        t: 0,
        color: elColor(def.el),
      };
      G.audio.sfx('unlock');
      G.uiV++;
    }
  }

  // ---------- main loop ----------
  let last = performance.now();
  let acc = 0;
  const STEP = 1 / 60;

  function frame(now: number): void {
    if (!G.running) return;
    requestAnimationFrame(frame);
    let dtReal = Math.min(0.1, (now - last) / 1000);
    last = now;

    // time scale
    let ts = 1;
    if (G.slowmo) {
      G.slowmo.t -= dtReal;
      ts = G.slowmo.scale;
      if (G.slowmo.t <= 0) G.slowmo = null;
    }
    if (G.hitstop > 0) {
      G.hitstop -= dtReal;
      ts = 0;
    }
    const simPaused = G.mode !== 'play';
    const dt = Math.min(ts * dtReal, 0.1);
    G.time += dt;
    G.frame++;

    G.input.update();
    handleModeKeys();
    // kick zoom decays — a heartbeat, not a lifestyle
    G.kickZoom = Math.max(0, G.kickZoom - dtReal * 0.22);

    // MUSIC: boss theme in fights, Arachne's Web for mini-bosses; muffle (not silence) while menus are open
    const miniUp = !!(G.spider && !G.spider.dead) || miniBossAlive(G);
    const wantTrack = G.boss && !G.boss.dead && G.boss.state !== 'dying' ? 'boss' : miniUp ? 'miniboss' : 'world';
    audio.setTrack(wantTrack);
    audio.setMuffled(G.mode !== 'play');

    if (!simPaused) {
      acc += dt;
      let steps = 0;
      while (acc >= STEP && steps < 4) {
        step(STEP);
        acc -= STEP;
        steps++;
      }
      if (steps === 4) acc = 0;
      G.prog.playtime += dt;
    }

    render();
    G.input.endFrame();
  }

  function step(dt: number): void {
    const p = G.player;
    updateSched(G, dt);
    updatePlayer(G, dt);
    updateMinions(G, dt);
    updateEnemies(G, dt);
    updateVillagers(G, dt);
    updateSpider(G, dt);
    updateMiniBosses(G, dt);
    updateGhosts(G, dt);
    updateBoss(G, dt);
    updateStatues(G, dt);
    updateArenas(G, dt);
    updateAmbient(G, dt);
    updateBullets(G, dt);
    updateZones(G, dt);
    updateBeams(G, dt);
    updateTeles(G, dt);
    updateFx(G, dt);
    updatePickups(G, dt);
    updateCorpses(G, dt);
    updateSpawner(G, dt);
    envHazardTick(G, dt);
    tryStartBoss(G);
    scanInteractions();
    checkNewUnlocks(dt);

    // dopamine engine timers
    if (G.combo.t > 0) {
      G.combo.t -= dt;
      if (G.combo.t <= 0) G.combo.n = 0;
    }
    if (G.overdrive > 0) {
      G.overdrive -= dt;
      if (G.frame % 4 === 0) {
        spawnParticle(G, {
          x: p.x + randR(-13, 13), y: p.y + randR(-15, 9),
          vx: randR(-12, 12), vy: -44, life: 0.5, size: 2,
          color: chance(0.5) ? '#ff9e4e' : '#ffd75e', glow: true,
        });
      }
      if (G.overdrive <= 0) addText(G, p.x, p.y - 20, 'overdrive ends', '#b8a890', 4);
    }
    if (G.odFlash > 0) G.odFlash = Math.max(0, G.odFlash - dt * 2);
    // world events: the Weald keeps surprising you
    if (G.mode === 'play') {
      G.eventT -= dt;
      if (G.eventT <= 0) { G.eventT = randR(140, 220); runWorldEvent(); }
      // the weaver ambush clock: it hunts the dark places, never during a boss
      if (!G.spider && !G.boss) {
        G.spiderT -= dt;
        if (G.spiderT <= 0) {
          G.spiderT = randR(110, 190);
          trySpawnWeaver(G);
        }
      }
    }
    // screen flash decay
    if (G.screenFlash) {
      G.screenFlash.t += dt;
      if (G.screenFlash.t >= G.screenFlash.dur) G.screenFlash = null;
    }
    questTick(G, questPool);
    if (G.prog.bosses.length !== lastBossCount) {
      lastBossCount = G.prog.bosses.length;
      trackBoss(G);
    }

    // gate enforcement
    if (G.gate && !p.dead) {
      const d = dist(p.x, p.y, G.gate.x, G.gate.y);
      if (d > G.gate.r) {
        const a = Math.atan2(p.y - G.gate.y, p.x - G.gate.x);
        p.x = G.gate.x + Math.cos(a) * G.gate.r;
        p.y = G.gate.y + Math.sin(a) * G.gate.r;
        if (p.iframes <= 0) damagePlayer(G, 5, 'fire');
        if (G.frame % 30 === 0) toast('You cannot abandon the hunt.', '#ff8a5e');
      }
    }

    // camera
    const lead = 0.12;
    const tx = p.x + (G.input.wx - p.x) * lead;
    const ty = p.y + (G.input.wy - p.y) * lead;
    G.cam.x = lerp(G.cam.x, tx, clamp(6 * dt, 0, 1));
    G.cam.y = lerp(G.cam.y, ty, clamp(6 * dt, 0, 1));
    G.cam.shake *= 1 - 6 * dt;
    G.cam.shX = (Math.random() - 0.5) * 2 * G.cam.shake;
    G.cam.shY = (Math.random() - 0.5) * 2 * G.cam.shake;

    // death check
    if (p.dead && G.mode === 'play') {
      G.prog.deaths++;
      G.mode = 'dead';
      G.uiV++;
    }

    // banner/toasts
    if (G.banner) { G.banner.t += dt; if (G.banner.t > 3.4) G.banner = null; }
    for (const t of G.toasts) t.t += dt;
    G.toasts = G.toasts.filter((t) => t.t < 3.6);

    // autosave
    G.saveT += dt;
    if (G.saveT > 12) { G.saveT = 0; saveGame(); }

    // input world coords
    G.input.wx = G.input.mx + G.cam.x - G.W / 2;
    G.input.wy = G.input.my + G.cam.y - G.H / 2;
  }

  // ---------- rendering ----------
  function render(): void {
    const ctx = G.ctx;
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#0d0a14';
    ctx.fillRect(0, 0, G.W, G.H);
    if (G.mode === 'title') {
      drawTitleBg();
      return;
    }
    const camL = G.cam.x + G.cam.shX - G.W / 2;
    const camT = G.cam.y + G.cam.shY - G.H / 2;
    ctx.save();
    // KICK ZOOM: the camera punches in for a heartbeat on big moments
    if (G.kickZoom > 0.001) {
      const z = 1 + G.kickZoom;
      ctx.translate(G.vw / 2, G.vh / 2);
      ctx.scale(z, z);
      ctx.translate(-G.vw / 2, -G.vh / 2);
    }
    ctx.translate(Math.round(-camL), Math.round(-camT));

    drawTiles(camL, camT);
    drawZones(G, 'ground');
    drawCorpses(G);
    drawPickups(G);
    if (G.stain) drawStain();
    drawYsorted(camL, camT);
    drawZones(G, 'air');
    drawBullets(G);
    drawRings(G);
    drawBeams(G);
    drawTeles(G);
    drawParticles(G);
    drawGate();
    drawGateBarrier(G);
    drawTexts(G);
    ctx.restore();

    // overlays
    if (G.realm) drawRealmOverlay(G);
    drawVignette();
    if (G.mode === 'map') { drawBigMap(); return; }
    drawHUD();
    drawCrosshair(G);
  }

  // tile id → ground family (for variant + edge-transition lookups)
  const TILE_FAMILY: Record<number, string> = {
    1: 'grass', 2: 'grass', 3: 'grass', 4: 'grass_dry',
    5: 'forest', 6: 'forest', 7: 'darkwood',
    8: 'sand', 9: 'sand', 10: 'snow', 11: 'snow', 22: 'tundra_rock',
    12: 'swamp', 13: 'rock', 14: 'wastes', 15: 'arcane', 16: 'volcanic',
    17: 'water', 18: 'water', 19: 'lava', 20: 'arena', 21: 'path', 23: 'arena',
  };
  const EDGE_SIDES: Array<[number, number, EdgeSide]> = [[0, -1, 'n'], [0, 1, 's'], [-1, 0, 'w'], [1, 0, 'e']];

  function familyOf(t: number): string {
    if (t >= T_FLOOR_BASE) return 'arena';
    return TILE_FAMILY[t] ?? 'grass';
  }

  function drawTiles(camL: number, camT: number): void {
    const ctx = G.ctx;
    const waterFrame = Math.floor(G.time * 1.8) % 2;
    const tx0 = Math.floor(camL / TILE) - 1;
    const ty0 = Math.floor(camT / TILE) - 1;
    const tx1 = Math.ceil((camL + G.W) / TILE) + 1;
    const ty1 = Math.ceil((camT + G.H) / TILE) + 1;
    const w = tx1 - tx0 + 1, h = ty1 - ty0 + 1;
    const ids = new Uint8Array(w * h);
    for (let ty = 0; ty < h; ty++) {
      for (let tx = 0; tx < w; tx++) {
        ids[ty * w + tx] = G.world.tileAt((tx0 + tx) * TILE + 8, (ty0 + ty) * TILE + 8);
      }
    }
    const seed = G.world.seed;
    // ---- pass 1: base tiles (mood = 4x4-region tint patch, variant = per-tile detail)
    for (let ty = 0; ty < h; ty++) {
      for (let tx = 0; tx < w; tx++) {
        const t = ids[ty * w + tx];
        const px = (tx0 + tx) * TILE, py = (ty0 + ty) * TILE;
        let spr: HTMLCanvasElement | undefined;
        if (t >= T_FLOOR_BASE) {
          const info = bossOfFloorTile(t);
          const tiers = info ? ARENA_FLOORS[info.boss] : null;
          if (tiers) {
            const arr = tiers[info!.tier];
            if (arr && arr.length) spr = arr[Math.floor(hash2(tx0 + tx, ty0 + ty, seed + 5) * arr.length) % arr.length];
          }
        } else if (t === T_WATER || t === T_SHALLOW) {
          spr = waterFrame ? SPR[t === T_WATER ? 'tile_water2' : 'tile_shallow2'] : SPR[t === T_WATER ? 'tile_water' : 'tile_shallow'];
        } else if (t === T_LAVA) {
          spr = waterFrame ? SPR.tile_lava2 : SPR.tile_lava;
        } else {
          const fam = familyOf(t);
          const arr = LUX_TILES[fam] ?? LUX_TILES.grass;
          if (arr && arr.length) {
            // mood: one hash per 4x4 region → whole patches share a tint
            const vCount = Math.max(1, Math.round(arr.length / 4));
            const moods = Math.max(1, Math.floor(arr.length / vCount));
            const mood = Math.min(moods - 1, Math.floor(hash2((tx0 + tx) >> 2, (ty0 + ty) >> 2, seed + 91) * moods));
            const v = Math.min(vCount - 1, Math.floor(hash2(tx0 + tx, ty0 + ty, seed + 17) * vCount));
            spr = arr[mood * vCount + v];
          }
        }
        if (spr) ctx.drawImage(spr, px, py);
      }
    }
    // ---- pass 2: boundary dithers — the neighbor's terrain bleeds onto mine
    for (let ty = 0; ty < h; ty++) {
      for (let tx = 0; tx < w; tx++) {
        const t = ids[ty * w + tx];
        const f = familyOf(t);
        if (f === 'wall') continue;
        const rank = FAMILY_RANK[f] ?? 3;
        for (const [dx, dy, side] of EDGE_SIDES) {
          const nx = tx + dx, ny = ty + dy;
          if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
          const nt = ids[ny * w + nx];
          const nf = familyOf(nt);
          if (nf === f || nf === 'wall') continue;
          const nRank = FAMILY_RANK[nf] ?? 3;
          const px = (tx0 + tx) * TILE, py = (ty0 + ty) * TILE;
          const edge = EDGE_TILES[nf]?.[side];
          if (!edge) continue;
          if (f === 'water' || f === 'lava') {
            // water gets foam, lava gets glow, toward any land neighbor
            const mine = EDGE_TILES[f]?.[side];
            if (mine) { ctx.globalAlpha = f === 'lava' ? 0.55 : 0.9; ctx.drawImage(mine, px, py); ctx.globalAlpha = 1; }
          } else if (nf === 'water' || nf === 'lava') {
            // wet / scorched rim on the land side
            ctx.globalAlpha = nf === 'lava' ? 0.3 : 0.4;
            ctx.drawImage(edge, px, py);
            ctx.globalAlpha = 1;
          } else if (nRank > rank) {
            ctx.drawImage(edge, px, py);
          }
        }
      }
    }
  }

  function drawYsorted(camL: number, camT: number): void {
    const items: Array<{ y: number; f: () => void }> = [];
    // landmarks (points of interest) near the camera
    for (const lm of landmarksNear(world.seed, G.cam.x, G.cam.y, 720, isLand)) {
      items.push({ y: lm.y, f: () => drawLandmark(lm) });
    }
    // village structures + wandering villagers
    for (const it of villageDrawItems(G)) items.push(it);
    for (const it of statueDrawItems(G)) items.push(it);
    // boss arena structures (walls, towers, braziers, banners, arch)
    for (const it of arenaDrawItems(G)) items.push(it);
    // ambient critters (rabbits, foxes, wisps...)
    for (const it of ambientDrawItems(G)) items.push(it);
    // decor from visible chunks
    const cx0 = Math.floor(camL / CHUNK_PX) - 1;
    const cy0 = Math.floor(camT / CHUNK_PX) - 1;
    const cx1 = Math.ceil((camL + G.W) / CHUNK_PX) + 1;
    const cy1 = Math.ceil((camT + G.H) / CHUNK_PX) + 1;
    for (let cy = cy0; cy <= cy1; cy++) {
      for (let cx = cx0; cx <= cx1; cx++) {
        const ch = G.world.chunkAt(cx, cy);
        for (const d of ch.decor) {
          if (d.x < camL - 24 || d.x > camL + G.W + 24 || d.y < camT - 40 || d.y > camT + G.H + 24) continue;
          items.push({
            y: d.y, f: () => {
              const spr = SPR[d.sprite];
              if (!spr) return;
              const c2 = G.ctx;
              if (d.solid) {
                c2.globalAlpha = 0.3; c2.fillStyle = '#000';
                c2.beginPath(); c2.ellipse(d.x, d.y - 1, spr.width * 0.32, 2, 0, 0, Math.PI * 2); c2.fill();
                c2.globalAlpha = 1;
              }
              if (d.flip) {
                c2.save();
                c2.translate(Math.round(d.x), Math.round(d.y));
                c2.scale(-1, 1);
                c2.drawImage(spr, -spr.width / 2, -spr.height + 2);
                c2.restore();
              } else {
                c2.drawImage(spr, Math.round(d.x - spr.width / 2), Math.round(d.y - spr.height + 2));
              }
            },
          });
        }
      }
    }
    for (const m of G.minions) {
      if (!m.dead) items.push({ y: m.y, f: () => drawMinionOne(G, m) });
    }
    for (const e of G.enemies) {
      if (!e.dead) items.push({ y: e.y, f: () => drawEnemyOne(G, e) });
    }
    for (const it of villagerDrawItems(G)) items.push(it);
    items.push({ y: G.player.y, f: () => drawPlayer(G) });
    if (G.ghosts.length) items.push({ y: G.player.y - 1, f: () => drawGhosts(G) });
    if (G.boss) items.push({ y: G.boss.y, f: () => drawBoss(G) });
    if (G.spider) items.push({ y: G.spider.body.y, f: () => drawSpider(G) });
    if (miniBossAlive(G)) items.push({ y: miniBossSortY(G), f: () => drawMiniBosses(G) });
    items.sort((a, b) => a.y - b.y);
    for (const it of items) it.f();
  }

  function drawEnemyOne(Gc: GameCtx, e: Parameters<typeof import('./enemies').drawEnemies>[0]['enemies'][number]): void {
    // draw single enemy via temporary single-item list
    const arr = Gc.enemies;
    Gc.enemies = [e];
    drawEnemies(Gc);
    Gc.enemies = arr;
  }

  function drawMinionOne(Gc: GameCtx, m: import('./core').Minion): void {
    const arr = Gc.minions;
    Gc.minions = [m];
    drawMinions(Gc);
    Gc.minions = arr;
  }

  function drawLandmark(lm: Landmark): void {
    const spr = SPR[LANDMARK_SPRITE[lm.kind]];
    if (!spr) return;
    const ctx = G.ctx;
    const done = G.prog.poiDone.includes(lm.id);
    // beacon glow for landmarks that still offer something
    if (!done) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.22 + 0.13 * Math.sin(G.time * 3 + lm.x * 0.1);
      ctx.fillStyle = LM_GLOW[lm.kind];
      ctx.beginPath(); ctx.arc(lm.x, lm.y - 8, 13, 0, TAU); ctx.fill();
      ctx.restore();
      // rising motes
      if (G.frame % 22 === 0) {
        spawnParticle(G, {
          x: lm.x + randR(-8, 8), y: lm.y - 4, vx: 0, vy: -16,
          life: 0.9, size: 1.6, color: LM_GLOW[lm.kind], glow: true,
        });
      }
    }
    ctx.globalAlpha = 0.25; ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.ellipse(lm.x, lm.y + 1, spr.width * 0.35, 2.2, 0, 0, TAU); ctx.fill();
    ctx.globalAlpha = done ? 0.6 : 1;
    ctx.drawImage(spr, Math.round(lm.x - spr.width / 2), Math.round(lm.y - spr.height + 2));
    ctx.globalAlpha = 1;
  }

  function drawStain(): void {
    const ctx = G.ctx;
    const s = G.stain!;
    const pulse = 1 + Math.sin(G.time * 5) * 0.15;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = '#ffd75e';
    ctx.beginPath(); ctx.arc(s.x, s.y, 8 * pulse, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 0.9;
    ctx.drawImage(SPR.stain, Math.round(s.x - 3.5), Math.round(s.y - 2.5));
    ctx.restore();
  }

  function drawGate(): void {
    if (!G.gate) return;
    const ctx = G.ctx;
    const g = G.gate;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 40; i++) {
      const a = (i / 40) * Math.PI * 2 + G.time * 0.4;
      const x = g.x + Math.cos(a) * g.r;
      const y = g.y + Math.sin(a) * g.r;
      ctx.globalAlpha = 0.5 + 0.4 * Math.sin(G.time * 6 + i);
      ctx.fillStyle = '#e2552e';
      ctx.fillRect(x - 2, y - 2, 4, 4);
    }
    ctx.restore();
  }

  function drawVignette(): void {
    const ctx = G.ctx;
    const biome = G.world.biomeAt(G.player.x, G.player.y);
    let tint: string | null = null;
    if (biome === 'volcanic') tint = 'rgba(160,40,10,0.10)';
    else if (biome === 'wastes') tint = 'rgba(90,40,120,0.10)';
    else if (biome === 'arcane') tint = 'rgba(120,80,180,0.08)';
    else if (biome === 'tundra') tint = 'rgba(180,220,240,0.07)';
    else if (biome === 'swamp') tint = 'rgba(60,90,40,0.08)';
    if (tint) {
      ctx.fillStyle = tint;
      ctx.fillRect(0, 0, G.W, G.H);
    }
    const grad = ctx.createRadialGradient(G.W / 2, G.H / 2, Math.min(G.W, G.H) * 0.42, G.W / 2, G.H / 2, Math.max(G.W, G.H) * 0.72);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(1, 'rgba(10,6,18,0.42)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, G.W, G.H);
    // overdrive: burning border
    if (G.overdrive > 0) {
      const a = 0.16 + 0.1 * Math.sin(G.time * 10);
      ctx.strokeStyle = `rgba(255,158,78,${a})`;
      ctx.lineWidth = 5;
      ctx.strokeRect(2.5, 2.5, G.W - 5, G.H - 5);
      ctx.strokeStyle = `rgba(255,215,94,${a * 0.6})`;
      ctx.lineWidth = 2;
      ctx.strokeRect(5.5, 5.5, G.W - 11, G.H - 11);
    }
    // grand-casting / parry screen flash (full wash, fades fast)
    if (G.screenFlash) {
      const f = G.screenFlash;
      ctx.globalAlpha = clamp(1 - f.t / f.dur, 0, 1) * 0.34;
      ctx.fillStyle = f.color;
      ctx.fillRect(0, 0, G.W, G.H);
      ctx.globalAlpha = 1;
    }
    // trigger flash
    if (G.odFlash > 0) {
      ctx.fillStyle = `rgba(255,180,90,${G.odFlash * 0.4})`;
      ctx.fillRect(0, 0, G.W, G.H);
    }
    // low hp warning
    if (G.player.hp / G.player.maxHp < 0.3 && !G.player.dead) {
      ctx.fillStyle = `rgba(180,20,20,${0.12 + 0.08 * Math.sin(G.time * 6)})`;
      ctx.fillRect(0, 0, G.W, G.H);
    }
  }

  // ---------- HUD ----------
  function drawHUD(): void {
    const ctx = G.ctx;
    const p = G.player;
    ctx.save();
    ctx.font = '5px monospace';

    // bars
    const bx = 8, by = 8;
    const bar = (x: number, y: number, w: number, h: number, frac: number, col: string, label: string) => {
      ctx.fillStyle = 'rgba(10,8,16,0.75)';
      ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
      ctx.fillStyle = '#2a2436';
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = col;
      ctx.fillRect(x, y, w * clamp(frac, 0, 1), h);
      ctx.font = '4px monospace';
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.fillText(label, x + 2, y + h - 1);
      ctx.font = '5px monospace';
    };
    bar(bx, by, 80, 6, p.hp / p.maxHp, '#c23a3a', `HP ${Math.ceil(p.hp)}/${p.maxHp}`);
    bar(bx, by + 8, 68, 5, p.mana / p.maxMana, '#3aa8a0', `MP ${Math.floor(p.mana)}`);
    bar(bx, by + 15, 56, 3, p.stam / p.maxStam, '#c9a84e', '');
    const xpNeed = charXpNeed(G.prog.lvl);
    bar(bx, by + 20, 56, 2, G.prog.xp / xpNeed, '#8e6ec9', '');
    // level badge
    ctx.fillStyle = '#2a2436';
    ctx.fillRect(bx + 60, by + 13, 26, 10);
    ctx.strokeStyle = '#8e6ec9';
    ctx.lineWidth = 1;
    ctx.strokeRect(bx + 60.5, by + 13.5, 25, 9);
    ctx.fillStyle = '#c9b0f2';
    ctx.font = '6px monospace';
    ctx.fillText(`Lv ${G.prog.lvl}`, bx + 63, by + 20);

    // aether + echoes + potions
    ctx.font = '6px monospace';
    ctx.fillStyle = '#ffd75e';
    ctx.fillText(`${G.prog.aether} aether`, bx, by + 32);
    ctx.fillStyle = '#8ee8ff';
    ctx.fillText(`${G.prog.echoes}\u25C7`, bx + 52, by + 32);
    ctx.fillStyle = '#ff8a9e';
    ctx.fillText(`[R] ${G.prog.vials}v`, bx + 68, by + 32);
    ctx.fillStyle = '#5ee8c9';
    ctx.fillText(`${G.prog.draughts}m`, bx + 92, by + 32);

    // statuses
    let sx = bx;
    const sy = by + 38;
    const st = p.st;
    const statusList: Array<[string, string]> = [];
    if (st.burn) statusList.push(['BURN', '#ff7a3e']);
    if (st.poison) statusList.push(['POISON', '#8ed94e']);
    if (st.chill) statusList.push(['CHILL', '#9edbe8']);
    if (st.stun || p.stunT > 0) statusList.push(['STUN', '#f2e35e']);
    if (st.root) statusList.push(['ROOT', '#6ab354']);
    if (st.wet) statusList.push(['WET', '#5eb8c9']);
    if (p.buffHaste > 0) statusList.push(['HASTE', '#e8c05e']);
    for (const [label, col] of statusList) {
      ctx.fillStyle = col;
      ctx.fillText(label, sx, sy);
      sx += ctx.measureText(label).width + 5;
    }

    // minimap
    drawMinimap(G.W - 72, 8, 64);

    // spell slots
    const slots = attuneSlots(G);
    const sw = 17;
    const totalW = slots * (sw + 2);
    const sx0 = G.W / 2 - totalW / 2;
    for (let i = 0; i < slots; i++) {
      const x = sx0 + i * (sw + 2);
      const y = G.H - 26;
      const id = G.prog.loadout[i];
      const def = id ? spellDef(id) : null;
      ctx.fillStyle = i === p.activeSlot ? 'rgba(60,45,90,0.9)' : 'rgba(16,12,26,0.85)';
      ctx.fillRect(x, y, sw, sw);
      ctx.strokeStyle = i === p.activeSlot ? '#ffd75e' : def ? elColor(def.el) : '#3a3448';
      ctx.lineWidth = i === p.activeSlot ? 1.5 : 1;
      ctx.strokeRect(x + 0.5, y + 0.5, sw - 1, sw - 1);
      if (def) {
        const glyph = SPR[`glyph_${def.el}_${def.form}`];
        if (glyph) ctx.drawImage(glyph, x + 2, y + 2);
        // cooldown sweep
        const cdTotal = def.cd;
        const cdFrac = clamp(p.castCd / Math.max(0.01, cdTotal), 0, 1);
        if (cdFrac > 0) {
          ctx.fillStyle = 'rgba(0,0,0,0.65)';
          ctx.fillRect(x, y, sw, sw * cdFrac);
        }
        if (p.mana < def.mana) {
          ctx.fillStyle = 'rgba(40,20,60,0.4)';
          ctx.fillRect(x, y, sw, sw);
        }
      }
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.font = '4px monospace';
      ctx.fillText(String(i + 1), x + 2, y + sw - 1.5);
    }

    // boss bar
    const boss = G.boss;
    if (boss) {
      const w = Math.min(240, G.W - 80);
      const x = G.W / 2 - w / 2;
      const y = G.H - 46;
      ctx.fillStyle = 'rgba(10,8,16,0.8)';
      ctx.fillRect(x - 2, y - 2, w + 4, 12);
      ctx.fillStyle = '#2a1010';
      ctx.fillRect(x, y, w, 6);
      ctx.fillStyle = boss.state === 'stagger' ? '#ffd75e' : '#a82a2a';
      ctx.fillRect(x, y, w * clamp(boss.hp / boss.maxHp, 0, 1), 6);
      // stagger meter
      ctx.fillStyle = '#2a2410';
      ctx.fillRect(x, y + 7, w, 2);
      ctx.fillStyle = '#e8c05e';
      ctx.fillRect(x, y + 7, w * clamp(boss.stagger / 100, 0, 1), 2);
      ctx.font = '5px monospace';
      ctx.fillStyle = '#e8e4d4';
      ctx.textAlign = 'center';
      ctx.fillText(boss.name, G.W / 2, y - 3);
      // phase pips
      for (let i = 0; i < boss.phaseCount; i++) {
        ctx.fillStyle = i <= boss.phase ? '#ffd75e' : '#4a4030';
        ctx.fillRect(x + w / 2 - boss.phaseCount * 3 + i * 6, y + 10, 4, 2);
      }
      ctx.textAlign = 'left';
    }

    // interact prompt
    if (G.interactPrompt || G.poiPrompt) {
      const pr = G.interactPrompt ?? G.poiPrompt!;
      ctx.font = '6px monospace';
      ctx.textAlign = 'center';
      const txt = pr.text;
      const px = pr.x - G.cam.x + G.W / 2;
      const py = pr.y - G.cam.y + G.H / 2;
      ctx.fillStyle = 'rgba(10,8,16,0.8)';
      const w = ctx.measureText(txt).width + 6;
      ctx.fillRect(px - w / 2, py - 8, w, 10);
      ctx.fillStyle = G.poiPrompt && !G.interactPrompt ? '#9ee8ff' : '#ffd75e';
      ctx.fillText(txt, px, py);
      ctx.textAlign = 'left';
    }

    // toasts
    ctx.font = '5px monospace';
    G.toasts.forEach((t, i) => {
      const a = clamp(Math.min(t.t * 3, (3.6 - t.t) * 2), 0, 1);
      ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(10,8,16,0.85)';
      const w = ctx.measureText(t.text).width + 8;
      ctx.fillRect(G.W / 2 - w / 2, 10 + i * 10, w, 8);
      ctx.fillStyle = t.color;
      ctx.textAlign = 'center';
      ctx.fillText(t.text, G.W / 2, 15 + i * 10);
      ctx.textAlign = 'left';
      ctx.globalAlpha = 1;
    });

    // combo counter (dopamine readout)
    if (G.combo.n >= 3) {
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      const pulse = 1 + (G.combo.t > 2.9 ? (G.combo.t - 2.9) * 3 : 0);
      ctx.globalAlpha = 0.95;
      ctx.fillStyle = '#000';
      ctx.fillText(`x${G.combo.n}`, G.W / 2 + 1, 33 * pulse + 1);
      ctx.fillStyle = G.overdrive > 0 ? '#ff9e4e' : '#ffd75e';
      ctx.fillText(`x${G.combo.n}`, G.W / 2, 33 * pulse);
      ctx.font = '4px monospace';
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.fillText('COMBO', G.W / 2, 39 * pulse);
      ctx.globalAlpha = 1;
      ctx.textAlign = 'left';
    }

    // overdrive meter
    if (G.overdrive > 0) {
      const w = 90;
      const x = G.W / 2 - w / 2;
      const y = 44;
      ctx.fillStyle = 'rgba(10,8,16,0.8)';
      ctx.fillRect(x - 1, y - 1, w + 2, 6);
      ctx.fillStyle = '#3a2410';
      ctx.fillRect(x, y, w, 4);
      ctx.fillStyle = '#ff9e4e';
      ctx.fillRect(x, y, w * clamp(G.overdrive / 6, 0, 1), 4);
      ctx.font = '5px monospace';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffd75e';
      ctx.fillText('OVERDRIVE — SPELLS EMPOWERED', G.W / 2, y + 11);
      ctx.textAlign = 'left';
    }

    // bounty tracker (current first bounty)
    const activeQ = G.prog.quests.find((q) => !q.done);
    if (activeQ) {
      ctx.font = '4px monospace';
      ctx.textAlign = 'right';
      ctx.fillStyle = 'rgba(232,228,212,0.75)';
      ctx.fillText(activeQ.title, G.W - 8, 70);
      ctx.fillStyle = '#7ce8a8';
      ctx.fillText(`${activeQ.have}/${activeQ.need}  ·  [J] bounties`, G.W - 8, 76);
      ctx.textAlign = 'left';
    }

    // banner
    if (G.banner) {
      const b = G.banner;
      const a = clamp(Math.min(b.t * 4, (3.4 - b.t) * 1.4), 0, 1);
      ctx.save();
      ctx.globalAlpha = a;
      ctx.textAlign = 'center';
      ctx.font = '14px monospace';
      ctx.fillStyle = '#000';
      ctx.fillText(b.title, G.W / 2 + 1, G.H * 0.3 + 1);
      ctx.fillStyle = b.color;
      ctx.fillText(b.title, G.W / 2, G.H * 0.3);
      ctx.font = '6px monospace';
      ctx.fillStyle = '#c9c2b0';
      ctx.fillText(b.sub, G.W / 2, G.H * 0.3 + 12);
      ctx.restore();
      ctx.textAlign = 'left';
    }

    // death fade handled by React overlay
    ctx.restore();
  }

  // ---------- minimap ----------
  let miniCanvas: HTMLCanvasElement | null = null;
  let miniT = 0;
  function drawMinimap(x: number, y: number, size: number): void {
    const ctx = G.ctx;
    miniT -= 1 / 60;
    if (!miniCanvas || miniT <= 0) {
      miniT = 0.5;
      if (!miniCanvas) {
        miniCanvas = document.createElement('canvas');
        miniCanvas.width = 27; miniCanvas.height = 27;
      }
      const mc = miniCanvas.getContext('2d')!;
      for (let iy = 0; iy < 27; iy++) {
        for (let ix = 0; ix < 27; ix++) {
          const wx = G.player.x + (ix - 13) * 90;
          const wy = G.player.y + (iy - 13) * 90;
          const b = G.world.biomeAt(wx, wy);
          mc.fillStyle = BIOME_COLORS[b] ?? '#333';
          mc.fillRect(ix, iy, 1, 1);
        }
      }
    }
    ctx.save();
    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(miniCanvas, x, y, size, size);
    // markers
    for (const loc of getLocations()) {
      const dx = (loc.x - G.player.x) / 90 / 27 * size + size / 2 + x;
      const dy = (loc.y - G.player.y) / 90 / 27 * size + size / 2 + y;
      if (dx < x - 2 || dx > x + size + 2 || dy < y - 2 || dy > y + size + 2) continue;
      if (loc.kind === 'shrine') {
        ctx.fillStyle = '#ffd75e';
        ctx.fillRect(dx - 1, dy - 1, 2, 2);
      } else if (loc.bossId) {
        const known = G.prog.bosses.includes(loc.bossId);
        const discovered = G.prog.discovered.includes(loc.id) || dist(G.player.x, G.player.y, loc.x, loc.y) < 2600;
        if (discovered) {
          ctx.fillStyle = known ? '#666' : '#e2552e';
          ctx.fillRect(dx - 1.5, dy - 1.5, 3, 3);
        }
      }
    }
    // discovered landmarks
    for (const lm of landmarksNear(world.seed, G.player.x, G.player.y, 1250, isLand)) {
      if (!G.prog.discovered.includes(lm.id)) continue;
      const dx = (lm.x - G.player.x) / 90 / 27 * size + size / 2 + x;
      const dy = (lm.y - G.player.y) / 90 / 27 * size + size / 2 + y;
      if (dx < x - 2 || dx > x + size + 2 || dy < y - 2 || dy > y + size + 2) continue;
      ctx.fillStyle = LM_GLOW[lm.kind];
      ctx.fillRect(dx - 1, dy - 1, 2, 2);
    }
    if (G.stain) {
      const dx = (G.stain.x - G.player.x) / 90 / 27 * size + size / 2 + x;
      const dy = (G.stain.y - G.player.y) / 90 / 27 * size + size / 2 + y;
      ctx.fillStyle = '#fff';
      ctx.fillRect(dx - 1, dy - 1, 2, 2);
    }
    // player arrow
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x + size / 2 - 1, y + size / 2 - 1, 2, 2);
    ctx.restore();
    ctx.strokeStyle = 'rgba(200,190,230,0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
    ctx.stroke();
  }

  // ---------- big map (clear atlas: regions, grid, compass, legend) ----------
  let bigMapCanvas: HTMLCanvasElement | null = null;
  const REGION_NAMES: Record<string, string> = {
    ocean: 'The Sunless Deeps', beach: 'The Pale Strand', grass: 'The Greenweald',
    forest: 'Tanglewood', darkwood: 'The Gloomshade', desert: 'The Searing Sands',
    swamp: 'The Mirefen', tundra: 'The Frostreach', volcanic: 'The Cinderwaste',
    wastes: 'The Hollow Wastes', arcane: 'The Aethermoor',
  };
  function drawBigMap(): void {
    const ctx = G.ctx;
    if (!bigMapCanvas) {
      bigMapCanvas = document.createElement('canvas');
      bigMapCanvas.width = 220; bigMapCanvas.height = 220;
      const mc = bigMapCanvas.getContext('2d')!;
      const range = 6600;
      // smoothed atlas: work at 110x110 with WIDE majority votes so biomes
      // read as coherent regions instead of confetti, then upscale 2x
      const N = 110;
      const votes: string[][] = [];
      for (let iy = 0; iy < N; iy++) {
        votes[iy] = [];
        for (let ix = 0; ix < N; ix++) {
          const wx = (ix / N - 0.5) * 2 * range;
          const wy = (iy / N - 0.5) * 2 * range;
          const tally: Record<string, number> = {};
          // 9 samples spread over ±170px — region-scale voting
          for (let sy = -1; sy <= 1; sy++) {
            for (let sx = -1; sx <= 1; sx++) {
              const b = G.world.biomeAt(wx + sx * 170, wy + sy * 170);
              tally[b] = (tally[b] ?? 0) + 1;
            }
          }
          let best = 'ocean', bn = 0;
          for (const [b, n] of Object.entries(tally)) if (n > bn) { bn = n; best = b; }
          votes[iy][ix] = best;
        }
      }
      // mode filter (3x3) for extra coherence
      const votes2: string[][] = votes.map((row, iy) => row.map((_, ix) => {
        const tally: Record<string, number> = {};
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const y2 = clamp(iy + dy, 0, N - 1), x2 = clamp(ix + dx, 0, N - 1);
            tally[votes[y2][x2]] = (tally[votes[y2][x2]] ?? 0) + 1;
          }
        }
        let best = votes[iy][ix], bn = 0;
        for (const [b, n] of Object.entries(tally)) if (n > bn) { bn = n; best = b; }
        return best;
      }));
      // shoreline detection at atlas resolution
      const isWater = votes2.map((row) => row.map((b) => b === 'ocean'));
      for (let iy = 0; iy < N; iy++) {
        for (let ix = 0; ix < N; ix++) {
          let col = BIOME_COLORS[votes2[iy][ix]] ?? '#333';
          if (isWater[iy][ix]) {
            const nearLand = [[0, -1], [0, 1], [-1, 0], [1, 0]].some(([dx, dy]) => {
              const y2 = iy + dy, x2 = ix + dx;
              return y2 >= 0 && y2 < N && x2 >= 0 && x2 < N && !isWater[y2][x2];
            });
            if (nearLand) col = '#e2d696';
          }
          mc.fillStyle = col;
          mc.fillRect(ix * 2, iy * 2, 2, 2);
        }
      }
    }
    const size = Math.min(G.W, G.H) - 54;
    const ox = G.W / 2 - size / 2;
    const oy = G.H / 2 - size / 2 + 4;
    const range = 6600;
    ctx.fillStyle = 'rgba(8,6,14,0.94)';
    ctx.fillRect(0, 0, G.W, G.H);
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(bigMapCanvas, ox, oy, size, size);
    // frame
    ctx.strokeStyle = '#6a5a8a';
    ctx.lineWidth = 1;
    ctx.strokeRect(ox - 1.5, oy - 1.5, size + 3, size + 3);
    ctx.strokeStyle = '#241d33';
    ctx.strokeRect(ox + 1.5, oy + 1.5, size - 3, size - 3);
    // grid every 2000px + labels
    ctx.strokeStyle = 'rgba(200,190,230,0.10)';
    ctx.fillStyle = 'rgba(200,190,230,0.45)';
    ctx.font = '4px monospace';
    for (let g = -6000; g <= 6000; g += 2000) {
      if (g === 0) continue;
      const [gx] = toMapPt(g, 0, ox, oy, size, range);
      const [, gy] = toMapPt(0, g, ox, oy, size, range);
      ctx.beginPath(); ctx.moveTo(gx, oy); ctx.lineTo(gx, oy + size); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(ox, gy); ctx.lineTo(ox + size, gy); ctx.stroke();
      ctx.fillText(`${g / 1000}k`, gx + 2, oy + 8);
      ctx.fillText(`${g / 1000}k`, ox + 3, gy - 2);
    }
    // center lines
    const [cx0, cy0] = toMapPt(0, 0, ox, oy, size, range);
    ctx.strokeStyle = 'rgba(255,248,216,0.16)';
    ctx.beginPath(); ctx.moveTo(cx0, oy); ctx.lineTo(cx0, oy + size); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ox, cy0); ctx.lineTo(ox + size, cy0); ctx.stroke();
    // region names (dominant biome per quadrant grid)
    ctx.textAlign = 'center';
    ctx.font = '5px monospace';
    for (let ry = 0; ry < 3; ry++) {
      for (let rx = 0; rx < 3; rx++) {
        const wx = (-4000 + rx * 4000);
        const wy = (-4000 + ry * 4000);
        const b = G.world.biomeAt(wx, wy);
        const [mx, my] = toMapPt(wx, wy, ox, oy, size, range);
        ctx.fillStyle = 'rgba(12,8,20,0.55)';
        ctx.fillRect(mx - 30, my - 4, 60, 8);
        ctx.fillStyle = 'rgba(232,228,212,0.75)';
        ctx.fillText(REGION_NAMES[b] ?? '', mx, my + 2);
      }
    }
    const toMap = (wx: number, wy: number): [number, number] => toMapPt(wx, wy, ox, oy, size, range);
    // locations
    for (const loc of getLocations()) {
      const [mx, my] = toMap(loc.x, loc.y);
      if (loc.kind === 'shrine') {
        // gold diamond
        ctx.fillStyle = '#ffd75e';
        ctx.beginPath();
        ctx.moveTo(mx, my - 2.5); ctx.lineTo(mx + 2.5, my); ctx.lineTo(mx, my + 2.5); ctx.lineTo(mx - 2.5, my);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.7)'; ctx.lineWidth = 0.5; ctx.stroke();
      } else if (loc.bossId) {
        const known = G.prog.bosses.includes(loc.bossId);
        const discovered = G.prog.discovered.includes(loc.id) || known;
        if (!discovered) continue;
        // red skull square (grey once slain)
        ctx.fillStyle = known ? '#7a7468' : '#e2552e';
        ctx.fillRect(mx - 2, my - 2, 4, 4);
        ctx.strokeStyle = '#000'; ctx.lineWidth = 0.6;
        ctx.strokeRect(mx - 2, my - 2, 4, 4);
        ctx.font = '4px monospace';
        ctx.fillStyle = known ? 'rgba(160,155,140,0.8)' : '#ffb0a0';
        ctx.fillText(BOSS_DEFS[loc.bossId]?.name ?? '', mx, my - 4);
      }
    }
    // villages — warm hearths on the atlas
    for (const v of villages()) {
      if (!G.prog.discovered.includes(v.id)) continue;
      const [mx, my] = toMap(v.x, v.y);
      if (mx < ox - 2 || mx > ox + size + 2 || my < oy - 2 || my > oy + size + 2) continue;
      ctx.fillStyle = '#ffb05e';
      ctx.fillRect(mx - 2.5, my - 2, 5, 4);
      ctx.fillStyle = '#7a4a20';
      ctx.beginPath(); ctx.moveTo(mx - 3, my - 2); ctx.lineTo(mx, my - 4.5); ctx.lineTo(mx + 3, my - 2); ctx.closePath(); ctx.fill();
      ctx.font = '4px monospace';
      ctx.fillStyle = 'rgba(255,200,140,0.9)';
      ctx.fillText(v.name, mx, my + 6);
    }
    // discovered landmarks — one glyph per kind
    ctx.font = '5px monospace';
    const LM_GLYPH: Record<string, string> = {
      camp: '\u25B2', tower: '\u25A0', obelisk: '\u25C6', cache: '\u25A1', grove: '\u25CB',
      dungeon: '\u25BC', merchant: '\u25B3', geyser: '\u25CF',
    };
    for (const lm of landmarksNear(world.seed, 0, 0, 8000, isLand)) {
      if (!G.prog.discovered.includes(lm.id)) continue;
      const [mx, my] = toMap(lm.x, lm.y);
      if (mx < ox - 2 || mx > ox + size + 2 || my < oy - 2 || my > oy + size + 2) continue;
      ctx.fillStyle = LM_GLOW[lm.kind];
      ctx.strokeStyle = 'rgba(0,0,0,0.8)';
      ctx.lineWidth = 0.6;
      ctx.fillText(LM_GLYPH[lm.kind] ?? '\u25CF', mx, my + 2);
      if (lm.kind === 'dungeon' || lm.kind === 'merchant') {
        ctx.strokeText(LM_GLYPH[lm.kind] ?? '', mx, my + 2);
      }
    }
    // death stain
    if (G.stain) {
      const [mx, my] = toMap(G.stain.x, G.stain.y);
      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = 0.5 + 0.5 * Math.sin(G.time * 6);
      ctx.beginPath(); ctx.arc(mx, my, 2, 0, TAU); ctx.fill();
      ctx.globalAlpha = 1;
    }
    // player arrow
    const [px, py] = toMap(G.player.x, G.player.y);
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.moveTo(px, py - 3); ctx.lineTo(px + 2.2, py + 2); ctx.lineTo(px - 2.2, py + 2);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#000'; ctx.lineWidth = 0.6; ctx.stroke();
    // compass
    ctx.fillStyle = '#c9b0f2';
    ctx.font = '7px monospace';
    ctx.fillText('N', ox + size / 2, oy - 8);
    // title + legend
    ctx.font = '7px monospace';
    ctx.fillStyle = '#c9b0f2';
    ctx.fillText('THE WEALD OF A THOUSAND SPELLS', G.W / 2, oy - 14);
    ctx.font = '4.5px monospace';
    ctx.fillStyle = '#a89ec0';
    const legend = [
      ['#ffd75e', 'shrine'], ['#e2552e', 'boss'], ['#ff9e4e', 'camp'], ['#9ee8ff', 'tower'],
      ['#c95ee8', 'obelisk'], ['#ffd75e', 'cache'], ['#5ee8c9', 'grove'], ['#e2552e', 'delve'],
      ['#f2c96e', 'peddler'], ['#7ab8ff', 'geyser'], ['#ffb05e', 'village'],
    ] as Array<[string, string]>;
    let lx = G.W / 2 - legend.length * 15;
    for (const [col, label] of legend) {
      ctx.fillStyle = col;
      ctx.fillRect(lx - 1, oy + size + 7, 2.5, 2.5);
      ctx.fillStyle = '#a89ec0';
      ctx.textAlign = 'left';
      ctx.fillText(label, lx + 2.5, oy + size + 10.5);
      lx += 15;
    }
    ctx.textAlign = 'center';
    ctx.fillStyle = '#6a6280';
    ctx.fillText(`you are here \u2014 tier ${tierOfDistance(G, G.player.x, G.player.y)} \u00B7 [M] close \u00B7 danger grows with distance`, G.W / 2, oy + size + 19);
    ctx.textAlign = 'left';
    ctx.restore();
  }

  function toMapPt(wx: number, wy: number, ox: number, oy: number, size: number, range: number): [number, number] {
    return [ox + (wx / range / 2 + 0.5) * size, oy + (wy / range / 2 + 0.5) * size];
  }

  // ---------- title bg ----------
  function drawTitleBg(): void {
    const ctx = G.ctx;
    const rng = mulberry32(7);
    ctx.fillStyle = '#0d0a14';
    ctx.fillRect(0, 0, G.W, G.H);
    for (let i = 0; i < 90; i++) {
      const x = rng() * G.W, y = rng() * G.H;
      const s = rng() > 0.85 ? 2 : 1;
      const tw = 0.4 + 0.6 * Math.abs(Math.sin(G.time * 1.4 + i));
      ctx.globalAlpha = tw * 0.8;
      ctx.fillStyle = rng() > 0.5 ? '#c9b0f2' : '#e8d494';
      ctx.fillRect(x, y, s, s);
    }
    ctx.globalAlpha = 1;
  }

  // ---------- snapshot ----------
  function buildSnapshot(): UISnapshot {
    const schools = ELEMENT_IDS.map((el) => ({
      id: el,
      name: ELEMENTS[el].name,
      school: ELEMENTS[el].school,
      lvl: G.prog.schools[el]?.lvl ?? 1,
      xp: G.prog.schools[el]?.xp ?? 0,
      need: schoolXpNeed(G.prog.schools[el]?.lvl ?? 1),
      color: elColor(el),
    }));
    const allSpells = Object.keys(G.prog.spells).map((id) => {
      const def = spellDef(id)!;
      const sp = G.prog.spells[id];
      return {
        id, name: def.name, el: def.el, el2: def.el2, form: def.form,
        lvl: sp.lvl, xp: sp.xp, need: spellXpNeed(sp.lvl),
        dmg: def.dmg, mana: def.mana, cd: def.cd,
        known: true, unlock: def.unlock, desc: def.desc, fused: !!def.fused,
      };
    });
    return {
      mode: G.mode,
      lvl: G.prog.lvl, xp: G.prog.xp, xpNeed: charXpNeed(G.prog.lvl),
      hp: G.player.hp, maxHp: G.player.maxHp, mana: G.player.mana, maxMana: G.player.maxMana,
      aether: G.prog.aether, vials: G.prog.vials, draughts: G.prog.draughts,
      slots: attuneSlots(G), activeSlot: G.player.activeSlot,
      loadout: [...G.prog.loadout],
      schools,
      spellCount: Object.keys(G.prog.spells).length,
      knownSpells: Object.keys(G.prog.spells),
      allSpells,
      fused: [...G.prog.fused],
      sigils: Object.entries(SIGILS).map(([id, s]) => ({ id, ...s, owned: G.prog.sigils.includes(id) })),
      bosses: [...G.prog.bosses],
      bossList: Object.values(BOSS_DEFS).map((d) => ({ id: d.id, name: d.name, killed: G.prog.bosses.includes(d.id) })),
      fusionUnlocked: G.prog.fusionUnlocked,
      kills: G.prog.kills, deaths: G.prog.deaths, playtime: G.prog.playtime,
      tier: tierOfDistance(G, G.player.x, G.player.y),
      muted: audio.isMuted(),
      hasSave: hasSave(),
      quests: G.prog.quests.map((q) => ({ id: q.id, title: q.title, have: q.have, need: q.need, done: q.done, reward: q.reward, kind: q.kind })),
      questsDone: G.prog.questsDone,
      landmarksFound: G.prog.discovered.filter((d) => d.startsWith('lm_')).length,
      overdrive: G.overdrive,
      combo: G.combo.n,
      mobile: G.mobile,
      cheatGod: G.cheat.god,
      cheatMana: G.cheat.infiniteMana,
      // v3: classes + skill tree
      cls: G.prog.cls,
      clsName: CLASSES[G.prog.cls]?.name ?? null,
      clsTitle: CLASSES[G.prog.cls]?.title ?? null,
      clsBlurb: CLASSES[G.prog.cls]?.blurb ?? null,
      clsPassive: CLASSES[G.prog.cls]?.passive ?? null,
      clsColor: CLASSES[G.prog.cls]?.color ?? '#c9b0f2',
      points: G.prog.points,
      pointsEarned: G.prog.pointsEarned,
      universal: { ...G.prog.universal },
      universalDefs: UNIVERSAL_IDS.map((u) => ({ id: u, name: UNIVERSALS[u].name, desc: UNIVERSALS[u].desc, color: UNIVERSALS[u].color, glyph: UNIVERSALS[u].glyph, max: UNIVERSAL_MAX })),
      // v4: relics + echoes + ascension
      echoes: G.prog.echoes,
      relics: Object.values(RELICS).map((r) => ({
        id: r.id, name: r.name, desc: r.desc, color: r.color, glyph: r.glyph, rarity: r.rarity,
        owned: G.prog.relics.includes(r.id),
        equipped: G.prog.equipped.indexOf(r.id),
      })),
      shopStock: SHOP_STOCK.map((s) => {
        const r = RELICS[s.id];
        return { id: s.id, name: r?.name ?? s.id, desc: r?.desc ?? '', color: r?.color ?? '#c9b0f2', glyph: r?.glyph ?? '◈', rarity: r?.rarity ?? 'common', cost: s.cost, owned: G.prog.relics.includes(s.id) };
      }),
      atVillage: !!villageShopNear(G.player.x, G.player.y),
      ngPlus: G.prog.ngPlus,
      ascensions: { ...G.prog.ascensions },
    };
  }

  // ---------- lifecycle ----------
  window.addEventListener('beforeunload', saveGame);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) saveGame();
  });

  requestAnimationFrame(frame);

  // debug/verification handle (harmless in production, useful for testing)
  if (typeof window !== 'undefined') {
    (window as unknown as { __arcana?: unknown }).__arcana = { G, api, landmarksNear: (r: number) => landmarksNear(world.seed, G.player.x, G.player.y, r, isLand), villages: () => villages() };
  }

  return { G, api };
}

// ---------- api type ----------
export interface GameApi {
  startNew: (clsId?: string) => void;
  continueGame: () => void;
  respawn: () => void;
  setMode: (m: UIMode) => void;
  investSkill: (kind: 'school' | 'universal', id: string) => boolean;
  attune: (slot: number, spellId: string | null) => void;
  buy: (item: 'vial' | 'draught' | 'slot') => boolean;
  slotCost: () => number;
  rest: () => void;
  canFusePair: (a: string, b: string) => { ok: boolean; reason: string; result?: SpellDef };
  fuse: (a: string, b: string) => { ok: boolean; msg: string };
  saveNow: () => void;
  quitToTitle: () => void;
  toggleMute: () => void;
  touchBtn: (name: 'dodge' | 'parry' | 'potion' | 'interact', v: boolean) => void;
  cheat: (action: string, arg?: string) => void;
  buyRelic: (id: string) => boolean;
  equipRelic: (slot: number, id: string | null) => void;
  getSnapshot: () => UISnapshot;
}

const BIOME_COLORS: Record<string, string> = {
  ocean: '#143f52',
  beach: '#e2cc84',
  grass: '#4e9e3e',
  forest: '#2f7a2e',
  darkwood: '#1f3a28',
  desert: '#d8b862',
  swamp: '#4e6a38',
  tundra: '#e8f0f4',
  volcanic: '#4a2622',
  wastes: '#54385e',
  arcane: '#6a5a92',
};
