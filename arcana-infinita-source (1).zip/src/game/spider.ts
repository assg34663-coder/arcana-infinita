/* ============================================================
   spider.ts — THE WEAVER. A giant spider miniboss that ambushes
   you in the dark places of the world. Fully procedural:

   - 8 legs, each its own damageable entity, each stepping with
     independent timing (procedural gait, IK-drawn).
   - A planted leg is an ANCHOR. The body only moves as well as
     its anchors allow. 3 legs (a tripod) keep it standing —
     the other 5 are free to attack you.
   - Fewer than 3 anchors and the whole beast COLLAPSES —
     a huge damage window while it scrambles to replant.
   - Kill the legs to cripple it, or dive past them and burst
     the body down directly. Your call.
   ============================================================ */
import {
  TAU, clamp, lerp, dist, angTo, rand, randR, chance,
  type GameCtx, type Enemy, type SpiderLeg, type SpiderState,
} from './core';
import {
  burst, spawnParticle, addText, addRing, addTelegraph, explosion,
  spawnZone, spawnPickup, shake, slowmo, screenFlash, damagePlayer,
  makeBullet,
} from './fx';
import { moveWithCollision } from './world';
import { DIFF, tierOfDistance, gainXp, KINDS } from './enemies';
import { elColor } from './sprites';

const ICHOR = '#8ee84e';
const CHITIN = '#2b1e36';
const CHITIN_DK = '#1c1324';
const EYE = '#ff5e6e';
// rest angles (relative to facing) per leg index on one side, front → back
const REST_ANG = [0.55, 1.18, 1.92, 2.55];
const REST_LEN = [44, 49, 47, 41];

export function weaverAlive(G: GameCtx): boolean {
  return !!G.spider && !G.spider.dead;
}

// ---------- spawn ----------
export function trySpawnWeaver(G: GameCtx, force = false): boolean {
  if (G.spider || G.boss || G.player.dead) return false;
  // normal ambusher needs live-play; the cheat console spawns from 'cheat' mode
  if (G.mode !== 'play' && !(force && G.mode === 'cheat')) return false;
  const tier = tierOfDistance(G, G.player.x, G.player.y);
  const biome = G.world.biomeAt(G.player.x, G.player.y);
  const homeBiomes = ['forest', 'darkwood', 'swamp', 'wastes', 'tundra'];
  if (!force) {
    if (tier < 2) return false;
    if (!homeBiomes.includes(biome)) return false;
  }
  // find a landing spot near the player — she drops from the canopy, so we
  // progressively relax the search and ALWAYS find ground (space must never
  // be the reason the ambush fails):
  //   pass 1: open (non-solid) ground in a comfy ring around the player
  //   pass 2: any non-ocean point in a wide ring — the collision resolver
  //           walks her out of tight spots, and pass 3 catches the rest
  let sx = 0, sy = 0, ok = false;
  const nonOcean = (x: number, y: number) => G.world.biomeAt(x, y) !== 'ocean';
  const nudgeToFree = (x: number, y: number): { x: number; y: number } | null => {
    for (let rr = 0; rr <= 3; rr++) {
      const steps = rr === 0 ? 1 : rr * 8;
      for (let i = 0; i < steps; i++) {
        const a = (i / steps) * TAU;
        const px = x + Math.cos(a) * rr * 8;
        const py = y + Math.sin(a) * rr * 8;
        if (!G.world.solidAt(px, py)) return { x: px, y: py };
      }
    }
    return null;
  };
  for (let i = 0; i < 48; i++) {
    const a = rand(0, TAU);
    const d = randR(150, 260);
    const x = G.player.x + Math.cos(a) * d;
    const y = G.player.y + Math.sin(a) * d;
    if (!nonOcean(x, y)) continue;
    const p = nudgeToFree(x, y);
    if (p) { sx = p.x; sy = p.y; ok = true; break; }
  }
  if (!ok) {
    for (let i = 0; i < 64; i++) {
      const a = rand(0, TAU);
      const d = randR(90, 420);
      const x = G.player.x + Math.cos(a) * d;
      const y = G.player.y + Math.sin(a) * d;
      if (nonOcean(x, y)) { sx = x; sy = y; ok = true; break; }
    }
  }
  if (!ok) { sx = G.player.x + 46; sy = G.player.y - 64; }

  const t = Math.min(9, tier);
  const tScale = 1 + 0.32 * (t - 1);
  // body entity
  const bodyHp = Math.round(560 * tScale * DIFF.hp);
  const body: Enemy = {
    x: sx, y: sy - 150, vx: 0, vy: 0, r: 14,
    hp: bodyHp, maxHp: bodyHp, team: 'enemy', st: {},
    flash: 0, dead: false, deadT: 0, face: 1, anim: rand(0, 9),
    kind: KINDS.weaver_body,
    tier: t, elite: null, state: 'chase', aiT: 0, atkT: 0, windup: 0,
    roamX: sx, roamY: sy, dmgMul: 1, hpMul: 1, contactT: 0, spawnGuard: 0.9,
    puppet: true,
  };

  const legs: SpiderLeg[] = [];
  for (let i = 0; i < 8; i++) {
    const side = i < 4 ? -1 : 1;
    const idx = i % 4;
    const legHp = Math.round(90 * (1 + 0.24 * (t - 1)) * DIFF.hp);
    const leg: Enemy = {
      x: sx, y: sy, vx: 0, vy: 0, r: 5,
      hp: legHp, maxHp: legHp, team: 'enemy', st: {},
      flash: 0, dead: false, deadT: 0, face: 1, anim: rand(0, 9),
      kind: KINDS.weaver_leg,
      tier: t, elite: null, state: 'chase', aiT: 0, atkT: 0, windup: 0,
      roamX: sx, roamY: sy, dmgMul: 1, hpMul: 1, contactT: 0, spawnGuard: 0.9,
      puppet: true,
    };
    legs.push({
      e: leg, side, idx,
      baseAng: REST_ANG[idx], baseLen: REST_LEN[idx] * (1 + randR(-0.04, 0.04)),
      fx: sx, fy: sy, planted: true, lift: 0,
      sx: sx, sy: sy, tx: sx, ty: sy, stepT: 0, stepDur: 0.15,
      atkCd: randR(2.6, 5.2), slamming: 0, markX: 0, markY: 0, grieved: false,
    });
  }

  const s: SpiderState = {
    body, legs,
    facing: angTo(sx, sy, G.player.x, G.player.y),
    groundX: sx, groundY: sy,
    collapsed: 0, collapseCd: 0, atkCd: randR(2.8, 4.2),
    intro: 0.85, dead: false, rewardT: 0, gaitT: 0,
  };
  // the parts live in the enemy list so every weapon in the game can hurt them
  G.enemies.push(body);
  for (const l of legs) G.enemies.push(l.e);
  G.spider = s;
  // splay the legs outward at spawn
  for (const l of legs) {
    const rest = restPos(s, l);
    l.fx = rest.x; l.fy = rest.y;
    l.e.x = rest.x; l.e.y = rest.y;
  }
  G.banner = { title: 'THE WEAVER', sub: 'Something eight-legged drops from the canopy', t: 0, color: '#c95ee8' };
  G.audio.sfx('roar', 0.72, 0.9);
  G.audio.sfx('skitter', 1, 0.9);
  shake(G, 3);
  slowmo(G, 0.5, 0.35);
  G.uiV++;
  return true;
}

// kinds resolve directly from the bestiary

function restPos(s: SpiderState, l: SpiderLeg): { x: number; y: number } {
  const a = s.facing + l.side * l.baseAng;
  return { x: s.body.x + Math.cos(a) * l.baseLen, y: s.body.y + Math.sin(a) * l.baseLen };
}

function angleLerp(a: number, b: number, t: number): number {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return a + d * t;
}

// ---------- per-frame update ----------
export function updateSpider(G: GameCtx, dt: number): void {
  const s = G.spider;
  if (!s) return;
  const p = G.player;
  const body = s.body;

  // player fled very far: the weaver loses interest
  if (dist(body.x, body.y, p.x, p.y) > 1400) {
    for (const l of s.legs) l.e.dead = true;
    body.dead = true;
    G.spider = null;
    return;
  }

  // legs dying → ichor + grieve
  for (const l of s.legs) {
    if (l.e.dead && !l.grieved) {
      l.grieved = true;
      l.planted = false;
      burst(G, l.fx, l.fy, ICHOR, 12, 90, { glow: true });
      addText(G, l.fx, l.fy - 10, 'LEG SEVERED', ICHOR, 5, true);
      addRing(G, l.fx, l.fy, 4, 110, ICHOR, 0.3, 2);
      shake(G, 1);
      G.audio.sfx('hit', 0.6, 1);
    }
  }

  // body death → the finale
  if (body.dead) {
    if (!s.dead) {
      s.dead = true;
      const t = body.tier;
      for (const l of s.legs) {
        if (!l.e.dead) { burst(G, l.fx, l.fy, ICHOR, 10, 80, { glow: true }); l.e.dead = true; }
      }
      G.banner = { title: 'THE WEAVER FELLED', sub: 'The canopy falls silent', t: 0, color: ICHOR };
      gainXp(G, 160 + t * 70);
      G.prog.kills++;
      for (let i = 0; i < 12; i++) {
        spawnPickup(G, 'aether', body.x + randR(-42, 42), body.y + randR(-42, 42), 3 + t);
      }
      spawnPickup(G, 'vial', body.x + randR(-20, 20), body.y + randR(-20, 20));
      spawnPickup(G, 'draught', body.x + randR(-20, 20), body.y + randR(-20, 20));
      explosion(G, body.x, body.y, 60, 0, 'shadow', 'enemy', { noDmg: true });
      screenFlash(G, '#1a0a22', 0.5);
      slowmo(G, 0.9, 0.25);
      shake(G, 4);
      G.audio.sfx('die', 0.7);
      G.audio.sfx('roar', 0.5, 0.7);
      G.uiV++;
      try {
        G.prog.x = p.x; G.prog.y = p.y;
        localStorage.setItem('arcana_infinita_save_v1', JSON.stringify(G.prog));
      } catch { /* ignore */ }
    }
    G.spider = null;
    return;
  }

  body.anim += dt;
  body.flash = Math.max(0, body.flash - dt);
  body.spawnGuard = Math.max(0, body.spawnGuard - dt);

  // ---- drop-in intro ----
  if (s.intro > 0) {
    s.intro -= dt;
    const k = clamp(1 - s.intro / 0.85, 0, 1);
    // feet splay around the LANDING SPOT (fixed at spawn — never the airborne body)
    const gb = { x: s.groundX, y: s.groundY };
    for (const l of s.legs) {
      const a = s.facing + l.side * l.baseAng;
      l.fx = gb.x + Math.cos(a) * l.baseLen;
      l.fy = gb.y + Math.sin(a) * l.baseLen;
      l.e.x = l.fx; l.e.y = l.fy;
    }
    // the body falls: ease from 150px above the landing spot down to it
    const drift = angTo(gb.x, gb.y, p.x, p.y);
    body.x = lerp(gb.x, gb.x + Math.cos(drift) * 14, k);
    body.y = s.groundY - 150 * (1 - k) * (1 - k);
    if (s.intro <= 0) {
      body.x = gb.x; body.y = gb.y;
      shake(G, 3.2);
      burst(G, body.x, body.y + 8, '#5a4668', 18, 90, { glow: false });
      addRing(G, body.x, body.y, 10, 200, '#8a6ea8', 0.4, 2.5);
      G.audio.sfx('boom', 0.8, 0.9);
    }
    return;
  }

  const stunned = !!body.st.stun || !!body.st.frozen;
  const alive = s.legs.filter((l) => !l.e.dead);
  // LIVE anchor count — mutated inside the leg loop so the tripod invariant holds
  let planted = alive.filter((l) => l.planted && l.slamming <= 0).length;

  // ---- collapse: fewer than 3 anchors and gravity wins ----
  if (planted < 3 && s.collapsed <= 0 && !stunned) {
    s.collapsed = 2.8;
    addText(G, body.x, body.y - 26, 'COLLAPSED!', ICHOR, 8, true);
    addRing(G, body.x, body.y, 12, 150, ICHOR, 0.4, 2.5);
    burst(G, body.x, body.y + 6, '#5a4668', 16, 80);
    shake(G, 2.6);
    G.audio.sfx('stagger', 0.6, 1);
    for (const l of alive) if (chance(0.6)) l.atkCd = Math.max(l.atkCd, 2.6);
  }
  if (s.collapsed > 0) {
    s.collapsed -= dt;
    body.st.amp = { t: 0.5, mult: 1.45 }; // scramble window: +45% damage taken
    if (G.frame % 8 === 0) {
      spawnParticle(G, { x: body.x + randR(-14, 14), y: body.y + randR(-6, 10), vy: -30, life: 0.5, size: 2, color: '#6a5278', glow: false });
    }
  }

  // ---- facing ----
  const wantFace = angTo(body.x, body.y, p.x, p.y);
  s.facing = angleLerp(s.facing, wantFace, clamp(3.2 * dt, 0, 1));

  // ---- anchored movement ----
  if (!stunned && s.collapsed <= 0 && planted >= 3) {
    const d = dist(body.x, body.y, p.x, p.y);
    const a = angTo(body.x, body.y, p.x, p.y);
    const want = 74;
    const dir = d > want ? 1 : -0.4;
    const speed = (30 + body.tier * 3.2) * (0.35 + 0.65 * (planted / 8));
    body.vx += Math.cos(a) * speed * dir * dt * 4.2;
    body.vy += Math.sin(a) * speed * dir * dt * 4.2;
    if (G.frame % 10 === 0) {
      G.audio.sfx('skitter', randR(0.9, 1.15), 0.14);
    }
  }
  const drag = 1 - clamp(5 * dt, 0, 0.9);
  body.vx *= drag; body.vy *= drag;
  if (!stunned) {
    const mv = moveWithCollision(G.world, body.x, body.y, body.vx, body.vy, body.r, dt);
    body.x = mv.x; body.y = mv.y;
  }
  // tether: the body hangs from its anchors
  if (planted >= 3) {
    let cx = 0, cy = 0;
    for (const l of alive) if (l.planted && l.slamming <= 0) { cx += l.fx; cy += l.fy; }
    if (planted > 0) {
      cx /= planted; cy /= planted;
      const pull = 1 - Math.exp(-1.1 * dt);
      body.x = lerp(body.x, cx, pull * 0.35);
      body.y = lerp(body.y, cy, pull * 0.35);
    }
  }

  // ---- legs: gait + attacks ----
  for (const l of alive) {
    l.e.flash = Math.max(0, l.e.flash - dt);
    l.e.anim += dt;
    l.e.spawnGuard = Math.max(0, l.e.spawnGuard - dt);
    l.atkCd -= dt;
    const lStun = !!l.e.st.stun || !!l.e.st.frozen || !!l.e.st.root;

    // slam resolution
    if (l.slamming > 0) {
      l.slamming -= dt;
      const k = 1 - clamp(l.slamming / 0.14, 0, 1);
      l.fx = lerp(l.sx, l.markX, k);
      l.fy = lerp(l.sy, l.markY, k);
      l.e.x = l.fx; l.e.y = l.fy;
      if (l.slamming <= 0) {
        l.planted = true;
        planted++;
        l.lift = 0;
        explosion(G, l.markX, l.markY, 24, (13 + body.tier * 3.2) * DIFF.dmg, 'shadow', 'enemy', {});
        addRing(G, l.markX, l.markY, 5, 150, '#8a6ea8', 0.3, 2);
        burst(G, l.markX, l.markY, '#5a4668', 10, 80);
        shake(G, 1.4);
        G.audio.sfx('boom', 1.5, 0.55);
      }
      continue;
    }

    // leg stab attack (only while the tripod holds)
    if (!lStun && l.planted && s.collapsed <= 0 && planted >= 4 && l.atkCd <= 0 && !p.dead) {
      const dp = dist(l.fx, l.fy, p.x, p.y);
      if (dp < 190) {
        l.atkCd = randR(2.6, 4.2);
        l.planted = false;
        planted--; // this anchor lifts off to strike
        l.lift = 1; // reared up
        l.sx = l.fx; l.sy = l.fy;
        const mx = p.x, my = p.y;
        addTelegraph(G, {
          kind: 'circle', x: mx, y: my, r: 20, dur: 0.5, color: '#c95ee8', team: 'enemy',
          onDone: () => {
            if (l.e.dead || !G.spider) return;
            l.slamming = 0.14;
            l.markX = mx; l.markY = my;
            G.audio.sfx('melee', 0.5, 1);
          },
        });
        continue;
      }
    }

    // while collapsed the legs SCRAMBLE to replant (that's the window)
    if (lStun) { l.e.x = l.fx; l.e.y = l.fy; continue; }

    // procedural step
    if (l.planted) {
      const rest = restPos(s, l);
      const stretch = dist(l.fx, l.fy, rest.x, rest.y);
      const thresh = s.collapsed > 0 ? 8 : 13;
      const minAnchors = s.collapsed > 0 ? 0 : 3;
      if (stretch > thresh && planted - 1 >= minAnchors) {
        l.planted = false;
        planted--;
        l.sx = l.fx; l.sy = l.fy;
        // overshoot into the direction of travel
        l.tx = rest.x + body.vx * 0.24;
        l.ty = rest.y + body.vy * 0.24;
        l.stepT = 0;
        l.stepDur = randR(0.12, 0.19);
      }
    } else {
      l.stepT += dt;
      const k = clamp(l.stepT / l.stepDur, 0, 1);
      l.fx = lerp(l.sx, l.tx, k);
      l.fy = lerp(l.sy, l.ty, k);
      l.lift = Math.sin(k * Math.PI);
      if (k >= 1) {
        l.planted = true;
        planted++;
        l.lift = 0;
        spawnParticle(G, { x: l.fx, y: l.fy + 2, vx: randR(-14, 14), vy: randR(-10, 4), life: 0.3, size: 1.6, color: '#4a3a56', glow: false });
        if (G.frame % 2 === 0) G.audio.sfx('skitter', randR(1.1, 1.5), 0.1);
      }
    }
    l.e.x = l.fx; l.e.y = l.fy;
  }

  // ---- body attacks ----
  s.atkCd -= dt;
  if (s.atkCd <= 0 && !stunned && !p.dead && s.intro <= 0) {
    if (s.collapsed > 0) {
      s.atkCd = 3.2;
      // desperate venom while down
      spawnZone(G, { kind: 'field', x: p.x, y: p.y, r: 40, dur: 2.8, el: 'poison', el2: null, team: 'enemy', dmg: (4 + body.tier * 1.6) * DIFF.dmg, tick: 0.5, owner: body });
      burst(G, p.x, p.y, elColor('poison'), 8, 60);
    } else {
      s.atkCd = randR(4.6, 7);
      const roll = chance(0.55) ? 'web' : 'venom';
      if (roll === 'web') {
        // WEB SPIT: roots you in place unless you move
        const mx = p.x, my = p.y;
        addTelegraph(G, {
          kind: 'circle', x: mx, y: my, r: 26, dur: 0.55, color: '#e8e4d4', team: 'enemy',
          onDone: () => {
            if (!G.spider || p.dead) return;
            burst(G, mx, my, '#e8e4d4', 14, 70, { glow: false });
            addRing(G, mx, my, 4, 90, '#e8e4d4', 0.3, 1.5);
            if (dist(p.x, p.y, mx, my) < 34) {
              p.st.root = { t: 1.15 };
              damagePlayer(G, (7 + body.tier * 1.8) * DIFF.dmg, null);
              addText(G, p.x, p.y - 16, 'WEBBED!', '#e8e4d4', 6, true);
            }
            // a few slow tracker globs for pressure
            const base = angTo(body.x, body.y, p.x, p.y);
            for (let i = -1; i <= 1; i++) {
              const a = base + i * 0.35;
              makeWebGlob(G, body, a);
            }
          },
        });
        G.audio.sfx('cast', 0.5, 0.8);
      } else {
        spawnZone(G, { kind: 'field', x: p.x, y: p.y, r: 46, dur: 3, el: 'poison', el2: null, team: 'enemy', dmg: (5 + body.tier * 1.8) * DIFF.dmg, tick: 0.5, owner: body });
        burst(G, p.x, p.y, elColor('poison'), 12, 80);
        G.audio.sfx('cast', 0.6, 0.7);
      }
    }
  }

  // ---- body contact ----
  if (!p.dead && body.spawnGuard <= 0 && dist(body.x, body.y, p.x, p.y) < body.r + p.r) {
    body.contactT -= dt;
    if (body.contactT <= 0) {
      body.contactT = 0.9;
      damagePlayer(G, (15 + body.tier * 2.4) * DIFF.contact * DIFF.dmg, 'shadow');
      const a2 = angTo(body.x, body.y, p.x, p.y);
      p.vx += Math.cos(a2) * 170; p.vy += Math.sin(a2) * 170;
    }
  }
}

function makeWebGlob(G: GameCtx, from: Enemy, ang: number): void {
  makeBullet(G, {
    x: from.x + Math.cos(ang) * 10, y: from.y + Math.sin(ang) * 10,
    vx: Math.cos(ang) * 95, vy: Math.sin(ang) * 95,
    r: 4, dmg: (5 + from.tier * 1.4) * DIFF.dmg, el: 'shadow', el2: null, team: 'enemy',
    life: 2.6, kind: 'orb', color: '#e8e4d4', color2: '#b8b0c0', trail: 0.3, from,
  });
}

// ---------- rendering (fully procedural, pixel-style) ----------
export function drawSpider(G: GameCtx): void {
  const s = G.spider;
  if (!s) return;
  const ctx = G.ctx;
  const body = s.body;
  const squash = s.collapsed > 0 ? 0.72 : 1;

  // dead legs leave stubs
  for (const l of s.legs) {
    if (!l.e.dead) continue;
    const a = s.facing + l.side * l.baseAng;
    const hx = body.x + Math.cos(a) * 8, hy = body.y + Math.sin(a) * 8 - 2;
    const kx = hx + Math.cos(a) * 7, ky = hy + Math.sin(a) * 7 - 2;
    drawLimb(ctx, hx, hy, kx, ky, CHITIN_DK);
    ctx.fillStyle = ICHOR;
    ctx.fillRect(Math.round(hx) - 1, Math.round(hy) - 1, 2, 2);
  }

  // legs (draw behind the body)
  for (const l of s.legs) {
    if (l.e.dead) continue;
    const a = s.facing + l.side * l.baseAng;
    const hx = body.x + Math.cos(a) * 9;
    const hy = body.y + Math.sin(a) * 9 - 3;
    const fy = l.fy - l.lift * 9;
    const seg1 = l.baseLen * 0.52;
    const seg2 = l.baseLen * 0.6;
    const knee = solveIK(hx, hy, l.fx, fy, seg1, seg2, l.side);
    const liftCol = l.lift > 0.15 ? '#43325a' : CHITIN;
    drawLimb(ctx, hx, hy, knee.x, knee.y, liftCol);
    drawLimb(ctx, knee.x, knee.y, l.fx, fy, liftCol);
    // joints
    ctx.fillStyle = '#463354';
    ctx.fillRect(Math.round(knee.x) - 1, Math.round(knee.y) - 1, 2, 2);
    // foot
    ctx.fillStyle = '#15101c';
    ctx.fillRect(Math.round(l.fx) - 1, Math.round(fy) - 1, 2, 2);
    // ground shadow while lifted
    if (l.lift > 0.2) {
      ctx.globalAlpha = 0.25;
      ctx.fillStyle = '#000';
      ctx.fillRect(Math.round(l.fx) - 1, Math.round(l.fy), 2, 1);
      ctx.globalAlpha = 1;
    }
    if (l.e.flash > 0) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = clamp(l.e.flash * 6, 0, 1);
      drawLimb(ctx, hx, hy, knee.x, knee.y, '#ffffff');
      drawLimb(ctx, knee.x, knee.y, l.fx, fy, '#ffffff');
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
    }
  }

  // body shadow
  ctx.globalAlpha = 0.3;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(body.x, body.y + 8, 14, 4, 0, 0, TAU);
  ctx.fill();
  ctx.globalAlpha = 1;

  // abdomen (rear) — drawn opposite of facing
  const bx = Math.round(body.x), by = Math.round(body.y);
  const fa = s.facing;
  const abx = bx - Math.cos(fa) * 7, aby = by - Math.sin(fa) * 7;
  const hdx = bx + Math.cos(fa) * 6, hdy = by + Math.sin(fa) * 6;
  drawBlob(ctx, abx, aby, 12, 9 * squash, CHITIN);
  drawBlob(ctx, abx, aby, 9, 6.4 * squash, '#352646');
  // pale hourglass marking
  ctx.fillStyle = '#b89ad4';
  ctx.fillRect(Math.round(abx - Math.cos(fa) * 4) - 1, Math.round(aby - Math.sin(fa) * 4) - 2, 2, 2);
  ctx.fillRect(Math.round(abx - Math.cos(fa) * 8) - 1, Math.round(aby - Math.sin(fa) * 8) - 1, 2, 3);
  // cephalothorax (head end)
  drawBlob(ctx, hdx, hdy, 7, 6 * squash, CHITIN_DK);
  // fangs
  ctx.strokeStyle = '#0d0912';
  ctx.lineWidth = 1.4;
  const faO = s.collapsed > 0 ? 0.35 : 0.7;
  ctx.beginPath();
  ctx.moveTo(hdx + Math.cos(fa - faO) * 5, hdy + Math.sin(fa - faO) * 5);
  ctx.lineTo(hdx + Math.cos(fa - faO * 0.4) * 9, hdy + Math.sin(fa - faO * 0.4) * 9);
  ctx.moveTo(hdx + Math.cos(fa + faO) * 5, hdy + Math.sin(fa + faO) * 5);
  ctx.lineTo(hdx + Math.cos(fa + faO * 0.4) * 9, hdy + Math.sin(fa + faO * 0.4) * 9);
  ctx.stroke();
  // eyes: 4 glowing pairs
  const eyeGlow = s.collapsed > 0 ? 0.35 : 1;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 4; i++) {
    const ea = fa + (i < 2 ? -1 : 1) * (0.28 + (i % 2) * 0.34);
    const er = 4.4 - (i % 2) * 1.1;
    ctx.globalAlpha = eyeGlow * (0.75 + 0.25 * Math.sin(G.time * 5 + i * 1.7));
    ctx.fillStyle = EYE;
    ctx.fillRect(Math.round(hdx + Math.cos(ea) * er) - 1, Math.round(hdy + Math.sin(ea) * er) - 1, 2, 2);
  }
  ctx.restore();

  // hit flash
  if (body.flash > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = clamp(body.flash * 6, 0, 1);
    drawBlob(ctx, abx, aby, 12, 9 * squash, '#ffffff');
    drawBlob(ctx, hdx, hdy, 7, 6 * squash, '#ffffff');
    ctx.restore();
  }

  // collapsed wobble
  if (s.collapsed > 0) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.4 + 0.3 * Math.sin(G.time * 20);
    ctx.strokeStyle = ICHOR;
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(bx, by, 18 + Math.sin(G.time * 14) * 2, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  // HP bar + leg pips
  const w = 44;
  ctx.fillStyle = 'rgba(10,8,16,0.8)';
  ctx.fillRect(bx - w / 2 - 1, by - 30, w + 2, 5);
  ctx.fillStyle = '#3a1030';
  ctx.fillRect(bx - w / 2, by - 29, w, 3);
  ctx.fillStyle = '#c94ea8';
  ctx.fillRect(bx - w / 2, by - 29, w * clamp(body.hp / body.maxHp, 0, 1), 3);
  for (let i = 0; i < 8; i++) {
    const l = s.legs[i];
    const px = bx - w / 2 + i * (w / 8);
    ctx.fillStyle = l.e.dead ? '#3a2030' : ICHOR;
    ctx.fillRect(px, by - 25, w / 8 - 1, 1.6);
  }
  ctx.fillStyle = 'rgba(232,228,212,0.75)';
  ctx.font = '4px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('THE WEAVER', bx, by - 33);
  ctx.textAlign = 'left';
}

// two-bone IK: returns the knee position
function solveIK(ax: number, ay: number, bx: number, by: number, l1: number, l2: number, bend: number): { x: number; y: number } {
  let d = dist(ax, ay, bx, by);
  d = clamp(d, Math.abs(l1 - l2) + 0.5, l1 + l2 - 0.5);
  const a1 = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1));
  const base = Math.atan2(by - ay, bx - ax);
  const ka = base + a1 * bend;
  return { x: ax + Math.cos(ka) * l1, y: ay + Math.sin(ka) * l1 };
}

// pixel-y limb: a run of 2px rects along the segment
function drawLimb(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number, col: string): void {
  const d = dist(x1, y1, x2, y2);
  const n = Math.max(2, Math.ceil(d / 1.8));
  ctx.fillStyle = col;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const px = Math.round(lerp(x1, x2, t));
    const py = Math.round(lerp(y1, y2, t));
    ctx.fillRect(px - 1, py - 1, 2, 2);
  }
}

// filled blob (pixel-ish ellipse)
function drawBlob(ctx: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, col: string): void {
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.ellipse(Math.round(x), Math.round(y), rx, ry, 0, 0, TAU);
  ctx.fill();
}
