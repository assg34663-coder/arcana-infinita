/* ============================================================
   spectacle.ts — GRAND CASTINGS. High-tier rituals are no
   longer "a big circle": every element gets its own cinematic,
   multi-stage choreography — implosions, pillars, sky-falls,
   crystal spires, eclipses — with the real spell payload
   detonating at the climax.

   Purely visual + timing; the gameplay payload is injected via
   the `effect` callback (casting.ts's ritualEffect), so this
   file never needs to know the spell rules.
   ============================================================ */
import {
  TAU, dist, rand, randR, chance, pick,
  type ElementId, type GameCtx,
} from './core';
import { elColor, elColor2 } from './sprites';
import {
  burst, spawnParticle, addRing, addBeam, addTelegraph, explosion,
  shake, screenFlash, slowmo, addText, makeBullet,
} from './fx';

// tiny local scheduler (same queue the bosses use)
function after(G: GameCtx, t: number, fn: () => void): void {
  G.sched.push({ t, fn });
}

const NAME: Record<ElementId, string> = {
  fire: 'SUPERNOVA', frost: 'ABSOLUTE ZERO', lightning: 'SKYFALL JUDGMENT',
  earth: "TITAN'S WRATH", wind: 'THE HURRICANE CROWN', water: 'THE GREAT WAVE',
  poison: 'PLAGUE BLOOM', blood: 'CRIMSON RITE', shadow: 'ECLIPSE',
  death: 'DANSE MACABRE', radiant: 'JUDGMENT DAWN', arcane: 'MANA DETONATION',
  time: 'TEMPORAL COLLAPSE', void: 'EVENT HORIZON', nature: 'THE WORLDROOT WAKES',
  chaos: 'ULTIMA CHAOS', crystal: 'PRISM REQUIEM', metal: 'IRON TEMPEST',
  gravity: 'SINGULARITY', sound: 'THE LAST CHORD', bone: 'THE OSSUARY WAKES',
  beast: 'THE GREAT HUNT', plasma: 'STELLAR INCINERATION', mirror: 'HALL OF MIRRORS',
};

export function grandRitual(
  G: GameCtx, el: ElementId, x: number, y: number, dmg: number,
  effect: () => void, scale = 1,
): void {
  const col = elColor(el);
  const col2 = elColor2(el);
  void dmg; void scale; // payload lives in effect()

  // every grand casting opens with the name + a deep detonation chord
  addText(G, x, y - 34, NAME[el], col, 9, true);
  G.audio.sfx('grand', 1, 0.9);
  shake(G, 2);

  switch (el) {
    // ---------- SUPERNOVA: implosion, then a triple-ring eruption ----------
    case 'fire': {
      screenFlash(G, '#ff9e4e', 0.35);
      for (let i = 0; i < 26; i++) {
        const a = rand(0, TAU);
        const r = randR(46, 84);
        spawnParticle(G, {
          x: x + Math.cos(a) * r, y: y + Math.sin(a) * r,
          vx: -Math.cos(a) * r * 5.5, vy: -Math.sin(a) * r * 5.5,
          life: 0.32, size: 2.4, color: pick(['#ff9e4e', '#ffd75e', '#ff5a2e']), glow: true,
        });
      }
      after(G, 0.38, () => {
        effect();
        screenFlash(G, '#ffd75e', 0.3);
        shake(G, 6);
        addRing(G, x, y, 10, 330, '#ffd75e', 0.5, 3.5);
        addRing(G, x, y, 6, 240, '#ff9e4e', 0.55, 3);
        addRing(G, x, y, 4, 170, '#ff5a2e', 0.6, 2.5);
        // five fire pillars
        for (let i = 0; i < 5; i++) {
          const a = (i / 5) * TAU + randR(0, 0.5);
          const px = x + Math.cos(a) * randR(34, 70);
          const py = y + Math.sin(a) * randR(34, 70);
          after(G, 0.12 * i, () => {
            addBeam(G, px, py - 46, Math.PI / 2, 48, 9, 'fire', 0.3);
            for (let j = 0; j < 16; j++) {
              spawnParticle(G, {
                x: px + randR(-5, 5), y: py, vx: randR(-18, 18), vy: -randR(60, 150),
                life: randR(0.4, 0.8), size: randR(2, 3.4),
                color: pick(['#ff9e4e', '#ffd75e', '#ff5a2e']), glow: true, grav: -30,
              });
            }
            explosion(G, px, py, 22, dmg * 0.35, 'fire', 'player', {});
          });
        }
        for (let j = 0; j < 40; j++) {
          const a = rand(0, TAU);
          const s = randR(60, 260);
          spawnParticle(G, {
            x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 40,
            life: randR(0.4, 0.9), size: randR(2, 4),
            color: pick(['#ff9e4e', '#ffd75e', '#e2e8dc']), glow: true, grav: 60,
          });
        }
      });
      break;
    }

    // ---------- ABSOLUTE ZERO: orbiting shards → giant ice spire → shatter ----------
    case 'frost': {
      screenFlash(G, '#bfe8ff', 0.4);
      for (let i = 0; i < 18; i++) {
        const a = (i / 18) * TAU;
        after(G, 0.05 * i, () => {
          makeBullet(G, {
            x: x + Math.cos(a) * 90, y: y + Math.sin(a) * 90,
            vx: -Math.cos(a) * 120, vy: -Math.sin(a) * 120,
            r: 3, dmg: 0, el: 'frost', el2: null, team: 'player', life: 0.8,
            kind: 'shard', color: '#dff4fc', color2: '#9edbe8', trail: 0.5, from: G.player,
          });
        });
      }
      after(G, 0.55, () => {
        effect();
        // the spire: a lattice of crossing beams + white core
        for (let i = 0; i < 3; i++) {
          const a = i * Math.PI / 3;
          addBeam(G, x, y, a, 66, 7, 'frost', 0.8);
          addBeam(G, x, y, a + Math.PI, 66, 7, 'frost', 0.8);
        }
        addBeam(G, x, y - 44, Math.PI / 2, 46, 12, 'frost', 0.9);
        addRing(G, x, y, 8, 200, '#dff4fc', 0.5, 3);
        shake(G, 3);
        G.audio.sfx('frozen', 0.6, 1);
        after(G, 0.9, () => {
          // SHATTER
          burst(G, x, y, '#dff4fc', 44, 220, { glow: true });
          burst(G, x, y, '#9edbe8', 30, 150, { glow: true });
          addRing(G, x, y, 6, 280, '#dff4fc', 0.45, 3);
          shake(G, 4);
          G.audio.sfx('frozen', 1.6, 1);
        });
      });
      break;
    }

    // ---------- SKYFALL JUDGMENT: six bolts from heaven ----------
    case 'lightning': {
      screenFlash(G, '#f2f2ff', 0.28);
      for (let i = 0; i < 6; i++) {
        after(G, i * 0.2, () => {
          const tx = x + randR(-80, 80), ty = y + randR(-80, 80);
          addTelegraph(G, {
            kind: 'circle', x: tx, y: ty, r: 16, dur: 0.16, color: '#f2e35e', team: 'player',
            onDone: () => {
              addBeam(G, tx, ty - 110, Math.PI / 2, 112, 5, 'lightning', 0.22);
              addBeam(G, tx, ty - 110, Math.PI / 2 + 0.25, 100, 3, 'lightning', 0.16);
              explosion(G, tx, ty, 22, dmg * 0.4, 'lightning', 'player', {});
              burst(G, tx, ty, '#f2e35e', 14, 130, { glow: true });
              shake(G, 1.8);
              G.audio.sfx('thunder', randR(1.1, 1.5), 0.5);
            },
          });
        });
      }
      after(G, 0.5, () => { effect(); });
      after(G, 1.3, () => {
        // the final judgment bolt, dead center
        addBeam(G, x, y - 140, Math.PI / 2, 142, 11, 'lightning', 0.35);
        screenFlash(G, '#f2f2ff', 0.3);
        shake(G, 5);
        explosion(G, x, y, 30, dmg * 0.6, 'lightning', 'player', {});
        G.audio.sfx('thunder', 0.8, 0.9);
      });
      break;
    }

    // ---------- TITAN'S WRATH: boulders arc up and crash down ----------
    case 'earth': {
      screenFlash(G, '#c9a06a', 0.3);
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * TAU;
        const px = x + Math.cos(a) * randR(30, 78);
        const py = y + Math.sin(a) * randR(30, 78);
        after(G, i * 0.18, () => {
          addTelegraph(G, {
            kind: 'circle', x: px, y: py, r: 26, dur: 0.5, color: '#c9a06a', team: 'player',
            onDone: () => {
              explosion(G, px, py, 30, dmg * 0.45, 'earth', 'player', {});
              addRing(G, px, py, 8, 190, '#c9a06a', 0.4, 3);
              for (let j = 0; j < 20; j++) {
                spawnParticle(G, {
                  x: px, y: py, vx: randR(-90, 90), vy: -randR(60, 190),
                  life: randR(0.4, 0.9), size: randR(2, 3.6),
                  color: pick(['#8a6a48', '#6a5238', '#c9a06a']), glow: false, grav: 260,
                });
              }
              shake(G, 2.6);
              G.audio.sfx('boom', 0.7, 0.9);
            },
          });
        });
      }
      after(G, 0.55, () => { effect(); });
      break;
    }

    // ---------- THE HURRICANE CROWN: a spinning gale that flings ----------
    case 'wind': {
      screenFlash(G, '#e2fff2', 0.25);
      after(G, 0.35, () => { effect(); });
      for (let ring = 0; ring < 4; ring++) {
        after(G, ring * 0.22, () => {
          for (let i = 0; i < 10; i++) {
            const a = (i / 10) * TAU + ring * 0.3;
            spawnParticle(G, {
              x: x + Math.cos(a) * 30, y: y + Math.sin(a) * 30,
              vx: Math.cos(a + 1.5) * 150, vy: Math.sin(a + 1.5) * 150,
              life: 0.5, size: 2, color: '#e2fff2', glow: true,
            });
          }
          addRing(G, x, y, 6 + ring * 8, 190 + ring * 40, '#cfeee0', 0.4, 2);
          G.audio.sfx('dodge', 1.4 + ring * 0.15, 0.4);
        });
      }
      after(G, 0.9, () => shake(G, 3));
      break;
    }

    // ---------- THE GREAT WAVE: a tsunami crescent sweeps out ----------
    case 'water': {
      screenFlash(G, '#7ab8ff', 0.3);
      for (let ring = 0; ring < 3; ring++) {
        after(G, ring * 0.28, () => {
          const n = 22 + ring * 6;
          for (let i = 0; i < n; i++) {
            const a = (i / n) * TAU;
            makeBullet(G, {
              x: x + Math.cos(a) * (14 + ring * 10), y: y + Math.sin(a) * (14 + ring * 10),
              vx: Math.cos(a) * (150 + ring * 45), vy: Math.sin(a) * (150 + ring * 45),
              r: 7, dmg: dmg * 0.3, el: 'water', el2: null, team: 'player', life: 1.1,
              kind: 'wave', pierce: 99, passWalls: true,
              color: '#7ab8ff', color2: '#cfeeff', trail: 0.3, from: G.player,
            });
          }
          addRing(G, x, y, 10 + ring * 12, 220 + ring * 60, '#7ab8ff', 0.5, 3);
          burst(G, x, y, '#cfeeff', 16, 120, { glow: true });
          shake(G, 1.6 + ring);
        });
      }
      after(G, 0.4, () => { effect(); });
      break;
    }

    // ---------- PLAGUE BLOOM: a rising column, then the cap blooms ----------
    case 'poison': {
      screenFlash(G, '#8ed94e', 0.3);
      for (let i = 0; i < 34; i++) {
        after(G, rand(0, 0.5), () => {
          spawnParticle(G, {
            x: x + randR(-14, 14), y: y + randR(-6, 10),
            vx: randR(-20, 20), vy: -randR(40, 130),
            life: randR(0.6, 1.3), size: randR(2, 4.4),
            color: pick(['#8ed94e', '#5a9e2e', '#c9e88e']), glow: true, grav: -14,
          });
        });
      }
      after(G, 0.55, () => {
        effect();
        // the mushroom cap
        for (let i = 0; i < 26; i++) {
          const a = (i / 26) * TAU;
          spawnParticle(G, {
            x: x + Math.cos(a) * 8, y: y - 24,
            vx: Math.cos(a) * 110, vy: Math.sin(a) * 34 - 8,
            life: randR(0.5, 0.9), size: randR(2.4, 4.6), color: '#8ed94e', glow: true, grav: 30,
          });
        }
        addRing(G, x, y, 8, 210, '#8ed94e', 0.5, 3);
        addRing(G, x, y - 20, 6, 150, '#c9e88e', 0.6, 2);
        shake(G, 3);
        G.audio.sfx('boom', 0.5, 0.8);
      });
      break;
    }

    // ---------- CRIMSON RITE: the blood of your enemies flows to you ----------
    case 'blood': {
      screenFlash(G, '#d94e5e', 0.35);
      after(G, 0.45, () => { effect(); });
      for (let i = 0; i < 3; i++) {
        after(G, i * 0.25, () => {
          for (const e of G.enemies) {
            if (e.dead || dist(e.x, e.y, x, y) > 150) continue;
            for (let j = 0; j < 5; j++) {
              spawnParticle(G, {
                x: e.x + randR(-4, 4), y: e.y + randR(-4, 4),
                vx: (x - e.x) * randR(1.5, 2.6), vy: (y - e.y) * randR(1.5, 2.6),
                life: 0.45, size: 2, color: pick(['#d94e5e', '#8e2038']), glow: true,
              });
            }
          }
          addRing(G, x, y, 8 + i * 6, 150, '#d94e5e', 0.45, 2.5);
          G.audio.sfx('parry', 0.5 + i * 0.1, 0.5);
        });
      }
      break;
    }

    // ---------- ECLIPSE: the lights die, tendrils lash out ----------
    case 'shadow': {
      screenFlash(G, '#0a0614', 0.9);
      after(G, 0.5, () => { effect(); });
      for (let i = 0; i < 9; i++) {
        after(G, i * 0.09, () => {
          const a = rand(0, TAU);
          addBeam(G, x, y, a, randR(60, 110), 5, 'shadow', 0.3);
          burst(G, x + Math.cos(a) * 50, y + Math.sin(a) * 50, '#4a3a66', 8, 70, { glow: true });
        });
      }
      after(G, 0.8, () => {
        addRing(G, x, y, 8, 240, '#4a3a66', 0.6, 3);
        shake(G, 3.4);
        G.audio.sfx('roar', 1.6, 0.4);
      });
      break;
    }

    // ---------- DANSE MACABRE: graves erupt, souls spiral ----------
    case 'death': {
      screenFlash(G, '#9ee8d8', 0.35);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        const px = x + Math.cos(a) * randR(26, 66);
        const py = y + Math.sin(a) * randR(26, 66);
        after(G, 0.12 * i, () => {
          burst(G, px, py, '#a8b0a0', 12, 80, { glow: true });
          burst(G, px, py, '#e2e8dc', 5, 50, { glow: true });
          addRing(G, px, py, 3, 90, '#9ee8d8', 0.35, 1.5);
          G.audio.sfx('summon', randR(0.8, 1.2), 0.5);
        });
      }
      after(G, 0.55, () => { effect(); });
      after(G, 0.9, () => {
        // soul spiral
        for (let i = 0; i < 20; i++) {
          const a = (i / 20) * TAU * 2;
          const r = 60 - (i / 20) * 40;
          spawnParticle(G, {
            x: x + Math.cos(a) * r, y: y + Math.sin(a) * r,
            vx: -Math.sin(a) * 90, vy: Math.cos(a) * 90 - 30,
            life: 0.7, size: 2, color: i % 2 ? '#9ee8d8' : '#e2e8dc', glow: true,
          });
        }
        addRing(G, x, y, 6, 220, '#9ee8d8', 0.5, 2.5);
        shake(G, 2.6);
      });
      break;
    }

    // ---------- JUDGMENT DAWN: a pillar of heaven-light ----------
    case 'radiant': {
      screenFlash(G, '#fff8d8', 0.45);
      addBeam(G, x, y - 150, Math.PI / 2, 152, 16, 'radiant', 0.7);
      addBeam(G, x, y - 150, Math.PI / 2, 152, 8, 'radiant', 0.9);
      for (let i = 0; i < 3; i++) {
        after(G, i * 0.22, () => addRing(G, x, y, 8 + i * 6, 200 + i * 50, '#ffe89e', 0.5, 3));
      }
      for (let i = 0; i < 24; i++) {
        spawnParticle(G, {
          x: x + randR(-40, 40), y: y + randR(-30, 10),
          vx: randR(-8, 8), vy: randR(10, 40),
          life: randR(0.6, 1.2), size: 1.8, color: '#ffe89e', glow: true, grav: -20,
        });
      }
      after(G, 0.4, () => { effect(); shake(G, 3); G.audio.sfx('shrine', 1.4, 0.9); });
      break;
    }

    // ---------- MANA DETONATION: it all comes back ----------
    case 'arcane': {
      screenFlash(G, '#f2c9ff', 0.35);
      for (let i = 0; i < 24; i++) {
        const a = rand(0, TAU);
        const r = randR(50, 90);
        spawnParticle(G, {
          x: x + Math.cos(a) * r, y: y + Math.sin(a) * r,
          vx: -Math.cos(a) * r * 5, vy: -Math.sin(a) * r * 5,
          life: 0.3, size: 2.2, color: pick(['#f2c9ff', '#c95ee8', '#ffffff']), glow: true,
        });
      }
      after(G, 0.4, () => {
        effect();
        for (let i = 0; i < 10; i++) {
          const a = (i / 10) * TAU + randR(0, 0.4);
          makeBullet(G, {
            x, y, vx: Math.cos(a) * 240, vy: Math.sin(a) * 240,
            r: 3.4, dmg: dmg * 0.4, el: 'arcane', el2: null, team: 'player', life: 1.2,
            kind: 'shard', color: '#f2c9ff', color2: '#c95ee8', trail: 0.6, from: G.player,
          });
        }
        addRing(G, x, y, 6, 300, '#f2c9ff', 0.45, 3);
        addRing(G, x, y, 4, 200, '#c95ee8', 0.5, 2);
        shake(G, 3.4);
      });
      break;
    }

    // ---------- TEMPORAL COLLAPSE: the world freezes, then snaps ----------
    case 'time': {
      screenFlash(G, '#e8d8a0', 0.4);
      slowmo(G, 0.55, 0.35);
      // the clock: two counter-rotating rings of hour-motes
      for (let i = 0; i < 24; i++) {
        const a = (i / 24) * TAU;
        const dir = i % 2 === 0 ? 1 : -1;
        spawnParticle(G, {
          x: x + Math.cos(a) * 56, y: y + Math.sin(a) * 56,
          vx: -Math.sin(a) * 90 * dir, vy: Math.cos(a) * 90 * dir,
          life: 0.9, size: 2, color: i % 3 === 0 ? '#fff2c9' : '#e8c05e', glow: true,
        });
      }
      addRing(G, x, y, 20, -140, '#e8c05e', 0.8, 2);
      addRing(G, x, y, 40, 90, '#fff2c9', 0.8, 2);
      after(G, 0.7, () => {
        effect();
        screenFlash(G, '#fff2c9', 0.3);
        shake(G, 4);
        addRing(G, x, y, 8, 320, '#fff2c9', 0.4, 3);
        G.audio.sfx('blink', 0.5, 1);
        G.audio.sfx('thunder', 1.6, 0.4);
      });
      break;
    }

    // ---------- EVENT HORIZON: everything falls in, then screams out ----------
    case 'void': {
      screenFlash(G, '#2a1040', 0.6);
      // accretion disc
      for (let i = 0; i < 30; i++) {
        const a = (i / 30) * TAU;
        spawnParticle(G, {
          x: x + Math.cos(a) * 70, y: y + Math.sin(a) * 70,
          vx: -Math.sin(a) * 160 - Math.cos(a) * 60, vy: Math.cos(a) * 160 - Math.sin(a) * 60,
          life: 0.7, size: 2, color: pick(['#e85eff', '#8e3ac9', '#2a1040']), glow: true,
        });
      }
      after(G, 0.6, () => {
        effect();
        addRing(G, x, y, 6, 320, '#e85eff', 0.5, 3.5);
        addRing(G, x, y, 4, 220, '#8e3ac9', 0.55, 2.5);
        for (let i = 0; i < 36; i++) {
          const a = rand(0, TAU);
          const s = randR(80, 280);
          spawnParticle(G, {
            x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
            life: randR(0.3, 0.7), size: randR(1.6, 3.2),
            color: pick(['#e85eff', '#8e3ac9', '#ffffff']), glow: true,
          });
        }
        shake(G, 4.4);
        G.audio.sfx('boom', 0.4, 1);
      });
      break;
    }

    // ---------- THE WORLDROOT WAKES: a grove erupts ----------
    case 'nature': {
      screenFlash(G, '#8effa8', 0.3);
      after(G, 0.45, () => { effect(); });
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * TAU + 0.4;
        const px = x + Math.cos(a) * randR(30, 66);
        const py = y + Math.sin(a) * randR(30, 66);
        after(G, i * 0.14, () => {
          // a thorn wall sprouts
          addBeam(G, px, py - 16, Math.PI / 2, 18, 6, 'nature', 0.5);
          for (let j = 0; j < 10; j++) {
            spawnParticle(G, {
              x: px + randR(-6, 6), y: py, vx: randR(-24, 24), vy: -randR(30, 90),
              life: randR(0.5, 0.9), size: randR(2, 3.2),
              color: pick(['#6ab354', '#8effa8', '#3e7a2e']), glow: false, grav: 90,
            });
          }
        });
      }
      after(G, 1, () => {
        for (let i = 0; i < 30; i++) {
          const a = rand(0, TAU);
          spawnParticle(G, {
            x: x + Math.cos(a) * 20, y: y,
            vx: Math.cos(a) * 120, vy: Math.sin(a) * 40 - 60,
            life: randR(0.6, 1.2), size: 2, color: pick(['#8effa8', '#ffe89e', '#6ab354']),
            glow: true, grav: 40,
          });
        }
        addRing(G, x, y, 8, 220, '#8effa8', 0.5, 3);
        shake(G, 2.6);
        G.audio.sfx('heal', 0.8, 0.9);
      });
      break;
    }

    // ---------- ULTIMA CHAOS: reality rolls the dice ----------
    case 'chaos': {
      screenFlash(G, '#ffffff', 0.25);
      for (let i = 0; i < 4; i++) {
        after(G, i * 0.14, () => {
          addRing(G, x, y, 6 + i * 4, randR(140, 280), pick(['#ff5a5a', '#5ee8c9', '#ffd75e', '#c95ee8', '#8effa8']), 0.4, 2.5);
          screenFlash(G, pick(['#ff5a5a', '#5ee8c9', '#ffd75e', '#c95ee8']), 0.12);
          shake(G, 1.6);
        });
      }
      for (let i = 0; i < 40; i++) {
        after(G, rand(0, 0.6), () => {
          const a = rand(0, TAU);
          spawnParticle(G, {
            x: x + Math.cos(a) * 10, y: y + Math.sin(a) * 10,
            vx: Math.cos(a) * randR(60, 220), vy: Math.sin(a) * randR(60, 220),
            life: randR(0.3, 0.7), size: randR(1.6, 3),
            color: pick(['#ff5a5a', '#5ee8c9', '#ffd75e', '#c95ee8', '#8effa8', '#ff9e4e']), glow: true,
          });
        });
      }
      after(G, 0.4, () => { effect(); });
      break;
    }

    // ---------- PRISM REQUIEM: a crystal lattice refracts into lasers ----------
    case 'crystal': {
      screenFlash(G, '#9ee8ff', 0.35);
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI; // 6 beams, 3 lines through center
        after(G, i * 0.05, () => addBeam(G, x, y, a, 95, 5, 'crystal', 0.75));
      }
      after(G, 0.45, () => {
        effect();
        // refraction burst: shards fly and split
        for (let i = 0; i < 14; i++) {
          const a = (i / 14) * TAU;
          makeBullet(G, {
            x, y, vx: Math.cos(a) * 230, vy: Math.sin(a) * 230,
            r: 3.2, dmg: dmg * 0.4, el: 'crystal', el2: null, team: 'player', life: 1.4,
            kind: 'shard', color: '#dff4fc', color2: '#9ee8ff', trail: 0.6, from: G.player,
          });
        }
        for (let i = 0; i < 3; i++) addRing(G, x, y, 6 + i * 5, 240 - i * 50, '#9ee8ff', 0.45, 2.5);
        for (let i = 0; i < 26; i++) {
          const a = rand(0, TAU);
          spawnParticle(G, {
            x, y, vx: Math.cos(a) * randR(80, 240), vy: Math.sin(a) * randR(80, 240),
            life: randR(0.3, 0.8), size: randR(1.6, 3), color: pick(['#dff4fc', '#9ee8ff', '#ffffff']), glow: true,
          });
        }
        shake(G, 3);
        G.audio.sfx('prism', 0.6, 1);
        G.audio.sfx('frozen', 1.2, 0.7);
      });
      break;
    }

    // ---------- IRON TEMPEST: twenty blades orbit, then fly ----------
    case 'metal': {
      screenFlash(G, '#e8e4d4', 0.25);
      after(G, 0.4, () => { effect(); });
      // orbit ring around the caster (metal signature: blades orbit)
      for (let i = 0; i < 20; i++) {
        const a = (i / 20) * TAU;
        makeBullet(G, {
          x: G.player.x + Math.cos(a) * 44, y: G.player.y + Math.sin(a) * 44,
          vx: 0, vy: 0, r: 3, dmg: dmg * 0.35, el: 'metal', el2: null, team: 'player',
          life: 0.6 + i * 0.02, kind: 'shard', color: '#d8d4e0', color2: '#8a8494',
          trail: 0.4, from: G.player,
          orbit: { ang: a, rad: 44, spin: 5.2 },
        });
      }
      for (let i = 0; i < 8; i++) {
        after(G, i * 0.08, () => G.audio.sfx('clang', randR(0.8, 1.3), 0.7));
      }
      after(G, 0.7, () => {
        for (let i = 0; i < 24; i++) {
          const a = rand(0, TAU);
          spawnParticle(G, {
            x: G.player.x, y: G.player.y,
            vx: Math.cos(a) * randR(120, 300), vy: Math.sin(a) * randR(120, 300),
            life: randR(0.25, 0.6), size: randR(1.4, 2.6),
            color: pick(['#e8e4d4', '#ffd75e', '#ffffff']), glow: true,
          });
        }
        shake(G, 3.4);
      });
      break;
    }

    // ---------- SINGULARITY: reality folds inward, then detonates outward ----------
    case 'gravity': {
      screenFlash(G, '#1a1626', 0.5);
      // everything streams into the crush point
      for (let i = 0; i < 30; i++) {
        const a = rand(0, TAU);
        const r = randR(60, 120);
        spawnParticle(G, {
          x: x + Math.cos(a) * r, y: y + Math.sin(a) * r,
          vx: -Math.cos(a) * r * 6, vy: -Math.sin(a) * r * 6,
          life: 0.34, size: 2.4, color: pick(['#8091c9', '#dfe8ff', '#ffffff']), glow: true,
        });
      }
      // two collapsing rings (implode = negative vr)
      addRing(G, x, y, 110, -220, '#8091c9', 0.5, 3);
      addRing(G, x, y, 80, -160, '#dfe8ff', 0.6, 2);
      after(G, 0.42, () => {
        effect();
        screenFlash(G, '#dfe8ff', 0.3);
        shake(G, 6);
        slowmo(G, 0.35, 0.25);
        // the recoil: everything blasts BACK outward
        for (let i = 0; i < 3; i++) addRing(G, x, y, 8, 360 - i * 80, i % 2 ? '#dfe8ff' : '#8091c9', 0.5, 3);
        for (let i = 0; i < 36; i++) {
          const a = rand(0, TAU);
          spawnParticle(G, {
            x, y, vx: Math.cos(a) * randR(150, 380), vy: Math.sin(a) * randR(150, 380),
            life: randR(0.35, 0.8), size: randR(1.6, 3.2),
            color: pick(['#8091c9', '#dfe8ff', '#ffffff']), glow: true,
          });
        }
      });
      break;
    }

    // ---------- THE LAST CHORD: three perfect rings of pure sound ----------
    case 'sound': {
      for (let i = 0; i < 3; i++) {
        after(G, i * 0.22, () => {
          effect();
          screenFlash(G, '#ffffff', 0.22);
          addRing(G, x, y, 6, 340, '#ffffff', 0.55, 3.5);
          addRing(G, x, y, 6, 260, '#c9f2e4', 0.5, 2.5);
          // the visible chord: three taut strings snap across the point
          for (let j = 0; j < 3; j++) {
            const a = rand(0, TAU);
            addBeam(G, x, y, a, 90, 2.5, 'sound', 0.35);
            addBeam(G, x, y, a + Math.PI, 90, 2.5, 'sound', 0.35);
          }
          shake(G, 3 - i * 0.6);
          G.audio.sfx('thunder', 1.4 + i * 0.25, 0.8);
          for (let k = 0; k < 18; k++) {
            const a2 = rand(0, TAU);
            spawnParticle(G, {
              x, y, vx: Math.cos(a2) * randR(180, 320), vy: Math.sin(a2) * randR(180, 320),
              life: 0.4, size: 2, color: pick(['#ffffff', '#c9f2e4']), glow: true,
            });
          }
        });
      }
      break;
    }

    // ---------- THE OSSUARY WAKES: bone pillars climb from the earth ----------
    case 'bone': {
      screenFlash(G, '#e8e0c9', 0.2);
      // six bone pillars erupt in a ring
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        const px = x + Math.cos(a) * randR(28, 62);
        const py = y + Math.sin(a) * randR(28, 62);
        after(G, 0.1 + i * 0.09, () => {
          // pillar = stacked white beams climbing up
          for (let s = 0; s < 3; s++) {
            after(G, s * 0.05, () => addBeam(G, px, py - s * 14, -Math.PI / 2, 16 + s * 4, 5, 'bone', 0.7));
          }
          burst(G, px, py, '#e8e0c9', 8, 70, { glow: true });
          G.audio.sfx('clang', randR(1.6, 2), 0.35);
        });
      }
      after(G, 0.75, () => {
        effect();
        shake(G, 4);
        addRing(G, x, y, 8, 240, '#e8e0c9', 0.45, 3);
        // skull ring closes above the point
        for (let i = 0; i < 12; i++) {
          const a = (i / 12) * TAU;
          spawnParticle(G, {
            x: x + Math.cos(a) * 70, y: y + Math.sin(a) * 70,
            vx: -Math.cos(a) * 130, vy: -Math.sin(a) * 130 - 20,
            life: 0.5, size: 2.4, color: pick(['#e8e0c9', '#fffbe8']), glow: true,
          });
        }
      });
      break;
    }

    // ---------- THE GREAT HUNT: the pack charges through the veil ----------
    case 'beast': {
      // converging spirit streaks, then a massed charge outward
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU + randR(-0.2, 0.2);
        const r = randR(80, 130);
        spawnParticle(G, {
          x: x + Math.cos(a) * r, y: y + Math.sin(a) * r,
          vx: -Math.cos(a) * r * 4.4, vy: -Math.sin(a) * r * 4.4,
          life: 0.38, size: 2.6, color: pick(['#c97e4e', '#ffd9a8', '#ffffff']), glow: true,
        });
      }
      after(G, 0.4, () => {
        effect();
        screenFlash(G, '#ffd9a8', 0.25);
        shake(G, 4);
        slowmo(G, 0.4, 0.3);
        G.audio.sfx('roar', 1.3, 0.8);
        // three claw slashes tear across the mark
        for (let i = 0; i < 3; i++) {
          after(G, 0.08 * i, () => {
            const a = -0.5 + i * 0.5;
            addBeam(G, x - Math.cos(a) * 40, y - Math.sin(a) * 40, a, 80, 4, 'beast', 0.3);
            addBeam(G, x - Math.cos(a + 0.12) * 40, y - Math.sin(a + 0.12) * 40, a + 0.12, 80, 4, 'beast', 0.3);
          });
        }
        // spirit wolves charge out
        for (let i = 0; i < 6; i++) {
          const a = rand(0, TAU);
          after(G, 0.1 * i, () => {
            makeBullet(G, {
              x, y, vx: Math.cos(a) * 320, vy: Math.sin(a) * 320,
              r: 3.4, dmg: dmg * 0.3, el: 'beast', el2: null, team: 'player', life: 0.9,
              kind: 'shard', homing: 2.2, color: '#c97e4e', color2: '#ffd9a8', trail: 0.6, from: G.player,
            });
          });
        }
        for (let i = 0; i < 26; i++) {
          const a2 = rand(0, TAU);
          spawnParticle(G, {
            x, y, vx: Math.cos(a2) * randR(140, 340), vy: Math.sin(a2) * randR(140, 340),
            life: randR(0.3, 0.7), size: randR(1.6, 3), color: pick(['#c97e4e', '#ffd9a8', '#e8e4d4']), glow: true,
          });
        }
      });
      break;
    }

    // ---------- STELLAR INCINERATION: twin stars collide, the sky ignites ----------
    case 'plasma': {
      screenFlash(G, '#a8f2ff', 0.3);
      // two streams (magenta + cyan) spiral in from opposite sides
      for (let i = 0; i < 14; i++) {
        after(G, i * 0.03, () => {
          const a = i * 0.5;
          spawnParticle(G, {
            x: x + Math.cos(a) * 100, y: y + Math.sin(a) * 100,
            vx: -Math.cos(a) * 240, vy: -Math.sin(a) * 240,
            life: 0.4, size: 2.8, color: '#ff5ec9', glow: true,
          });
          spawnParticle(G, {
            x: x - Math.cos(a) * 100, y: y - Math.sin(a) * 100,
            vx: Math.cos(a) * 240, vy: Math.sin(a) * 240,
            life: 0.4, size: 2.8, color: '#a8f2ff', glow: true,
          });
        });
      }
      after(G, 0.5, () => {
        effect();
        // the collision: white-hot core, double pillar, flare crown
        screenFlash(G, '#ffffff', 0.4);
        shake(G, 6);
        slowmo(G, 0.4, 0.3);
        addBeam(G, x, y - 60, Math.PI / 2, 62, 12, 'plasma', 0.5);
        addBeam(G, x, y + 14, -Math.PI / 2, 62, 12, 'plasma', 0.5);
        addRing(G, x, y, 8, 300, '#ff5ec9', 0.5, 3);
        addRing(G, x, y, 6, 210, '#a8f2ff', 0.55, 2.5);
        for (let i = 0; i < 44; i++) {
          const a = rand(0, TAU);
          const s = randR(80, 340);
          spawnParticle(G, {
            x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 60,
            life: randR(0.4, 0.9), size: randR(2, 3.6), grav: 80,
            color: pick(['#ff5ec9', '#a8f2ff', '#ffffff', '#ffd75e']), glow: true,
          });
        }
        G.audio.sfx('thunder', 0.7, 0.9);
      });
      break;
    }

    // ---------- HALL OF MIRRORS: eight images of you, one truth ----------
    case 'mirror': {
      // eight mirror motes orbit, each flashing a thin beam to the center
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU;
        after(G, 0.06 * i, () => {
          spawnParticle(G, {
            x: x + Math.cos(a) * 74, y: y + Math.sin(a) * 74, vx: 0, vy: 0,
            life: 0.5, size: 3, color: '#f2fbff', glow: true,
          });
          addBeam(G, x + Math.cos(a) * 74, y + Math.sin(a) * 74, a + Math.PI, 74, 1.6, 'mirror', 0.3);
          G.audio.sfx('prism', randR(1.3, 1.8), 0.3);
        });
      }
      after(G, 0.55, () => {
        effect();
        // the glass shatters
        screenFlash(G, '#f2fbff', 0.3);
        shake(G, 3);
        addRing(G, x, y, 6, 260, '#f2fbff', 0.45, 2.5);
        addRing(G, x, y, 4, 180, '#c9d8e8', 0.5, 2);
        for (let i = 0; i < 34; i++) {
          const a = rand(0, TAU);
          spawnParticle(G, {
            x, y, vx: Math.cos(a) * randR(120, 320), vy: Math.sin(a) * randR(120, 320),
            life: randR(0.3, 0.7), size: randR(1.4, 2.8),
            color: pick(['#f2fbff', '#c9d8e8', '#ffffff']), glow: true, shrink: true,
          });
        }
      });
      break;
    }
  }
}
