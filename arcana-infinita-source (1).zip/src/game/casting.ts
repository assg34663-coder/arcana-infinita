/* ============================================================
   casting.ts — spell casting engine. Implements every form:
   bolts, volleys, orbs, rays, waves, novas, storms, fields,
   runes, wards, auras, brands, summons, steps, mends and
   grand rituals — flavored by all 16 elements.
   ============================================================ */
import {
  TAU, clamp, angTo, dist, rand, randR, chance, pick,
  type ElementId, type GameCtx, type Minion, type SpellDef, type Ent, type Bullet,
} from './core';
import { elColor, elColor2 } from './sprites';
import {
  makeBullet, spawnZone, addBeam, addTelegraph, explosion, burst,
  damageEnemy, damageBoss, applyElement, addText, spawnParticle, addRing,
  shake, schoolLvlOf, registerRitualHandler, screenFlash,
  type BulletOpts,
} from './fx';
import {
  ELEMENTS, baseSpellDef, spellDamage, spellMana, spellCd, mendAmount,
} from './magic';
import { SCHOOL_SIG } from './schools';
import { grandRitual } from './spectacle';
import { relicVal } from './items';

export const MAX_MINIONS = 7;

// ---------- xp hooks ----------
// v3 PROGRESSION: schools no longer level from XP — casting the schools you
// love fills their attunement bar, and a full bar grants a SKILL POINT you
// may spend anywhere in the skill tree (K).
export function grantCastXp(G: GameCtx, def: SpellDef, hits: number): void {
  const school = G.prog.schools[def.el];
  if (school && school.lvl < 40) {
    school.xp += 2 + hits;
    let gained = 0;
    while (school.lvl < 40 && school.xp >= 26 * Math.pow(Math.max(1, Math.floor(school.lvl / 2)), 1.42) * 0.9) {
      school.xp -= 26 * Math.pow(Math.max(1, Math.floor(school.lvl / 2)), 1.42) * 0.9;
      gained++;
      if (gained > 3) { school.xp = 0; break; }
    }
    if (gained > 0) {
      G.prog.points += gained;
      G.prog.pointsEarned += gained;
      addText(G, G.player.x, G.player.y - 26, `+${gained} SKILL POINT${gained > 1 ? 'S' : ''}  [K]`, '#c95ee8', 5, true);
      G.audio.sfx('unlock', 1.4, 0.4);
      burst(G, G.player.x, G.player.y - 4, '#c95ee8', 10, 70, { glow: true });
      G.uiV++;
    }
  }
  const sp = G.prog.spells[def.id];
  if (sp && sp.lvl < 10) {
    sp.xp += 2 + hits;
    while (sp.lvl < 10 && sp.xp >= 16 * Math.pow(sp.lvl, 1.4)) {
      sp.xp -= 16 * Math.pow(sp.lvl, 1.4);
      sp.lvl++;
    }
    if (sp.lvl >= 10) sp.xp = 0;
  }
}

// ---------- minions ----------
export interface MinionArch {
  sprite: string; hp: number; dmg: number; speed: number;
  ranged: boolean; cd: number; bulletSpeed: number;
}

export const MINION_ARCHES: Record<ElementId, MinionArch> = {
  fire: { sprite: 'min_imp', hp: 26, dmg: 9, speed: 88, ranged: false, cd: 0.8, bulletSpeed: 0 },
  frost: { sprite: 'min_wisp', hp: 20, dmg: 6, speed: 60, ranged: true, cd: 1.2, bulletSpeed: 175 },
  lightning: { sprite: 'min_wisp', hp: 20, dmg: 7, speed: 66, ranged: true, cd: 1.0, bulletSpeed: 240 },
  earth: { sprite: 'min_golem', hp: 60, dmg: 14, speed: 46, ranged: false, cd: 1.1, bulletSpeed: 0 },
  wind: { sprite: 'min_gale', hp: 16, dmg: 5, speed: 74, ranged: true, cd: 0.7, bulletSpeed: 220 },
  water: { sprite: 'min_tide', hp: 24, dmg: 6, speed: 62, ranged: true, cd: 1.3, bulletSpeed: 160 },
  poison: { sprite: 'shroom', hp: 22, dmg: 6, speed: 55, ranged: true, cd: 1.4, bulletSpeed: 130 },
  blood: { sprite: 'min_bat', hp: 18, dmg: 7, speed: 96, ranged: false, cd: 0.6, bulletSpeed: 0 },
  shadow: { sprite: 'min_wraith', hp: 24, dmg: 10, speed: 70, ranged: false, cd: 0.9, bulletSpeed: 0 },
  death: { sprite: 'min_skel', hp: 34, dmg: 11, speed: 76, ranged: false, cd: 0.9, bulletSpeed: 0 },
  radiant: { sprite: 'min_healer', hp: 20, dmg: 0, speed: 70, ranged: false, cd: 1.0, bulletSpeed: 0 },
  arcane: { sprite: 'min_wisp', hp: 20, dmg: 7, speed: 64, ranged: true, cd: 1.1, bulletSpeed: 200 },
  time: { sprite: 'min_gale', hp: 18, dmg: 5, speed: 72, ranged: true, cd: 1.2, bulletSpeed: 170 },
  void: { sprite: 'min_void', hp: 24, dmg: 8, speed: 58, ranged: true, cd: 1.4, bulletSpeed: 150 },
  nature: { sprite: 'min_treant', hp: 40, dmg: 9, speed: 50, ranged: false, cd: 1.0, bulletSpeed: 0 },
  chaos: { sprite: 'min_imp', hp: 24, dmg: 9, speed: 80, ranged: false, cd: 0.8, bulletSpeed: 0 },
  crystal: { sprite: 'min_wisp', hp: 22, dmg: 7, speed: 66, ranged: true, cd: 1.1, bulletSpeed: 210 },
  metal: { sprite: 'min_golem', hp: 34, dmg: 10, speed: 54, ranged: false, cd: 0.9, bulletSpeed: 0 },
  gravity: { sprite: 'min_void', hp: 26, dmg: 8, speed: 56, ranged: true, cd: 1.5, bulletSpeed: 140 },
  sound: { sprite: 'min_wisp', hp: 18, dmg: 6, speed: 70, ranged: true, cd: 0.9, bulletSpeed: 230 },
  bone: { sprite: 'min_skel', hp: 30, dmg: 10, speed: 70, ranged: false, cd: 0.9, bulletSpeed: 0 },
  beast: { sprite: 'min_bat', hp: 26, dmg: 10, speed: 95, ranged: false, cd: 0.6, bulletSpeed: 0 },
  plasma: { sprite: 'min_imp', hp: 22, dmg: 9, speed: 84, ranged: true, cd: 0.8, bulletSpeed: 200 },
  mirror: { sprite: 'min_wraith', hp: 20, dmg: 7, speed: 68, ranged: true, cd: 1.0, bulletSpeed: 190 },
};

export function nearestCorpse(G: GameCtx, x: number, y: number, r: number): number {
  let best = -1;
  let bd = r * r;
  for (let i = 0; i < G.corpses.length; i++) {
    const c = G.corpses[i];
    if (c.used) continue;
    const d = (c.x - x) ** 2 + (c.y - y) ** 2;
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

export function createMinion(G: GameCtx, el: ElementId, x: number, y: number, power: number, bonusHp = 0): Minion | null {
  if (G.minions.filter((m) => !m.dead).length >= maxMinions(G)) return null;
  const a = MINION_ARCHES[el];
  const cls = G.prog.cls;
  const hpv = (a.hp + bonusHp) * (1 + power * 0.35) * (cls === 'summoner' ? 1.3 : 1);
  const m: Minion = {
    x, y, vx: 0, vy: 0, r: 6,
    hp: hpv, maxHp: hpv,
    team: 'player', st: {}, flash: 0, dead: false, deadT: 0, face: 1, anim: rand(0, 9),
    mtype: el, sprite: a.sprite, el,
    life: (25 + power * 2) * (cls === 'summoner' ? 1.3 : 1),
    dmg: a.dmg * (1 + power * 0.45) * (cls === 'summoner' ? 1.25 : 1),
    speed: a.speed, ranged: a.ranged, atkT: 0, atkCd: a.cd, bulletSpeed: a.bulletSpeed,
  };
  if (el === 'shadow') m.passWalls = true;
  G.minions.push(m);
  burst(G, x, y, elColor(el), 10, 70);
  G.audio.sfx('summon');
  return m;
}

// necromancer commands a larger horde
export function maxMinions(G: GameCtx): number {
  return MAX_MINIONS + (G.prog.cls === 'necromancer' ? 2 : 0);
}

// ---------- generic hit helper ----------
function hitEntity(G: GameCtx, e: Ent, dmg: number, el: ElementId, el2: ElementId | null, crit: boolean): void {
  const isBoss = 'defId' in e;
  if (isBoss) {
    damageBoss(G, e as never, dmg, el, crit);
  } else {
    damageEnemy(G, e as never, dmg, el, { crit, from: G.player });
  }
  if (el2) applyElement(G, e, el2, 0.45, 'player');
}

// ---------- school personality: shape every spawned projectile ----------
export function applySchoolMods(G: GameCtx, o: BulletOpts, def: SpellDef): BulletOpts {
  const m = SCHOOL_SIG[def.el]?.proj;
  if (m) {
    if (m.speed) { o.vx = (o.vx ?? 0) * m.speed; o.vy = (o.vy ?? 0) * m.speed; }
    if (m.r) o.r = (o.r ?? 3) + m.r;
    if (m.pierce) o.pierce = (o.pierce ?? 0) + m.pierce;
    if (m.homing) o.homing = (o.homing ?? 0) + m.homing;
    if (m.gravity) o.gravity = (o.gravity ?? 0) + m.gravity;
    if (m.zigzag) o.zigzag = (o.zigzag ?? 0) + m.zigzag;
    if (m.life) o.life = (o.life ?? 3) * m.life;
    if (m.trail) o.trail = (o.trail ?? 0.4) + m.trail;
    if (m.boomR) { o.boomR = Math.max(o.boomR ?? 0, m.boomR); o.boomDmg = Math.max(o.boomDmg ?? 0, (o.dmg ?? 0) * 0.45); }
    if (m.accel) o.accel = (o.accel ?? 0) + m.accel;
    if (SCHOOL_SIG[def.el].passWalls || m.passWalls) o.passWalls = true;
  }
  if (def.el === 'blood') o.boomerang = 1;
  if (def.el === 'death') o.kind = 'soul';
  if (def.el === 'bone' && (def.form === 'bolt' || def.form === 'volley' || def.form === 'nova')) o.kind = 'shard';
  if (def.el === 'mirror' && def.form !== 'beam' && def.form !== 'blink') o.kind = 'orb';
  if (def.el === 'plasma' && def.form !== 'beam' && def.form !== 'blink' && def.form !== 'ward') o.kind = 'orb';
  if (def.el === 'beast' && (def.form === 'bolt' || def.form === 'volley')) o.kind = 'shard';
  if (def.el === 'metal' && def.form !== 'beam' && def.form !== 'storm' && def.form !== 'blink') {
    // FERRUMANCY: steel orbits the caster like a blade dance
    const isBig = def.form === 'orb';
    o.orbit = { ang: rand(0, TAU), rad: isBig ? 52 : 40, spin: isBig ? 3.1 : 3.9 };
    o.life = Math.max(o.life ?? 3, 3.4);
    o.pierce = 99;
  }
  // spell mastery: higher spell levels look bigger and burn brighter
  const sl = G.prog.spells[def.id]?.lvl ?? 1;
  if (sl > 1 && o.r) o.r += (sl - 1) * 0.14;
  if (G.overdrive > 0 && o.r) { o.r += 0.8; o.trail = (o.trail ?? 0.4) + 0.25; }
  return o;
}

// NECROMANCY: every death spell devours nearby corpses for power
function consumeCorpses(G: GameCtx, max = 2): number {
  const p = G.player;
  let n = 0;
  for (const c of G.corpses) {
    if (c.used || n >= max) continue;
    if (dist(c.x, c.y, p.x, p.y) < 120) {
      c.used = true;
      n++;
      // soul essence streams into the caster
      for (let i = 0; i < 6; i++) {
        spawnParticle(G, {
          x: c.x + randR(-5, 5), y: c.y + randR(-5, 5),
          vx: (p.x - c.x) * randR(1.2, 2.2), vy: (p.y - c.y) * randR(1.2, 2.2) - 50,
          life: 0.5, size: 2.2, color: i % 2 ? '#e2e8dc' : '#9ee8d8', glow: true,
        });
      }
      addText(G, c.x, c.y - 10, 'SOUL +40%', '#e2e8dc', 4);
      burst(G, c.x, c.y, '#a8b0a0', 6, 50, { glow: true });
    }
  }
  if (n > 0) {
    addRing(G, p.x, p.y, 8, 140, '#9ee8d8', 0.35, 2);
    G.audio.sfx('summon', 1.4, 0.5);
  }
  return n;
}

// ---------- high-tier casting ceremony ----------
// Spell tiers (unlock level) drive a small ritual before big magic:
// converging motes, a rune ring, screen pulse — the dopamine part.
function castSpectacle(G: GameCtx, def: SpellDef, ang: number): void {
  const sLvl = G.prog.schools[def.el]?.lvl ?? 1;
  const tier = def.unlock + (def.form === 'ritual' ? 12 : 0);
  const big = def.form === 'ritual' || def.form === 'summon' || def.form === 'storm' || def.form === 'nova';
  const p = G.player;
  const col = elColor(def.el);
  if (tier >= 9 || sLvl >= 14 || big) {
    // converging motes spiral into the staff tip
    const sx = p.x + Math.cos(ang) * 10, sy = p.y - 2 + Math.sin(ang) * 10;
    const n = 8 + Math.min(10, Math.floor(sLvl / 4));
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + randR(-0.3, 0.3);
      const rr = randR(26, 40);
      spawnParticle(G, {
        x: p.x + Math.cos(a) * rr, y: p.y + Math.sin(a) * rr - 2,
        vx: (sx - p.x - Math.cos(a) * rr) * 5.5, vy: (sy - p.y + 2 - Math.sin(a) * rr) * 5.5,
        life: 0.3, size: 2, color: i % 3 === 0 ? '#ffffff' : col, glow: true,
      });
    }
    addRing(G, p.x, p.y - 2, 4, 110, col, 0.32, 1.5);
  }
  if (big || tier >= 16 || sLvl >= 22) {
    // grand ceremony: double rune ring + cast roar
    addRing(G, p.x, p.y - 2, 10, 200, elColor2(def.el), 0.45, 2.5);
    addRing(G, p.x, p.y - 2, 2, 260, col, 0.4, 1.5);
    G.audio.sfx('castBig', randR(0.9, 1.15), 0.7);
    if (def.form === 'ritual') {
      G.odFlash = Math.max(G.odFlash, 0.25);
      shake(G, 1.6);
    }
  }
}

// ---------- the caster ----------
export function castSpell(G: GameCtx, def0: SpellDef, aimX: number, aimY: number): boolean {
  const p = G.player;
  if (p.dead || p.castCd > 0 || p.stunT > 0) return false;
  // chaos re-rolls the element every cast
  let def = def0;
  if (def0.el === 'chaos') {
    const rolled = pick(ELEMENT_IDS_NO_CHAOS);
    def = { ...def0, el: rolled, el2: def0.el2 === 'chaos' ? null : def0.el2 };
  }
  let mana = spellMana(G, def0) * (1 - clamp(relicVal(G, 'manaCost'), 0, 0.25)); // RELIC: the unwound gear
  // HEMOMANCY: blood spells are paid in blood, not mana (60% of the mana price)
  const bloodCast = def0.el === 'blood';
  const hpCost = Math.round(mana * 0.6 * (G.prog.cls === 'ritualist' ? 0.75 : 1));
  // MYSTICISM: casting at (nearly) full mana triggers a free ARCANE SURGE
  const surge = def0.el === 'arcane' && !bloodCast && p.mana >= p.maxMana * 0.92;
  if (bloodCast) {
    if (p.hp <= hpCost + 4) {
      G.audio.sfx('ui', 0.5, 0.4);
      addText(G, p.x, p.y - 16, 'NOT ENOUGH BLOOD', '#d94e5e', 5);
      return false;
    }
    p.hp -= hpCost;
    p.flash = Math.max(p.flash, 0.1);
    addText(G, p.x, p.y - 18, `-${hpCost} BLOOD`, '#d94e5e', 4);
    burst(G, p.x, p.y, '#d94e5e', 5, 40, { glow: true });
  } else if (!surge) {
    if (p.mana < mana) {
      G.audio.sfx('ui', 0.5, 0.4);
      return false;
    }
    p.mana -= mana;
  } else {
    addText(G, p.x, p.y - 20, 'ARCANE SURGE!', '#f2c9ff', 6, true);
    burst(G, p.x, p.y - 4, '#f2c9ff', 14, 90, { glow: true });
    addRing(G, p.x, p.y, 6, 150, '#f2c9ff', 0.35, 2);
    G.audio.sfx('unlock', 1.4, 0.6);
  }
  p.castCd = spellCd(G, def0) * (1 - clamp(relicVal(G, 'cdMult'), 0, 0.3)); // RELIC: sigil of the unsworn
  // RELIC: the cracked chalice — sometimes it gives the sip back
  const mRef = relicVal(G, 'manaRefund');
  if (mRef > 0 && !bloodCast && !surge && chance(Math.min(0.4, mRef))) {
    p.mana = Math.min(p.maxMana, p.mana + mana);
    addText(G, p.x, p.y - 24, 'REFUND', '#9ee8ff', 4);
    G.audio.sfx('graze', 1.3, 0.35);
  }
  p.manaRegenT = 1.6;
  p.face = aimX >= p.x ? 1 : -1;
  p.castAnimT = 0.22;

  const ang = angTo(p.x, p.y, aimX, aimY);
  // AEROMANCY: casting a gale while moving whips a TAILWIND dash
  if (def0.el === 'wind') {
    const mv = Math.hypot(p.vx, p.vy);
    if (mv > 30) {
      p.vx += (p.vx / mv) * 165;
      p.vy += (p.vy / mv) * 165;
      for (let i = 0; i < 6; i++) {
        spawnParticle(G, {
          x: p.x - (p.vx / mv) * randR(4, 14), y: p.y - (p.vy / mv) * randR(4, 14) + randR(-4, 4),
          vx: -(p.vx / mv) * randR(40, 80), vy: -(p.vy / mv) * randR(40, 80),
          life: 0.3, size: 2, color: '#e2fff2', glow: true,
        });
      }
    }
  }

  // high-tier ceremony: converging motes + rune rings + rumble
  castSpectacle(G, def0, ang);

  // NECROMANCY: corpse essence empowers all death magic
  G.corpseBonus = (def.el === 'death' || def.el2 === 'death') ? consumeCorpses(G) : 0;

  const power = (G.prog.schools[def.el]?.lvl ?? 1) + (G.prog.spells[def.id]?.lvl ?? 1);
  const dmg = spellDamage(G, def) * (surge ? 1.25 : 1);
  const el = def.el, el2 = def.el2;
  const col = elColor(el), col2 = elColor2(el);

  // muzzle flash at the staff tip
  {
    const sx = p.x + Math.cos(ang) * 10, sy = p.y - 2 + Math.sin(ang) * 10;
    burst(G, sx, sy, col, 5, 60, { glow: true, life: 0.22, size: 2 });
  }

  let hits = 0;
  G.cb.spellCast(def);

  switch (def.form) {
    case 'bolt': {
      makeBullet(G, applySchoolMods(G, {
        x: p.x + Math.cos(ang) * 8, y: p.y + Math.sin(ang) * 8 - 3,
        vx: Math.cos(ang) * 340, vy: Math.sin(ang) * 340,
        r: 3, dmg, el, el2, team: 'player', life: 1.3, kind: 'bolt',
        color: col, color2: col2, trail: 0.5, from: p,
      }, def));
      hits = 1;
      break;
    }
    case 'volley': {
      const m = SCHOOL_SIG[el].proj;
      const n = 5 + (m.count ?? 0);
      for (let i = 0; i < n; i++) {
        const a = ang + (i - (n - 1) / 2) * 0.14 * (m.spread ?? 1) + randR(-0.03, 0.03);
        const cel = def0.el === 'chaos' ? pick(ELEMENT_IDS_NO_CHAOS) : el;
        makeBullet(G, applySchoolMods(G, {
          x: p.x + Math.cos(a) * 8, y: p.y + Math.sin(a) * 8 - 3,
          vx: Math.cos(a) * 300, vy: Math.sin(a) * 300,
          r: 2.5, dmg: def0.el === 'chaos' ? dmg * 0.92 : dmg, el: cel, el2, team: 'player', life: 1.2, kind: 'bolt',
          color: def0.el === 'chaos' ? elColor(cel) : col, color2: def0.el === 'chaos' ? elColor2(cel) : col2,
          trail: 0.35, from: p,
        }, def));
      }
      hits = 2;
      break;
    }
    case 'orb': {
      makeBullet(G, applySchoolMods(G, {
        x: p.x + Math.cos(ang) * 10, y: p.y + Math.sin(ang) * 10 - 3,
        vx: Math.cos(ang) * 115, vy: Math.sin(ang) * 115,
        r: 7, dmg, el, el2, team: 'player', life: 2.8, kind: 'orb',
        pierce: 3, color: col, color2: col2, trail: 0.9, from: p,
      }, def));
      burst(G, p.x + Math.cos(ang) * 12, p.y + Math.sin(ang) * 12, col, 8, 70, { glow: true });
      hits = 2;
      break;
    }
    case 'beam': {
      const LEN = 430, W = 13;
      const bMul = SCHOOL_SIG[el].beamMul ?? 1;
      addBeam(G, p.x, p.y - 3, ang, LEN, W, el, 0.24);
      const hitRay = (e: Ent): void => {
        const t = clamp((e.x - p.x) * Math.cos(ang) + (e.y - p.y) * Math.sin(ang), 0, LEN);
        const px = p.x + Math.cos(ang) * t, py = p.y + Math.sin(ang) * t;
        if (dist(px, py, e.x, e.y) < W / 2 + e.r) {
          const crit = chance(0.08);
          hitEntity(G, e, dmg * bMul * (crit ? 1.6 : 1), el, el2, crit);
          // beam scorch mark
          burst(G, px, py, col, 4, 60, { glow: true });
          hits++;
        }
      };
      for (const e of G.enemies) if (!e.dead) hitRay(e);
      if (G.boss && !G.boss.dead && G.boss.state !== 'intro') hitRay(G.boss);
      // beam recoil kick
      p.vx -= Math.cos(ang) * 30; p.vy -= Math.sin(ang) * 30;
      G.audio.sfx('zap', 0.8);
      break;
    }
    case 'wave': {
      makeBullet(G, applySchoolMods(G, {
        x: p.x + Math.cos(ang) * 6, y: p.y + Math.sin(ang) * 6,
        vx: Math.cos(ang) * 150, vy: Math.sin(ang) * 150,
        r: 9, dmg, el, el2, team: 'player', life: 1.7, kind: 'wave',
        pierce: 99, passWalls: true, color: col, color2: col2, trail: 0.2, from: p,
      }, def));
      hits = 2;
      break;
    }
    case 'nova': {
      const m = SCHOOL_SIG[el].proj;
      const N = 14 + (m.count ?? 0);
      for (let i = 0; i < N; i++) {
        const a = (i / N) * TAU + randR(-0.05, 0.05);
        makeBullet(G, applySchoolMods(G, {
          x: p.x, y: p.y, vx: Math.cos(a) * 235, vy: Math.sin(a) * 235,
          r: 3, dmg, el, el2, team: 'player', life: 0.85, kind: 'bolt',
          color: col, color2: col2, trail: 0.4, from: p,
        }, def));
      }
      burst(G, p.x, p.y, col2, 16, 130, { glow: true });
      addRing(G, p.x, p.y, 8, 240, col, 0.3, 2);
      // high mastery novas hit like a detonation, not a firework
      const novaMastery = G.prog.schools[el]?.lvl ?? 1;
      if (novaMastery >= 10) {
        screenFlash(G, col, 0.16);
        addRing(G, p.x, p.y, 4, 320, col2, 0.4, 3);
        addRing(G, p.x, p.y, 2, 200, col, 0.45, 2);
        shake(G, 1.6);
        G.audio.sfx('boom', 1.3, 0.5);
      }
      hits = 2;
      break;
    }
    case 'storm': {
      const R = 62, N = 10;
      for (let i = 0; i < N; i++) {
        const tx = aimX + randR(-R, R), ty = aimY + randR(-R, R);
        addTelegraph(G, {
          kind: 'circle', x: tx, y: ty, r: 16, dur: 0.45 + i * 0.09, color: col, team: 'player',
          onDone: () => {
            addBeam(G, tx, ty - 90, Math.PI / 2, 92, 4, el, 0.18);
            explosion(G, tx, ty, 20, dmg, el, 'player', { el2, from: p });
            if (el === 'lightning') G.audio.sfx('thunder', 1.4, 0.5);
          },
        });
      }
      hits = 4;
      break;
    }
    case 'field': {
      const fMul = SCHOOL_SIG[el].fieldMul ?? 1;
      spawnZone(G, { kind: 'field', x: aimX, y: aimY, r: 55, dur: 5.5, el, el2, team: 'player', dmg: dmg * 0.42 * fMul, tick: 0.38, owner: p });
      burst(G, aimX, aimY, col, 10, 80, { glow: true });
      hits = 2;
      break;
    }
    case 'trap': {
      spawnZone(G, { kind: 'trap', x: aimX, y: aimY, r: 26, dur: 26, el, el2, team: 'player', dmg, tick: 1, owner: p });
      hits = 1;
      break;
    }
    case 'ward': {
      const amt = 28 + power * 1.6;
      p.ward = { t: 9 + power * 0.12, amt, maxAmt: amt, el };
      burst(G, p.x, p.y, col, 16, 90);
      G.audio.sfx('shrine', 1.3, 0.6);
      hits = 1;
      break;
    }
    case 'aura': {
      const fMul = SCHOOL_SIG[el].fieldMul ?? 1;
      spawnZone(G, { kind: 'aura', x: p.x, y: p.y, r: 44, dur: 6.5, el, el2, team: 'player', dmg: dmg * 0.8 * fMul, tick: 0.36, follow: p, owner: p });
      hits = 2;
      break;
    }
    case 'enchant': {
      p.enchant = { t: 13, el };
      burst(G, p.x, p.y, col, 10, 60);
      G.audio.sfx('unlock', 1.2, 0.5);
      hits = 1;
      break;
    }
    case 'summon': {
      let bonus = 0;
      if (el === 'death') {
        const ci = nearestCorpse(G, p.x, p.y, 80);
        if (ci >= 0) { G.corpses[ci].used = true; bonus = 18; burst(G, p.x, p.y, '#a8b0a0', 8, 60); }
      }
      const count = el === 'death' ? 2 : 1;
      for (let i = 0; i < count; i++) {
        createMinion(G, el, p.x + randR(-14, 14), p.y + randR(-14, 14), power, bonus);
      }
      hits = 1;
      break;
    }
    case 'blink': {
      if (el === 'time') {
        const idx = Math.max(0, p.history.length - 1 - Math.floor(2.2 * 60));
        const h = p.history[idx];
        if (h) {
          burst(G, p.x, p.y, col, 12, 80);
          p.x = h.x; p.y = h.y;
          p.iframes = Math.max(p.iframes, 0.3);
          burst(G, p.x, p.y, col, 12, 80);
          G.audio.sfx('blink', 0.7);
        }
      } else {
        let d = Math.min(150, dist(p.x, p.y, aimX, aimY));
        let fx = p.x + Math.cos(ang) * d, fy = p.y + Math.sin(ang) * d;
        for (let s = 0; s < 12 && G.world.solidAt(fx, fy); s++) {
          d -= 12;
          fx = p.x + Math.cos(ang) * d; fy = p.y + Math.sin(ang) * d;
        }
        burst(G, p.x, p.y, col, 10, 80);
        p.x = fx; p.y = fy;
        p.iframes = Math.max(p.iframes, 0.26);
        burst(G, p.x, p.y, col, 10, 80);
        G.audio.sfx('blink');
      }
      hits = 1;
      break;
    }
    case 'mend': {
      const heal = mendAmount(G, def);
      p.hp = Math.min(p.maxHp, p.hp + heal);
      if (el === 'blood') { delete p.st.burn; delete p.st.poison; }
      addText(G, p.x, p.y - 12, `+${Math.round(heal)}`, '#8effa8', 6);
      burst(G, p.x, p.y - 4, el === 'blood' ? '#d94e5e' : '#b8ffb0', 10, 50, { dir: -Math.PI / 2, spread: 0.9 });
      G.audio.sfx('heal');
      hits = 1;
      break;
    }
    case 'ritual': {
      castRitual(G, def, aimX, aimY, dmg);
      hits = 5;
      break;
    }
  }

  grantCastXp(G, def0, hits);
  return true;
}

const ELEMENT_IDS_NO_CHAOS: ElementId[] = [
  'fire', 'frost', 'lightning', 'earth', 'wind', 'water', 'poison', 'blood',
  'shadow', 'death', 'radiant', 'arcane', 'time', 'void', 'nature', 'crystal', 'metal',
];

// ---------- rituals ----------
export function castRitual(G: GameCtx, def: SpellDef, x: number, y: number, dmg: number): void {
  const col = elColor(def.el);
  G.audio.sfx('castBig', 0.8);
  addTelegraph(G, {
    kind: 'circle', x, y, r: 105, dur: 0.85, color: col, team: 'player',
    onDone: () => {
      // the GRAND CASTING: a full cinematic, with the real payload at its climax
      grandRitual(G, def.el, x, y, dmg, () => ritualEffect(G, def.el, x, y, dmg, def.el2, 1));
    },
  });
}

export function ritualEffect(
  G: GameCtx, el: ElementId, x: number, y: number, dmg: number, el2: ElementId | null, scale: number,
): void {
  const col = elColor(el);
  const p = G.player;
  const inR = (r: number): Ent[] => {
    const out: Ent[] = [];
    for (const e of G.enemies) if (!e.dead && dist(e.x, e.y, x, y) < r) out.push(e);
    if (G.boss && !G.boss.dead && dist(G.boss.x, G.boss.y, x, y) < r) out.push(G.boss);
    return out;
  };
  const boomAll = (r: number, mul: number): void => {
    for (const e of inR(r)) hitEntity(G, e, dmg * mul * scale, el, el2, false);
  };
  switch (el) {
    case 'fire':
      explosion(G, x, y, 115, dmg * scale, el, 'player', { el2 });
      spawnZone(G, { kind: 'field', x, y, r: 70, dur: 3.5, el, team: 'player', dmg: dmg * 0.25, tick: 0.4 });
      break;
    case 'frost':
      boomAll(115, 1);
      for (const e of inR(115)) if (e.st) e.st.chill = { t: 3.5, mult: 0.35 };
      spawnZone(G, { kind: 'field', x, y, r: 80, dur: 4, el: 'frost', team: 'player', dmg: dmg * 0.15, tick: 0.5 });
      burst(G, x, y, col, 30, 160);
      break;
    case 'lightning': {
      G.audio.sfx('thunder');
      for (let i = 0; i < 12; i++) {
        const tx = x + randR(-95, 95), ty = y + randR(-95, 95);
        addTelegraph(G, {
          kind: 'circle', x: tx, y: ty, r: 14, dur: 0.12 + i * 0.06, color: col, team: 'player',
          onDone: () => {
            addBeam(G, tx, ty - 90, Math.PI / 2, 92, 4, 'lightning', 0.15);
            explosion(G, tx, ty, 18, dmg * 0.45 * scale, 'lightning', 'player', { el2 });
          },
        });
      }
      for (const e of inR(115)) if (e.st) e.st.stun = { t: 0.8 };
      break;
    }
    case 'earth':
      for (const e of inR(115)) if (e.st) e.st.stun = { t: 1.4 };
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * TAU;
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 180, vy: Math.sin(a) * 180,
          r: 4, dmg: dmg * 0.5 * scale, el: 'earth', el2, team: 'player', life: 1.1,
          kind: 'shard', color: col, color2: elColor2('earth'), from: p,
        });
      }
      explosion(G, x, y, 90, dmg * 0.8 * scale, 'earth', 'player', { el2 });
      break;
    case 'wind':
      for (const e of inR(130)) {
        const a = angTo(x, y, e.x, e.y);
        e.vx += Math.cos(a) * 420 * scale;
        e.vy += Math.sin(a) * 420 * scale;
      }
      for (let i = 0; i < 20; i++) {
        const a = rand(0, TAU);
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 260, vy: Math.sin(a) * 260,
          r: 3, dmg: dmg * 0.4 * scale, el: 'wind', el2, team: 'player', life: 0.9,
          kind: 'bolt', color: col, color2: elColor2('wind'), from: p,
        });
      }
      break;
    case 'water':
      for (let i = 0; i < 22; i++) {
        const a = (i / 22) * TAU;
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 140, vy: Math.sin(a) * 140,
          r: 7, dmg: dmg * 0.45 * scale, el: 'water', el2, team: 'player', life: 1.4,
          kind: 'wave', pierce: 99, passWalls: true, color: col, color2: elColor2('water'), from: p,
        });
      }
      break;
    case 'poison':
      boomAll(115, 0.8);
      for (const e of inR(115)) if (e.st) e.st.amp = { t: 5, mult: 1.25 };
      spawnZone(G, { kind: 'field', x, y, r: 85, dur: 5, el: 'poison', team: 'player', dmg: dmg * 0.2, tick: 0.45 });
      break;
    case 'blood': {
      let total = 0;
      for (const e of inR(115)) {
        const before = e.hp;
        hitEntity(G, e, dmg * scale, 'blood', el2, false);
        total += Math.max(0, before - e.hp);
      }
      p.hp = Math.min(p.maxHp, p.hp + total * 0.35);
      addText(G, p.x, p.y - 12, `+${Math.round(total * 0.35)}`, '#8effa8', 6);
      break;
    }
    case 'shadow':
      for (const e of inR(115)) if (e.st) e.st.fear = { t: 2 };
      for (let i = 0; i < 12; i++) {
        const a = rand(0, TAU);
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 120, vy: Math.sin(a) * 120,
          r: 3.5, dmg: dmg * 0.5 * scale, el: 'shadow', el2, team: 'player', life: 2.2,
          kind: 'orb', homing: 3.2, color: col, color2: elColor2('shadow'), from: p,
        });
      }
      break;
    case 'death': {
      let consumed = 0;
      for (const c of G.corpses) {
        if (c.used || consumed >= 4) continue;
        if (dist(c.x, c.y, x, y) < 140) {
          c.used = true;
          consumed++;
          explosion(G, c.x, c.y, 46, dmg * 0.5 * scale, 'death', 'player', { el2 });
        }
      }
      boomAll(115, 0.9);
      let raised = 0;
      for (const c of G.corpses) {
        if (c.used || raised >= 2) continue;
        if (dist(c.x, c.y, x, y) < 120) {
          c.used = true;
          createMinion(G, 'death', c.x, c.y, (G.prog.schools.death?.lvl ?? 1) + (G.prog.spells[def_id_of(G, 'death', 'ritual')]?.lvl ?? 1), 8);
          raised++;
        }
      }
      break;
    }
    case 'radiant': {
      for (let i = 0; i < 4; i++) addBeam(G, x, y, (i / 4) * Math.PI, 130, 16, 'radiant', 0.5);
      boomAll(120, 1.1);
      p.hp = Math.min(p.maxHp, p.hp + 22);
      addText(G, p.x, p.y - 12, '+22', '#8effa8', 6);
      break;
    }
    case 'arcane':
      explosion(G, x, y, 135, dmg * scale, 'arcane', 'player', { el2 });
      p.mana = Math.min(p.maxMana, p.mana + spellMana(G, def_of(G, 'arcane', 'ritual')) * 0.5);
      break;
    case 'time':
      for (const e of inR(120)) if (e.st) e.st.stun = { t: 3 };
      p.buffHaste = 4.5;
      spawnZone(G, { kind: 'field', x, y, r: 90, dur: 3, el: 'time', team: 'player', dmg: dmg * 0.12, tick: 0.5 });
      G.audio.sfx('blink', 0.5);
      break;
    case 'void': {
      const z = spawnZone(G, { kind: 'field', x, y, r: 95, dur: 3.2, el: 'void', team: 'player', dmg: dmg * 0.22, tick: 0.3 });
      z.potency = 2;
      break;
    }
    case 'nature':
      for (const e of inR(115)) if (e.st) e.st.root = { t: 2.4 };
      boomAll(115, 0.7);
      spawnZone(G, { kind: 'field', x, y, r: 80, dur: 4, el: 'nature', team: 'player', dmg: dmg * 0.18, tick: 0.45 });
      p.hp = Math.min(p.maxHp, p.hp + 10);
      break;
    case 'crystal': {
      // prism bloom: a lattice of refracting shards
      for (let i = 0; i < 14; i++) {
        const a = (i / 14) * TAU;
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 210, vy: Math.sin(a) * 210,
          r: 3.4, dmg: dmg * 0.42 * scale, el: 'crystal', el2, team: 'player', life: 1.6,
          kind: 'shard', color: col, color2: elColor2('crystal'), from: p,
        });
      }
      boomAll(105, 0.8);
      addRing(G, x, y, 8, 300, elColor2('crystal'), 0.5, 2.5);
      break;
    }
    case 'metal': {
      // forge tempest: an instant storm of flung steel
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * TAU + randR(-0.1, 0.1);
        makeBullet(G, {
          x: p.x, y: p.y, vx: Math.cos(a) * 250, vy: Math.sin(a) * 250,
          r: 3.2, dmg: dmg * 0.4 * scale, el: 'metal', el2, team: 'player', life: 1.8,
          kind: 'shard', color: col, color2: elColor2('metal'), from: p,
        });
      }
      boomAll(100, 0.9);
      for (const e of inR(110)) if (e.st) e.st.stun = { t: 0.6 };
      G.audio.sfx('clang', 0.8, 0.9);
      shake(G, 2);
      break;
    }
    case 'gravity': {
      // SINGULARITY: everything gets dragged into the crush, then the crush lands
      for (const e of inR(150)) {
        const a = angTo(e.x, e.y, x, y);
        e.vx += Math.cos(a) * 460 * scale;
        e.vy += Math.sin(a) * 460 * scale;
      }
      const z = spawnZone(G, { kind: 'field', x, y, r: 110, dur: 3.2, el: 'gravity', team: 'player', dmg: dmg * 0.22, tick: 0.3 });
      z.potency = 3;
      boomAll(115, 0.8);
      for (const e of inR(120)) if (e.st) e.st.stun = { t: 0.9 };
      addText(G, x, y - 20, 'COLLAPSE', elColor('gravity'), 6, true);
      break;
    }
    case 'sound': {
      // THE LAST CHORD: three staggered echoes erupt outward
      G.audio.sfx('thunder', 1.5, 0.7);
      for (let i = 0; i < 3; i++) {
        addRing(G, x, y, 6 + i * 8, 300 - i * 60, i % 2 ? elColor2('sound') : col, 0.45 + i * 0.12, 2.5);
      }
      boomAll(120, 0.9);
      for (const e of inR(130)) {
        if (e.st) e.st.stun = { t: 1.1 };
        const a = angTo(x, y, e.x, e.y);
        e.vx += Math.cos(a) * 300; e.vy += Math.sin(a) * 300;
      }
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * TAU;
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 300, vy: Math.sin(a) * 300,
          r: 3, dmg: dmg * 0.35 * scale, el: 'sound', el2, team: 'player', life: 0.6,
          kind: 'wave', pierce: 99, color: col, color2: elColor2('sound'), from: p,
        });
      }
      break;
    }
    case 'bone': {
      // OSSUARY ERUPTION: grave spikes + wardens rise from any corpse in range
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU + randR(-0.08, 0.08);
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 230, vy: Math.sin(a) * 230,
          r: 3, dmg: dmg * 0.42 * scale, el: 'bone', el2, team: 'player', life: 1.4,
          kind: 'shard', homing: 1.6, color: col, color2: elColor2('bone'), from: p,
        });
      }
      boomAll(105, 0.75);
      for (const e of inR(110)) if (e.st) e.st.amp = { t: 4, mult: 1.15 };
      let raised = 0;
      for (const c of G.corpses) {
        if (c.used || raised >= 2) continue;
        if (dist(c.x, c.y, x, y) < 120) {
          c.used = true;
          createMinion(G, 'bone', c.x, c.y, (G.prog.schools.bone?.lvl ?? 1) + (G.prog.spells[def_id_of(G, 'bone', 'ritual')]?.lvl ?? 1), 6);
          raised++;
        }
      }
      break;
    }
    case 'beast': {
      // THE GREAT HUNT: the pack answers, everyone is marked
      const power = (G.prog.schools.beast?.lvl ?? 1) + (G.prog.spells[def_id_of(G, 'beast', 'ritual')]?.lvl ?? 1);
      let summoned = 0;
      for (let i = 0; i < 2; i++) if (createMinion(G, 'beast', p.x + randR(-14, 14), p.y + randR(-14, 14), power, 4)) summoned++;
      for (const e of inR(130)) {
        e.st.packMark = { n: 3, t: 5 }; // marked: next hit (or the hunt itself) lunges
        if (e.st) e.st.amp = { t: 4, mult: 1.2 };
      }
      boomAll(115, 0.6);
      p.buffHaste = Math.max(p.buffHaste, 3);
      addText(G, p.x, p.y - 16, summoned ? 'THE PACK ANSWERS' : 'THE HUNT IS ON', elColor2('beast'), 5, true);
      break;
    }
    case 'plasma': {
      // STELLAR INCINERATION: fire and lightning become one star
      explosion(G, x, y, 120, dmg * scale, 'plasma', 'player', { el2 });
      for (const e of inR(120)) {
        applyElement(G, e, 'fire', 1.2, 'player');
        if (e.st) e.st.stun = { t: 0.7 };
      }
      spawnZone(G, { kind: 'field', x, y, r: 62, dur: 4, el: 'fire', team: 'player', dmg: dmg * 0.22, tick: 0.4 });
      for (let i = 0; i < 10; i++) {
        const a = rand(0, TAU);
        makeBullet(G, {
          x, y, vx: Math.cos(a) * 260, vy: Math.sin(a) * 260,
          r: 3, dmg: dmg * 0.38 * scale, el: 'plasma', el2, team: 'player', life: 1.2,
          kind: 'orb', homing: 2.6, color: col, color2: elColor2('plasma'), trail: 0.6, from: p,
        });
      }
      G.audio.sfx('thunder', 0.8, 0.8);
      screenFlash(G, elColor2('plasma'), 0.2);
      break;
    }
    case 'mirror': {
      // HALL OF MIRRORS: the spell attacks from everywhere at once
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * TAU;
        makeBullet(G, {
          x: p.x + Math.cos(a) * 26, y: p.y + Math.sin(a) * 26,
          vx: Math.cos(a) * 240, vy: Math.sin(a) * 240,
          r: 3.2, dmg: dmg * 0.4 * scale, el: 'mirror', el2, team: 'player', life: 1.6,
          kind: 'orb', color: col, color2: elColor2('mirror'), trail: 0.35, from: p,
        });
      }
      boomAll(105, 0.7);
      addRing(G, p.x, p.y, 6, 220, elColor2('mirror'), 0.4, 2);
      G.audio.sfx('prism', 0.7, 0.9);
      break;
    }
    case 'chaos': {
      const groups: ElementId[][] = [
        ['fire', 'frost', 'lightning'], ['void', 'blood', 'earth'],
        ['shadow', 'radiant', 'wind'], ['nature', 'water', 'death'],
        ['crystal', 'metal', 'arcane'],
        ['gravity', 'sound', 'bone'], ['beast', 'plasma', 'mirror'],
      ];
      for (const e2 of pick(groups)) ritualEffect(G, e2, x, y, dmg * 0.7, null, scale);
      break;
    }
  }
  // void / gravity zone pull (also handles newly spawned ones)
  for (const z of G.zones) {
    if (z.kind === 'field' && (z.el === 'void' || z.el === 'gravity') && !z.dead) {
      for (const e of G.enemies) {
        if (e.dead) continue;
        const d = dist(e.x, e.y, z.x, z.y);
        if (d < z.r + 60 && d > 6) {
          const a = angTo(e.x, e.y, z.x, z.y);
          e.vx += Math.cos(a) * 260 * z.potency * 0.016;
          e.vy += Math.sin(a) * 260 * z.potency * 0.016;
        }
      }
    }
  }
}

// helpers to fetch base ritual defs for mana refunds / minion power
function def_of(G: GameCtx, el: ElementId, form: 'ritual'): SpellDef {
  void G;
  return baseSpellDef(el, form);
}
function def_id_of(G: GameCtx, el: ElementId, form: 'ritual'): string {
  void G;
  return `${el}.${form}`;
}

// wire wild-magic rituals (fx.ts chaos hits) through the hook
registerRitualHandler((G, el, x, y, dmg, scale) => ritualEffect(G, el, x, y, dmg, null, scale));
