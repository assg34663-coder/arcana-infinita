/* ============================================================
   arenas.ts — REAL BOSS ARENAS (this round's headline fix).
   Every boss no longer fights you "in a circle of stone on the
   ground": each of the eight bosses owns an actual walled arena
   carved into the Weald — themed flagstone mosaics, a solid
   pseudo-3D wall ring with corner towers, an entrance arch,
   flanking banners, braziers that ignite when the fight starts,
   and an energy barrier that seals the gate while the boss
   lives. Statue rematches TELEPORT you into the arena itself.

   Geometry lives here as PURE functions so world.ts (which
   carves the solid wall tiles + floor mosaics during chunk
   generation) and the draw code below always agree.

   Exports:
     ARENA_NAMES                 display name per bossId
     arenaDims(bossId)           { rf, rw, gapHalf }
     arenaGapAngle(x, y)         entrance faces the map origin
     ringWallTiles(cx,cy,rw,gapA,gapHalf)  canonical wall tiles
     angDiff(a, b)               smallest angular distance
     initArenas()                build runtime arena list
     arenaForBoss(bossId)        runtime arena (or null)
     arenaAt(x, y)               arena containing a point
     updateArenas(G, dt)         approach banners + brazier life
     arenaDrawItems(G)           y-sortable structure draw list
     drawGateBarrier(G)          shimmering seal across the gap
   ============================================================ */
import { TAU, dist, randR, hash2, chance, type GameCtx } from './core';
import { getLocations } from './world';
import { ARENA_KITS, elColor, SPR } from './sprites';
import { spawnParticle, shake } from './fx';
import { BOSS_DEFS } from './bosses';

type C2D = CanvasRenderingContext2D;

// ---------- pure geometry ----------
export function angDiff(a: number, b: number): number {
  let d = Math.abs(a - b) % TAU;
  if (d > Math.PI) d = TAU - d;
  return d;
}

export const ARENA_NAMES: Record<string, string> = {
  ashen: 'The Ashfall Colosseum',
  frost: 'Rimecrown Cathedral',
  hollow: 'The Bone Court',
  storm: 'The Stormspire Ring',
  maw: 'The Verdant Pit',
  tide: 'The Drowned Ring',
  aeon: 'The Clockwork Proving Grounds',
  void: 'The Unnameable Rift',
};

export function arenaDims(_bossId: string): { rf: number; rw: number; gapHalf: number } {
  // rf: walkable floor radius — rw: wall-ring radius — gapHalf: entrance half-angle
  return { rf: 168, rw: 192, gapHalf: 0.2 };
}

export function arenaGapAngle(x: number, y: number): number {
  // the entrance always faces back toward the heart of the Weald
  return Math.atan2(-y, -x);
}

/** Canonical wall-ring tiles — world.ts carves these SOLID, we draw them. */
export function ringWallTiles(cx: number, cy: number, rw: number, gapA: number, gapHalf: number): Array<{ tx: number; ty: number }> {
  const n = Math.max(28, Math.round((TAU * rw) / 14));
  const seen = new Set<string>();
  const out: Array<{ tx: number; ty: number }> = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU;
    if (angDiff(a, gapA) < gapHalf) continue;
    const px = cx + Math.cos(a) * rw;
    const py = cy + Math.sin(a) * rw;
    const tx = Math.floor(px / 16);
    const ty = Math.floor(py / 16);
    const key = `${tx},${ty}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ tx, ty });
  }
  return out;
}

// ---------- runtime state ----------
export interface Arena {
  locId: string;
  bossId: string;
  name: string;
  x: number;
  y: number;
  rf: number;
  rw: number;
  gapA: number;
  gapHalf: number;
  walls: Array<{ x: number; y: number }>; // px centers of wall tiles
  towers: Array<{ x: number; y: number }>;
  braziers: Array<{ x: number; y: number }>;
  banners: Array<{ x: number; y: number }>;
  props: Array<{ x: number; y: number; spr: string; flip: boolean }>;
}

const ARENAS: Arena[] = [];
const approached = new Set<string>();

export function initArenas(): void {
  ARENAS.length = 0;
  approached.clear();
  for (const loc of getLocations()) {
    if (loc.kind !== 'boss' || !loc.bossId) continue;
    const dims = arenaDims(loc.bossId);
    const gapA = arenaGapAngle(loc.x, loc.y);
    const ar: Arena = {
      locId: loc.id,
      bossId: loc.bossId,
      name: ARENA_NAMES[loc.bossId] ?? loc.name,
      x: loc.x, y: loc.y,
      rf: dims.rf, rw: dims.rw, gapA, gapHalf: dims.gapHalf,
      walls: [], towers: [], braziers: [], banners: [], props: [],
    };
    // walls — mirror of the carved solid tiles
    for (const w of ringWallTiles(loc.x, loc.y, dims.rw, gapA, dims.gapHalf)) {
      ar.walls.push({ x: w.tx * 16 + 8, y: w.ty * 16 + 8 });
    }
    // four corner towers, offset from the entrance
    for (const off of [Math.PI * 0.42, Math.PI * 0.58, Math.PI * 1.42, Math.PI * 1.58]) {
      const a = gapA + off;
      ar.towers.push({ x: loc.x + Math.cos(a) * (dims.rw + 4), y: loc.y + Math.sin(a) * (dims.rw + 4) });
    }
    // braziers: inner quartet + entrance pair
    for (const off of [Math.PI * 0.5, Math.PI, Math.PI * 1.5, 0]) {
      const a = gapA + off;
      ar.braziers.push({ x: loc.x + Math.cos(a) * dims.rf * 0.78, y: loc.y + Math.sin(a) * dims.rf * 0.78 });
    }
    for (const off of [-0.3, 0.3]) {
      const a = gapA + off;
      ar.braziers.push({ x: loc.x + Math.cos(a) * (dims.rw + 26), y: loc.y + Math.sin(a) * (dims.rw + 26) });
    }
    // banners: flanking the arch + two deep at the back
    for (const off of [-0.26, 0.26]) {
      const a = gapA + off;
      ar.banners.push({ x: loc.x + Math.cos(a) * (dims.rw + 14), y: loc.y + Math.sin(a) * (dims.rw + 14) });
    }
    for (const off of [-0.5, 0.5]) {
      const a = gapA + Math.PI + off;
      ar.banners.push({ x: loc.x + Math.cos(a) * (dims.rw - 16), y: loc.y + Math.sin(a) * (dims.rw - 16) });
    }
    // centerpiece props (non-solid — the fight floor stays fluid)
    const backA = gapA + Math.PI;
    const bx = loc.x + Math.cos(backA) * dims.rf * 0.6;
    const by = loc.y + Math.sin(backA) * dims.rf * 0.6;
    const seed = Math.floor(loc.x) + Math.floor(loc.y);
    const jitter = () => (hash2(seed, 7, 3) - 0.5) * 26;
    const clusters: Record<string, string[]> = {
      ashen: ['skullpile', 'bones', 'lavarock', 'bones'],
      frost: ['icespike', 'icespike', 'icespike'],
      hollow: ['altar', 'skullpile', 'bones'],
      storm: ['obelisk', 'pillar'],
      maw: ['mushroom_big', 'mushroom_big', 'tree'],
      tide: ['spring', 'pillar'],
      aeon: ['obelisk', 'pillar', 'pillar'],
      void: ['crystal', 'crystal', 'crystal'],
    };
    const cl = clusters[loc.bossId] ?? ['pillar'];
    cl.forEach((spr, i) => {
      const a = backA + (i - (cl.length - 1) / 2) * 0.24;
      ar.props.push({
        x: bx + Math.cos(a) * 22 + jitter(),
        y: by + Math.sin(a) * 16 + jitter() * 0.6,
        spr,
        flip: chance(0.5),
      });
    });
    ARENAS.push(ar);
  }
}

export function arenaForBoss(bossId: string): Arena | null {
  return ARENAS.find((a) => a.bossId === bossId) ?? null;
}

export function arenaAt(x: number, y: number): Arena | null {
  for (const a of ARENAS) {
    if (Math.hypot(x - a.x, y - a.y) < a.rw + 26) return a;
  }
  return null;
}

/** true when the arena's boss is being fought (or about to be) right here */
function fightLive(G: GameCtx, ar: Arena): boolean {
  if (G.gate && dist(G.gate.x, G.gate.y, ar.x, ar.y) < 6) return true;
  if (G.boss && !G.boss.dead && dist(G.boss.x, G.boss.y, ar.x, ar.y) < ar.rw + 40) return true;
  return false;
}

// ---------- update ----------
export function updateArenas(G: GameCtx, dt: number): void {
  const p = G.player;
  for (const ar of ARENAS) {
    const d = dist(p.x, p.y, ar.x, ar.y);
    // approach dread: first time you near an unclaimed arena
    if (d < ar.rf + 150 && !approached.has(ar.locId) && !G.prog.bosses.includes(ar.bossId) && !G.boss && G.mode === 'play') {
      approached.add(ar.locId);
      const el = BOSS_DEFS[ar.bossId]?.el ?? 'fire';
      G.toasts.push({ text: `${ar.name} — something vast stirs within.`, t: 0, color: elColor(el) });
      G.audio.sfx('roar', 0.4, 0.55);
      shake(G, 2);
    }
    // brazier life + occasional spark when the fight is on
    if (d < 620 && fightLive(G, ar)) {
      const el = ar.bossId;
      const col = BRAZIER_COL[el] ?? '#ff9e4e';
      for (const b of ar.braziers) {
        if (Math.abs(b.x - G.cam.x) > G.W / 2 + 24 || Math.abs(b.y - G.cam.y) > G.H / 2 + 24) continue;
        if ((G.frame + Math.floor(b.x)) % 5 === 0) {
          spawnParticle(G, {
            x: b.x + randR(-2, 2), y: b.y - 10,
            vx: randR(-7, 7), vy: randR(-34, -18),
            life: randR(0.3, 0.7), size: randR(1.2, 2.2),
            color: chance(0.4) ? '#ffd75e' : col, glow: true,
          });
        }
      }
    }
  }
  void dt;
}

const BRAZIER_COL: Record<string, string> = {
  ashen: '#ff7a3e', frost: '#9edbe8', hollow: '#b8e8ff', storm: '#fff45e',
  maw: '#a8e06a', tide: '#8ad4de', aeon: '#5ee8d8', void: '#e85eff',
};

// ---------- drawing ----------
function drawShadow(G: GameCtx, x: number, y: number, w: number): void {
  const c = G.ctx;
  c.globalAlpha = 0.28;
  c.fillStyle = '#000';
  c.beginPath();
  c.ellipse(x, y + 1, w, 2.4, 0, 0, TAU);
  c.fill();
  c.globalAlpha = 1;
}

function drawSprAt(G: GameCtx, spr: HTMLCanvasElement, x: number, y: number, sink = 2): void {
  G.ctx.drawImage(spr, Math.round(x - spr.width / 2), Math.round(y - spr.height + sink));
}

function arenaLit(G: GameCtx, ar: Arena): boolean {
  return fightLive(G, ar) || G.prog.discovered.includes(ar.locId);
}

export function arenaDrawItems(G: GameCtx): Array<{ y: number; f: () => void }> {
  const out: Array<{ y: number; f: () => void }> = [];
  for (const ar of ARENAS) {
    if (Math.abs(ar.x - G.cam.x) > G.W / 2 + ar.rw + 80 || Math.abs(ar.y - G.cam.y) > G.H / 2 + ar.rw + 80) continue;
    const kit = ARENA_KITS[ar.bossId];
    if (!kit) continue;
    const lit = arenaLit(G, ar);
    const el = BRAZIER_COL[ar.bossId] ?? '#ff9e4e';
    for (const w of ar.walls) {
      if (Math.abs(w.x - G.cam.x) > G.W / 2 + 32 || Math.abs(w.y - G.cam.y) > G.H / 2 + 56) continue;
      out.push({ y: w.y + 7, f: () => drawSprAt(G, kit.wall, w.x, w.y + 8, 6) });
    }
    for (const t of ar.towers) {
      if (Math.abs(t.x - G.cam.x) > G.W / 2 + 48 || Math.abs(t.y - G.cam.y) > G.H / 2 + 80) continue;
      out.push({
        y: t.y + 7, f: () => {
          drawShadow(G, t.x, t.y + 2, 12);
          drawSprAt(G, kit.tower, t.x, t.y + 8, 6);
          // tower window glow when lit
          if (lit) {
            const c = G.ctx;
            c.save();
            c.globalCompositeOperation = 'lighter';
            c.globalAlpha = 0.35 + 0.2 * Math.sin(G.time * 3.4 + t.x * 0.13);
            c.fillStyle = el;
            c.fillRect(Math.round(t.x - 2), Math.round(t.y - 14), 4, 5);
            c.restore();
          }
        },
      });
    }
    for (const b of ar.braziers) {
      if (Math.abs(b.x - G.cam.x) > G.W / 2 + 24 || Math.abs(b.y - G.cam.y) > G.H / 2 + 40) continue;
      out.push({
        y: b.y + 4, f: () => {
          drawShadow(G, b.x, b.y + 2, 6);
          drawSprAt(G, kit.brazier, b.x, b.y + 6, 2);
          if (lit) {
            // brazier fire — flickering double flame
            const c = G.ctx;
            const fx = Math.sin(G.time * 13 + b.x * 0.7) * 1.2;
            const fy = Math.sin(G.time * 17 + b.y * 0.5) * 1.1;
            c.save();
            c.globalCompositeOperation = 'lighter';
            c.globalAlpha = 0.75;
            c.fillStyle = el;
            c.beginPath(); c.ellipse(b.x + fx * 0.4, b.y - 11 + fy * 0.3, 3.1, 4.6, 0, 0, TAU); c.fill();
            c.globalAlpha = 0.9;
            c.fillStyle = '#ffd75e';
            c.beginPath(); c.ellipse(b.x + fx * 0.5, b.y - 10 + fy * 0.4, 1.5, 2.6, 0, 0, TAU); c.fill();
            c.restore();
          } else {
            // dormant ember
            const c = G.ctx;
            c.globalAlpha = 0.4 + 0.2 * Math.sin(G.time * 2 + b.x);
            c.fillStyle = '#8a4a2e';
            c.fillRect(Math.round(b.x - 2), Math.round(b.y - 11), 4, 2);
            c.globalAlpha = 1;
          }
        },
      });
    }
    for (let i = 0; i < ar.banners.length; i++) {
      const b = ar.banners[i];
      if (Math.abs(b.x - G.cam.x) > G.W / 2 + 24 || Math.abs(b.y - G.cam.y) > G.H / 2 + 44) continue;
      out.push({
        y: b.y + 4, f: () => {
          drawShadow(G, b.x, b.y + 2, 5);
          const frame = Math.floor(G.time * 2.6 + i * 1.7) % 2;
          drawSprAt(G, frame === 0 ? kit.banner0 : kit.banner1, b.x, b.y + 6, 2);
        },
      });
    }
    for (const pr of ar.props) {
      const spr = SPR[pr.spr];
      if (!spr) continue;
      if (Math.abs(pr.x - G.cam.x) > G.W / 2 + 24 || Math.abs(pr.y - G.cam.y) > G.H / 2 + 40) continue;
      out.push({
        y: pr.y, f: () => {
          drawShadow(G, pr.x, pr.y + 1, spr.width * 0.3);
          if (pr.flip) {
            const c = G.ctx;
            c.save();
            c.translate(Math.round(pr.x), Math.round(pr.y));
            c.scale(-1, 1);
            c.drawImage(spr, -spr.width / 2, -spr.height + 2);
            c.restore();
          } else {
            drawSprAt(G, spr, pr.x, pr.y, 2);
          }
        },
      });
    }
    // entrance arch — one wide sprite over the gap
    const ax = ar.x + Math.cos(ar.gapA) * (ar.rw + 12);
    const ay = ar.y + Math.sin(ar.gapA) * (ar.rw + 12);
    if (Math.abs(ax - G.cam.x) < G.W / 2 + 80 && Math.abs(ay - G.cam.y) < G.H / 2 + 80) {
      out.push({
        y: ay + 10, f: () => {
          drawSprAt(G, kit.arch, ax, ay + 12, 6);
        },
      });
    }
  }
  return out;
}

/** Shimmering elemental veil across the entrance while the boss lives. */
export function drawGateBarrier(G: GameCtx): void {
  if (!G.gate) return;
  const ar = ARENAS.find((a) => dist(a.x, a.y, G.gate!.x, G.gate!.y) < 8);
  if (!ar) return;
  const ctx = G.ctx;
  const col = BRAZIER_COL[ar.bossId] ?? '#e2552e';
  const a0 = ar.gapA - ar.gapHalf;
  const a1 = ar.gapA + ar.gapHalf;
  const pulse = 0.16 + 0.07 * Math.sin(G.time * 5.2);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  // the veil
  ctx.globalAlpha = pulse;
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.arc(ar.x, ar.y, ar.rw + 10, a0, a1);
  ctx.arc(ar.x, ar.y, ar.rw - 16, a1, a0, true);
  ctx.closePath();
  ctx.fill();
  // rim arcs
  ctx.globalAlpha = 0.5;
  ctx.strokeStyle = col;
  ctx.lineWidth = 1;
  for (const rr of [ar.rw + 10, ar.rw - 16]) {
    ctx.beginPath();
    ctx.arc(ar.x, ar.y, rr, a0, a1);
    ctx.stroke();
  }
  // rising sigil sparks across the gap
  const n = 9;
  for (let i = 0; i < n; i++) {
    const t = (i / (n - 1)) * 2 - 1;
    const a = ar.gapA + t * ar.gapHalf * 0.9;
    const rr = ar.rw - 4 + Math.sin(G.time * 2.4 + i * 1.9) * 7;
    const x = ar.x + Math.cos(a) * rr;
    const y = ar.y + Math.sin(a) * rr;
    ctx.globalAlpha = 0.4 + 0.35 * Math.sin(G.time * 7 + i * 2.4);
    ctx.fillStyle = i % 2 ? '#ffffff' : col;
    ctx.fillRect(x - 1, y - 1, 2, 2);
  }
  ctx.restore();
  // the gate bites back: ember spray near the player when they push it
  if (G.frame % 9 === 0 && dist(G.player.x, G.player.y, ar.x, ar.y) > ar.rw - 30) {
    const a = Math.atan2(G.player.y - ar.y, G.player.x - ar.x);
    spawnParticle(G, {
      x: ar.x + Math.cos(a) * (ar.rw - 6) + randR(-6, 6),
      y: ar.y + Math.sin(a) * (ar.rw - 6) + randR(-6, 6),
      vx: randR(-10, 10), vy: randR(-24, -10),
      life: 0.5, size: 1.6, color: col, glow: true,
    });
  }
}
