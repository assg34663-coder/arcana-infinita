/* ============================================================
   audio.ts — procedural WebAudio SFX + REAL MUSIC SYSTEM.
   "Motif de Lumière" = main looping OST (world + title).
   "Pixel Boss Battle" = boss fights. Music is quiet background
   sound; it MUFFLES (low-pass + slight fade) while any menu is
   open — never silent, just out of your ears' way.
   ============================================================ */
import type { AudioSys, MusicTrack } from './core';

// Standalone (.html) builds inject `window.__ARCANA_AUDIO__` — a map of
// track name -> base64 data URL — so the single file stays self-contained.
// The hosted build simply leaves it undefined and uses the file paths below.
export type InlineAudioMap = Partial<Record<MusicTrack, string>>;
declare global {
  interface Window {
    __ARCANA_AUDIO__?: InlineAudioMap;
    __ARCANA_STANDALONE__?: boolean;
  }
}

// bg track volumes: music should sit well below the SFX layer
const MUSIC_BASE = 0.30;   // music bus level (0..1)
const MUFFLE_MUL = 0.55;   // gain multiplier while muffled
const MUFFLE_HZ = 800;     // low-pass cutoff while muffled
const OPEN_HZ = 16000;     // low-pass cutoff while open

// file paths used by the hosted (Next.js public/) build
const TRACK_SRC: Record<Exclude<MusicTrack, 'none'>, string> = {
  world: '/audio/motif-de-lumiere.mp3',
  boss: '/audio/pixel-boss-battle.mp3',
  miniboss: '/audio/arachnes-web.mp3',
};

export function createAudio(): AudioSys {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  let musicBus: GainNode | null = null;
  let musicFilter: BiquadFilterNode | null = null;
  let muted = false;
  let musicStarted = false;
  let curTrack: MusicTrack = 'none';
  let muffled = false;

  // HTML audio elements + their WebAudio gain nodes
  const els: Partial<Record<MusicTrack, HTMLAudioElement>> = {};
  const gains: Partial<Record<MusicTrack, GainNode>> = {};

  function ensure(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.5;
      master.connect(ctx.destination);
      musicFilter = ctx.createBiquadFilter();
      musicFilter.type = 'lowpass';
      musicFilter.frequency.value = OPEN_HZ;
      musicFilter.Q.value = 0.4;
      musicBus = ctx.createGain();
      musicBus.gain.value = MUSIC_BASE;
      musicBus.connect(musicFilter);
      musicFilter.connect(master);
    }
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  }

  // ------ music ------
  function startMusic(): void {
    const c = ensure();
    if (!c || !musicBus || musicStarted) return;
    musicStarted = true;
    const mk = (track: MusicTrack, src: string, loop: boolean): void => {
      try {
        const el = new Audio(src);
        el.loop = loop;
        el.preload = 'auto';
        (el as HTMLAudioElement & { crossOrigin?: string }).crossOrigin = 'anonymous';
        const node = c.createMediaElementSource(el);
        const g = c.createGain();
        g.gain.value = track === 'world' ? 1 : 0;
        node.connect(g);
        g.connect(musicBus!);
        els[track] = el;
        gains[track] = g;
      } catch { /* audio unavailable */ }
    };
    const inline = typeof window !== 'undefined' ? window.__ARCANA_AUDIO__ : undefined;
    const tracks: Exclude<MusicTrack, 'none'>[] = ['world', 'boss', 'miniboss'];
    for (const t of tracks) {
      mk(t, inline?.[t] || TRACK_SRC[t], true);
    }
    // begin playing whichever track is current (world by default)
    for (const t of ['world', 'boss', 'miniboss'] as MusicTrack[]) {
      const el = els[t];
      if (el) el.play().catch(() => { /* waits for next gesture */ });
    }
  }

  function setTrack(t: MusicTrack): void {
    if (t === curTrack) return;
    const prev = curTrack;
    curTrack = t;
    const c = ctx;
    if (!c) return;
    for (const key of ['world', 'boss', 'miniboss'] as MusicTrack[]) {
      const g = gains[key];
      const el = els[key];
      if (!g || !el) continue;
      const want = key === t ? 1 : 0;
      try {
        g.gain.cancelScheduledValues(c.currentTime);
        g.gain.setTargetAtTime(want, c.currentTime, 0.5);
      } catch { /* ignore */ }
      if (want > 0 && el.paused) el.play().catch(() => { /* needs gesture */ });
      if (want === 0 && prev === key) {
        // let the old track fade fully, then pause it to save cycles
        window.setTimeout(() => {
          if (els[key] && curTrack !== key) { els[key]!.pause(); els[key]!.currentTime = 0; }
        }, 1600);
      }
    }
  }

  function setMuffled(m: boolean): void {
    if (m === muffled || !ctx || !musicFilter || !musicBus) return;
    muffled = m;
    try {
      const t = ctx.currentTime;
      musicFilter.frequency.setTargetAtTime(m ? MUFFLE_HZ : OPEN_HZ, t, 0.22);
      musicBus.gain.setTargetAtTime(MUSIC_BASE * (m ? MUFFLE_MUL : 1), t, 0.22);
    } catch { /* ignore */ }
  }

  window.addEventListener('pointerdown', () => { ensure(); startMusic(); }, { once: true });
  window.addEventListener('keydown', () => { ensure(); startMusic(); }, { once: true });

  // ------ primitive voices ------
  function tone(f0: number, f1: number, dur: number, type: OscillatorType, vol: number, delay = 0) {
    const c = ensure(); if (!c || !master) return;
    const t0 = c.currentTime + delay;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(20, f0), t0);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(master);
    o.start(t0); o.stop(t0 + dur + 0.05);
  }

  function noise(dur: number, vol: number, filterFreq: number, delay = 0, q = 1) {
    const c = ensure(); if (!c || !master) return;
    const t0 = c.currentTime + delay;
    const len = Math.max(1, Math.floor(c.sampleRate * dur));
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = c.createBufferSource();
    src.buffer = buf;
    const f = c.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = filterFreq; f.Q.value = q;
    const g = c.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t0);
  }

  // ------ sfx table ------
  function sfx(name: string, pitch = 1, vol = 1) {
    if (muted) return;
    try {
      switch (name) {
        case 'cast': {
          tone(660 * pitch, 220 * pitch, 0.18, 'sawtooth', 0.10 * vol);
          tone(990 * pitch, 330 * pitch, 0.12, 'sine', 0.08 * vol);
          break;
        }
        case 'castBig': {
          tone(220 * pitch, 60 * pitch, 0.4, 'sawtooth', 0.14 * vol);
          noise(0.3, 0.12 * vol, 900);
          break;
        }
        case 'hit': {
          noise(0.08, 0.16 * vol, 2400);
          tone(300 * pitch, 120 * pitch, 0.07, 'square', 0.06 * vol);
          break;
        }
        case 'boom': {
          noise(0.5, 0.28 * vol, 700);
          tone(120 * pitch, 40 * pitch, 0.4, 'sine', 0.2 * vol);
          break;
        }
        case 'parry': {
          tone(1760 * pitch, 2200 * pitch, 0.09, 'square', 0.12 * vol);
          tone(2637 * pitch, 3200 * pitch, 0.22, 'sine', 0.09 * vol, 0.02);
          noise(0.06, 0.08 * vol, 6000);
          break;
        }
        case 'dodge': {
          noise(0.16, 0.10 * vol, 1600);
          tone(500, 180, 0.14, 'sine', 0.05 * vol);
          break;
        }
        case 'melee': {
          noise(0.06, 0.10 * vol, 3000);
          tone(220, 90, 0.08, 'square', 0.06 * vol);
          break;
        }
        case 'hurt': {
          tone(220 * pitch, 90, 0.2, 'sawtooth', 0.16 * vol);
          noise(0.12, 0.14 * vol, 1200);
          break;
        }
        case 'die': {
          tone(300, 40, 0.9, 'sawtooth', 0.2 * vol);
          noise(0.7, 0.2 * vol, 500);
          break;
        }
        case 'potion': {
          tone(500, 900, 0.12, 'sine', 0.10 * vol);
          tone(700, 1300, 0.14, 'sine', 0.08 * vol, 0.08);
          break;
        }
        case 'pickup': {
          tone(880 * pitch, 1320 * pitch, 0.08, 'sine', 0.07 * vol);
          break;
        }
        case 'aether': {
          tone(1200 * pitch, 1800 * pitch, 0.1, 'triangle', 0.06 * vol);
          break;
        }
        case 'levelup': {
          [523, 659, 784, 1046].forEach((f, i) => tone(f, f * 1.01, 0.16, 'square', 0.08 * vol, i * 0.09));
          break;
        }
        case 'unlock': {
          [784, 988, 1175].forEach((f, i) => tone(f, f, 0.2, 'triangle', 0.08 * vol, i * 0.11));
          break;
        }
        case 'shrine': {
          [392, 523, 659, 784].forEach((f, i) => tone(f, f, 0.5, 'sine', 0.07 * vol, i * 0.16));
          break;
        }
        case 'ui': {
          tone(700, 900, 0.05, 'square', 0.05 * vol);
          break;
        }
        case 'roar': {
          tone(90 * pitch, 35 * pitch, 1.1, 'sawtooth', 0.24 * vol);
          noise(1.0, 0.22 * vol, 400);
          tone(180 * pitch, 60 * pitch, 0.9, 'square', 0.1 * vol, 0.1);
          break;
        }
        case 'stagger': {
          tone(400, 100, 0.5, 'square', 0.14 * vol);
          noise(0.3, 0.12 * vol, 2000);
          break;
        }
        case 'summon': {
          tone(200, 600, 0.3, 'triangle', 0.09 * vol);
          noise(0.25, 0.07 * vol, 900);
          break;
        }
        case 'blink': {
          tone(900, 200, 0.16, 'sine', 0.09 * vol);
          noise(0.1, 0.06 * vol, 4000);
          break;
        }
        case 'heal': {
          [660, 880, 1100].forEach((f, i) => tone(f, f * 1.05, 0.25, 'sine', 0.06 * vol, i * 0.07));
          break;
        }
        case 'thunder': {
          noise(0.7, 0.3 * vol, 2400);
          tone(80, 30, 0.6, 'sawtooth', 0.16 * vol);
          break;
        }
        case 'zap': {
          tone(1400 * pitch, 300 * pitch, 0.12, 'sawtooth', 0.09 * vol);
          noise(0.08, 0.08 * vol, 5000);
          break;
        }
        case 'reflect': {
          // gleaming counter-strike zing
          tone(1200 * pitch, 2400 * pitch, 0.1, 'square', 0.1 * vol);
          tone(2400 * pitch, 3600 * pitch, 0.18, 'sine', 0.08 * vol, 0.03);
          noise(0.05, 0.08 * vol, 7000);
          break;
        }
        case 'combo': {
          tone(700 * pitch, 1050 * pitch, 0.09, 'square', 0.07 * vol);
          tone(1050 * pitch, 1400 * pitch, 0.12, 'sine', 0.05 * vol, 0.05);
          break;
        }
        case 'overdrive': {
          tone(180, 900, 0.5, 'sawtooth', 0.14 * vol);
          tone(360, 1800, 0.55, 'square', 0.07 * vol, 0.05);
          noise(0.4, 0.1 * vol, 3000);
          break;
        }
        case 'quest': {
          [659, 784, 988].forEach((f, i) => tone(f, f * 1.02, 0.18, 'triangle', 0.08 * vol, i * 0.1));
          break;
        }
        case 'frozen': {
          tone(2000 * pitch, 3200 * pitch, 0.12, 'sine', 0.07 * vol);
          noise(0.1, 0.06 * vol, 8000);
          break;
        }
        case 'clang': {
          // metal: ringing steel
          tone(880 * pitch, 860 * pitch, 0.18, 'triangle', 0.09 * vol);
          tone(1320 * pitch, 1280 * pitch, 0.24, 'sine', 0.06 * vol, 0.01);
          noise(0.05, 0.07 * vol, 6000);
          break;
        }
        case 'prism': {
          // crystal: glassy refraction
          tone(1900 * pitch, 2500 * pitch, 0.1, 'sine', 0.07 * vol);
          tone(2540 * pitch, 3300 * pitch, 0.14, 'triangle', 0.05 * vol, 0.02);
          break;
        }
        case 'grand': {
          // a GRAND CASTING opens: deep boom + rising choir-ish stack
          tone(90 * pitch, 42 * pitch, 0.9, 'sawtooth', 0.2 * vol);
          tone(180 * pitch, 340 * pitch, 0.7, 'triangle', 0.1 * vol, 0.06);
          tone(523 * pitch, 523 * pitch, 0.5, 'sine', 0.06 * vol, 0.12);
          tone(784 * pitch, 784 * pitch, 0.6, 'sine', 0.05 * vol, 0.18);
          noise(0.6, 0.18 * vol, 700);
          break;
        }
        case 'whiff': {
          // the parry that found nothing: dull, hollow, embarrassing
          noise(0.14, 0.06 * vol, 900);
          tone(320 * pitch, 150 * pitch, 0.14, 'sine', 0.05 * vol);
          break;
        }
        case 'graze': {
          // Touhou graze: a tiny glass tick as a bullet parts your hair
          tone(2400 * pitch, 3100 * pitch, 0.05, 'sine', 0.05 * vol);
          tone(4800 * pitch, 5200 * pitch, 0.03, 'sine', 0.025 * vol);
          break;
        }
        case 'skitter': {
          // chitin tick-tick-tick — the Weaver moves
          for (let i = 0; i < 4; i++) {
            noise(0.025, 0.05 * vol, 3600, i * 0.035);
            tone(2100 * pitch + i * 300, 1700 * pitch, 0.03, 'square', 0.02 * vol, i * 0.035);
          }
          break;
        }
        case 'dashBoost': {
          // the dash layer: an airy rising whoosh over the base dodge thump
          tone(420 * pitch, 1150 * pitch, 0.16, 'sawtooth', 0.035 * vol);
          noise(0.16, 0.055 * vol, 2600);
          tone(190 * pitch, 90 * pitch, 0.2, 'sine', 0.05 * vol, 0.02);
          break;
        }
        default: break;
      }
    } catch { /* audio unavailable */ }
  }

  return {
    sfx,
    setMuted(m: boolean) {
      muted = m;
      if (master) master.gain.value = m ? 0 : 0.5;
    },
    isMuted: () => muted,
    setTrack,
    setMuffled,
  };
}
