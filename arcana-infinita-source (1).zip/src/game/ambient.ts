/* ============================================================
   ambient.ts — the Weald breathes (anti-emptiness pass).
   Two systems:

   1. WEATHER / MOTES — biome-driven particle rain: snowfall in
      the tundra, falling leaves in the forest, fireflies in the
      darkwood and swamps, rising embers over volcanic ground,
      purple ash in the wastes, sand streaks in the desert,
      arcane sparkles, pollen in the meadows. Purely visual,
      routed through fx.spawnParticle so they layer above the
      world for free.

   2. CRITTERS — tiny ambient animals that live near the player:
      rabbits in meadows, hares in the tundra, lizards in the
      desert, frogs in swamps, foxes in the forest, drifting
      wisp-larvae in arcane/wastes. They wander, flee from you,
      and despawn — the world never sits still.

   Exports:
     updateAmbient(G, dt)      spawns/updates both systems
     ambientDrawItems(G)       y-sortable critter draw list
   ============================================================ */
import { TAU, dist, randR, chance, type GameCtx, type BiomeId } from './core';
import { spawnParticle } from './fx';

// ---------- critters ----------
interface Critter {
  x: number; y: number; vx: number; vy: number;
  kind: string; anim: number; flip: boolean;
  flee: number; tx: number; ty: number; wait: number;
}

const CRITTER_KINDS: Record<string, { biomes: BiomeId[]; speed: number }> = {
  rabbit: { biomes: ['grass'], speed: 26 },
  fox: { biomes: ['forest'], speed: 32 },
  hare: { biomes: ['tundra'], speed: 30 },
  lizard: { biomes: ['desert', 'beach'], speed: 30 },
  frog: { biomes: ['swamp'], speed: 18 },
  larva: { biomes: ['arcane', 'wastes'], speed: 13 },
  scarab: { biomes: ['volcanic'], speed: 20 },
};

const CRITTERS: Critter[] = [];
let spawnT = 0;

function biomeOf(G: GameCtx): BiomeId {
  return G.world.biomeAt(G.player.x, G.player.y);
}

function tileFree(G: GameCtx, x: number, y: number): boolean {
  const t = G.world.tileAt(x, y);
  if (t === 17 || t === 19 || t === 23) return false; // water / lava / wall
  if (G.world.solidAt(x, y)) return false;
  return true;
}

function spawnCritter(G: GameCtx): void {
  const biome = biomeOf(G);
  const kinds = Object.entries(CRITTER_KINDS).filter(([, k]) => k.biomes.includes(biome));
  if (!kinds.length) return;
  for (let tries = 0; tries < 6; tries++) {
    const a = Math.random() * TAU;
    const d = randR(300, 620);
    const x = G.player.x + Math.cos(a) * d;
    const y = G.player.y + Math.sin(a) * d;
    if (!tileFree(G, x, y)) continue;
    const [kind] = kinds[Math.floor(Math.random() * kinds.length)];
    CRITTERS.push({
      x, y, vx: 0, vy: 0, kind,
      anim: Math.random() * 9, flip: chance(0.5),
      flee: 0, tx: x, ty: y, wait: randR(0.4, 2),
    });
    return;
  }
}

function updateCritters(G: GameCtx, dt: number): void {
  const p = G.player;
  spawnT -= dt;
  if (spawnT <= 0) {
    spawnT = 1.5;
    if (CRITTERS.length < 8) spawnCritter(G);
  }
  for (let i = CRITTERS.length - 1; i >= 0; i--) {
    const c = CRITTERS[i];
    const d = dist(c.x, c.y, p.x, p.y);
    if (d > 900) { CRITTERS.splice(i, 1); continue; }
    // flee!
    if (d < 68 && c.flee <= 0) {
      c.flee = 1.3;
      const a = Math.atan2(c.y - p.y, c.x - p.x) + randR(-0.5, 0.5);
      c.tx = c.x + Math.cos(a) * 190;
      c.ty = c.y + Math.sin(a) * 190;
    }
    c.flee = Math.max(0, c.flee - dt);
    const spec = CRITTER_KINDS[c.kind];
    const speed = spec.speed * (c.flee > 0 ? 2.7 : 0.55);
    const dx = c.tx - c.x, dy = c.ty - c.y;
    const dd = Math.hypot(dx, dy);
    if (dd < 3) {
      c.wait -= dt;
      if (c.wait <= 0) {
        c.wait = randR(0.6, 2.6);
        const a = Math.random() * TAU;
        c.tx = c.x + Math.cos(a) * randR(30, 110);
        c.ty = c.y + Math.sin(a) * randR(30, 110);
      }
      continue;
    }
    const nx = c.x + (dx / dd) * speed * dt;
    const ny = c.y + (dy / dd) * speed * dt;
    if (tileFree(G, nx, ny)) {
      c.x = nx; c.y = ny;
      if (Math.abs(dx) > 0.5) c.flip = dx < 0;
      c.anim += dt * (c.flee > 0 ? 2 : 1);
    } else {
      c.tx = c.x; c.ty = c.y;
    }
  }
}

const CRITTER_PAL: Record<string, { body: string; back: string; eye: string }> = {
  rabbit: { body: '#9a8a78', back: '#b8a896', eye: '#1a1020' },
  fox: { body: '#c97a3e', back: '#e89a5e', eye: '#1a1020' },
  hare: { body: '#e2e8ec', back: '#f8fcfd', eye: '#1a1020' },
  lizard: { body: '#b8a05e', back: '#d0bc7e', eye: '#1a1020' },
  frog: { body: '#6aa84e', back: '#8ac46e', eye: '#1a1020' },
  larva: { body: '#a86ec9', back: '#d09ef2', eye: '#e8c9ff' },
  scarab: { body: '#7a4e3e', back: '#a86e5e', eye: '#ffd75e' },
};

function drawCritter(G: GameCtx, c: Critter): void {
  const ctx = G.ctx;
  const x = Math.round(c.x), y = Math.round(c.y);
  const moving = Math.abs(c.vx) + Math.abs(c.vy) > 0 || c.wait < 2;
  const hop = c.flee > 0 ? (Math.sin(c.anim * 22) > 0 ? -2 : 0) : moving && Math.sin(c.anim * 9) > 0.3 ? -1 : 0;
  if (c.kind === 'larva') {
    // floating arcane larva — a glowing droplet
    const bob = Math.sin(c.anim * 2.4) * 2;
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.globalAlpha = 0.4 + 0.2 * Math.sin(c.anim * 3.1);
    ctx.fillStyle = '#c9a0f2';
    ctx.beginPath(); ctx.arc(x, y - 6 + bob, 4.4, 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = '#f2e0ff';
    ctx.beginPath(); ctx.arc(x, y - 6 + bob, 1.8, 0, TAU); ctx.fill();
    ctx.restore();
    return;
  }
  // shadow
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = '#000';
  ctx.beginPath(); ctx.ellipse(x, y + 1, 4, 1.6, 0, 0, TAU); ctx.fill();
  ctx.globalAlpha = 1;
  const pal = CRITTER_PAL[c.kind] ?? CRITTER_PAL.rabbit;
  const dir = c.flip ? -1 : 1;
  ctx.save();
  ctx.translate(x, y + hop);
  ctx.scale(dir, 1);
  // body + head + ear/tail by kind
  if (c.kind === 'lizard') {
    ctx.fillStyle = pal.body; ctx.fillRect(-3, -3, 5, 2);
    ctx.fillRect(2, -4, 2, 2);
    ctx.fillStyle = pal.back; ctx.fillRect(-2, -3, 3, 1);
    ctx.fillStyle = pal.body; ctx.fillRect(-5, -2, 2, 1); // tail
  } else if (c.kind === 'frog') {
    ctx.fillStyle = pal.body; ctx.fillRect(-2, -3, 4, 2);
    ctx.fillStyle = pal.back; ctx.fillRect(-1, -4, 2, 1);
    ctx.fillStyle = pal.eye;
    ctx.fillRect(-2, -4, 1, 1); ctx.fillRect(1, -4, 1, 1);
  } else if (c.kind === 'scarab') {
    ctx.fillStyle = pal.body; ctx.fillRect(-2, -3, 4, 3);
    ctx.fillStyle = pal.back; ctx.fillRect(-1, -3, 2, 2);
    ctx.fillStyle = pal.eye; ctx.fillRect(1, -2, 1, 1);
  } else {
    // generic hopper: rabbit / fox / hare
    ctx.fillStyle = pal.body; ctx.fillRect(-2, -3, 4, 3);
    ctx.fillStyle = pal.back; ctx.fillRect(1, -4, 2, 2); // head
    ctx.fillStyle = pal.body; ctx.fillRect(1, -6, 1, 2); // ear
    if (c.kind === 'fox') { ctx.fillStyle = '#f2ead0'; ctx.fillRect(-4, -2, 2, 1); } // tail tip
    ctx.fillStyle = pal.eye; ctx.fillRect(2, -3, 1, 1);
  }
  ctx.restore();
}

export function ambientDrawItems(G: GameCtx): Array<{ y: number; f: () => void }> {
  const out: Array<{ y: number; f: () => void }> = [];
  for (const c of CRITTERS) {
    if (Math.abs(c.x - G.cam.x) > G.W / 2 + 24 || Math.abs(c.y - G.cam.y) > G.H / 2 + 32) continue;
    out.push({ y: c.y, f: () => drawCritter(G, c) });
  }
  return out;
}

// ---------- weather / motes ----------
function weather(G: GameCtx): void {
  if (G.parts.length > 640) return;
  const biome = biomeOf(G);
  const W = G.W, H = G.H;
  const cam = G.cam;
  const spawn = (n: number, f: (x: number, y: number) => void): void => {
    for (let i = 0; i < n; i++) {
      const x = cam.x + randR(-0.55, 0.55) * W;
      const y = cam.y + randR(-0.55, 0.55) * H;
      f(x, y);
    }
  };
  switch (biome) {
    case 'tundra':
      if (G.frame % 2 === 0) spawn(2, (x, y) => {
        spawnParticle(G, {
          x, y: y - H * 0.6, vx: randR(-8, 4), vy: randR(16, 30),
          life: randR(1.8, 2.8), size: randR(1.2, 2), color: chance(0.3) ? '#e8f4fa' : '#ffffff',
          shrink: false,
        });
      });
      break;
    case 'forest':
      if (G.frame % 4 === 0) spawn(1, (x, y) => {
        spawnParticle(G, {
          x, y: y - H * 0.6, vx: randR(-14, -2), vy: randR(10, 18),
          life: randR(2.2, 3.2), size: 1.6,
          color: ['#6a9e4a', '#9a8a3e', '#c9a84e'][Math.floor(Math.random() * 3)],
          shrink: false,
        });
      });
      break;
    case 'darkwood':
    case 'swamp':
      if (G.frame % 3 === 0) spawn(1, (x, y) => {
        spawnParticle(G, {
          x, y, vx: randR(-6, 6), vy: randR(-9, -3),
          life: randR(1.6, 2.6), size: randR(1.4, 2), color: chance(0.5) ? '#d8f0a0' : '#a0f0d0', glow: true,
        });
      });
      break;
    case 'volcanic':
      spawn(1, (x, y) => {
        spawnParticle(G, {
          x, y, vx: randR(-6, 6), vy: randR(-38, -20),
          life: randR(0.8, 1.5), size: randR(1.4, 2.2), color: chance(0.4) ? '#ffd75e' : '#ff8a3e', glow: true,
        });
      });
      break;
    case 'wastes':
      if (G.frame % 2 === 0) spawn(1, (x, y) => {
        spawnParticle(G, {
          x, y, vx: randR(-10, 10), vy: randR(-14, -6),
          life: randR(1.6, 2.6), size: 1.6, color: chance(0.3) ? '#c95ee8' : '#8a6ea8', glow: true,
        });
      });
      break;
    case 'desert':
      if (G.frame % 2 === 0) spawn(1, (x, y) => {
        spawnParticle(G, {
          x, y, vx: randR(46, 74), vy: randR(-3, 3),
          life: randR(0.4, 0.7), size: 1.4, color: '#d8c088', shrink: false,
        });
      });
      break;
    case 'arcane':
      if (G.frame % 2 === 0) spawn(1, (x, y) => {
        spawnParticle(G, {
          x, y, vx: randR(-5, 5), vy: randR(-10, -4),
          life: randR(1.4, 2.2), size: 1.5, color: chance(0.4) ? '#e8dcff' : '#9ef2e8', glow: true,
        });
      });
      break;
    case 'grass':
      if (G.frame % 5 === 0) spawn(1, (x, y) => {
        spawnParticle(G, {
          x, y, vx: randR(-7, 7), vy: randR(-6, 6),
          life: randR(1.8, 2.6), size: 1.2, color: '#e8f0b0', shrink: false,
        });
      });
      break;
    default:
      break;
  }
}

export function updateAmbient(G: GameCtx, dt: number): void {
  if (G.mode !== 'play') return;
  weather(G);
  updateCritters(G, dt);
}
