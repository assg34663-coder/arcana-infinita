/* ============================================================
   villages.ts — deterministic hamlets for the Weald: houses
   around a well, a market stall, fence rings, and wandering
   villager NPCs. Villages are SAFE ZONES (no enemy spawns —
   game.ts gates the spawner with inVillage()) and their well /
   stall reuse the existing shrine shop panel.

   DEPENDENCY RULE: this file imports ONLY from core.ts and
   sprites.ts (never world.ts / fx.ts) so world.ts can consult
   villageStructuresNear() from moveWithCollision without a
   module cycle.
   ============================================================ */
import { TAU, hash2, mulberry32, randR, type GameCtx } from './core';
import { SPR } from './sprites';

// ---------- types ----------
export interface VillageStruct {
  x: number; y: number;
  spr: 'house_a' | 'house_b' | 'well' | 'stall' | 'fence';
  flip: boolean;
}

export interface Village {
  id: string;
  name: string;
  x: number; y: number;
  r: number;                    // village radius (~190) — safe zone bounds
  houses: VillageStruct[];      // ALL structures (well + stall included)
}

interface Villager {
  home: Village;
  x: number; y: number;
  tx: number; ty: number;       // wander target
  t: number;                    // pause timer
  face: number;                 // -1 | 1
  anim: number;                 // walk cycle clock
  moving: boolean;
  tunic: string;
  hair: string;
  chatT: number;                // greeting cooldown (one per 6s max)
  line: number;
}

// ---------- module state (per world) ----------
const VILLAGES: Village[] = [];
const VILLAGERS: Villager[] = [];

const NAMES = [
  'Hearthmere', 'Bramblewick', 'Duskmoor', 'Fallowbrook', 'Emberrest',
  'Thornhaven', 'Millbrook', 'Oakenshade', 'Winterhollow', 'Greenside',
];
const TUNICS = ['#8e5a8e', '#5a7e9e', '#9e6e4e', '#4e8e6e', '#a85a4e', '#7a6e9e', '#b09e4e', '#5e8a9e'];
const HAIRS = ['#3a2a1e', '#6e4a2a', '#a8a290', '#8e3a2e', '#2e2a38'];
const GREETINGS = ['Welcome!', '...', 'Fine day, mage.', 'Mind the roads.', 'Travel far?', 'The well is sweet.'];

// ---------- init ----------
export function initVillages(
  seed: number,
  findLand: (x: number, y: number) => { x: number; y: number },
  biomeAt: (x: number, y: number) => string,
  avoid: Array<{ x: number; y: number; r: number }> = [],
): void {
  VILLAGES.length = 0;
  VILLAGERS.length = 0;
  const rng = mulberry32(seed + 4711);
  const usedNames = new Set<number>();

  for (let i = 0; i < 3; i++) {
    // deterministic base angle (2π/3 apart) + hashed jitter, distance 1000–1500
    const jitter = (hash2(i, 3, seed + 3100) - 0.5) * 0.9;
    const baseD = 1000 + hash2(i, 13, seed + 4200) * 500;
    let px = 0, py = 0;
    let ok = false;
    for (let att = 0; att < 40; att++) {
      const a = i * (TAU / 3) + jitter + (att === 0 ? 0 : (hash2(i, att, seed + 5300) - 0.5) * 0.5);
      const d = baseD + (att === 0 ? 0 : (hash2(i, att, seed + 5400) - 0.5) * 240);
      const p = findLand(Math.cos(a) * d, Math.sin(a) * d);
      px = p.x; py = p.y;
      // never settle inside (or right next to) a boss arena or special site
      let blocked = false;
      for (const av of avoid) {
        if (Math.hypot(px - av.x, py - av.y) < av.r + 280) { blocked = true; break; }
      }
      if (blocked) continue;
      const b = biomeAt(px, py);
      if ((b === 'grass' || b === 'forest') && !tooCloseToWater(px, py, biomeAt)) { ok = true; break; }
    }
    if (!ok) {
      // fallback: sweep angles/distances, still honoring arena avoidance
      for (let att = 0; att < 24 && !ok; att++) {
        const a = i * (TAU / 3) + jitter + att * 0.42;
        const d = baseD + 260 * Math.ceil(att / 8) + (hash2(i, att, seed + 5400) - 0.5) * 200;
        const p = findLand(Math.cos(a) * d, Math.sin(a) * d);
        px = p.x; py = p.y;
        let blocked = false;
        for (const av of avoid) {
          if (Math.hypot(px - av.x, py - av.y) < av.r + 240) { blocked = true; break; }
        }
        if (!blocked) ok = true;
      }
    }
    // name: seeded pick without repeats
    let ni = Math.floor(hash2(i, 99, seed + 6100) * NAMES.length);
    for (let g = 0; g < NAMES.length && usedNames.has(ni); g++) ni = (ni + 1) % NAMES.length;
    usedNames.add(ni);

    const v: Village = {
      id: `village_${i}`,
      name: NAMES[ni],
      x: Math.round(px), y: Math.round(py),
      r: 190,
      houses: [],
    };
    layoutVillage(v, seed + i * 77, rng, biomeAt);
    VILLAGES.push(v);
    spawnVillagers(v, rng);
  }
}

function tooCloseToWater(x: number, y: number, biomeAt: (x: number, y: number) => string): boolean {
  for (let k = 0; k < 8; k++) {
    const a = (k / 8) * TAU;
    if (biomeAt(x + Math.cos(a) * 170, y + Math.sin(a) * 170) === 'ocean') return true;
  }
  return false;
}

// ---------- layout: houses ring + well + stall + fences ----------
function layoutVillage(
  v: Village,
  seed: number,
  rng: () => number,
  biomeAt: (x: number, y: number) => string,
): void {
  const land = (x: number, y: number) => biomeAt(x, y) !== 'ocean';
  // the well is the heart of the village (also the shop interaction point)
  v.houses.push({ x: v.x, y: v.y, spr: 'well', flip: false });
  // market stall off-center
  const stallA = rng() * TAU;
  const sx = v.x + Math.cos(stallA) * 36, sy = v.y + Math.sin(stallA) * 36;
  if (land(sx, sy)) v.houses.push({ x: sx, y: sy, spr: 'stall', flip: rng() > 0.5 });
  // 5–7 houses in a rough ring: ≥60px from the well, ≥42px apart
  const n = 5 + Math.floor(rng() * 3);
  const placed: Array<{ x: number; y: number }> = [];
  for (let k = 0; k < n; k++) {
    const baseA = (k / n) * TAU + rng() * 0.5;
    for (let att = 0; att < 12; att++) {
      const a = baseA + (att === 0 ? 0 : (att % 2 ? 1 : -1) * Math.ceil(att / 2) * 0.23);
      const d = 68 + rng() * 62;
      const hx = v.x + Math.cos(a) * d, hy = v.y + Math.sin(a) * d;
      if (Math.hypot(hx - v.x, hy - v.y) < 60) continue;
      let crowded = false;
      for (const p of placed) {
        if (Math.hypot(p.x - hx, p.y - hy) < 42) { crowded = true; break; }
      }
      if (crowded || !land(hx, hy)) continue;
      placed.push({ x: hx, y: hy });
      v.houses.push({ x: Math.round(hx), y: Math.round(hy), spr: rng() > 0.45 ? 'house_a' : 'house_b', flip: rng() > 0.5 });
      break;
    }
  }
  // fence ring with a 2-post entrance gap facing the stall
  const fn = 12;
  const gapK = Math.round((stallA / TAU) * fn) % fn;
  for (let k = 0; k < fn; k++) {
    if (k === gapK || k === (gapK + 1) % fn) continue;
    const a = (k / fn) * TAU + rng() * 0.06;
    const fr = 150 + rng() * 14;
    const fx = v.x + Math.cos(a) * fr, fy = v.y + Math.sin(a) * fr;
    if (!land(fx, fy)) continue;
    v.houses.push({ x: Math.round(fx), y: Math.round(fy), spr: 'fence', flip: rng() > 0.5 });
  }
}

function spawnVillagers(v: Village, rng: () => number): void {
  const n = 3 + Math.floor(rng() * 3); // 3–5
  for (let j = 0; j < n; j++) {
    let x = v.x, y = v.y;
    for (let att = 0; att < 8; att++) {
      const a = rng() * TAU, d = rng() * v.r * 0.5;
      x = v.x + Math.cos(a) * d; y = v.y + Math.sin(a) * d;
      if (!villagerBlocked(v, x, y)) break;
    }
    VILLAGERS.push({
      home: v,
      x, y,
      tx: x, ty: y,
      t: rng() * 3,
      face: rng() > 0.5 ? 1 : -1,
      anim: 0, moving: false,
      tunic: TUNICS[Math.floor(rng() * TUNICS.length)],
      hair: HAIRS[Math.floor(rng() * HAIRS.length)],
      chatT: 0,
      line: Math.floor(rng() * GREETINGS.length),
    });
  }
}

// ---------- queries ----------
export function villages(): Village[] {
  return VILLAGES;
}

export function villageNear(x: number, y: number, pad = 0): Village | null {
  for (const v of VILLAGES) {
    const dx = x - v.x, dy = y - v.y;
    const rr = v.r + pad;
    if (dx * dx + dy * dy <= rr * rr) return v;
  }
  return null;
}

/** true when the point is inside a village — the enemy spawner must skip it. */
export function inVillage(x: number, y: number): boolean {
  return villageNear(x, y, 0) !== null;
}

/** village whose well / stall is within trade distance of the player. */
export function villageShopNear(x: number, y: number): Village | null {
  for (const v of VILLAGES) {
    if (Math.hypot(x - v.x, y - v.y) < 46) return v;
    const stall = v.houses.find((s) => s.spr === 'stall');
    if (stall && Math.hypot(x - stall.x, y - stall.y) < 34) return v;
  }
  return null;
}

/**
 * Solid structure query for world.ts moveWithCollision's blocked() closure.
 * Returns the structures whose collision box may overlap a circle of radius
 * `r` at (x, y), or null when no village is anywhere near (fast path).
 */
export function villageStructuresNear(x: number, y: number, r: number): VillageStruct[] | null {
  for (const v of VILLAGES) {
    const dx = x - v.x, dy = y - v.y;
    const reach = v.r + r + 40;
    if (dx < -reach || dx > reach || dy < -reach || dy > reach) continue;
    const out: VillageStruct[] = [];
    for (const s of v.houses) {
      if (Math.abs(s.x - x) < r + 14 && Math.abs(s.y - y) < r + 14) out.push(s);
    }
    return out;
  }
  return null;
}

/**
 * Ground modifier for chunk generation: 0 = normal biome, 1 = dirt plaza
 * (drawn as path tiles with a ragged edge), 2 = village grounds (no decor).
 */
export function villageGround(wx: number, wy: number): number {
  for (const v of VILLAGES) {
    const dx = wx - v.x, dy = wy - v.y;
    if (dx < -v.r || dx > v.r || dy < -v.r || dy > v.r) continue;
    const d = Math.hypot(dx, dy);
    if (d < 30) return 1;
    if (d < 44 && hash2(Math.floor(wx), Math.floor(wy), 333) < 0.55) return 1;
    if (d < v.r) return 2;
  }
  return 0;
}

// ---------- villager simulation (pure ambience — no hp, no ai) ----------
function villagerBlocked(v: Village, x: number, y: number): boolean {
  for (const s of v.houses) {
    if (s.spr === 'fence') {
      const dx = x - s.x, dy = y - (s.y - 4);
      if (dx * dx + dy * dy < 36) return true; // post r3 + body r3
    } else if (s.spr === 'house_a' || s.spr === 'house_b') {
      if (Math.abs(x - s.x) < 10 && Math.abs(y - (s.y - 6)) < 8) return true;
    } else { // well / stall
      if (Math.abs(x - s.x) < 9 && Math.abs(y - (s.y - 4)) < 6) return true;
    }
  }
  return false;
}

function pickWanderTarget(vil: Villager): void {
  const v = vil.home;
  for (let i = 0; i < 8; i++) {
    const a = Math.random() * TAU;
    const d = Math.random() * v.r * 0.6; // never leave the village heart
    const tx = v.x + Math.cos(a) * d, ty = v.y + Math.sin(a) * d;
    if (!villagerBlocked(v, tx, ty)) { vil.tx = tx; vil.ty = ty; return; }
  }
  vil.tx = v.x; vil.ty = v.y;
}

export function updateVillagers(G: GameCtx, dt: number): void {
  if (!VILLAGERS.length) return;
  for (const vil of VILLAGERS) {
    // only simulate near the player (villagers are pure ambience)
    if (Math.abs(vil.x - G.player.x) > 900 || Math.abs(vil.y - G.player.y) > 900) continue;
    const pdx = G.player.x - vil.x, pdy = G.player.y - vil.y;
    const pd = Math.hypot(pdx, pdy);
    if (pd < 26) {
      // stop, face the player, greet sparingly (at most once per 6s)
      vil.moving = false;
      vil.anim = 0;
      vil.face = pdx < 0 ? -1 : 1;
      vil.chatT -= dt;
      if (vil.chatT <= 0) {
        vil.chatT = 6;
        sayText(G, vil.x, vil.y - 14, GREETINGS[vil.line % GREETINGS.length]);
        vil.line++;
      }
      continue;
    }
    if (vil.t > 0) {
      vil.t -= dt;
      vil.moving = false;
      vil.anim = 0;
      continue;
    }
    const dx = vil.tx - vil.x, dy = vil.ty - vil.y;
    const dd = Math.hypot(dx, dy);
    if (dd < 2) {
      pickWanderTarget(vil);
      vil.t = randR(2, 5);
      continue;
    }
    const step = Math.min(18 * dt, dd);
    const nx = vil.x + (dx / dd) * step, ny = vil.y + (dy / dd) * step;
    if (villagerBlocked(vil.home, nx, ny)) {
      pickWanderTarget(vil);
      vil.t = randR(1, 2.5);
      continue;
    }
    vil.x = nx; vil.y = ny;
    vil.moving = true;
    vil.anim += dt;
    if (Math.abs(dx) > 0.5) vil.face = dx < 0 ? -1 : 1;
  }
}

// mirrors fx.addText (kept local so villages.ts never imports fx.ts → world.ts)
function sayText(G: GameCtx, x: number, y: number, text: string): void {
  if (G.texts.length > 60) G.texts.shift();
  G.texts.push({ x: x + randR(-4, 4), y: y - 8, vy: -22, t: 0, dur: 0.9, text, color: '#ffe2a8', size: 4 });
}

// ---------- drawing ----------
function drawStructure(G: GameCtx, s: VillageStruct): void {
  const spr = SPR[s.spr];
  if (!spr) return;
  const c = G.ctx;
  c.globalAlpha = 0.3;
  c.fillStyle = '#000';
  c.beginPath();
  c.ellipse(s.x, s.y - 1, spr.width * 0.32, 2.4, 0, 0, TAU);
  c.fill();
  c.globalAlpha = 1;
  if (s.flip) {
    c.save();
    c.translate(Math.round(s.x), Math.round(s.y));
    c.scale(-1, 1);
    c.drawImage(spr, -spr.width / 2, -spr.height + 2);
    c.restore();
  } else {
    c.drawImage(spr, Math.round(s.x - spr.width / 2), Math.round(s.y - spr.height + 2));
  }
}

/** y-sorted world items for all structures near the camera (cull ~900px). */
export function villageDrawItems(G: GameCtx): Array<{ y: number; f: () => void }> {
  const out: Array<{ y: number; f: () => void }> = [];
  for (const v of VILLAGES) {
    if (Math.hypot(v.x - G.cam.x, v.y - G.cam.y) > 900 + v.r) continue;
    for (const s of v.houses) {
      if (Math.abs(s.x - G.cam.x) > G.W / 2 + 48 || Math.abs(s.y - G.cam.y) > G.H / 2 + 64) continue;
      out.push({ y: s.y, f: () => drawStructure(G, s) });
    }
  }
  return out;
}

/** tiny pixel person, 2-frame walk, drawn procedurally (6x10 body). */
function drawVillagerOne(G: GameCtx, vil: Villager): void {
  const ctx = G.ctx;
  const x = Math.round(vil.x), y = Math.round(vil.y);
  ctx.globalAlpha = 0.25;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(x, y, 3.4, 1.6, 0, 0, TAU);
  ctx.fill();
  ctx.globalAlpha = 1;
  const f = vil.moving ? Math.floor(vil.anim * 6) % 2 : 0;
  const bob = vil.moving && f === 1 ? -1 : 0;
  // legs (2-frame stride)
  ctx.fillStyle = '#4a3a2e';
  if (f === 1) {
    ctx.fillRect(x - 3, y - 3 + bob, 2, 3);
    ctx.fillRect(x + 1, y - 3 + bob, 2, 2);
  } else {
    ctx.fillRect(x - 2, y - 3 + bob, 2, 3);
    ctx.fillRect(x, y - 3 + bob, 2, 3);
  }
  // tunic + belt
  ctx.fillStyle = vil.tunic;
  ctx.fillRect(x - 3, y - 7 + bob, 6, 5);
  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.fillRect(x - 3, y - 4 + bob, 6, 1);
  // arms
  ctx.fillStyle = vil.tunic;
  ctx.fillRect(x - 4, y - 6 + bob, 1, 3);
  ctx.fillRect(x + 3, y - 6 + bob, 1, 3);
  // head + hair (no facial details — quiet village folk)
  ctx.fillStyle = '#e8c096';
  ctx.fillRect(x - 2, y - 10 + bob, 4, 3);
  ctx.fillStyle = vil.hair;
  ctx.fillRect(x - 2, y - 11 + bob, 4, 2);
}

/** y-sorted villager items for drawYsorted (cull ~viewport). */
export function villagerDrawItems(G: GameCtx): Array<{ y: number; f: () => void }> {
  const out: Array<{ y: number; f: () => void }> = [];
  for (const vil of VILLAGERS) {
    if (Math.abs(vil.x - G.cam.x) > G.W / 2 + 60 || Math.abs(vil.y - G.cam.y) > G.H / 2 + 80) continue;
    out.push({ y: vil.y, f: () => drawVillagerOne(G, vil) });
  }
  return out;
}
