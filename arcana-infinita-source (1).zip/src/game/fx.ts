/* ============================================================
   fx.ts — the combat backbone: bullets, particles, zones,
   beams, telegraphs, explosions, damage & element statuses.
   ============================================================ */
import {
  TAU, clamp, circleHit, dist, dist2, angTo, rand, randR, chance, pick,
  type Bullet, type ElementId, type Ent, type Enemy, type GameCtx,
  type Minion, type Particle, type Zone, type BeamFx, type Telegraph,
  type FloatText, type Team, type RingFx, type Pickup,
} from './core';
import { elColor, elColor2, SPR } from './sprites';
import { TILE_HURT_LAVA, TILE_SLOW } from './world';
import { SCHOOL_SIG } from './schools';
import { RELICS, RARITY_COLOR, grantRelic, relicVal } from './items';

const MAX_PARTS = 1200;
const MAX_BULLETS = 1100;

// ritual hook: casting.ts registers ritualEffect here at boot
// (avoids a circular import; same pattern as quests.ts xp handler)
let wildRitual: ((G: GameCtx, el: ElementId, x: number, y: number, dmg: number, scale: number) => void) | null = null;
export function registerRitualHandler(fn: NonNullable<typeof wildRitual>): void { wildRitual = fn; }

// ---------- particles ----------
export function spawnParticle(G: GameCtx, p: Partial<Particle>): void {
  if (G.parts.length >= MAX_PARTS) G.parts.shift();
  G.parts.push({
    x: p.x ?? 0, y: p.y ?? 0, vx: p.vx ?? 0, vy: p.vy ?? 0,
    life: p.life ?? 0.5, maxLife: p.life ?? 0.5,
    size: p.size ?? 2, color: p.color ?? '#ffffff',
    grav: p.grav ?? 0, glow: p.glow ?? false, shrink: p.shrink ?? true,
  });
}

export function burst(
  G: GameCtx, x: number, y: number, color: string, n: number,
  speed = 60, opts: { life?: number; size?: number; glow?: boolean; grav?: number; spread?: number; dir?: number } = {},
): void {
  for (let i = 0; i < n; i++) {
    const a = opts.dir !== undefined
      ? opts.dir + randR(-(opts.spread ?? Math.PI), opts.spread ?? Math.PI)
      : rand(0, TAU);
    const s = randR(speed * 0.3, speed);
    spawnParticle(G, {
      x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
      life: opts.life ?? randR(0.25, 0.6), size: opts.size ?? randR(1.5, 3),
      color, glow: opts.glow ?? true, grav: opts.grav ?? 0,
    });
  }
}

export function addText(G: GameCtx, x: number, y: number, text: string, color: string, size = 5, crit = false): void {
  if (G.texts.length > 60) G.texts.shift();
  G.texts.push({ x: x + randR(-4, 4), y: y - 8, vy: -22, t: 0, dur: crit ? 0.9 : 0.65, text, color, size });
}

export function shake(G: GameCtx, amt: number): void {
  G.cam.shake = Math.min(7, G.cam.shake + amt);
}

export function slowmo(G: GameCtx, t: number, scale: number): void {
  G.slowmo = { t, scale };
}

// full-screen color wash that fades (the grand-casting / parry flash)
export function screenFlash(G: GameCtx, color: string, dur = 0.2): void {
  if (G.screenFlash && G.screenFlash.dur > dur) return; // don't cut a bigger flash short
  G.screenFlash = { t: 0, dur, color };
}

// ---------- shockwave rings ----------
export function addRing(G: GameCtx, x: number, y: number, r: number, vr: number, color: string, dur = 0.35, w = 2): void {
  if (G.rings.length > 24) G.rings.shift();
  G.rings.push({ x, y, r, vr, t: 0, dur, color, w });
}

export function updateRings(G: GameCtx, dt: number): void {
  for (const r of G.rings) { r.t += dt; r.r += r.vr * dt; }
  // implode rings (negative vr) must die at r<=0 — a negative radius
  // makes ctx.arc throw IndexSizeError every frame afterwards
  G.rings = G.rings.filter((r) => r.t < r.dur && r.r > 0.4);
}

export function drawRings(G: GameCtx): void {
  const ctx = G.ctx;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const r of G.rings) {
    const k = Math.max(0, 1 - r.t / r.dur);
    const rr = Math.max(0.15, r.r); // never feed arc() a negative radius
    ctx.globalAlpha = k * 0.8;
    ctx.strokeStyle = r.color;
    ctx.lineWidth = Math.max(0.2, r.w * k + 0.5);
    ctx.beginPath(); ctx.arc(r.x, r.y, rr, 0, TAU); ctx.stroke();
  }
  ctx.restore();
}

// ---------- dopamine engine: combo / overdrive ----------
export function bumpCombo(G: GameCtx): void {
  G.combo.n++;
  G.combo.t = 3.2;
  if (G.combo.n === 10 || G.combo.n === 20 || G.combo.n === 35) {
    G.overdrive = 6;
    G.odFlash = 0.55;
    addText(G, G.player.x, G.player.y - 30, 'OVERDRIVE!', '#ff9e4e', 10, true);
    addText(G, G.player.x, G.player.y - 18, 'SPELLS EMPOWERED', '#ffd75e', 5);
    G.audio.sfx('overdrive');
    shake(G, 3.5);
    addRing(G, G.player.x, G.player.y, 10, 260, '#ff9e4e', 0.5, 3);
    burst(G, G.player.x, G.player.y, '#ff9e4e', 30, 160, { glow: true });
    G.cb.overdrive(G.combo.n);
  } else if (G.combo.n >= 4 && G.combo.n % 5 === 0) {
    addText(G, G.player.x, G.player.y - 22, `x${G.combo.n} COMBO`, '#ffd75e', 7, true);
    G.audio.sfx('combo', 1 + G.combo.n * 0.015, 0.8);
  }
}

// ---------- elements ----------
export function isUndead(e: Ent): boolean {
  return !!(e as Enemy).undead;
}

export function applyElement(G: GameCtx, target: Ent, el: ElementId, potency: number, fromTeam: Team): void {
  if (potency <= 0) return;
  const st = target.st;
  const isPlayer = target === (G.player as unknown as Ent);
  switch (el) {
    case 'fire':
      if (isPlayer && G.prog.sigils.includes('ashen')) break;
      // PYROMANCER CLASS: your burns cling and bite harder
      const pyro = G.prog.cls === 'pyromancer';
      // RELIC: salamander's tooth — your fires run hotter
      const fAmp = fromTeam === 'player' ? 1 + relicVal(G, 'burnAmp') : 1;
      if (target.st.wet) { delete st.wet; st.burn = { t: pyro ? 1.8 : 1.2, dps: 6 * potency * (pyro ? 1.3 : 1) * fAmp, team: fromTeam }; }
      else st.burn = { t: pyro ? 3.4 : 2.4, dps: 5 * potency * (pyro ? 1.3 : 1) * fAmp, team: fromTeam };
      break;
    case 'frost': {
      if (isPlayer && G.prog.sigils.includes('frost')) break;
      if (st.frozen) { st.frozen.t = Math.max(st.frozen.t, 0.7); break; }
      // GLACIAL STACKS: every frost hit stacks — 3 stacks FREEZE solid
      if (!isPlayer) {
        const s = st.frzStack ?? { n: 0, t: 0 };
        s.n++; s.t = 2.6;
        st.frzStack = s;
        if (s.n >= 3) {
          delete st.frzStack;
          st.frozen = { t: 1.3 };
          burst(G, target.x, target.y, '#cfeefc', 10, 80, { glow: true });
          addText(G, target.x, target.y - 14, 'FROZEN', '#9edbe8', 5, true);
          G.audio.sfx('frozen', 1, 0.8);
          break;
        }
      }
      if (!isPlayer && st.chill && chance(0.1)) {
        st.frozen = { t: 1.1 };
        burst(G, target.x, target.y, '#cfeefc', 9, 70, { glow: true });
        addText(G, target.x, target.y - 14, 'FROZEN', '#9edbe8', 5, true);
        G.audio.sfx('frozen', 1, 0.7);
      }
      st.chill = { t: 2.2, mult: st.wet ? 0.4 : 0.6 };
      break;
    }
    case 'lightning':
      if (!isPlayer && chance(0.3 * potency)) st.stun = { t: 0.4 };
      if (isPlayer) G.player.stunT = Math.max(G.player.stunT ?? 0, 0.18);
      break;
    case 'earth':
      if (!isPlayer && !target.fly) {
        const a = angTo(G.player.x, G.player.y, target.x, target.y);
        target.vx += Math.cos(a) * 140 * potency;
        target.vy += Math.sin(a) * 140 * potency;
      }
      break;
    case 'wind': {
      const a = angTo(G.player.x, G.player.y, target.x, target.y);
      target.vx += Math.cos(a) * 90 * potency;
      target.vy += Math.sin(a) * 90 * potency;
      break;
    }
    case 'water':
      st.wet = { t: 4 };
      break;
    case 'poison':
      if (isPlayer && G.prog.sigils.includes('maw')) break;
      // ESCALATING PLAGUE: stacks deepen the rot and the damage taken
      if (!isPlayer) {
        const ps = st.plague ?? { n: 0, t: 0 };
        ps.n = Math.min(8, ps.n + 1); ps.t = 4.5;
        st.plague = ps;
        st.poison = { t: 4.5, dps: (3.5 + ps.n * 1.1) * potency };
        st.amp = { t: 4.5, mult: Math.min(1.4, 1.1 + ps.n * 0.045) };
      } else {
        st.poison = { t: 4, dps: 3.5 * potency };
      }
      break;
    case 'blood':
      break; // lifesteal handled in damage
    case 'shadow':
      // DREAD CURSE: doomed foes deal 30% less damage
      if (!isPlayer) {
        st.doom = { t: 4 };
        if (chance(0.22 * potency)) st.fear = { t: 1.4 };
      }
      break;
    case 'death':
      break;
    case 'radiant':
      break;
    case 'arcane':
      if (fromTeam === 'player' && !isPlayer) {
        // MANA ENGINE: arcane hits pour mana back into the caster
        G.player.mana = Math.min(G.player.maxMana, G.player.mana + 1.2 + schoolLvlOf(G, 'arcane') * 0.06);
      }
      break;
    case 'time': {
      st.chill = { t: 1.6, mult: 0.55 };
      // TEMPORAL LOCK: 3 hour charges stop time entirely (2 for Chronomancers)
      if (!isPlayer) {
        const ts = st.tStop ?? { n: 0, t: 0 };
        ts.n++; ts.t = 3;
        st.tStop = ts;
        if (ts.n >= (G.prog.cls === 'chronomancer' ? 2 : 3)) {
          delete st.tStop;
          st.stun = { t: 1.6 };
          addText(G, target.x, target.y - 14, 'TIME STOP', '#e8c05e', 6, true);
          addRing(G, target.x, target.y, 6, 130, '#e8c05e', 0.4, 2);
          burst(G, target.x, target.y, '#fff2c9', 8, 70, { glow: true });
          G.audio.sfx('blink', 0.6, 0.7);
        }
      }
      break;
    }
    case 'void': {
      const a = angTo(target.x, target.y, G.player.x, G.player.y);
      target.vx += Math.cos(a) * 60 * potency;
      target.vy += Math.sin(a) * 60 * potency;
      break;
    }
    case 'nature':
      if (!isPlayer) st.root = { t: 1.1 * potency };
      break;
    case 'chaos':
      applyElement(G, target, pick(['fire', 'frost', 'lightning', 'earth', 'wind', 'water', 'poison', 'shadow', 'void', 'nature'] as ElementId[]), potency, fromTeam);
      break;
  }
}

function statusDmgMult(el: ElementId, target: Ent): number {
  let m = 1;
  if (target.st.wet && (el === 'lightning' || el === 'frost')) m *= 1.5;
  if (target.st.burn && el !== 'fire') m *= 1.25; // burning foes take +25% from everything
  if (isUndead(target)) {
    if (el === 'radiant') m *= 1.6;
    if (el === 'death') m *= 0.75;
  }
  return m;
}

// ---------- damage ----------
function shatterBonus(G: GameCtx, e: Ent, d: number): number {
  if (!e.st.frozen) return d;
  e.st.frozen = undefined;
  delete e.st.frozen;
  const bonus = d * 1.5;
  addText(G, e.x, e.y - 14, 'SHATTER!', '#cfeefc', 7, true);
  burst(G, e.x, e.y, '#dff4fc', 12, 110, { glow: true });
  addRing(G, e.x, e.y, 6, 120, '#cfeefc', 0.3, 2);
  G.audio.sfx('frozen', 1.5, 0.8);
  return bonus;
}

export function damageEnemy(G: GameCtx, e: Enemy, dmg: number, el: ElementId | null, opts: { crit?: boolean; from?: Ent | null; silent?: boolean } = {}): void {
  if (e.dead) return;
  let d = dmg;
  // RELIC: arcane focus — player-sourced hits (spells, blasts, blades) carry the lens
  if (opts.from?.team === 'player') d *= 1 + 0.08 * relicVal(G, 'spellDmg');
  if (el) d *= statusDmgMult(el, e);
  if (e.st.amp) d *= e.st.amp.mult;
  if (e.st.chill) d *= 1.1;
  if (el !== 'frost') d = shatterBonus(G, e, d); // frost sets up, everything else shatters
  d = Math.max(1, Math.round(d));
  e.hp -= d;
  e.flash = 0.12;
  if (el) applyElement(G, e, el, 1, 'player');
  if (opts.from?.team === 'player' && el === 'blood') {
    G.player.hp = Math.min(G.player.maxHp, G.player.hp + d * 0.22);
  }
  // RELIC: serpent coil — the wound drinks back toward the mage
  const ls = relicVal(G, 'lifesteal');
  if (ls > 0 && !G.player.dead) G.player.hp = Math.min(G.player.maxHp, G.player.hp + d * ls);
  if (!opts.silent) addText(G, e.x, e.y, `${d}`, el ? elColor(el) : '#ffffff', opts.crit ? 7 : 5, opts.crit);
  if (e.hp <= 0) { G.cb.enemyDie(e, el ?? 'arcane'); }
  else G.cb.enemyHit(e, d, el ?? 'arcane', !!opts.crit);
}

export function damageMinion(G: GameCtx, m: Minion, dmg: number, el: ElementId | null): void {
  if (m.dead) return;
  m.hp -= Math.max(1, Math.round(dmg));
  m.flash = 0.12;
  if (el) applyElement(G, m, el, 1, 'enemy');
  if (m.hp <= 0) { m.dead = true; G.cb.minionDie(m); }
  else G.cb.minionHit(m, dmg, el ?? 'arcane');
}

export function damageBoss(G: GameCtx, b: Ent & { hp: number }, dmg: number, el: ElementId | null, crit = false): void {
  if (b.dead) return;
  const bb = b as unknown as import('./core').Boss;
  let d = dmg;
  // RELIC: arcane focus — only the player's party ever damages bosses
  d *= 1 + 0.08 * relicVal(G, 'spellDmg');
  if (bb.state === 'stagger') d *= 1.5;
  if (el) d *= statusDmgMult(el, b);
  if (b.st.amp) d *= b.st.amp.mult;
  if (el !== 'frost') d = shatterBonus(G, b, d);
  d = Math.max(1, Math.round(d));
  b.hp -= d;
  b.flash = 0.1;
  if (el) applyElement(G, b, el, 0.6, 'player');
  if (el === 'blood') G.player.hp = Math.min(G.player.maxHp, G.player.hp + d * 0.18);
  const lsB = relicVal(G, 'lifesteal');
  if (lsB > 0 && !G.player.dead) G.player.hp = Math.min(G.player.maxHp, G.player.hp + d * lsB);
  addText(G, b.x, b.y - 10, `${d}`, el ? elColor(el) : '#ffffff', crit ? 7 : 5, crit);
  G.cb.bossHit(bb, d, el ?? 'arcane', crit);
  if (b.hp <= 0 && !bb.dead && bb.state !== 'dying') {
    b.hp = 0;
    bb.state = 'dying';
    bb.stT = 0;
    G.cb.bossDie(bb);
  }
}

export interface PlayerHitOpts {
  melee?: boolean;          // a body/blade hit — can be parried
  from?: Ent | null;        // who swung at you
}

export function damagePlayer(G: GameCtx, dmg: number, el: ElementId | null, opts?: PlayerHitOpts): void {
  const p = G.player;
  if (p.dead || p.iframes > 0 || G.mode === 'dead') return;
  if (G.cheat.god) {
    // cheat console: the mage is unkillable
    burst(G, p.x, p.y, '#ffd75e', 3, 40, { glow: true });
    return;
  }
  // ---- MELEE PARRY: a timed guard turns a body into a mistake ----
  if (opts?.melee && p.parryT > 0 && opts.from && !opts.from.dead) {
    if (p.perfectT > 0) {
      // PERFECT: negate + stagger the attacker + riposte window
      const f = opts.from;
      p.parryHits++;
      p.parryReflT = 0.18;
      const a = angTo(p.x, p.y, f.x, f.y);
      if (!('defId' in f)) { f.st.stun = { t: 1.1 }; f.vx += Math.cos(a) * 260; f.vy += Math.sin(a) * 260; }
      G.hitstop = Math.max(G.hitstop, 0.07);
      slowmo(G, 0.32, 0.3);
      screenFlash(G, '#fff8d8', 0.26);
      G.audio.sfx('parry', 1.9, 0.9);
      G.audio.sfx('reflect', 1);
      addText(G, p.x, p.y - 16, 'PERFECT PARRY!', '#ffd75e', 8, true);
      bumpCombo(G);
      shake(G, 2.4);
      p.mana = Math.min(p.maxMana, p.mana + 14);
      explosion(G, p.x, p.y, 42, 13 + G.prog.lvl * 1.2, 'radiant', 'player', { from: p });
      addRing(G, p.x, p.y - 1, 8, 260, '#fff8d8', 0.35, 3);
      p.iframes = Math.max(p.iframes, 0.3);
      return;
    }
    // NORMAL GUARD: half damage bleeds through, guard is spent
    dmg *= 0.5;
    addText(G, p.x, p.y - 12, 'GUARD', '#c9c2b0', 5);
    G.audio.sfx('clang', 1.15, 0.7);
    burst(G, p.x, p.y, '#ffd75e', 8, 80, { glow: true });
    p.parryT = 0;
  }
  let d = dmg;
  if (p.ward && p.ward.amt > 0) {
    const absorbed = Math.min(p.ward.amt, d);
    p.ward.amt -= absorbed;
    d -= absorbed;
    burst(G, p.x, p.y, elColor(p.ward.el), 6, 50);
    if (p.ward.el === 'void') p.mana = Math.min(p.maxMana, p.mana + absorbed * 0.5);
    if (p.ward.amt <= 0) { p.ward = null; addText(G, p.x, p.y - 12, 'WARD SHATTERED', '#ffffff', 5); }
    if (d <= 0.5) { G.audio.sfx('parry', 0.7, 0.6); return; }
  }
  // RELIC: scales of the kindly one — she looked away, so the blow lands lighter
  d *= 1 - clamp(relicVal(G, 'damageReduction'), 0, 0.3);
  d = Math.max(1, Math.round(d));
  p.hp -= d;
  p.iframes = 0.35;
  p.flash = 0.15;
  p.hurtCd = 0.2;
  // RELIC: gossamer aegis — a wound can weave its own answer
  const wOn = relicVal(G, 'wardOnHit');
  if (wOn > 0 && !p.ward && chance(Math.min(0.25, wOn * 0.08))) {
    p.ward = { t: 2, amt: 14, maxAmt: 14, el: 'arcane' };
    addText(G, p.x, p.y - 20, 'A WARD BLOOMS', '#c9b0f2', 5, true);
    burst(G, p.x, p.y, '#c9b0f2', 9, 60, { glow: true });
    G.audio.sfx('reflect', 0.85, 0.5);
  }
  if (el) applyElement(G, p, el, 0.8, 'enemy');
  shake(G, 2.5);
  G.audio.sfx('hurt');
  addText(G, p.x, p.y - 10, `-${d}`, '#ff5a5a', 6);
  G.cb.playerHit(d, el);
  if (p.hp <= 0) {
    p.hp = 0; p.dead = true;
    G.audio.sfx('die');
    slowmo(G, 0.9, 0.15);
  }
}

// ---------- bullets ----------
export type BulletOpts = Partial<Bullet>;

export function makeBullet(G: GameCtx, o: BulletOpts): Bullet | null {
  if (G.bullets.length >= MAX_BULLETS) return null;
  const b: Bullet = {
    x: o.x ?? 0, y: o.y ?? 0, vx: o.vx ?? 0, vy: o.vy ?? 0, r: o.r ?? 3,
    dmg: o.dmg ?? 5, el: o.el ?? 'arcane', el2: o.el2 ?? null, team: o.team ?? 'enemy',
    life: o.life ?? 3, maxLife: o.life ?? 3, t: 0,
    kind: o.kind ?? 'bolt',
    pierce: o.pierce ?? 0,
    homing: o.homing ?? 0, accel: o.accel ?? 0,
    color: o.color ?? elColor(o.el ?? 'arcane'), color2: o.color2 ?? elColor2(o.el ?? 'arcane'),
    parryable: o.parryable ?? false,
    passWalls: o.passWalls ?? false,
    trail: o.trail ?? 0.4, spin: o.spin ?? 0,
    boomR: o.boomR ?? 0, boomDmg: o.boomDmg ?? 0,
    hp: o.hp ?? 0, destructible: o.destructible ?? false,
    zigzag: o.zigzag ?? 0, gravity: o.gravity ?? 0,
    seed: rand(0, 1000),
    hit: new Set<Ent>(), from: o.from ?? null,
    potency: o.potency ?? 1, dead: false,
    boomerang: o.boomerang,
    orbit: o.orbit,
    onBoomEl: o.onBoomEl,
  };
  G.bullets.push(b);
  return b;
}

function nearestFoe(G: GameCtx, b: Bullet): Ent | null {
  if (b.team === 'player') {
    let best: Ent | null = null, bd = 220 * 220;
    for (const e of G.enemies) {
      if (e.dead) continue;
      const d = dist2(b.x, b.y, e.x, e.y);
      if (d < bd) { bd = d; best = e; }
    }
    if (G.boss && !G.boss.dead) {
      const d = dist2(b.x, b.y, G.boss.x, G.boss.y);
      if (d < bd) { bd = d; best = G.boss; }
    }
    return best;
  }
  if (!G.player.dead && G.mode !== 'dead') return G.player;
  for (const m of G.minions) { if (!m.dead) return m; }
  return null;
}

function bulletBoom(G: GameCtx, b: Bullet): void {
  if (b.team === 'player') schoolProjBoom(G, b);
  if (b.boomR > 0) {
    explosion(G, b.x, b.y, b.boomR, b.boomDmg, b.el, b.team, { color: b.color, from: b.from, el2: b.el2, potency: b.potency });
  } else {
    burst(G, b.x, b.y, b.color, 4, 70, { life: 0.3, size: 2 });
  }
}

// ============================================================
// SCHOOL SIGNATURES — what makes each path unique in play
// ============================================================
export function schoolLvlOf(G: GameCtx, el: ElementId): number {
  return G.prog.schools[el]?.lvl ?? 1;
}

function microBoom(G: GameCtx, x: number, y: number, r: number, dmg: number, el: ElementId, from: Ent | null, skip: Ent | null): void {
  burst(G, x, y, elColor(el), 6, r * 3.4, { life: 0.3, size: 2.6, glow: true });
  addRing(G, x, y, r * 0.3, r * 3, elColor(el), 0.22, 1.5);
  if (dmg <= 0) return;
  for (const e of G.enemies) {
    if (e.dead || e === skip) continue;
    if (circleHit(x, y, r, e.x, e.y, e.r)) damageEnemy(G, e, dmg, el, { from });
  }
  const bo = G.boss;
  if (bo && !bo.dead && bo.state !== 'intro' && bo !== skip && circleHit(x, y, r, bo.x, bo.y, bo.r)) {
    damageBoss(G, bo, dmg, el);
  }
}

function chainLightning(G: GameCtx, b: Bullet, dmg: number): void {
  const storm = G.prog.cls === 'stormcaller';
  const jumps = 1 + Math.floor(schoolLvlOf(G, 'lightning') / 8) + (storm ? 1 : 0);
  const chainMul = storm ? 0.525 : 0.42;
  let px = b.x, py = b.y;
  const struck = new Set<Ent>([...(b.hit ?? [])]);
  for (let j = 0; j < jumps; j++) {
    let best: Enemy | null = null, bd = 100 * 100;
    for (const e of G.enemies) {
      if (e.dead || struck.has(e)) continue;
      const d = dist2(px, py, e.x, e.y);
      if (d < bd) { bd = d; best = e; }
    }
    if (!best) break;
    struck.add(best);
    const ang = angTo(px, py, best.x, best.y);
    addBeam(G, px, py, ang, dist(px, py, best.x, best.y), 2.5, 'lightning', 0.14);
    damageEnemy(G, best, dmg * chainMul, 'lightning', { from: b.from });
    px = best.x; py = best.y;
  }
  G.audio.sfx('zap', randR(1.2, 1.6), 0.4);
}

// extra effect when a PLAYER projectile hits a foe
export function schoolProjHit(G: GameCtx, b: Bullet, e: Ent, dmg: number): void {
  const p = G.player;
  switch (b.el) {
    case 'fire':
      microBoom(G, b.x, b.y, 15 + b.r * 1.5, dmg * 0.3, 'fire', b.from, e);
      break;
    case 'lightning':
      chainLightning(G, b, dmg);
      break;
    case 'earth': {
      const a = angTo(p.x, p.y, e.x, e.y);
      e.vx += Math.cos(a) * 240; e.vy += Math.sin(a) * 240;
      microBoom(G, b.x, b.y, 17, 0, 'earth', b.from, e);
      if (e.st.stun || e.st.root) {
        addText(G, e.x, e.y - 12, 'CRUSH', '#e0c896', 6, true);
        damageEnemy2(G, e, dmg * 0.5, b, 'earth');
      }
      break;
    }
    case 'wind': {
      const a = angTo(p.x, p.y, e.x, e.y);
      e.vx += Math.cos(a) * 320; e.vy += Math.sin(a) * 320;
      burst(G, b.x, b.y, elColor2('wind'), 4, 90);
      break;
    }
    case 'water': {
      burst(G, b.x, b.y, elColor2('water'), 6, 70, { glow: true });
      for (const o of G.enemies) {
        if (!o.dead && dist(o.x, o.y, b.x, b.y) < 34) applyElement(G, o, 'water', 0.8, 'player');
      }
      break;
    }
    case 'poison':
      if (G.zones.length < 34) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 15, dur: 2.4, el: 'poison', team: 'player', dmg: dmg * 0.16, tick: 0.5, owner: b.from });
      }
      break;
    case 'shadow':
      if (chance(0.3)) {
        e.st.fear = { t: 1.5 };
        burst(G, e.x, e.y, '#7a5ea8', 5, 50, { glow: true });
      }
      break;
    case 'death': {
      // souls stream back to their master
      for (let i = 0; i < 3; i++) {
        spawnParticle(G, {
          x: e.x + randR(-4, 4), y: e.y + randR(-4, 4),
          vx: (p.x - e.x) * 1.4, vy: (p.y - e.y) * 1.4 - 30,
          life: 0.55, size: 2, color: '#dfe8dc', glow: true,
        });
      }
      break;
    }
    case 'radiant': {
      burst(G, b.x, b.y, '#fff8d8', 5, 60, { glow: true });
      if ((e as Enemy).undead) p.hp = Math.min(p.maxHp, p.hp + 1);
      break;
    }
    case 'arcane': {
      // split into seeking motes
      if (b.r >= 4 || chance(0.25)) {
        for (let i = 0; i < 2; i++) {
          const a = rand(0, TAU);
          makeBullet(G, {
            x: b.x, y: b.y, vx: Math.cos(a) * 150, vy: Math.sin(a) * 150,
            r: 2, dmg: dmg * 0.28, el: 'arcane', el2: b.el2, team: 'player', life: 1.1,
            kind: 'bolt', homing: 4, color: elColor('arcane'), color2: elColor2('arcane'),
            trail: 0.5, from: b.from,
          });
        }
      }
      break;
    }
    case 'time':
      if (G.zones.length < 34) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 22, dur: 2.2, el: 'time', team: 'player', dmg: dmg * 0.08, tick: 0.6 });
      }
      break;
    case 'void': {
      for (const o of G.enemies) {
        if (o.dead || o === e) continue;
        const d = dist(o.x, o.y, b.x, b.y);
        if (d < 62 && d > 4) {
          const a = angTo(o.x, o.y, b.x, b.y);
          o.vx += Math.cos(a) * 220; o.vy += Math.sin(a) * 220;
        }
      }
      addRing(G, b.x, b.y, 4, 90, elColor('void'), 0.3, 1.5);
      break;
    }
    case 'nature': {
      if (chance(0.4)) e.st.root = { t: Math.max(e.st.root?.t ?? 0, 1.2) };
      burst(G, b.x, b.y, elColor2('nature'), 4, 50, { glow: true });
      p.hp = Math.min(p.maxHp, p.hp + 0.8);
      break;
    }
    case 'chaos': {
      applyElement(G, e, pick(['fire', 'frost', 'lightning', 'earth', 'wind', 'water', 'poison', 'shadow', 'void', 'nature', 'blood', 'arcane'] as ElementId[]), 1, 'player');
      // WILD MAGIC: hits can erupt into full random rituals
      if (chance(0.08) && schoolLvlOf(G, 'chaos') >= 4 && wildRitual) {
        const ritualEl = pick(['fire', 'frost', 'lightning', 'earth', 'void', 'shadow', 'radiant', 'nature'] as ElementId[]);
        addText(G, b.x, b.y - 16, 'WILD MAGIC!', '#e85eb8', 6, true);
        wildRitual(G, ritualEl, b.x, b.y, dmg * 0.6, 0.6);
      }
      break;
    }
    case 'crystal': {
      // REFRACTION: impacts split into two new shard angles
      if (b.r >= 3 && G.bullets.length < 900) {
        const ba = Math.atan2(b.vy, b.vx);
        for (const da of [-0.55, 0.55]) {
          // offset spawn so shards escape the foe they refracted from
          makeBullet(G, {
            x: b.x + Math.cos(ba + da) * 9, y: b.y + Math.sin(ba + da) * 9,
            vx: Math.cos(ba + da) * 250, vy: Math.sin(ba + da) * 250,
            r: 2, dmg: dmg * 0.35, el: 'crystal', el2: b.el2, team: 'player', life: 1,
            kind: 'shard', color: elColor('crystal'), color2: elColor2('crystal'),
            trail: 0.3, from: b.from,
          });
        }
        G.audio.sfx('prism', randR(1.1, 1.5), 0.35);
      }
      break;
    }
    case 'metal': {
      // steel rings on impact
      addRing(G, b.x, b.y, 3, 110, elColor2('metal'), 0.2, 1.2);
      break;
    }
    case 'gravity': {
      // MASS COLLAPSE: the impact is a crush point — everything gets dragged in
      for (const o of G.enemies) {
        if (o.dead || o === e) continue;
        const d = dist(o.x, o.y, b.x, b.y);
        if (d < 66 && d > 4) {
          const a = angTo(o.x, o.y, b.x, b.y);
          o.vx += Math.cos(a) * 300; o.vy += Math.sin(a) * 300;
        }
      }
      addRing(G, b.x, b.y, 3, 100, elColor('gravity'), 0.28, 1.5);
      if ((e as Enemy).elite) {
        addText(G, e.x, e.y - 12, 'SLAMMED', '#dfe8ff', 5, true);
        damageEnemy2(G, e, dmg * 0.4, b, 'gravity');
        if (e.st) e.st.stun = { t: 0.5 };
      }
      break;
    }
    case 'sound': {
      // STAGGER: the shockwave interrupts whatever they were doing
      if (e.st) e.st.stun = { t: Math.max(e.st.stun?.t ?? 0, 0.3) };
      addRing(G, b.x, b.y, 2, 120, elColor2('sound'), 0.22, 1.5);
      burst(G, b.x, b.y, '#ffffff', 3, 60, { glow: true });
      break;
    }
    case 'bone': {
      // OSSIFY: armor cracks — everything hurts them more
      if (e.st) {
        const cur = e.st.amp;
        if (!cur || cur.mult < 1.15) e.st.amp = { t: 3.5, mult: 1.15 };
        else cur.t = Math.max(cur.t, 3.5);
      }
      burst(G, b.x, b.y, elColor('bone'), 3, 50, { glow: true });
      break;
    }
    case 'beast': {
      // PACK MARKS: 3 marks and a spirit beast lunges from you
      if (e.st) {
        const mk = e.st.packMark ?? { n: 0, t: 0 };
        mk.n++; mk.t = 4.5;
        e.st.packMark = mk;
        if (mk.n >= 3) {
          mk.n = 0;
          const a = angTo(p.x, p.y, e.x, e.y);
          makeBullet(G, {
            x: p.x, y: p.y, vx: Math.cos(a) * 420, vy: Math.sin(a) * 420,
            r: 3.4, dmg: dmg * 1.6, el: 'beast', el2: b.el2, team: 'player', life: 0.7,
            kind: 'shard', homing: 3, color: '#c97e4e', color2: '#ffd9a8', trail: 0.7, from: p,
          });
          addText(G, e.x, e.y - 14, 'LUNGE!', '#ffd9a8', 5, true);
          G.audio.sfx('roar', 1.8, 0.3);
        }
      }
      break;
    }
    case 'plasma': {
      // STELLAR FUSION: burn AND arc from one star
      applyElement(G, e, 'fire', 0.9, 'player');
      // micro-arc to one nearby foe
      let best: Enemy | null = null, bd = 90 * 90;
      for (const o of G.enemies) {
        if (o.dead || o === e || (b.hit && b.hit.has(o))) continue;
        const d = dist2(b.x, b.y, o.x, o.y);
        if (d < bd) { bd = d; best = o; }
      }
      if (best) {
        addBeam(G, b.x, b.y, angTo(b.x, b.y, best.x, best.y), dist(b.x, b.y, best.x, best.y), 2, 'plasma', 0.14);
        damageEnemy(G, best, dmg * 0.3, 'plasma', { from: b.from });
      }
      burst(G, b.x, b.y, '#a8f2ff', 4, 70, { glow: true });
      break;
    }
    case 'mirror': {
      // mirrored twin: the spell answers from your other side
      if (b.r >= 3 && G.bullets.length < 900 && chance(0.25)) {
        const a = angTo(p.x, p.y, e.x, e.y);
        makeBullet(G, {
          x: p.x - Math.cos(a) * 20, y: p.y - Math.sin(a) * 20,
          vx: Math.cos(a) * 260, vy: Math.sin(a) * 260,
          r: 2.4, dmg: dmg * 0.45, el: 'mirror', el2: b.el2, team: 'player', life: 1.2,
          kind: 'orb', color: elColor('mirror'), color2: elColor2('mirror'), trail: 0.35, from: p,
        });
        G.audio.sfx('prism', randR(1.4, 1.8), 0.3);
      }
      break;
    }
  }
}

// helper: secondary hit from a signature (counts hit so pierce doesn't re-trigger)
function damageEnemy2(G: GameCtx, e: Ent, dmg: number, b: Bullet, el: ElementId): void {
  damageEnemy(G, e as Enemy, dmg, el, { from: b.from });
}

// effect when a PLAYER projectile expires
export function schoolProjBoom(G: GameCtx, b: Bullet): void {
  switch (b.el) {
    case 'crystal':
      burst(G, b.x, b.y, elColor2('crystal'), 5, 60, { glow: true });
      break;
    case 'metal':
      burst(G, b.x, b.y, elColor2('metal'), 4, 70, { glow: true });
      addRing(G, b.x, b.y, 3, 90, elColor('metal'), 0.2, 1);
      break;
    case 'poison':
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 18, dur: 3, el: 'poison', team: 'player', dmg: b.dmg * 0.14, tick: 0.5, owner: b.from });
      }
      break;
    case 'water':
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 22, dur: 2.6, el: 'water', team: 'player', dmg: 0, tick: 0.6 });
      }
      break;
    case 'void':
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 26, dur: 2, el: 'void', team: 'player', dmg: b.dmg * 0.1, tick: 0.4 });
      }
      break;
    case 'nature':
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 16, dur: 4, el: 'nature', team: 'player', dmg: 0, tick: 1.2 });
      }
      break;
    case 'frost':
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 16, dur: 2, el: 'frost', team: 'player', dmg: 0, tick: 0.5 });
      }
      break;
    case 'arcane':
      if (chance(0.3)) {
        for (let i = 0; i < 2; i++) {
          const a = rand(0, TAU);
          makeBullet(G, {
            x: b.x, y: b.y, vx: Math.cos(a) * 140, vy: Math.sin(a) * 140,
            r: 2, dmg: b.dmg * 0.25, el: 'arcane', el2: b.el2, team: 'player', life: 0.9,
            kind: 'bolt', homing: 4, color: elColor('arcane'), color2: elColor2('arcane'), trail: 0.5, from: b.from,
          });
        }
      }
      break;
    case 'sound': {
      // THE ECHO: the wave rings once more, backward, at 40% — smaller r=1.8 bullets never re-echo
      if (b.r >= 2.5 && G.bullets.length < 900) {
        const a = Math.atan2(b.vy, b.vx);
        makeBullet(G, {
          x: b.x, y: b.y, vx: -Math.cos(a) * 200, vy: -Math.sin(a) * 200,
          r: 1.8, dmg: b.dmg * 0.4, el: 'sound', el2: b.el2, team: 'player', life: 0.55,
          kind: 'wave', pierce: 99, color: elColor2('sound'), color2: '#ffffff', trail: 0.2, from: b.from,
        });
      }
      break;
    }
    case 'gravity':
      if (G.zones.length < 40) {
        const z = spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 26, dur: 1.8, el: 'gravity', team: 'player', dmg: b.dmg * 0.12, tick: 0.35 });
        z.potency = 2;
      }
      break;
    case 'bone':
      // the corpse of the spell hunts: two bone darts seek the next foe
      for (let i = 0; i < 2; i++) {
        const a = rand(0, TAU);
        makeBullet(G, {
          x: b.x, y: b.y, vx: Math.cos(a) * 170, vy: Math.sin(a) * 170,
          r: 2, dmg: b.dmg * 0.3, el: 'bone', el2: b.el2, team: 'player', life: 0.9,
          kind: 'shard', homing: 3.4, color: elColor('bone'), color2: elColor2('bone'), from: b.from,
        });
      }
      break;
    case 'beast':
      burst(G, b.x, b.y, elColor2('beast'), 5, 80, { glow: true });
      if (chance(0.15) && G.bullets.length < 900) {
        makeBullet(G, {
          x: b.x, y: b.y, vx: randR(-40, 40), vy: randR(-40, 40),
          r: 2.8, dmg: b.dmg * 0.3, el: 'beast', el2: b.el2, team: 'player', life: 0.8,
          kind: 'shard', homing: 2.6, color: elColor('beast'), color2: elColor2('beast'), trail: 0.5, from: b.from,
        });
      }
      break;
    case 'plasma':
      // the star melts the ground where it dies
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: b.x, y: b.y, r: 17, dur: 2.2, el: 'fire', team: 'player', dmg: b.dmg * 0.16, tick: 0.4 });
      }
      burst(G, b.x, b.y, '#a8f2ff', 4, 70, { glow: true });
      break;
    case 'mirror': {
      // HALL OF MIRRORS: expired spells reflect backward at half power (r 1.8 copies never re-reflect)
      if (b.r >= 2.5 && G.bullets.length < 900) {
        const a = Math.atan2(b.vy, b.vx);
        makeBullet(G, {
          x: b.x, y: b.y, vx: -Math.cos(a) * 230, vy: -Math.sin(a) * 230,
          r: 1.8, dmg: b.dmg * 0.5, el: 'mirror', el2: b.el2, team: 'player', life: 1,
          kind: 'orb', color: elColor2('mirror'), color2: '#ffffff', trail: 0.3, from: b.from,
        });
      }
      break;
    }
  }
}

// on-kill signature (called from handleEnemyDeath)
export function schoolKill(G: GameCtx, e: Enemy, el: ElementId): void {
  const p = G.player;
  const sl = schoolLvlOf(G, el);
  switch (el) {
    case 'fire': {
      // CHAIN DETONATION: the slain erupt and set the ground ablaze
      explosion(G, e.x, e.y, 26 + sl * 0.5, 6 + sl * 1.1, 'fire', 'player', { from: p });
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: e.x, y: e.y, r: 20, dur: 2.6, el: 'fire', team: 'player', dmg: 3 + sl * 0.35, tick: 0.4 });
      }
      break;
    }
    case 'poison': {
      // CONTAGION: heavily rotted corpses burst and infect neighbors
      const stacks = e.st.plague?.n ?? 1;
      if (G.zones.length < 40) spawnZone(G, { kind: 'field', x: e.x, y: e.y, r: 26 + stacks * 2, dur: 2.6, el: 'poison', team: 'player', dmg: 2.5 + sl * 0.3 + stacks, tick: 0.45 });
      if (stacks >= 3) {
        addText(G, e.x, e.y - 14, 'CONTAGION', '#8ed94e', 5, true);
        for (const o of G.enemies) {
          if (!o.dead && o !== e && dist(o.x, o.y, e.x, e.y) < 70) {
            applyElement(G, o, 'poison', 2, 'player');
          }
        }
      }
      break;
    }
    case 'shadow':
      for (const o of G.enemies) {
        if (!o.dead && dist(o.x, o.y, e.x, e.y) < 74 && chance(0.4)) o.st.fear = { t: 1.1 };
      }
      burst(G, e.x, e.y, '#7a5ea8', 10, 80, { glow: true });
      break;
    case 'radiant':
      if (e.undead) {
        p.hp = Math.min(p.maxHp, p.hp + 4);
        addText(G, p.x, p.y - 12, '+4', '#fff8d8', 5);
        addBeam(G, e.x, e.y - 40, Math.PI / 2, 44, 6, 'radiant', 0.25);
      }
      // SANCTUARY: hallowed ground blooms where evil fell
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: e.x, y: e.y, r: 24, dur: 3, el: 'radiant', team: 'player', dmg: 0, tick: 0.5 });
      }
      break;
    case 'nature': {
      // SPORE PODS: the slain bloom into healing ground
      p.hp = Math.min(p.maxHp, p.hp + 2);
      burst(G, e.x, e.y, '#b8e89e', 8, 60, { glow: true, dir: -Math.PI / 2, spread: 1 });
      if (G.zones.length < 40) {
        spawnZone(G, { kind: 'field', x: e.x, y: e.y, r: 20, dur: 4, el: 'nature', team: 'player', dmg: 0, tick: 0.6 });
      }
      break;
    }
    case 'blood':
      p.hp = Math.min(p.maxHp, p.hp + 2);
      for (let i = 0; i < 3; i++) {
        spawnParticle(G, { x: e.x, y: e.y, vx: (p.x - e.x) * 1.2, vy: (p.y - e.y) * 1.2, life: 0.5, size: 2, color: '#d94e5e', glow: true });
      }
      break;
    case 'arcane':
      p.mana = Math.min(p.maxMana, p.mana + 2);
      break;
    case 'lightning':
      burst(G, e.x, e.y, '#fffbd0', 8, 110, { glow: true });
      addRing(G, e.x, e.y, 4, 140, elColor('lightning'), 0.22, 1.5);
      break;
    case 'frost': {
      burst(G, e.x, e.y, '#cfeefc', 10, 90, { glow: true });
      for (const o of G.enemies) {
        if (!o.dead && dist(o.x, o.y, e.x, e.y) < 46 && chance(0.3)) o.st.chill = { t: 1.6, mult: 0.5 };
      }
      break;
    }
    case 'water':
      burst(G, e.x, e.y, elColor2('water'), 8, 80, { glow: true });
      for (const o of G.enemies) {
        if (!o.dead && dist(o.x, o.y, e.x, e.y) < 40) applyElement(G, o, 'water', 0.7, 'player');
      }
      break;
    case 'earth':
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * TAU + randR(0, 1);
        makeBullet(G, {
          x: e.x, y: e.y, vx: Math.cos(a) * 190, vy: Math.sin(a) * 190,
          r: 2.5, dmg: 3 + sl * 0.4, el: 'earth', el2: null, team: 'player', life: 0.7,
          kind: 'shard', color: elColor('earth'), color2: elColor2('earth'), from: p,
        });
      }
      break;
    case 'void': {
      addRing(G, e.x, e.y, 6, 160, elColor('void'), 0.35, 2);
      for (const o of G.enemies) {
        if (!o.dead) {
          const d = dist(o.x, o.y, e.x, e.y);
          if (d < 80) { const a = angTo(o.x, o.y, e.x, e.y); o.vx += Math.cos(a) * 170; o.vy += Math.sin(a) * 170; }
        }
      }
      // SWALLOWED: the abyss spits out essence when it eats
      if (chance(0.3)) spawnPickup(G, 'aether', e.x, e.y, Math.max(1, Math.round(e.kind.aether * 0.4)));
      break;
    }
    case 'wind': {
      burst(G, e.x, e.y, elColor2('wind'), 8, 100);
      for (const o of G.enemies) {
        if (!o.dead) {
          const d = dist(o.x, o.y, e.x, e.y);
          if (d < 70) { const a = angTo(e.x, e.y, o.x, o.y); o.vx += Math.cos(a) * 200; o.vy += Math.sin(a) * 200; }
        }
      }
      break;
    }
    case 'time':
      burst(G, e.x, e.y, '#fff2c9', 8, 70, { glow: true });
      p.buffHaste = Math.max(p.buffHaste, 1.2);
      break;
    case 'chaos':
      schoolKill(G, e, pick(['fire', 'poison', 'shadow', 'lightning', 'frost', 'crystal', 'void'] as ElementId[]));
      break;
    case 'crystal': {
      burst(G, e.x, e.y, '#f28ac9', 12, 110, { glow: true });
      addRing(G, e.x, e.y, 5, 150, elColor2('crystal'), 0.3, 2);
      for (let i = 0; i < 3; i++) {
        const a = rand(0, TAU);
        makeBullet(G, {
          x: e.x, y: e.y, vx: Math.cos(a) * 220, vy: Math.sin(a) * 220,
          r: 2.2, dmg: 3 + sl * 0.5, el: 'crystal', el2: null, team: 'player', life: 1,
          kind: 'shard', color: elColor('crystal'), color2: elColor2('crystal'), from: p,
        });
      }
      break;
    }
    case 'metal': {
      G.audio.sfx('clang', randR(0.9, 1.3), 0.7);
      burst(G, e.x, e.y, '#f2f7fa', 10, 120, { glow: true });
      addRing(G, e.x, e.y, 4, 170, elColor('metal'), 0.28, 2);
      // shrapnel volley
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * TAU + randR(0, 1);
        makeBullet(G, {
          x: e.x, y: e.y, vx: Math.cos(a) * 200, vy: Math.sin(a) * 200,
          r: 2.2, dmg: 3 + sl * 0.45, el: 'metal', el2: null, team: 'player', life: 0.8,
          kind: 'shard', color: elColor('metal'), color2: elColor2('metal'), from: p,
        });
      }
      break;
    }
    case 'death':
      for (let i = 0; i < 5; i++) {
        spawnParticle(G, {
          x: e.x + randR(-5, 5), y: e.y + randR(-5, 5),
          vx: (p.x - e.x) * randR(0.8, 1.6), vy: (p.y - e.y) * randR(0.8, 1.6) - 40,
          life: 0.6, size: 2.2, color: '#e2e8dc', glow: true,
        });
      }
      break;
    case 'gravity': {
      // IMPLOSION: the kill site becomes a gravity scar that drags and stuns
      addRing(G, e.x, e.y, 6, 170, elColor('gravity'), 0.35, 2);
      for (const o of G.enemies) {
        if (!o.dead) {
          const d = dist(o.x, o.y, e.x, e.y);
          if (d < 90) { const a = angTo(o.x, o.y, e.x, e.y); o.vx += Math.cos(a) * 280; o.vy += Math.sin(a) * 280; if (d < 40 && o.st) o.st.stun = { t: 0.4 }; }
        }
      }
      if (chance(0.2)) spawnPickup(G, 'aether', e.x, e.y, Math.max(1, Math.round(e.kind.aether * 0.3)));
      break;
    }
    case 'sound': {
      // SONIC RUPTURE: the death-cry knocks everyone back
      addRing(G, e.x, e.y, 4, 200, elColor2('sound'), 0.3, 2);
      for (const o of G.enemies) {
        if (!o.dead) {
          const d = dist(o.x, o.y, e.x, e.y);
          if (d < 74) { const a = angTo(e.x, e.y, o.x, o.y); o.vx += Math.cos(a) * 230; o.vy += Math.sin(a) * 230; }
        }
      }
      break;
    }
    case 'bone': {
      // THE OSSUARY CLAIMS: two darts hunt the killer's kin
      burst(G, e.x, e.y, elColor('bone'), 8, 70, { glow: true });
      for (let i = 0; i < 2; i++) {
        const a = rand(0, TAU);
        makeBullet(G, {
          x: e.x, y: e.y, vx: Math.cos(a) * 200, vy: Math.sin(a) * 200,
          r: 2.2, dmg: 3 + sl * 0.5, el: 'bone', el2: null, team: 'player', life: 1,
          kind: 'shard', homing: 3, color: elColor('bone'), color2: elColor2('bone'), from: p,
        });
      }
      break;
    }
    case 'beast': {
      // PACK HOWL: you surge, the next foe is marked twice
      burst(G, e.x, e.y, '#ffd9a8', 9, 90, { glow: true });
      p.buffHaste = Math.max(p.buffHaste, 1);
      let near: Enemy | null = null, nd = 140 * 140;
      for (const o of G.enemies) {
        if (o.dead || o === e) continue;
        const d = dist2(e.x, e.y, o.x, o.y);
        if (d < nd) { nd = d; near = o; }
      }
      if (near) near.st.packMark = { n: 2, t: 4 };
      break;
    }
    case 'plasma': {
      // the star goes nova: burn everything nearby
      explosion(G, e.x, e.y, 24 + sl * 0.5, 5 + sl * 0.9, 'plasma', 'player', { from: p });
      for (const o of G.enemies) {
        if (!o.dead && dist(o.x, o.y, e.x, e.y) < 44) applyElement(G, o, 'fire', 0.7, 'player');
      }
      break;
    }
    case 'mirror': {
      // SHATTER: glass shards fly; the reflection pays you back
      burst(G, e.x, e.y, elColor2('mirror'), 10, 100, { glow: true });
      for (let i = 0; i < 3; i++) {
        const a = rand(0, TAU);
        makeBullet(G, {
          x: e.x, y: e.y, vx: Math.cos(a) * 230, vy: Math.sin(a) * 230,
          r: 2.2, dmg: 3 + sl * 0.45, el: 'mirror', el2: null, team: 'player', life: 0.9,
          kind: 'shard', color: elColor('mirror'), color2: elColor2('mirror'), from: p,
        });
      }
      p.mana = Math.min(p.maxMana, p.mana + 1);
      break;
    }
  }
}

// reflected parry hits rattle a boss's stagger meter
function parryStaggerBonus(bo: unknown): void {
  const b = bo as { stagger?: number } | null;
  if (b && typeof b.stagger === 'number') b.stagger = Math.min(100, b.stagger + 6);
}

export function updateBullets(G: GameCtx, dt: number): void {
  const p = G.player;
  for (const b of G.bullets) {
    if (b.dead) continue;
    b.t += dt;
    if (b.t >= b.life) { b.dead = true; bulletBoom(G, b); continue; }
    if (b.homing > 0) {
      const foe = nearestFoe(G, b);
      if (foe) {
        const want = angTo(b.x, b.y, foe.x, foe.y);
        const cur = Math.atan2(b.vy, b.vx);
        const d = ((want - cur + Math.PI * 3) % TAU) - Math.PI;
        const na = cur + clamp(d, -b.homing * dt, b.homing * dt);
        const sp = Math.hypot(b.vx, b.vy);
        b.vx = Math.cos(na) * sp; b.vy = Math.sin(na) * sp;
      }
    }
    if (b.zigzag !== 0) {
      const perp = Math.atan2(b.vy, b.vx) + Math.PI / 2;
      const mag = Math.sin(b.t * 10 + b.seed) * b.zigzag;
      b.x += Math.cos(perp) * mag * dt * 30;
      b.y += Math.sin(perp) * mag * dt * 30;
    }
    // blood school: boomerang return flight (hits again on the way back)
    if (b.boomerang && b.from && !b.from.dead) {
      if (b.t > 0.42 && b.hit.size > 0) { b.hit.clear(); burst(G, b.x, b.y, '#ffb0b8', 3, 50); }
      const ba = angTo(b.x, b.y, b.from.x, b.from.y);
      const bsp = Math.min(420, Math.hypot(b.vx, b.vy) + 380 * dt);
      b.vx = Math.cos(ba) * bsp; b.vy = Math.sin(ba) * bsp;
    }
    // metal school: ORBIT the caster like whirling steel, reaping all around
    if (b.orbit && b.from && !b.from.dead) {
      b.orbit.ang += b.orbit.spin * dt;
      const rad = b.orbit.rad + Math.sin(b.t * 3 + b.seed) * 5;
      b.x = b.from.x + Math.cos(b.orbit.ang) * rad;
      b.y = b.from.y + Math.sin(b.orbit.ang) * rad - 2;
      // let orbiting blades re-hit the same foes periodically
      if (b.t > 0.4 && b.hit.size > 0 && Math.floor(b.t * 2) !== Math.floor((b.t - dt) * 2)) {
        b.hit.clear();
      }
      const ta = b.orbit.ang + Math.PI / 2 * Math.sign(b.orbit.spin);
      b.vx = Math.cos(ta) * 160; b.vy = Math.sin(ta) * 160;
      // in the final moments the blades fling outward
      if (b.life - b.t < 0.35) {
        const fa = Math.atan2(b.y - b.from.y, b.x - b.from.x);
        b.vx = Math.cos(fa) * 330; b.vy = Math.sin(fa) * 330;
        b.orbit = undefined;
      }
      if (G.frame % 3 === 0) {
        spawnParticle(G, { x: b.x, y: b.y, vx: 0, vy: 0, life: 0.16, size: 1.6, color: b.color2, glow: true });
      }
    }
    if (b.accel !== 0) {
      const sp = Math.hypot(b.vx, b.vy);
      const ns = Math.max(10, sp + b.accel * dt);
      if (sp > 0) { b.vx = (b.vx / sp) * ns; b.vy = (b.vy / sp) * ns; }
    }
    b.vy += b.gravity * dt;
    b.x += b.vx * dt; b.y += b.vy * dt;

    if (b.trail > 0 && G.frame % 2 === 0) {
      spawnParticle(G, {
        x: b.x, y: b.y, vx: randR(-8, 8), vy: randR(-8, 8),
        life: 0.28, size: b.r * 0.7, color: b.color2, glow: true,
      });
    }

    // walls
    if (!b.passWalls && G.world.solidAt(b.x, b.y)) {
      b.dead = true; bulletBoom(G, b); continue;
    }

    if (b.team === 'player') {
      // vs enemies
      for (const e of G.enemies) {
        if (e.dead || b.hit.has(e)) continue;
        if (circleHit(b.x, b.y, b.r, e.x, e.y, e.r)) {
          b.hit.add(e);
          const crit = chance(0.08);
          // CRYSTALLOMANCY: shards that flew far enough arrive as PRISMS
          const prism = b.el === 'crystal' && b.t > 0.55;
          const dealt = b.dmg * (crit ? 1.6 : 1) * (prism ? 1.5 : 1);
          damageEnemy(G, e, dealt, b.el, { crit, from: b.from });
          if (b.el2) applyElement(G, e, b.el2, 0.45 * b.potency, 'player');
          schoolProjHit(G, b, e, dealt);
          if (prism) { addText(G, e.x, e.y - 18, 'PRISM!', '#ffe8f7', 6, true); G.audio.sfx('prism', 1, 0.7); }
          burst(G, b.x, b.y, b.reflected ? '#ffd75e' : b.color, b.reflected ? 9 : 5, b.reflected ? 110 : 80);
          G.audio.sfx('hit', randR(0.9, 1.2) + (b.reflected ? 0.3 : 0), 0.7);
          if (b.pierce <= 0) { b.dead = true; bulletBoom(G, b); break; }
          b.pierce--;
        }
      }
      // vs boss
      const bo = G.boss;
      if (!b.dead && bo && !bo.dead && bo.state !== 'intro' && !b.hit.has(bo)) {
        if (circleHit(b.x, b.y, b.r, bo.x, bo.y, bo.r)) {
          b.hit.add(bo);
          const crit = chance(0.08);
          const dealt = b.dmg * (crit ? 1.6 : 1) * (b.reflected ? 1.4 : 1);
          damageBoss(G, bo, dealt, b.el, crit);
          if (b.reflected) parryStaggerBonus(bo);
          if (b.el2) applyElement(G, bo, b.el2, 0.45 * b.potency, 'player');
          schoolProjHit(G, b, bo, dealt);
          burst(G, b.x, b.y, b.reflected ? '#ffd75e' : b.color, b.reflected ? 10 : 6, 90);
          G.audio.sfx('hit', 0.8, 0.9);
          if (b.pierce <= 0) { b.dead = true; bulletBoom(G, b); }
          else b.pierce--;
        }
      }
      // vs destructible enemy bullets
      if (!b.dead) {
        for (const ob of G.bullets) {
          if (ob.dead || ob.team === 'player' || !ob.destructible || ob.hp <= 0) continue;
          if (circleHit(b.x, b.y, b.r, ob.x, ob.y, ob.r)) {
            ob.hp -= b.dmg;
            burst(G, ob.x, ob.y, ob.color, 3, 60);
            if (ob.hp <= 0) { ob.dead = true; explosion(G, ob.x, ob.y, 14, 0, ob.el, 'enemy', { color: ob.color, noDmg: true }); }
            if (b.pierce <= 0) { b.dead = true; break; }
            b.pierce--;
          }
        }
      }
    } else {
      // enemy bullets vs player — with TOUHOU GRAZE: threading a bullet
      // without getting hit feeds your mana and your ego
      const dxB = b.x - p.x, dyB = b.y - p.y;
      const dSq = dxB * dxB + dyB * dyB;
      const hitR = p.r + b.r;
      if (!b.grazed && !b.hit.has(p) && !p.dead) {
        const grazeR = hitR + 9;
        if (dSq < grazeR * grazeR && dSq > hitR * hitR * 0.55) {
          b.grazed = true;
          if (p.iframes <= 0 || dSq > hitR * hitR) {
            p.mana = Math.min(p.maxMana, p.mana + 1.1 + relicVal(G, 'grazeMana'));
            bumpCombo(G);
            spawnParticle(G, {
              x: b.x, y: b.y, vx: randR(-40, 40), vy: randR(-70, -20),
              life: 0.3, size: 1.6, color: '#ffd75e', glow: true,
            });
            if (G.frame % 5 === 0) G.audio.sfx('graze', randR(1.5, 1.9), 0.22);
          }
        }
      }
      if (!p.dead && p.iframes <= 0 && !b.hit.has(p) && dSq <= hitR * hitR) {
        b.hit.add(p);
        damagePlayer(G, b.dmg, b.el);
        if (b.el2) applyElement(G, p, b.el2, 0.4, 'enemy');
        burst(G, b.x, b.y, b.color, 6, 90);
        if (b.pierce <= 0) { b.dead = true; bulletBoom(G, b); }
        else b.pierce--;
      }
      // vs minions
      if (!b.dead) {
        for (const m of G.minions) {
          if (m.dead || b.hit.has(m)) continue;
          if (circleHit(b.x, b.y, b.r, m.x, m.y, m.r)) {
            b.hit.add(m);
            damageMinion(G, m, b.dmg * 0.6, b.el);
            if (b.pierce <= 0) { b.dead = true; bulletBoom(G, b); break; }
            b.pierce--;
          }
        }
      }
    }
  }
  // compact
  let w = 0;
  for (let i = 0; i < G.bullets.length; i++) {
    if (!G.bullets[i].dead) G.bullets[w++] = G.bullets[i];
  }
  G.bullets.length = w;
}

// ---------- school bullet SHAPES ----------
// Every magic type has its own BODY — nobody mistakes cryo for hydro.
function poly(ctx: CanvasRenderingContext2D, pts: number[][]): void {
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.closePath();
}

function drawSchoolShape(G: GameCtx, b: Bullet, blink: number): void {
  const ctx = G.ctx;
  const t = b.t, seed = b.seed;
  const a = Math.atan2(b.vy, b.vx);
  const r = b.r;
  switch (b.el) {
    case 'fire': {
      // COMET: flickering layered tail, white-hot heart
      const fl = 0.7 + Math.sin(t * 22 + seed) * 0.3;
      ctx.globalAlpha = 0.32 * blink;
      ctx.fillStyle = '#ff5a2e';
      ctx.beginPath(); ctx.arc(b.x - Math.cos(a) * r * 1.5, b.y - Math.sin(a) * r * 1.5, r * 1.2, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.62 * blink * fl;
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.95, 0, TAU); ctx.fill();
      ctx.globalAlpha = blink;
      ctx.fillStyle = '#ffd75e';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.55, 0, TAU); ctx.fill();
      break;
    }
    case 'frost': {
      // HEX CRYSTAL: faceted shard with a star glint
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a + t * 3);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      poly(ctx, [[0, -r * 1.4], [r * 0.95, -r * 0.3], [r * 0.7, r], [-r * 0.7, r], [-r * 0.95, -r * 0.3]]); ctx.fill();
      ctx.globalAlpha = 0.9 * blink; ctx.strokeStyle = b.color2; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(0, -r * 1.2); ctx.lineTo(0, r * 0.8); ctx.stroke();
      ctx.restore();
      ctx.globalAlpha = 0.95 * blink; ctx.fillStyle = '#ffffff';
      ctx.fillRect(b.x - 0.8, b.y - r * 1.7, 1.6, 1.6);
      ctx.fillRect(b.x - r * 0.9, b.y - 0.8, 1.6, 1.6);
      break;
    }
    case 'lightning': {
      // JAGGED BOLT: a crackling zigzag with a blinding core
      ctx.globalAlpha = blink;
      ctx.strokeStyle = b.color; ctx.lineWidth = 1.6;
      ctx.beginPath();
      const segs = 4;
      let px = b.x - Math.cos(a) * r * 2.6, py = b.y - Math.sin(a) * r * 2.6;
      ctx.moveTo(px, py);
      for (let i = 1; i <= segs; i++) {
        const da = (Math.sin(t * 30 + seed * 7 + i * 2.4) * 0.5);
        px += Math.cos(a + da) * r * 1.3; py += Math.sin(a + da) * r * 1.3;
        ctx.lineTo(px, py);
      }
      ctx.stroke();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.7, 0, TAU); ctx.fill();
      break;
    }
    case 'earth': {
      // ROCK: chucked boulder with a lit rim
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(seed + t * 1.4);
      ctx.globalAlpha = blink; ctx.fillStyle = '#5e4a34';
      poly(ctx, [[-r, -r * 0.5], [-r * 0.4, -r], [r * 0.7, -r * 0.8], [r, r * 0.3], [r * 0.3, r], [-r * 0.7, r * 0.7]]); ctx.fill();
      ctx.globalAlpha = 0.8 * blink; ctx.strokeStyle = b.color2; ctx.lineWidth = 1;
      poly(ctx, [[-r, -r * 0.5], [-r * 0.4, -r], [r * 0.7, -r * 0.8], [r, r * 0.3], [r * 0.3, r], [-r * 0.7, r * 0.7]]); ctx.stroke();
      ctx.restore();
      break;
    }
    case 'wind': {
      // CRESCENT GALE: two curved blades of air
      ctx.globalAlpha = 0.9 * blink;
      ctx.strokeStyle = b.color; ctx.lineWidth = 1.6;
      for (const off of [-0.5, 0.5]) {
        ctx.beginPath();
        ctx.arc(b.x, b.y, r * (1.1 + off * 0.3), a - 1.1 + off, a + 1.1 + off);
        ctx.stroke();
      }
      ctx.globalAlpha = blink; ctx.fillStyle = b.color2;
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.4, 0, TAU); ctx.fill();
      break;
    }
    case 'water': {
      // DROPLET: a wobbling teardrop
      const wob = Math.sin(t * 12 + seed) * 0.18;
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a + Math.PI / 2);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      ctx.beginPath();
      ctx.moveTo(0, -r * 1.6);
      ctx.quadraticCurveTo(r * 1.1, r * 0.2 + wob * r, 0, r);
      ctx.quadraticCurveTo(-r * 1.1, r * 0.2 + wob * r, 0, -r * 1.6);
      ctx.fill();
      ctx.globalAlpha = 0.85 * blink; ctx.fillStyle = b.color2;
      ctx.beginPath(); ctx.arc(0, r * 0.1, r * 0.4, 0, TAU); ctx.fill();
      ctx.restore();
      break;
    }
    case 'poison': {
      // BUBBLING VESICLE: a blister with inner bubbles
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, r, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.9 * blink; ctx.fillStyle = b.color2;
      ctx.beginPath(); ctx.arc(b.x - r * 0.3, b.y - r * 0.25, r * 0.32, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.arc(b.x + r * 0.35, b.y + r * 0.3, r * 0.2 + Math.sin(t * 9 + seed) * 0.6, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.5 * blink;
      ctx.beginPath(); ctx.arc(b.x - Math.cos(a) * r * 1.6, b.y - Math.sin(a) * r * 1.6, r * 0.45, 0, TAU); ctx.fill();
      break;
    }
    case 'blood': {
      // VITAE ORB: heavy drop trailing drips
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, r, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.7 * blink;
      ctx.beginPath(); ctx.arc(b.x - Math.cos(a) * r * 1.7, b.y - Math.sin(a) * r * 1.7, r * 0.5, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.arc(b.x - Math.cos(a) * r * 2.9, b.y - Math.sin(a) * r * 2.9, r * 0.3, 0, TAU); ctx.fill();
      ctx.globalAlpha = blink; ctx.fillStyle = '#ffb0b8';
      ctx.beginPath(); ctx.arc(b.x + r * 0.25, b.y - r * 0.3, r * 0.35, 0, TAU); ctx.fill();
      break;
    }
    case 'shadow': {
      // WISP: a hole in the light trailing violet smoke
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 0.85 * blink; ctx.fillStyle = '#17101f';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.95, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.5 * blink; ctx.strokeStyle = b.color; ctx.lineWidth = 1.4;
      for (let i = 0; i < 2; i++) {
        const wob = Math.sin(t * 8 + seed + i * 2.6) * r * 0.8;
        ctx.beginPath();
        ctx.arc(b.x - Math.cos(a) * (r + i * 2.6), b.y - Math.sin(a) * (r + i * 2.6) + wob * 0.4, r * (0.8 - i * 0.25), 0, TAU);
        ctx.stroke();
      }
      ctx.globalAlpha = 0.85 * blink; ctx.fillStyle = b.color2;
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.35, 0, TAU); ctx.fill();
      break;
    }
    case 'death': {
      // SOUL FLAME: pale ghost-fire with hollow eyes
      const fl = 0.75 + Math.sin(t * 18 + seed) * 0.25;
      ctx.globalAlpha = 0.55 * blink * fl; ctx.fillStyle = '#9ee8d8';
      ctx.beginPath(); ctx.arc(b.x - Math.cos(a) * r * 0.9, b.y - Math.sin(a) * r * 0.9 - 1.5, r * 1.05, 0, TAU); ctx.fill();
      ctx.globalAlpha = blink; ctx.fillStyle = '#e2e8dc';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.9, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 0.9 * blink; ctx.fillStyle = '#2a2e2a';
      ctx.fillRect(b.x - r * 0.45, b.y - r * 0.25, r * 0.3, r * 0.4);
      ctx.fillRect(b.x + r * 0.15, b.y - r * 0.25, r * 0.3, r * 0.4);
      ctx.globalCompositeOperation = 'lighter';
      break;
    }
    case 'radiant': {
      // STAR FLARE: four-point cross + rotating halo
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(t * 2.4);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      poly(ctx, [[0, -r * 1.8], [r * 0.35, -r * 0.35], [r * 1.8, 0], [r * 0.35, r * 0.35], [0, r * 1.8], [-r * 0.35, r * 0.35], [-r * 1.8, 0], [-r * 0.35, -r * 0.35]]); ctx.fill();
      ctx.restore();
      ctx.globalAlpha = 0.7 * blink; ctx.strokeStyle = b.color2; ctx.lineWidth = 0.9;
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 1.4 + Math.sin(t * 6) * 0.8, 0, TAU); ctx.stroke();
      break;
    }
    case 'arcane': {
      // RUNESTAR: a pentagram star with an orbiting mote
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(t * 4);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      for (let i = 0; i < 5; i++) {
        const a1 = (i / 5) * TAU - Math.PI / 2;
        const a2 = ((i + 0.5) / 5) * TAU - Math.PI / 2;
        poly(ctx, [[0, 0], [Math.cos(a1) * r * 1.6, Math.sin(a1) * r * 1.6], [Math.cos(a2) * r * 0.7, Math.sin(a2) * r * 0.7]]);
        ctx.fill();
      }
      ctx.restore();
      const oa = t * 7 + seed;
      ctx.globalAlpha = blink; ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(b.x + Math.cos(oa) * r * 1.9, b.y + Math.sin(oa) * r * 1.9, 1.1, 0, TAU); ctx.fill();
      break;
    }
    case 'time': {
      // HOURFACE: a tiny clock with sweeping hands
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, r, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.9 * blink; ctx.strokeStyle = '#fff2c9'; ctx.lineWidth = 0.9;
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.95, 0, TAU); ctx.stroke();
      const ha = t * 5, ma = t * 9;
      ctx.beginPath();
      ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + Math.cos(ha) * r * 0.7, b.y + Math.sin(ha) * r * 0.7);
      ctx.moveTo(b.x, b.y); ctx.lineTo(b.x + Math.cos(ma) * r * 0.45, b.y + Math.sin(ma) * r * 0.45);
      ctx.stroke();
      break;
    }
    case 'void': {
      // ABYSS: a bite in reality with an accretion spiral
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 0.92 * blink; ctx.fillStyle = '#0d0812';
      ctx.beginPath(); ctx.arc(b.x, b.y, r, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.8 * blink; ctx.strokeStyle = b.color2; ctx.lineWidth = 1.2;
      ctx.beginPath();
      for (let i = 0; i <= 10; i++) {
        const sa = t * 6 + i * 0.55;
        const sr = r * (1.5 - i * 0.11);
        const sx = b.x + Math.cos(sa) * sr, sy = b.y + Math.sin(sa) * sr;
        if (i === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
      }
      ctx.stroke();
      break;
    }
    case 'nature': {
      // SEED LEAF: a spinning leaf with a vein
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a + Math.sin(t * 10 + seed) * 0.7);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.ellipse(0, 0, r * 1.35, r * 0.62, 0, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.85 * blink; ctx.strokeStyle = b.color2; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(-r * 1.2, 0); ctx.lineTo(r * 1.2, 0); ctx.stroke();
      ctx.restore();
      break;
    }
    case 'chaos': {
      // SHAPESHIFTER: sides mutate as it flies, colors war
      const sides = 3 + (Math.floor(t * 6 + seed) % 4);
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(t * 9);
      ctx.globalAlpha = blink; ctx.fillStyle = (Math.floor(t * 8) % 2) ? b.color : b.color2;
      ctx.beginPath();
      for (let i = 0; i <= sides; i++) {
        const pa = (i / sides) * TAU;
        const pr = r * (1.1 + Math.sin(pa * 2 + t * 12) * 0.3);
        const sx = Math.cos(pa) * pr, sy = Math.sin(pa) * pr;
        if (i === 0) ctx.moveTo(sx, sy); else ctx.lineTo(sx, sy);
      }
      ctx.closePath(); ctx.fill();
      ctx.restore();
      break;
    }
    case 'crystal': {
      // PRISM: an elongated diamond with a refraction line
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      poly(ctx, [[r * 2.1, 0], [0, -r * 0.8], [-r * 1.6, 0], [0, r * 0.8]]); ctx.fill();
      ctx.globalAlpha = 0.9 * blink; ctx.strokeStyle = b.color2; ctx.lineWidth = 0.8;
      poly(ctx, [[r * 2.1, 0], [0, -r * 0.8], [-r * 1.6, 0], [0, r * 0.8]]); ctx.stroke();
      ctx.restore();
      ctx.globalAlpha = 0.8 * blink; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.moveTo(b.x - Math.cos(a + 0.4) * r * 1.4, b.y - Math.sin(a + 0.4) * r * 1.4);
      ctx.lineTo(b.x + Math.cos(a - 0.4) * r * 1.4, b.y + Math.sin(a - 0.4) * r * 1.4); ctx.stroke();
      break;
    }
    case 'metal': {
      // WHIRLING BLADE: a sharpened spinner
      ctx.save(); ctx.translate(b.x, b.y);
      ctx.rotate(b.orbit ? -b.orbit.ang + t * 9 : a);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      poly(ctx, [[r * 2.2, 0], [r * 0.4, -r * 0.7], [-r * 1.6, -r * 0.5], [-r * 1.6, r * 0.5], [r * 0.4, r * 0.7]]); ctx.fill();
      ctx.globalAlpha = 0.9 * blink; ctx.fillStyle = '#f2f7fa';
      poly(ctx, [[r * 2.2, 0], [r * 0.4, -r * 0.28], [-r * 1.4, 0], [r * 0.4, r * 0.28]]); ctx.fill();
      ctx.restore();
      break;
    }
    case 'gravity': {
      // KERNEL: a compressed singularity with orbiting debris
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 0.9 * blink; ctx.fillStyle = '#131020';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.85, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.85 * blink; ctx.strokeStyle = b.color; ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.arc(b.x, b.y, r * (1.15 + Math.sin(t * 9) * 0.18), 0, TAU); ctx.stroke();
      for (let i = 0; i < 2; i++) {
        const oa = t * 8 + seed + i * Math.PI;
        ctx.fillStyle = i ? '#dfe8ff' : b.color2;
        ctx.globalAlpha = blink;
        ctx.beginPath(); ctx.arc(b.x + Math.cos(oa) * r * 1.5, b.y + Math.sin(oa) * r * 1.5, 1.1, 0, TAU); ctx.fill();
      }
      break;
    }
    case 'sound': {
      // RIPPLE: three expanding arcs of pressure
      ctx.globalAlpha = blink;
      ctx.strokeStyle = b.color; ctx.lineWidth = 1.3;
      for (let i = 0; i < 3; i++) {
        const ph = ((t * 2.2 + i / 3 + seed) % 1);
        ctx.globalAlpha = (1 - ph) * 0.9 * blink;
        ctx.beginPath(); ctx.arc(b.x, b.y, r * (0.6 + ph * 1.6), 0, TAU); ctx.stroke();
      }
      ctx.globalAlpha = blink; ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.4, 0, TAU); ctx.fill();
      break;
    }
    case 'bone': {
      // CROSSBONE: the classic, spinning
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a + t * 2.2);
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      ctx.fillRect(-r * 1.6, -r * 0.3, r * 3.2, r * 0.6);
      ctx.rotate(Math.PI / 2.6);
      ctx.fillRect(-r * 1.6, -r * 0.3, r * 3.2, r * 0.6);
      ctx.fillStyle = b.color2;
      for (const s of [-1, 1]) {
        ctx.beginPath(); ctx.arc(s * r * 1.6, -r * 0.3, r * 0.4, 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.arc(s * r * 1.6, r * 0.3, r * 0.4, 0, TAU); ctx.fill();
      }
      ctx.restore();
      break;
    }
    case 'beast': {
      // CLAW RAKE: three streaks tearing through the air
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(a);
      ctx.globalAlpha = 0.9 * blink;
      ctx.strokeStyle = b.color; ctx.lineWidth = 1.2;
      for (const off of [-0.55, 0, 0.55]) {
        ctx.beginPath();
        ctx.moveTo(-r * 1.4, off * r);
        ctx.quadraticCurveTo(0, off * r * 1.7, r * 1.8, off * r * 0.6);
        ctx.stroke();
      }
      ctx.globalAlpha = blink; ctx.fillStyle = b.color2;
      ctx.beginPath(); ctx.arc(r * 0.4, 0, r * 0.42, 0, TAU); ctx.fill();
      ctx.restore();
      break;
    }
    case 'plasma': {
      // MICRO-STAR: white core, screaming corona, cyan sparks
      const fl = 0.75 + Math.sin(t * 26 + seed) * 0.25;
      ctx.globalAlpha = 0.5 * blink * fl; ctx.fillStyle = '#ff5ec9';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 1.35, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.7 * blink; ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.85, 0, TAU); ctx.fill();
      ctx.globalAlpha = blink; ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(b.x, b.y, r * 0.5, 0, TAU); ctx.fill();
      const sa = t * 11 + seed;
      ctx.fillStyle = b.color2;
      ctx.fillRect(b.x + Math.cos(sa) * r * 1.8 - 0.7, b.y + Math.sin(sa) * r * 1.8 - 0.7, 1.4, 1.4);
      ctx.fillRect(b.x + Math.cos(sa + Math.PI) * r * 1.8 - 0.7, b.y + Math.sin(sa + Math.PI) * r * 1.8 - 0.7, 1.4, 1.4);
      break;
    }
    case 'mirror': {
      // GLASS TWIN: mirrored diamonds with a prism flash
      ctx.save(); ctx.translate(b.x, b.y);
      const gl = Math.sin(t * 10 + seed) > 0.4;
      ctx.globalAlpha = blink; ctx.fillStyle = b.color;
      poly(ctx, [[0, -r * 1.3], [r * 0.75, 0], [0, r * 1.3], [-r * 0.75, 0]]); ctx.fill();
      ctx.globalAlpha = 0.55 * blink; ctx.fillStyle = b.color2;
      poly(ctx, [[-r * 1.7, -r * 0.65], [-r * 1.15, 0], [-r * 1.7, r * 0.65], [-r * 2.25, 0]]); ctx.fill();
      if (gl) {
        ctx.globalAlpha = blink; ctx.fillStyle = '#ffffff';
        ctx.fillRect(-r * 0.1, -r * 1.5, 1.2, r * 3);
      }
      ctx.restore();
      break;
    }
    default:
      // unknown element fallback: plain orb
      ctx.globalAlpha = blink;
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
      break;
  }
}

const SCHOOL_SHAPED = new Set<string>([
  'fire', 'frost', 'lightning', 'earth', 'wind', 'water', 'poison', 'blood',
  'shadow', 'death', 'radiant', 'arcane', 'time', 'void', 'nature', 'chaos',
  'crystal', 'metal', 'gravity', 'sound', 'bone', 'beast', 'plasma', 'mirror',
]);

export function drawBullets(G: GameCtx): void {
  const ctx = G.ctx;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const b of G.bullets) {
    const blink = b.parryable && !b.reflected ? (Math.sin(b.t * 18) > 0 ? 1 : 0.55) : 1;
    if (b.reflected) {
      ctx.globalAlpha = 0.5 * blink;
      ctx.fillStyle = '#fff8d8';
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 2.5, 0, TAU); ctx.fill();
      ctx.globalAlpha = blink;
      ctx.fillStyle = '#ffd75e';
      // gleaming counter-strike
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 1, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.9 * blink;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.5, 0, TAU); ctx.fill();
      const a = Math.atan2(b.vy, b.vx);
      ctx.globalAlpha = 0.5 * blink;
      ctx.strokeStyle = '#ffd75e';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(b.x - Math.cos(a) * b.r * 2.4, b.y - Math.sin(a) * b.r * 2.4);
      ctx.lineTo(b.x + Math.cos(a) * b.r, b.y + Math.sin(a) * b.r);
      ctx.stroke();
    } else if (b.kind === 'gold') {
      ctx.globalAlpha = blink;
      ctx.fillStyle = '#ffd75e';
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#fff8d8'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 2 + Math.sin(b.t * 14) * 1.5, 0, TAU); ctx.stroke();
    } else if (SCHOOL_SHAPED.has(b.el)) {
      // every school has its own body — cryo is never hydro
      drawSchoolShape(G, b, blink);
    } else if (b.kind === 'shard' || b.kind === 'meteor') {
      ctx.globalAlpha = blink;
      ctx.fillStyle = b.color;
      const a = Math.atan2(b.vy, b.vx);
      ctx.save();
      ctx.translate(b.x, b.y); ctx.rotate(a);
      ctx.fillRect(-b.r * 1.8, -b.r * 0.55, b.r * 3.2, b.r * 1.1);
      ctx.restore();
    } else if (b.kind === 'orb' || b.kind === 'soul') {
      ctx.globalAlpha = blink;
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.8;
      ctx.strokeStyle = b.color2; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 2 + Math.sin(b.t * 8) * 1.2, 0, TAU); ctx.stroke();
    } else if (b.kind === 'wave') {
      ctx.globalAlpha = 0.75;
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.3;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 4, 0, TAU); ctx.fill();
    } else {
      ctx.globalAlpha = blink;
      ctx.fillStyle = b.color;
      ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.9 * blink;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.arc(b.x - b.vx * 0.004, b.y - b.vy * 0.004, b.r * 0.45, 0, TAU); ctx.fill();
    }
  }
  ctx.restore();
}

// ---------- zones ----------
export function spawnZone(G: GameCtx, z: Partial<Zone>): Zone {
  const zone: Zone = {
    kind: z.kind ?? 'field', x: z.x ?? 0, y: z.y ?? 0, r: z.r ?? 40,
    t: 0, dur: z.dur ?? 5, el: z.el ?? 'arcane', el2: z.el2 ?? null,
    team: z.team ?? 'player', dmg: z.dmg ?? 4, tick: z.tick ?? 0.4, tickT: 0,
    owner: z.owner ?? null, follow: z.follow ?? null, armed: z.armed ?? true,
    potency: z.potency ?? 1, dead: false,
  };
  G.zones.push(zone);
  return zone;
}

export function updateZones(G: GameCtx, dt: number): void {
  const p = G.player;
  for (const z of G.zones) {
    z.t += dt;
    if (z.follow) { z.x = z.follow.x; z.y = z.follow.y; }
    if (z.t >= z.dur) { z.dead = true; continue; }
    if (z.kind === 'trap') {
      if (!z.armed && z.t > 0.5) z.armed = true;
      if (z.armed && z.team === 'player') {
        for (const e of G.enemies) {
          if (!e.dead && circleHit(z.x, z.y, z.r, e.x, e.y, e.r)) {
            z.dead = true;
            explosion(G, z.x, z.y, z.r + 16, z.dmg * 2.2, z.el, z.team, { el2: z.el2, potency: z.potency, from: z.owner });
            break;
          }
        }
        const bo = G.boss;
        if (!z.dead && bo && !bo.dead && circleHit(z.x, z.y, z.r, bo.x, bo.y, bo.r)) {
          z.dead = true;
          explosion(G, z.x, z.y, z.r + 16, z.dmg * 2.2, z.el, z.team, { el2: z.el2, potency: z.potency, from: z.owner });
        }
      } else if (z.armed && z.team === 'enemy') {
        if (!p.dead && circleHit(z.x, z.y, z.r, p.x, p.y, p.r)) {
          z.dead = true;
          explosion(G, z.x, z.y, z.r + 14, z.dmg, z.el, z.team, { el2: z.el2, potency: z.potency });
        }
      }
      continue;
    }
    z.tickT -= dt;
    if (z.tickT <= 0) {
      z.tickT = z.tick;
      if (z.team === 'player') {
        for (const e of G.enemies) {
          if (!e.dead && circleHit(z.x, z.y, z.r, e.x, e.y, e.r)) {
            if (z.dmg > 0) {
              damageEnemy(G, e, z.dmg, z.el, { silent: chance(0.5), from: z.owner });
              if (z.el2) applyElement(G, e, z.el2, 0.4 * z.potency, 'player');
            }
            // school field flavors
            if (z.el === 'frost' && chance(0.14) && !e.st.frozen) {
              e.st.frozen = { t: 1.1 };
              addText(G, e.x, e.y - 12, 'FROZEN', '#9edbe8', 5, true);
            }
            if (z.el === 'water') applyElement(G, e, 'water', 0.5, 'player');
            if (z.el === 'shadow' && chance(0.2)) e.st.fear = { t: 1 };
            if (z.el === 'nature' && chance(0.22)) e.st.root = { t: 1 };
          }
        }
        const bo = G.boss;
        if (bo && !bo.dead && circleHit(z.x, z.y, z.r, bo.x, bo.y, bo.r)) {
          if (z.dmg > 0) {
            damageBoss(G, bo, z.dmg, z.el);
            if (z.el2) applyElement(G, bo, z.el2, 0.4 * z.potency, 'player');
          }
        }
        // school zone auras on the caster
        if (circleHit(z.x, z.y, z.r, p.x, p.y, p.r)) {
          if (z.el === 'radiant') p.hp = Math.min(p.maxHp, p.hp + 1.2);
          if (z.el === 'nature') p.hp = Math.min(p.maxHp, p.hp + 0.8);
          if (z.el === 'blood') p.hp = Math.min(p.maxHp, p.hp + 1.0);
          if (z.el === 'arcane') p.mana = Math.min(p.maxMana, p.mana + 0.8);
          if (z.el === 'time') p.buffHaste = Math.max(p.buffHaste, 0.5);
          // HYDROMANCY: your own springs cleanse and pour mana back
          if (z.el === 'water' && z.team === 'player') {
            if (p.st.burn || p.st.poison) { delete p.st.burn; delete p.st.poison; addText(G, p.x, p.y - 14, 'CLEANSED', '#c9f2f7', 4); }
            p.mana = Math.min(p.maxMana, p.mana + 1.4);
          }
        }
        // void / gravity wells pull continuously
        if (z.el === 'void' || z.el === 'gravity') {
          for (const e of G.enemies) {
            if (e.dead) continue;
            const d = dist(e.x, e.y, z.x, z.y);
            if (d < z.r + 60 && d > 6) {
              const a = angTo(e.x, e.y, z.x, z.y);
              e.vx += Math.cos(a) * 300 * z.potency * dt;
              e.vy += Math.sin(a) * 300 * z.potency * dt;
            }
          }
        }
      } else {
        if (!p.dead && circleHit(z.x, z.y, z.r, p.x, p.y, p.r)) {
          damagePlayer(G, z.dmg, z.el);
          if (z.el2) applyElement(G, p, z.el2, 0.4, 'enemy');
        }
        for (const m of G.minions) {
          if (!m.dead && circleHit(z.x, z.y, z.r, m.x, m.y, m.r)) damageMinion(G, m, z.dmg, z.el);
        }
      }
    }
  }
  let w = 0;
  for (let i = 0; i < G.zones.length; i++) if (!G.zones[i].dead) G.zones[w++] = G.zones[i];
  G.zones.length = w;
}

export function drawZones(G: GameCtx, layer: 'ground' | 'air'): void {
  const ctx = G.ctx;
  for (const z of G.zones) {
    const isAir = z.kind === 'aura' || z.kind === 'wardPad';
    if ((layer === 'ground') === isAir) continue;
    const c1 = elColor(z.el), c2 = elColor2(z.el);
    const fade = z.t > z.dur - 0.6 ? (z.dur - z.t) / 0.6 : Math.min(1, z.t * 3);
    ctx.save();
    ctx.globalAlpha = 0.16 * fade;
    ctx.fillStyle = c1;
    ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.7 * fade;
    ctx.strokeStyle = c2; ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.lineDashOffset = -z.t * 20;
    ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.stroke();
    ctx.setLineDash([]);
    if (z.kind === 'trap') {
      ctx.globalAlpha = 0.9 * fade;
      ctx.strokeStyle = z.armed ? c1 : '#888';
      ctx.lineWidth = 1.5;
      const s = 5;
      ctx.beginPath();
      ctx.moveTo(z.x - s, z.y - s); ctx.lineTo(z.x + s, z.y + s);
      ctx.moveTo(z.x + s, z.y - s); ctx.lineTo(z.x - s, z.y + s);
      ctx.stroke();
    }
    // bubbles/embers rising
    if (G.frame % 6 === 0 && fade > 0.2) {
      spawnParticle(G, {
        x: z.x + randR(-z.r, z.r) * 0.8, y: z.y + randR(-z.r, z.r) * 0.8,
        vx: 0, vy: -18, life: 0.7, size: 1.6, color: c2, glow: true,
      });
    }
    ctx.restore();
  }
}

// ---------- beams & telegraphs ----------
export function addBeam(G: GameCtx, x: number, y: number, ang: number, len: number, w: number, el: ElementId, dur = 0.22): void {
  G.beams.push({ x, y, ang, len, w, t: 0, dur, color: elColor(el), color2: elColor2(el) });
}

export function updateBeams(G: GameCtx, dt: number): void {
  for (const b of G.beams) b.t += dt;
  G.beams = G.beams.filter((b) => b.t < b.dur);
}

export function drawBeams(G: GameCtx): void {
  const ctx = G.ctx;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const b of G.beams) {
    const k = 1 - b.t / b.dur;
    ctx.globalAlpha = k;
    ctx.strokeStyle = b.color2;
    ctx.lineWidth = b.w * k;
    ctx.beginPath();
    ctx.moveTo(b.x, b.y);
    ctx.lineTo(b.x + Math.cos(b.ang) * b.len, b.y + Math.sin(b.ang) * b.len);
    ctx.stroke();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = b.w * k * 0.4;
    ctx.stroke();
  }
  ctx.restore();
}

export function addTelegraph(G: GameCtx, t: Partial<Telegraph>): void {
  G.teles.push({
    kind: t.kind ?? 'circle', x: t.x ?? 0, y: t.y ?? 0, ang: t.ang ?? 0,
    len: t.len ?? 60, r: t.r ?? 30, w: t.w ?? 8,
    t: 0, dur: t.dur ?? 0.8, color: t.color ?? '#ff5a5a', team: t.team ?? 'enemy',
    onDone: t.onDone ?? (() => {}), dead: false,
  });
}

export function updateTeles(G: GameCtx, dt: number): void {
  for (const t of G.teles) {
    t.t += dt;
    if (t.t >= t.dur && !t.dead) { t.dead = true; t.onDone(); }
  }
  G.teles = G.teles.filter((t) => !t.dead);
}

export function drawTeles(G: GameCtx): void {
  const ctx = G.ctx;
  for (const t of G.teles) {
    const k = t.t / t.dur;
    ctx.save();
    ctx.globalAlpha = 0.28 + 0.25 * Math.sin(t.t * 14);
    ctx.strokeStyle = t.color;
    ctx.fillStyle = t.color;
    ctx.lineWidth = 1.5;
    if (t.kind === 'circle') {
      ctx.beginPath(); ctx.arc(t.x, t.y, t.r, 0, TAU); ctx.stroke();
      ctx.globalAlpha = 0.14 + 0.3 * k;
      ctx.beginPath(); ctx.arc(t.x, t.y, t.r * k, 0, TAU); ctx.fill();
    } else if (t.kind === 'line') {
      const x2 = t.x + Math.cos(t.ang) * t.len, y2 = t.y + Math.sin(t.ang) * t.len;
      ctx.globalAlpha = 0.2 + 0.3 * k;
      ctx.lineWidth = t.w;
      ctx.beginPath(); ctx.moveTo(t.x, t.y); ctx.lineTo(x2, y2); ctx.stroke();
      ctx.globalAlpha = 0.8;
      ctx.lineWidth = 1;
      ctx.stroke();
    } else {
      ctx.globalAlpha = 0.18 + 0.3 * k;
      ctx.beginPath();
      ctx.moveTo(t.x, t.y);
      ctx.arc(t.x, t.y, t.len, t.ang - t.w, t.ang + t.w);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
}

// ---------- explosion (JUICY) ----------
export function explosion(
  G: GameCtx, x: number, y: number, r: number, dmg: number, el: ElementId, team: Team,
  opts: { color?: string; from?: Ent | null; el2?: ElementId | null; potency?: number; noDmg?: boolean } = {},
): void {
  const color = opts.color ?? elColor(el);
  const juice = G.overdrive > 0 ? 1.4 : 1;
  // chunky pixel debris
  burst(G, x, y, color, Math.round(16 * juice), r * 4.2, { life: 0.45, size: 3.4, glow: true });
  burst(G, x, y, elColor2(el), Math.round(9 * juice), r * 3.2, { life: 0.5, size: 2.6, glow: true });
  // white hot core
  burst(G, x, y, '#ffffff', Math.round(6 * juice), r * 2, { life: 0.18, size: 2.6, glow: true });
  // dark smoke chunks (non-glow, slow drift)
  for (let i = 0; i < 5; i++) {
    const a = rand(0, TAU), s = randR(10, 40);
    spawnParticle(G, {
      x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 14,
      life: randR(0.5, 0.9), size: randR(3, 5.5), color: '#2a2030', glow: false, shrink: false,
    });
  }
  // shockwave rings
  addRing(G, x, y, r * 0.25, r * 3.4, color, 0.32, 2.5);
  if (r >= 34) addRing(G, x, y, r * 0.15, r * 4.6, '#ffffff', 0.22, 1.5);
  shake(G, (r / 38) * juice);
  G.audio.sfx('boom', randR(0.85, 1.2), clamp(r / 60, 0.4, 1));
  // debris ring
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    spawnParticle(G, {
      x: x + Math.cos(a) * r * 0.4, y: y + Math.sin(a) * r * 0.4,
      vx: Math.cos(a) * r * 2.6, vy: Math.sin(a) * r * 2.6,
      life: 0.32, size: 2.4, color, glow: true,
    });
  }
  if (opts.noDmg || dmg <= 0) return;
  if (team === 'player') {
    for (const e of G.enemies) {
      if (!e.dead && circleHit(x, y, r, e.x, e.y, e.r)) {
        damageEnemy(G, e, dmg, el, { from: opts.from ?? null });
        if (opts.el2) applyElement(G, e, opts.el2, 0.45 * (opts.potency ?? 1), 'player');
      }
    }
    const bo = G.boss;
    if (bo && !bo.dead && bo.state !== 'intro' && circleHit(x, y, r, bo.x, bo.y, bo.r)) {
      damageBoss(G, bo, dmg, el);
      if (opts.el2) applyElement(G, bo, opts.el2, 0.45 * (opts.potency ?? 1), 'player');
    }
    // clear enemy destructible bullets
    for (const b of G.bullets) {
      if (b.team === 'enemy' && b.destructible && circleHit(x, y, r, b.x, b.y, b.r)) { b.hp = 0; b.dead = true; }
    }
  } else {
    if (!G.player.dead && circleHit(x, y, r, G.player.x, G.player.y, G.player.r)) {
      damagePlayer(G, dmg, el);
      if (opts.el2) applyElement(G, G.player, opts.el2, 0.4, 'enemy');
    }
    for (const m of G.minions) {
      if (!m.dead && circleHit(x, y, r, m.x, m.y, m.r)) damageMinion(G, m, dmg, el);
    }
  }
}

// ---------- float texts & particles update ----------
export function updateFx(G: GameCtx, dt: number): void {
  updateRings(G, dt);
  for (const p of G.parts) {
    p.life -= dt;
    p.x += p.vx * dt; p.y += p.vy * dt;
    p.vy += p.grav * dt;
    p.vx *= 1 - 2 * dt; p.vy *= 1 - 2 * dt;
  }
  G.parts = G.parts.filter((p) => p.life > 0);
  for (const t of G.texts) { t.t += dt; t.y += t.vy * dt; t.vy *= 1 - 1.5 * dt; }
  G.texts = G.texts.filter((t) => t.t < t.dur);
}

export function drawParticles(G: GameCtx): void {
  const ctx = G.ctx;
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const p of G.parts) {
    const k = clamp(p.life / p.maxLife, 0, 1);
    ctx.globalAlpha = k;
    const s = p.shrink ? p.size * k : p.size;
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x - s / 2, p.y - s / 2, s, s);
  }
  ctx.restore();
}

export function drawTexts(G: GameCtx): void {
  const ctx = G.ctx;
  ctx.save();
  ctx.textAlign = 'center';
  for (const t of G.texts) {
    const k = 1 - t.t / t.dur;
    ctx.globalAlpha = Math.min(1, k * 2);
    ctx.font = `${t.size}px monospace`;
    ctx.fillStyle = '#000000';
    ctx.fillText(t.text, t.x + 1, t.y + 1);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, t.x, t.y);
  }
  ctx.restore();
}

// ---------- pickups, stains, corpses ----------
export function spawnPickup(G: GameCtx, kind: 'vial' | 'draught' | 'aether', x: number, y: number, amount = 1): void {
  const a = rand(0, TAU);
  G.pickups.push({
    kind, x, y, vx: Math.cos(a) * randR(20, 60), vy: Math.sin(a) * randR(20, 60),
    t: 0, amount, mag: false,
  });
}

export function updatePickups(G: GameCtx, dt: number): void {
  const p = G.player;
  // RELIC: lodestone heart — lost things come to you willingly
  const magR = 60 + relicVal(G, 'magnet') * 30;
  for (const it of G.pickups) {
    it.t += dt;
    it.x += it.vx * dt; it.y += it.vy * dt;
    it.vx *= 1 - 4 * dt; it.vy *= 1 - 4 * dt;
    const d = dist(it.x, it.y, p.x, p.y);
    if (d < magR || it.mag) {
      it.mag = true;
      const a = angTo(it.x, it.y, p.x, p.y);
      const s = clamp(200 - d, 60, 200);
      it.vx += Math.cos(a) * s * dt * 6; it.vy += Math.sin(a) * s * dt * 6;
    }
    if (d < 8) {
      it.t = 999;
      if (it.kind === 'aether') {
        G.prog.aether += it.amount;
        addText(G, p.x, p.y - 14, `+${it.amount} aether`, '#ffd75e', 4);
        G.audio.sfx('aether');
      } else if (it.kind === 'vial') {
        G.prog.vials = Math.min(9, G.prog.vials + 1);
        addText(G, p.x, p.y - 14, '+vial', '#ff8a9e', 4);
        G.audio.sfx('pickup');
      } else if (it.kind === 'relic') {
        // RELIC: found only in the deep places of the world
        const def = it.relicId ? RELICS[it.relicId] : null;
        if (def) {
          grantRelic(G, def.id);
          addText(G, p.x, p.y - 24, def.name.toUpperCase(), RARITY_COLOR[def.rarity], 6, true);
          G.audio.sfx('levelup');
        }
      } else if (it.kind === 'echo') {
        // ECHO SHARDS: statue currency — the dead remember what they owed
        G.prog.echoes += it.amount;
        addText(G, p.x, p.y - 14, `+${it.amount} echo shard${it.amount > 1 ? 's' : ''}`, '#ffe89e', 4);
        G.audio.sfx('aether');
      } else {
        G.prog.draughts = Math.min(9, G.prog.draughts + 1);
        addText(G, p.x, p.y - 14, '+draught', '#5ee8c9', 4);
        G.audio.sfx('pickup');
      }
    }
  }
  G.pickups = G.pickups.filter((it) => it.t < 60);
}

function drawRelicPickup(G: GameCtx, it: Pickup): void {
  const ctx = G.ctx;
  const def = it.relicId ? RELICS[it.relicId] : null;
  const col = def?.color ?? '#c9b0f2';
  const rc = RARITY_COLOR[def?.rarity ?? 'common'];
  const bob = Math.sin(it.t * 4) * 1.5;
  const x = Math.round(it.x), y = Math.round(it.y + bob);
  const pulse = Math.sin(it.t * 5.2);
  // rarity halo
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.26 + 0.1 * pulse;
  ctx.fillStyle = rc;
  ctx.beginPath(); ctx.arc(x, y, 8 + pulse * 1.4, 0, TAU); ctx.fill();
  ctx.restore();
  // the gem — a dark setting around a relic-colored diamond
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = '#2e2a3a';
  ctx.beginPath();
  ctx.moveTo(0, -6); ctx.lineTo(4.5, 0); ctx.lineTo(0, 6); ctx.lineTo(-4.5, 0);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.moveTo(0, -4); ctx.lineTo(3, 0); ctx.lineTo(0, 4); ctx.lineTo(-3, 0);
  ctx.closePath(); ctx.fill();
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-1.5, -2.5, 1.5, 1.5); // glint
  ctx.restore();
  // twin twinkles
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.35 + 0.45 * Math.sin(it.t * 7);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x + 5, y - 7, 1.5, 1.5);
  ctx.fillRect(x - 7, y + 4, 1.5, 1.5);
  ctx.restore();
}

function drawEchoPickup(G: GameCtx, it: Pickup): void {
  const ctx = G.ctx;
  const bob = Math.sin(it.t * 4) * 1.5;
  const x = Math.round(it.x), y = Math.round(it.y + bob);
  // pale-gold glow
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha = 0.28 + 0.12 * Math.sin(it.t * 6);
  ctx.fillStyle = '#ffe89e';
  ctx.beginPath(); ctx.arc(x, y, 6, 0, TAU); ctx.fill();
  ctx.restore();
  // a sliver of something that used to be a voice
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = '#cbb37a';
  ctx.beginPath();
  ctx.moveTo(0, -5); ctx.lineTo(2.2, -1); ctx.lineTo(1.2, 5); ctx.lineTo(-2.2, 1);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#fff6d8';
  ctx.beginPath();
  ctx.moveTo(0, -3.5); ctx.lineTo(1.1, -0.5); ctx.lineTo(0.5, 3); ctx.lineTo(-1, 0.5);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

export function drawPickups(G: GameCtx): void {
  const ctx = G.ctx;
  for (const it of G.pickups) {
    if (it.kind === 'relic') { drawRelicPickup(G, it); continue; }
    if (it.kind === 'echo') { drawEchoPickup(G, it); continue; }
    const spr = it.kind === 'aether' ? SPR.shard : it.kind === 'vial' ? SPR.vial : SPR.draught;
    const bob = Math.sin(it.t * 4) * 1.5;
    ctx.drawImage(spr, Math.round(it.x - spr.width / 2), Math.round(it.y - spr.height / 2 + bob));
  }
}

export function updateCorpses(G: GameCtx, dt: number): void {
  for (const c of G.corpses) c.t += dt;
  G.corpses = G.corpses.filter((c) => c.t < 24);
}

export function drawCorpses(G: GameCtx): void {
  const ctx = G.ctx;
  for (const c of G.corpses) {
    const spr = SPR[c.sprite];
    if (!spr) continue;
    ctx.save();
    ctx.globalAlpha = clamp(1 - (c.t - 18) / 6, 0, 1) * 0.9;
    ctx.translate(Math.round(c.x), Math.round(c.y));
    ctx.rotate(c.flip ? Math.PI / 2 : -Math.PI / 2);
    ctx.drawImage(spr, -spr.width / 2, -spr.height / 2);
    ctx.restore();
  }
}

// ---------- environment hazards ----------
export function envHazardTick(G: GameCtx, dt: number): void {
  const p = G.player;
  if (p.dead) return;
  const t = G.world.tileAt(p.x, p.y);
  if (TILE_HURT_LAVA.has(t)) {
    if (G.prog.sigils.includes('ashen')) return;
    p.hurtCd -= dt;
    if (p.hurtCd <= 0) {
      p.hurtCd = 0.5;
      damagePlayer(G, 8, 'fire');
      burst(G, p.x, p.y, '#ff7a3e', 6, 60);
    }
  }
  if (p.st.burn) {
    p.st.burn.t -= dt;
    p.hp -= p.st.burn.dps * dt;
    if (G.frame % 10 === 0) spawnParticle(G, { x: p.x + randR(-4, 4), y: p.y - 4, vy: -20, life: 0.4, size: 2, color: '#ff7a3e', glow: true });
    if (p.st.burn.t <= 0) delete p.st.burn;
    if (p.hp <= 0 && !p.dead) { p.hp = 0; p.dead = true; G.audio.sfx('die'); slowmo(G, 0.9, 0.15); }
  }
  if (p.st.poison) {
    p.st.poison.t -= dt;
    p.hp -= p.st.poison.dps * dt;
    if (G.frame % 14 === 0) spawnParticle(G, { x: p.x + randR(-4, 4), y: p.y - 4, vy: -14, life: 0.5, size: 2, color: '#8ed94e', glow: true });
    if (p.st.poison.t <= 0) delete p.st.poison;
    if (p.hp <= 0 && !p.dead) { p.hp = 0; p.dead = true; G.audio.sfx('die'); slowmo(G, 0.9, 0.15); }
  }
  if (p.st.chill) { p.st.chill.t -= dt; if (p.st.chill.t <= 0) delete p.st.chill; }
  if (p.st.stun) { p.st.stun.t -= dt; if (p.st.stun.t <= 0) delete p.st.stun; }
  if (p.st.root) { p.st.root.t -= dt; if (p.st.root.t <= 0) delete p.st.root; }
  if (p.st.wet) { p.st.wet.t -= dt; if (p.st.wet.t <= 0) delete p.st.wet; }
}

export function tileSpeedMult(G: GameCtx, x: number, y: number): number {
  const t = G.world.tileAt(x, y);
  if (TILE_SLOW.has(t)) return 0.6;
  return 1;
}
