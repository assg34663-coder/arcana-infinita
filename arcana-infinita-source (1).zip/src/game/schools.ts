/* ============================================================
   schools.ts — SCHOOL IDENTITY. Every element plays DIFFERENTLY.
   Each school rewrites how its projectiles fly, what they do on
   impact, what resource they spend and what happens when things
   die. This is what makes Pyromancy feel like Pyromancy,
   Hemomancy a suicide pact and Ferrumancy a blade dance — on
   EVERY spell form, from the very first bolt.
   ============================================================ */
import type { ElementId } from './core';
import type { FormId } from './core';

// ---------- projectile personality (pure data) ----------
export interface ProjMods {
  speed?: number;      // multiplier on projectile speed
  r?: number;          // flat size add
  count?: number;      // extra projectiles for multi-shot forms
  spread?: number;     // spread multiplier
  pierce?: number;     // pierce add
  homing?: number;     // homing strength add
  gravity?: number;    // arcing shots
  zigzag?: number;     // wavering path
  life?: number;       // life multiplier
  trail?: number;      // trail add
  boomR?: number;      // explodes on impact
  accel?: number;      // accelerates in flight
  cdMul?: number;      // cooldown multiplier (wind: faster casting)
  passWalls?: boolean; // projectiles ignore terrain
}

export interface SchoolSig {
  tagline: string;        // one-line identity, shown in grimoire
  proj: ProjMods;
  fieldMul?: number;      // zone damage multiplier
  beamMul?: number;       // beam damage multiplier
  passWalls?: boolean;    // projectiles ignore terrain
}

export const SCHOOL_SIG: Record<ElementId, SchoolSig> = {
  fire: {
    tagline: 'CHAIN DETONATION: slain foes erupt, ground ignites, burning foes take +25% and pop.',
    proj: { boomR: 22, speed: 0.95, trail: 0.3, life: 0.95 },
    fieldMul: 1.25, beamMul: 1.15,
  },
  frost: {
    tagline: 'GLACIAL STACKS: every hit stacks — 3 stacks FREEZE. Frozen foes SHATTER for +50%.',
    proj: { pierce: 1, speed: 1.1, r: 0.4, trail: 0.1 },
    fieldMul: 0.9,
  },
  lightning: {
    tagline: 'INSTANT STORM: near-hitscan arcs, no travel time, hits CHAIN between foes.',
    proj: { speed: 2.7, life: 0.34, trail: 0.45, spread: 1.1 },
    beamMul: 1.2,
  },
  earth: {
    tagline: 'ARTILLERY: lobbed mortars quake on landing, hurl foes, briefly STUN. +50% vs stunned/rooted.',
    proj: { speed: 0.62, r: 1.8, pierce: 0, trail: 0.15, life: 1.5, gravity: 210, boomR: 26 },
    fieldMul: 1.1,
  },
  wind: {
    tagline: 'TAILWIND: cheapest, fastest casting; piercing gales fling foes, casting while moving dashes you.',
    proj: { speed: 1.6, pierce: 99, spread: 0.7, trail: 0.2, life: 0.9, cdMul: 0.82 },
    fieldMul: 0.8,
  },
  water: {
    tagline: 'THE ENABLER: soaks foes (+50% frost & lightning), fields cleanse you and pour back mana.',
    proj: { gravity: 90, speed: 1.05, r: 0.8, life: 1.3 },
    fieldMul: 1.0,
  },
  poison: {
    tagline: 'ESCALATING PLAGUE: stacks raise the rot and damage taken; 3+ stacks spread contagion on death.',
    proj: { speed: 0.95, trail: 0.3, life: 1.15 },
    fieldMul: 1.15,
  },
  blood: {
    tagline: 'BLOOD PRICE: spells cost HP instead of mana, then carve it back — lifesteal on everything.',
    proj: { speed: 0.85, r: 0.3, trail: 0.35, life: 1.6 },
    fieldMul: 0.9,
  },
  shadow: {
    tagline: 'DREAD CURSE: shades pass through walls; hits DOOM foes (-30% damage) and strike fear.',
    proj: { homing: 2.6, speed: 0.9, trail: 0.3, life: 1.4, passWalls: true },
    fieldMul: 1.0,
  },
  death: {
    tagline: 'NECROMANCY: casts devour corpses (+40% each); kills may RISE as thralls under your banner.',
    proj: { speed: 0.95, r: 0.4, trail: 0.45, life: 1.2 },
    fieldMul: 1.0, beamMul: 1.1,
  },
  radiant: {
    tagline: 'SANCTUARY: kills leave healing hallowed ground; +60% vs the undead; light mends you.',
    proj: { pierce: 2, speed: 1.05, r: 0.6, trail: 0.25 },
    fieldMul: 0.95, beamMul: 1.15,
  },
  arcane: {
    tagline: 'MANA ENGINE: hits refund mana, missiles split into seeking motes; full mana = FREE ARCANE SURGE.',
    proj: { speed: 1.0, trail: 0.2, life: 1.1 },
    fieldMul: 0.95,
  },
  time: {
    tagline: 'TEMPORAL LOCK: hits are hour charges — 3 charges STOP TIME. Impacts smother foes in slow.',
    proj: { speed: 0.9, trail: 0.25, life: 1.25, zigzag: 0.3 },
    fieldMul: 0.85,
  },
  void: {
    tagline: 'DEVOURING GRAVITY: impacts tear pull-wells; kills swallowed by the Abyss spit out bonus aether.',
    proj: { speed: 0.85, r: 0.7, trail: 0.35, life: 1.3 },
    fieldMul: 1.05,
  },
  nature: {
    tagline: 'THE WILD RECLAIMS: strikes root foes in place; the slain bloom into healing spore pods.',
    proj: { speed: 0.95, r: 0.5, trail: 0.2, life: 1.2, homing: 0.6 },
    fieldMul: 1.0,
  },
  chaos: {
    tagline: 'WILD MAGIC: random element every cast, random affliction every hit, random RITUALS on impact.',
    proj: { speed: 1.05, trail: 0.3, spread: 1.3 },
    fieldMul: 1.1,
  },
  crystal: {
    tagline: 'REFRACTION: impacts split shards into new angles; shards that fly far enough become PRISMS (+50%).',
    proj: { speed: 1.0, r: 0.3, trail: 0.3, life: 1.15 },
    fieldMul: 0.95, beamMul: 1.05,
  },
  metal: {
    tagline: 'BLADE DANCE: projectiles ORBIT you as whirling steel, reaping repeatedly, then fling outward.',
    proj: { speed: 0.9, r: 0.4, trail: 0.25 },
    fieldMul: 0.9, beamMul: 1.0,
  },
  gravity: {
    tagline: 'MASS COLLAPSE: impacts drag every nearby foe into the crush point; the heavy get SLAMMED. Kills implode.',
    proj: { speed: 0.8, r: 0.9, trail: 0.4, life: 1.35 },
    fieldMul: 1.1,
  },
  sound: {
    tagline: 'ECHO CHAMBER: near-instant ripples STAGGER foes; every wave echoes once behind you for 40%.',
    proj: { speed: 1.9, life: 0.42, trail: 0.25, spread: 1.0 },
    beamMul: 1.1,
  },
  bone: {
    tagline: 'THE OSSUARY: hits OSSIFY armor (+15% dmg taken); the slain burst into homing bone darts.',
    proj: { speed: 1.05, r: 0.2, pierce: 1, trail: 0.15, life: 1.1 },
    fieldMul: 0.95,
  },
  beast: {
    tagline: 'THE PACK HUNTS: hits stack PACK MARKS — at 3 a spirit beast LUNGES from you. Sharper summons.',
    proj: { speed: 1.15, trail: 0.2, life: 1.05, homing: 1.2 },
    fieldMul: 0.95,
  },
  plasma: {
    tagline: 'STELLAR FUSION: impacts burn AND arc simultaneously; your stars melt the ground beneath them.',
    proj: { speed: 1.25, r: 0.5, boomR: 16, trail: 0.5, life: 0.9 },
    fieldMul: 1.1, beamMul: 1.15,
  },
  mirror: {
    tagline: 'HALL OF MIRRORS: expired spells reflect backward at half power; hits spawn mirrored twins.',
    proj: { speed: 1.1, trail: 0.3, life: 1.2 },
    fieldMul: 0.9, beamMul: 1.05,
  },
};

// ---------- unlock curve (per-element overrides) ----------
const BASE_UNLOCK: Array<[FormId, number]> = [
  ['bolt', 1], ['mend', 2], ['ward', 4], ['volley', 5],
  ['orb', 7], ['nova', 9], ['beam', 11], ['field', 12],
  ['blink', 14], ['storm', 16], ['trap', 18], ['wave', 20],
  ['enchant', 22], ['aura', 24], ['summon', 26], ['ritual', 30],
];

// per-element overrides — Necromancy gets its fantasy EARLY
const EL_UNLOCK: Partial<Record<ElementId, Partial<Record<FormId, number>>>> = {
  death: { summon: 3, aura: 14, ritual: 22, nova: 8 },
  nature: { summon: 8 },
  blood: { aura: 16 },
  arcane: { summon: 12 },
  radiant: { summon: 10 },
  crystal: { beam: 8 },
  metal: { nova: 6, aura: 12 },
  gravity: { nova: 8, field: 10, ritual: 24 },
  sound: { beam: 8, storm: 14, ritual: 24 },
  bone: { summon: 6, trap: 10, ritual: 24 },
  beast: { summon: 3, aura: 12, ritual: 22 },
  plasma: { orb: 6, nova: 12, ritual: 24 },
  mirror: { blink: 8, wave: 10, ritual: 24 },
};

export function unlockLevelFor(el: ElementId, form: FormId): number {
  const o = EL_UNLOCK[el]?.[form];
  if (o !== undefined) return o;
  return BASE_UNLOCK.find(([f]) => f === form)?.[1] ?? 40;
}
