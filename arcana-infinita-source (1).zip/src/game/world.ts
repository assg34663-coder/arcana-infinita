/* ============================================================
   world.ts — infinite procedural world: biomes, chunks,
   collision, decor, hazards, plus fixed special locations
   (shrines & boss arenas carved into the terrain).
   ============================================================ */
import {
  TILE, CHUNK, CHUNK_PX, TAU, fbm2, hash2, clamp,
  type BiomeId, type Chunk, type Decor, type World,
} from './core';
import { villageStructuresNear, villageGround, villages } from './villages';
import { arenaDims, arenaGapAngle, angDiff } from './arenas';

// tile ids
export const T_EMPTY = 0;
export const T_GRASS = 1, T_GRASS2 = 2, T_GRASS3 = 3, T_DRY = 4;
export const T_FOREST = 5, T_FOREST2 = 6, T_DARK = 7;
export const T_SAND = 8, T_SAND2 = 9, T_SNOW = 10, T_SNOW2 = 11;
export const T_SWAMP = 12, T_ROCK = 13, T_WASTES = 14, T_ARCANE = 15, T_VOLC = 16;
export const T_WATER = 17, T_SHALLOW = 18, T_LAVA = 19, T_ARENA = 20, T_PATH = 21, T_TROCK = 22;
export const T_WALL = 23; // solid arena wall tile (pseudo-3D sprite drawn over it)

// themed arena floor tile ids — 8 bosses x 3 tiers (outer / rune ring / emblem)
export const ARENA_BOSS_ORDER = ['ashen', 'frost', 'hollow', 'storm', 'maw', 'tide', 'aeon', 'void'];
export const T_FLOOR_BASE = 30;
export function arenaFloorBase(bossId: string): number {
  const i = ARENA_BOSS_ORDER.indexOf(bossId);
  return i < 0 ? -1 : T_FLOOR_BASE + i * 3;
}
export function bossOfFloorTile(t: number): { boss: string; tier: number } | null {
  if (t < T_FLOOR_BASE || t >= T_FLOOR_BASE + ARENA_BOSS_ORDER.length * 3) return null;
  const k = t - T_FLOOR_BASE;
  return { boss: ARENA_BOSS_ORDER[Math.floor(k / 3)], tier: k % 3 };
}

export const TILE_SOLID = new Set<number>([T_WATER, T_WALL]);
export const TILE_SLOW = new Set<number>([T_SHALLOW]);
export const TILE_HURT_LAVA = new Set<number>([T_LAVA]);

// ---------- special locations ----------
export type LocKind = 'shrine' | 'boss';
export interface GameLocation {
  id: string;
  kind: LocKind;
  x: number; y: number;
  name: string;
  bossId?: string;
  r: number; // arena radius (boss) or interact radius (shrine)
}

const DIRS: Array<[number, number]> = [
  [1, 0], [0.7, 0.7], [0, 1], [-0.7, 0.7], [-1, 0], [-0.7, -0.7], [0, -1], [0.7, -0.7],
];

export const BOSSES = [
  { id: 'ashen', name: 'Grum, the Ashen Tyrant', dist: 1300 },
  { id: 'frost', name: 'Ylva, Queen of the Frozen Waste', dist: 1900 },
  { id: 'hollow', name: 'The Hollow King', dist: 2500 },
  { id: 'storm', name: 'Tem Kaa, Stormfather', dist: 3100 },
  { id: 'maw', name: 'The Verdant Maw', dist: 3700 },
  { id: 'tide', name: 'Nerissa, Tide Empress', dist: 4300 },
  { id: 'aeon', name: 'Aeon, the Chrono Warden', dist: 5000 },
  { id: 'void', name: 'The Nameless Void', dist: 6000 },
];

export const SIGILS: Record<string, { name: string; desc: string }> = {
  ashen: { name: 'Sigil of Ash', desc: '+15% fire damage. Immune to lava burns.' },
  frost: { name: 'Sigil of Rime', desc: '+15% frost damage. Cannot be chilled.' },
  hollow: { name: 'Sigil of the Hollow', desc: '+1 minion limit. Kills heal 2 HP.' },
  storm: { name: 'Sigil of the Storm', desc: '+12% cast speed (cooldowns -12%).' },
  maw: { name: 'Sigil of Bloom', desc: '+15% nature damage. Immune to poison.' },
  tide: { name: 'Sigil of the Deep', desc: '+35% mana regeneration.' },
  aeon: { name: 'Sigil of the Hour', desc: 'Dodge roll costs 30% less stamina. +0.05s i-frames.' },
  void: { name: 'Sigil of the Nameless', desc: '+10% all spell damage.' },
};

export function buildLocations(findLand: (x: number, y: number) => { x: number; y: number }): GameLocation[] {
  const locs: GameLocation[] = [];
  const spawn = findLand(0, 0);
  locs.push({ id: 'shrine_spawn', kind: 'shrine', x: spawn.x, y: spawn.y, name: 'Wayfarer Shrine', r: 42 });
  BOSSES.forEach((b, i) => {
    const [dx, dy] = DIRS[i];
    const p = findLand(dx * b.dist, dy * b.dist);
    locs.push({
      id: `arena_${b.id}`, kind: 'boss', x: p.x, y: p.y,
      name: b.name, bossId: b.id, r: 168, // walkable arena floor radius (arenas.ts)
    });
    // midpath shrine toward each boss (halfway)
    const s = findLand(dx * b.dist * 0.52, dy * b.dist * 0.52);
    locs.push({ id: `shrine_${i}`, kind: 'shrine', x: s.x, y: s.y, name: `Shrine of the ${['Ember', 'Rime', 'Hollow', 'Storm', 'Bloom', 'Deep', 'Hour', 'Abyss'][i]} Road`, r: 42 });
  });
  return locs;
}

// ---------- landmarks (points of interest) ----------
export type LandmarkKind = 'camp' | 'tower' | 'obelisk' | 'cache' | 'grove' | 'dungeon' | 'merchant' | 'geyser';
export interface Landmark {
  id: string; kind: LandmarkKind; x: number; y: number; name: string; tier: number;
}

const LM_CELL = 820; // world px per lattice cell
const LM_NAMES: Record<LandmarkKind, string[]> = {
  camp: ['Raider Camp', 'Marauder Camp', 'Outlaw Den', 'Beast Warren'],
  tower: ['Archmage Tower', 'Sage Spire', 'Forgotten Library', 'Star Reader Rest'],
  obelisk: ['Whispering Obelisk', 'Standing Stone', 'Rune Monolith', 'Echoing Pillar'],
  cache: ['Buried Cache', 'Smuggler Stash', 'Old Strongbox', 'Traveler Hoard'],
  grove: ['Moonwell', 'Healing Grove', 'Fae Spring', 'Silver Pool'],
  dungeon: ['Buried Barrow', 'Sunken Vault', 'Howling Crypt', 'The Gloam Warrens', 'Sealed Reliquary'],
  merchant: ['Wandering Peddler', 'Hollow Trader', 'The Rag Cart', 'Masked Merchant'],
  geyser: ['Aether Geyser', 'Singing Vent', 'Manafall Fissure', 'Weeping Well'],
};

export const LANDMARK_SPRITE: Record<LandmarkKind, string> = {
  camp: 'campfire', tower: 'tower', obelisk: 'obelisk', cache: 'chest', grove: 'spring',
  dungeon: 'barrow', merchant: 'tent', geyser: 'geyser',
};

export function landmarkForCell(seed: number, cellX: number, cellY: number): Landmark | null {
  const h = hash2(cellX, cellY, seed + 7777);
  if (h > 0.66) return null;
  const kindRoll = hash2(cellX, cellY, seed + 8888);
  const kind: LandmarkKind =
    kindRoll < 0.2 ? 'camp' : kindRoll < 0.4 ? 'cache' : kindRoll < 0.55 ? 'tower'
    : kindRoll < 0.68 ? 'obelisk' : kindRoll < 0.78 ? 'grove'
    : kindRoll < 0.88 ? 'dungeon' : kindRoll < 0.95 ? 'merchant' : 'geyser';
  const jx = hash2(cellX, cellY, seed + 9999) * (LM_CELL * 0.5) + LM_CELL * 0.25;
  const jy = hash2(cellX, cellY, seed + 1111) * (LM_CELL * 0.5) + LM_CELL * 0.25;
  const x = Math.round(cellX * LM_CELL + jx);
  const y = Math.round(cellY * LM_CELL + jy);
  const nameIdx = Math.floor(hash2(cellX, cellY, seed + 2222) * LM_NAMES[kind].length);
  const tier = clamp(1 + Math.floor(Math.hypot(x, y) / 1000), 1, 9);
  return { id: `lm_${cellX}_${cellY}`, kind, x, y, name: LM_NAMES[kind][nameIdx], tier };
}

// biome filter + land check happen at call site (game.ts owns the world)
export function landmarksNear(
  seed: number, wx: number, wy: number, radius: number,
  isLand: (x: number, y: number) => boolean,
): Landmark[] {
  const out: Landmark[] = [];
  const c0x = Math.floor((wx - radius) / LM_CELL), c1x = Math.floor((wx + radius) / LM_CELL);
  const c0y = Math.floor((wy - radius) / LM_CELL), c1y = Math.floor((wy + radius) / LM_CELL);
  for (let cy = c0y; cy <= c1y; cy++) {
    for (let cx = c0x; cx <= c1x; cx++) {
      const lm = landmarkForCell(seed, cx, cy);
      if (!lm) continue;
      if (Math.hypot(lm.x - wx, lm.y - wy) > radius) continue;
      if (!isLand(lm.x, lm.y)) continue;
      // never inside (or crowded against) a boss arena or shrine grounds
      let inSpecial = false;
      for (const loc of LOCATIONS) {
        const rr = loc.kind === 'boss' ? arenaDims(loc.bossId!).rw + 60 : loc.r + 60;
        if (Math.hypot(lm.x - loc.x, lm.y - loc.y) < rr) { inSpecial = true; break; }
      }
      if (inSpecial) continue;
      out.push(lm);
    }
  }
  return out;
}

// ---------- biome logic ----------
// GEOGRAPHY MODEL: two slow climate fields (temperature + moisture) over the
// elevation map. Temperature forms huge coherent continents of climate with a
// gentle latitude gradient (north = colder), so you never see a desert hard up
// against a tundra. Travelling north reads: grass → forest → darkwood/taiga →
// tundra. Deserts, wastes and volcanoes only ever appear in the hot south.
export function biomeFn(seed: number) {
  return (wx: number, wy: number): BiomeId => {
    const x = wx * 0.0032, y = wy * 0.0032;
    const e = fbm2(x, y, seed, 4);
    if (e < 0.335) return 'ocean';
    if (e < 0.372) return 'beach';
    // gentle lands near the spawn shrine — no lethal biomes in the first stretches
    const distOrigin = Math.hypot(wx, wy);
    const safe = distOrigin < 620;
    // TEMPERATURE: continent-scale fbm (~2.2kpx features) + latitude gradient.
    // temp decreases as y decreases → the frozen north lies at negative y.
    let t = fbm2(wx * 0.00045 + 91, wy * 0.00045 + 64, seed + 900, 3);
    t = clamp(t + wy * 0.00006, 0, 1);
    // MOISTURE: separate slow field, its own seed
    const m = fbm2(wx * 0.00060 + 43, wy * 0.00060 + 17, seed + 500, 3);
    const c = fbm2(wx * 0.0016 + 210, wy * 0.0016 + 55, seed + 1300, 3);
    const a = fbm2(wx * 0.0034 + 310, wy * 0.0034 + 99, seed + 1700, 3);
    // overlays (keep): arcane rifts, and corruption that never bleeds into the cold
    if (!safe && a > 0.735) return 'arcane';
    if (!safe && t >= 0.48 && c > 0.645) return 'wastes';
    // volcano country: hot rims around the corrupted wastes (never on beaches —
    // the beach check above already returned)
    if (!safe && t >= 0.68 && c > 0.63) return 'volcanic';
    // spawn-safe meadow around the Wayfarer Shrine
    if (safe) return 'grass';
    // ---- temperature bands: every border is sensible by construction ----
    if (t < 0.30) {
      // frozen north: tundra and cold taiga ONLY — never grass or desert
      return m < 0.55 ? 'tundra' : 'darkwood';
    }
    if (t < 0.48) {
      // cool belt: meadows and deep forest
      if (m > 0.72) return 'darkwood';
      if (m > 0.45) return 'forest';
      return 'grass';
    }
    if (t < 0.68) {
      // temperate belt: grass, forest, swamp — never tundra/desert/volcanic
      if (m < 0.62) return 'grass';
      if (m < 0.80) return 'forest';
      return 'swamp';
    }
    // hot south: desert → savannah → forest → swamp — never anything cold
    if (m < 0.42) return 'desert';
    if (m < 0.68) return 'grass';
    if (m < 0.82) return 'forest';
    return 'swamp';
  };
}

// ---------- chunk generation ----------
function biomeTile(biome: BiomeId, wx: number, wy: number, seed: number): number {
  const h = hash2(wx, wy, seed + 7);
  switch (biome) {
    case 'ocean': return T_WATER;
    case 'beach': return h < 0.25 ? T_SAND2 : T_SAND;
    case 'grass': return h < 0.2 ? T_GRASS2 : h < 0.32 ? T_GRASS3 : h < 0.36 ? T_PATH : T_GRASS;
    case 'forest': return h < 0.3 ? T_FOREST2 : T_FOREST;
    case 'darkwood': return h < 0.2 ? T_FOREST : T_DARK;
    case 'desert': return h < 0.25 ? T_SAND2 : T_SAND;
    case 'swamp': return h < 0.14 ? T_SHALLOW : h < 0.24 ? T_FOREST2 : T_SWAMP;
    case 'tundra': return h < 0.14 ? T_TROCK : h < 0.3 ? T_SNOW2 : T_SNOW;
    case 'volcanic': return h < 0.055 ? T_LAVA : h < 0.2 ? T_ROCK : T_VOLC;
    case 'wastes': return h < 0.06 ? T_ROCK : T_WASTES;
    case 'arcane': return h < 0.1 ? T_ROCK : T_ARCANE;
    default: return T_GRASS;
  }
}

const DECOR_RULES: Array<{ biome: BiomeId[]; sprite: string; p: number; solid: boolean }> = [
  { biome: ['grass'], sprite: 'tree', p: 0.028, solid: true },
  { biome: ['grass'], sprite: 'flower', p: 0.05, solid: false },
  { biome: ['grass'], sprite: 'bush', p: 0.022, solid: true },
  { biome: ['grass'], sprite: 'pebbles', p: 0.02, solid: false },
  { biome: ['grass'], sprite: 'sapling', p: 0.012, solid: false },
  { biome: ['grass'], sprite: 'rock', p: 0.014, solid: true },
  { biome: ['grass'], sprite: 'stump', p: 0.009, solid: true },
  { biome: ['grass'], sprite: 'log', p: 0.007, solid: true },
  { biome: ['forest'], sprite: 'tree', p: 0.15, solid: true },
  { biome: ['forest'], sprite: 'bush', p: 0.03, solid: true },
  { biome: ['forest'], sprite: 'mushroom_big', p: 0.02, solid: true },
  { biome: ['forest'], sprite: 'mushroom', p: 0.03, solid: false },
  { biome: ['forest'], sprite: 'flower', p: 0.03, solid: false },
  { biome: ['forest'], sprite: 'log', p: 0.013, solid: true },
  { biome: ['forest'], sprite: 'stump', p: 0.01, solid: true },
  { biome: ['darkwood'], sprite: 'deadtree', p: 0.11, solid: true },
  { biome: ['darkwood'], sprite: 'tree', p: 0.06, solid: true },
  { biome: ['darkwood'], sprite: 'mushroom_big', p: 0.03, solid: true },
  { biome: ['darkwood'], sprite: 'roots', p: 0.024, solid: false },
  { biome: ['darkwood'], sprite: 'skullpile', p: 0.008, solid: true },
  { biome: ['desert'], sprite: 'cactus', p: 0.035, solid: true },
  { biome: ['desert'], sprite: 'pebbles', p: 0.032, solid: false },
  { biome: ['desert'], sprite: 'bones', p: 0.02, solid: false },
  { biome: ['desert'], sprite: 'rock', p: 0.018, solid: true },
  { biome: ['desert'], sprite: 'boulder', p: 0.008, solid: true },
  { biome: ['beach'], sprite: 'shell', p: 0.022, solid: false },
  { biome: ['beach'], sprite: 'pebbles', p: 0.016, solid: false },
  { biome: ['beach'], sprite: 'rock', p: 0.012, solid: true },
  { biome: ['beach'], sprite: 'bones', p: 0.008, solid: false },
  { biome: ['swamp'], sprite: 'deadtree', p: 0.07, solid: true },
  { biome: ['swamp'], sprite: 'reeds', p: 0.05, solid: false },
  { biome: ['swamp'], sprite: 'cattail', p: 0.034, solid: false },
  { biome: ['swamp'], sprite: 'mushroom_big', p: 0.026, solid: true },
  { biome: ['swamp'], sprite: 'roots', p: 0.02, solid: false },
  { biome: ['tundra'], sprite: 'snowdrift', p: 0.05, solid: false },
  { biome: ['tundra'], sprite: 'pine', p: 0.055, solid: true },
  { biome: ['tundra'], sprite: 'icespike', p: 0.04, solid: true },
  { biome: ['tundra'], sprite: 'rock', p: 0.02, solid: true },
  { biome: ['tundra'], sprite: 'stump', p: 0.005, solid: true },
  { biome: ['volcanic'], sprite: 'lavarock', p: 0.05, solid: true },
  { biome: ['volcanic'], sprite: 'rock', p: 0.03, solid: true },
  { biome: ['volcanic'], sprite: 'bones', p: 0.008, solid: false },
  { biome: ['wastes'], sprite: 'deadtree', p: 0.06, solid: true },
  { biome: ['wastes'], sprite: 'crystal', p: 0.035, solid: true },
  { biome: ['wastes'], sprite: 'bones', p: 0.03, solid: false },
  { biome: ['wastes'], sprite: 'skullpile', p: 0.012, solid: true },
  { biome: ['wastes'], sprite: 'crystal_shard', p: 0.012, solid: true },
  { biome: ['arcane'], sprite: 'crystal', p: 0.06, solid: true },
  { biome: ['arcane'], sprite: 'pillar', p: 0.03, solid: true },
  { biome: ['arcane'], sprite: 'crystal_shard', p: 0.018, solid: true },
];

// ---------- roads (the authored spine of the Weald) ----------
interface RoadSeg { x1: number; y1: number; x2: number; y2: number; phase: number }
let ROADS: RoadSeg[] = [];
let roadsDirty = true;

function pushSeg(x1: number, y1: number, x2: number, y2: number, i: number): void {
  if (Math.hypot(x2 - x1, y2 - y1) < 90) return; // don't pave the doorstep
  ROADS.push({ x1, y1, x2, y2, phase: hash2(i, 3, 55) * TAU });
}

/** (Re)build the road network: spawn → road shrines → arena gates, spawn → villages. */
export function rebuildRoads(): void {
  ROADS = [];
  const locs = getLocations();
  const spawn = locs.find((l) => l.id === 'shrine_spawn');
  if (!spawn) return;
  let i = 0;
  for (const loc of locs) {
    if (loc.kind === 'shrine' && loc.id !== 'shrine_spawn') pushSeg(spawn.x, spawn.y, loc.x, loc.y, i++);
  }
  for (const loc of locs) {
    if (loc.kind !== 'boss' || !loc.bossId) continue;
    const idx = ARENA_BOSS_ORDER.indexOf(loc.bossId);
    const sh = locs.find((l) => l.id === `shrine_${idx}`);
    if (!sh) continue;
    // road ends at the arena's front doorstep
    const gapA = arenaGapAngle(loc.x, loc.y);
    const dims = arenaDims(loc.bossId);
    pushSeg(sh.x, sh.y, loc.x + Math.cos(gapA) * (dims.rw + 30), loc.y + Math.sin(gapA) * (dims.rw + 30), i++);
  }
  for (const v of villages()) {
    pushSeg(spawn.x, spawn.y, v.x, v.y, i++);
  }
  roadsDirty = false;
}

function roadAt(wx: number, wy: number): boolean {
  if (roadsDirty) rebuildRoads();
  for (const r of ROADS) {
    const minx = Math.min(r.x1, r.x2) - 20, maxx = Math.max(r.x1, r.x2) + 20;
    const miny = Math.min(r.y1, r.y2) - 20, maxy = Math.max(r.y1, r.y2) + 20;
    if (wx < minx || wx > maxx || wy < miny || wy > maxy) continue;
    const dx = r.x2 - r.x1, dy = r.y2 - r.y1;
    const len2 = dx * dx + dy * dy || 1;
    let t = ((wx - r.x1) * dx + (wy - r.y1) * dy) / len2;
    t = clamp(t, 0, 1);
    const px = r.x1 + dx * t, py = r.y1 + dy * t;
    const wob = Math.sin(t * 9.4 + r.phase) * 5;
    const d = Math.hypot(wx - px, wy - py) - wob;
    if (d < 11) return true;
  }
  return false;
}

export function createWorld(seed: number): World {
  const chunks = new Map<string, Chunk>();
  const biomeAt = biomeFn(seed);

  function genChunk(cx: number, cy: number): Chunk {
    const tiles = new Uint8Array(CHUNK * CHUNK);
    const solid = new Uint8Array(CHUNK * CHUNK);
    const decor: Decor[] = [];
    const ox = cx * CHUNK, oy = cy * CHUNK;
    // majority biome for decor rules
    const midBiome = biomeAt((ox + CHUNK / 2) * TILE, (oy + CHUNK / 2) * TILE);
    for (let ty = 0; ty < CHUNK; ty++) {
      for (let tx = 0; tx < CHUNK; tx++) {
        const wx = (ox + tx) * TILE, wy = (oy + ty) * TILE;
        const biome = biomeAt(wx + 8, wy + 8);
        let t = biomeTile(biome, ox + tx, oy + ty, seed);
        // village dirt plaza (villages.ts lays out houses/well/stall around it)
        const vg = villageGround(wx + 8, wy + 8);
        if (vg === 1 && t !== T_WATER) t = T_PATH;
        // roads: dirt track, fords across water, causeways over lava
        if (t !== T_PATH && roadAt(wx + 8, wy + 8)) {
          if (t === T_WATER) t = T_SHALLOW;
          else if (t === T_LAVA) t = T_TROCK;
          else t = T_PATH;
        }
        tiles[ty * CHUNK + tx] = t;
        if (TILE_SOLID.has(t)) solid[ty * CHUNK + tx] = 1;
      }
    }
    // carve special locations overlapping this chunk
    for (const loc of LOCATIONS) {
      const lx = loc.x, ly = loc.y;
      if (Math.abs(lx - (ox + CHUNK / 2) * TILE) > CHUNK_PX / 2 + loc.r + 96) continue;
      if (Math.abs(ly - (oy + CHUNK / 2) * TILE) > CHUNK_PX / 2 + loc.r + 96) continue;
      const isArena = loc.kind === 'boss';
      if (isArena && loc.bossId) {
        // ---- REAL ARENA: themed mosaic floor + solid wall ring + entrance gap ----
        const dims = arenaDims(loc.bossId);
        const gapA = arenaGapAngle(lx, ly);
        const fBase = arenaFloorBase(loc.bossId);
        for (let ty = 0; ty < CHUNK; ty++) {
          for (let tx = 0; tx < CHUNK; tx++) {
            const wx = (ox + tx) * TILE + 8, wy = (oy + ty) * TILE + 8;
            const dx = wx - lx, dy = wy - ly;
            const d = Math.hypot(dx, dy);
            const idx = ty * CHUNK + tx;
            if (d <= dims.rf) {
              // themed floor: emblem disc → rune ring → outer flagstone
              const tier = d < dims.rf * 0.24 ? 2 : d < dims.rf * 0.66 ? 1 : 0;
              tiles[idx] = fBase + tier;
              solid[idx] = 0;
            } else if (d <= dims.rf + 30 && tiles[idx] === T_SHALLOW) {
              // shallow ford skirt: walkable causeway edge
              tiles[idx] = T_PATH;
            } else if (d <= dims.rw + 34 && d > dims.rw + 6 && tiles[idx] !== T_WATER && tiles[idx] !== T_LAVA) {
              // packed-earth apron outside the walls
              tiles[idx] = T_PATH;
            }
          }
        }
        // wall ring: full solid band (|d - rw| <= 11px) — immune to diagonal
        // aliasing leaks; the pseudo-3D wall sprites fully cover this band
        for (let ty = 0; ty < CHUNK; ty++) {
          for (let tx = 0; tx < CHUNK; tx++) {
            const wx = (ox + tx) * TILE + 8, wy = (oy + ty) * TILE + 8;
            const d = Math.hypot(wx - lx, wy - ly);
            if (d < dims.rw - 8 || d > dims.rw + 8) continue;
            const a = Math.atan2(wy - ly, wx - lx);
            if (angDiff(a, gapA) < dims.gapHalf + 0.02) continue;
            const idx = ty * CHUNK + tx;
            tiles[idx] = T_WALL;
            solid[idx] = 1;
          }
        }
        // road meets the front gate
        const gx = lx + Math.cos(gapA) * (dims.rw + 46), gy = ly + Math.sin(gapA) * (dims.rw + 46);
        for (let ty = 0; ty < CHUNK; ty++) {
          for (let tx = 0; tx < CHUNK; tx++) {
            const wx = (ox + tx) * TILE + 8, wy = (oy + ty) * TILE + 8;
            if (Math.hypot(wx - gx, wy - gy) < 30 && tiles[ty * CHUNK + tx] !== T_WATER && tiles[ty * CHUNK + tx] !== T_LAVA) {
              tiles[ty * CHUNK + tx] = T_PATH;
            }
          }
        }
      } else {
        // ---- shrines: hallowed ring + idol ----
        const rTiles = 3.2;
        for (let ty = 0; ty < CHUNK; ty++) {
          for (let tx = 0; tx < CHUNK; tx++) {
            const wx = (ox + tx) * TILE + 8, wy = (oy + ty) * TILE + 8;
            const d = Math.hypot(wx - lx, wy - ly) / TILE;
            if (d <= rTiles) {
              const idx = ty * CHUNK + tx;
              tiles[idx] = T_ARENA;
              solid[idx] = 0;
            } else if (d <= 3.4 && tiles[ty * CHUNK + tx] !== T_WATER) {
              tiles[ty * CHUNK + tx] = T_PATH;
            }
          }
        }
        decor.push({ x: lx - 7, y: ly - 2, sprite: 'shrine', solid: true, flip: false });
      }
    }
    // decor pass (kept clear of village grounds, roads, and arena grounds)
    for (let ty = 0; ty < CHUNK; ty++) {
      for (let tx = 0; tx < CHUNK; tx++) {
        const t = tiles[ty * CHUNK + tx];
        if (TILE_SOLID.has(t) || t === T_LAVA || t === T_PATH) continue;
        const wx = (ox + tx) * TILE, wy = (oy + ty) * TILE;
        if (villageGround(wx + 8, wy + 8) === 1) continue;
        if (roadAt(wx + 8, wy + 8)) continue;
        // skip inside any special location's grounds
        let nearSpecial = false;
        for (const loc of LOCATIONS) {
          const rr = loc.kind === 'boss' ? arenaDims(loc.bossId!).rw + 30 : loc.r + 52;
          if (Math.abs(wx - loc.x) < rr && Math.abs(wy - loc.y) < rr) { nearSpecial = true; break; }
        }
        if (nearSpecial) continue;
        for (const rule of DECOR_RULES) {
          if (!rule.biome.includes(midBiome)) continue;
          const hh = hash2(ox + tx, oy + ty, seed + 991 + rule.sprite.length);
          if (hh < rule.p) {
            decor.push({
              x: wx + 4 + hash2(ox + tx, oy + ty, seed + 55) * 8,
              y: wy + 6 + hash2(ox + tx, oy + ty, seed + 77) * 6,
              sprite: rule.sprite, solid: rule.solid,
              flip: hash2(ox + tx, oy + ty, seed + 13) > 0.5,
            });
            break;
          }
        }
      }
    }
    return { cx, cy, tiles, solid, biome: midBiome, decor };
  }

  const world: World = {
    seed,
    chunks,
    biomeAt,
    tileAt(wx: number, wy: number): number {
      const cx = Math.floor(wx / CHUNK_PX), cy = Math.floor(wy / CHUNK_PX);
      const ch = world.chunkAt(cx, cy);
      const tx = Math.floor((wx - cx * CHUNK_PX) / TILE);
      const ty = Math.floor((wy - cy * CHUNK_PX) / TILE);
      return ch.tiles[ty * CHUNK + tx];
    },
    solidAt(wx: number, wy: number): boolean {
      const cx = Math.floor(wx / CHUNK_PX), cy = Math.floor(wy / CHUNK_PX);
      const ch = world.chunkAt(cx, cy);
      const tx = Math.floor((wx - cx * CHUNK_PX) / TILE);
      const ty = Math.floor((wy - cy * CHUNK_PX) / TILE);
      return ch.solid[ty * CHUNK + tx] === 1;
    },
    chunkAt(cx: number, cy: number): Chunk {
      const key = `${cx},${cy}`;
      let ch = chunks.get(key);
      if (!ch) { ch = genChunk(cx, cy); chunks.set(key, ch); }
      return ch;
    },
    findLand(x: number, y: number): { x: number; y: number } {
      for (let r = 0; r < 220; r++) {
        const steps = r === 0 ? 1 : r * 6;
        for (let i = 0; i < steps; i++) {
          const a = (i / steps) * Math.PI * 2;
          const px = x + Math.cos(a) * r * TILE * 1.2;
          const py = y + Math.sin(a) * r * TILE * 1.2;
          const b = biomeAt(px, py);
          if (b !== 'ocean') {
            // make sure a small patch is land
            let ok = true;
            for (let k = 0; k < 6; k++) {
              const a2 = (k / 6) * Math.PI * 2;
              if (biomeAt(px + Math.cos(a2) * 40, py + Math.sin(a2) * 40) === 'ocean') { ok = false; break; }
            }
            if (ok) return { x: px, y: py };
          }
        }
      }
      return { x, y };
    },
  };
  return world;
}

// locations are built per-world; store module-level for chunk carving
let LOCATIONS: GameLocation[] = [];
export function setLocations(locs: GameLocation[]) { LOCATIONS = locs; }
export function getLocations(): GameLocation[] { return LOCATIONS; }

export function decorSolidNear(world: World, wx: number, wy: number, r: number): Decor | null {
  const cx = Math.floor(wx / CHUNK_PX), cy = Math.floor(wy / CHUNK_PX);
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const ch = world.chunkAt(cx + dx, cy + dy);
      for (const d of ch.decor) {
        if (!d.solid) continue;
        if (Math.abs(d.x + 6 - wx) < r + 6 && Math.abs(d.y + 6 - wy) < r + 4) return d;
      }
    }
  }
  return null;
}

// circle vs world collision resolve — FLUID MOVEMENT:
// substepped, circle-sampled, slides along walls, nudges around
// tiny corners, and a much smaller decor footprint so bushes and
// pebbles never snag you again.
export function moveWithCollision(
  world: World, x: number, y: number, vx: number, vy: number, r: number, dt: number, passWalls = false,
): { x: number; y: number } {
  if (passWalls) return { x: x + vx * dt, y: y + vy * dt };
  const dx = vx * dt, dy = vy * dt;
  const want = Math.hypot(dx, dy);
  if (want < 0.0001) return { x, y };
  // never step more than ~2.5px per probe: no tunneling, no ghost walls
  const steps = Math.max(1, Math.min(10, Math.ceil(want / 2.5)));
  const R = Math.max(2, r - 0.5); // slightly forgiving radius
  let nx = x, ny = y;
  const blocked = (bx: number, by: number): boolean => {
    // circle vs solid tiles: center + 8 rim samples
    if (world.solidAt(bx, by)) return true;
    for (let k = 0; k < 8; k++) {
      const a = (k / 8) * TAU;
      if (world.solidAt(bx + Math.cos(a) * R * 0.82, by + Math.sin(a) * R * 0.82)) return true;
    }
    // decor: tight box (was a huge invisible square — the #1 snag cause)
    const cx = Math.floor(bx / CHUNK_PX), cy = Math.floor(by / CHUNK_PX);
    for (let oy = -1; oy <= 1; oy++) {
      for (let ox = -1; ox <= 1; ox++) {
        const ch = world.chunkAt(cx + ox, cy + oy);
        for (const d of ch.decor) {
          if (!d.solid) continue;
          if (Math.abs(d.x + 6 - bx) < R + 3 && Math.abs(d.y + 6 - by) < R + 2) return true;
        }
      }
    }
    // village structures: houses/well/stall are solid boxes, fences posts
    const vst = villageStructuresNear(bx, by, R);
    if (vst) {
      for (const s of vst) {
        if (s.spr === 'fence') {
          const fx = s.x - bx, fy = s.y - 4 - by;
          if (fx * fx + fy * fy < (R + 3) * (R + 3)) return true;
        } else {
          const small = s.spr === 'well' || s.spr === 'stall';
          const hw = small ? (s.spr === 'stall' ? 6 : 5) : 7;
          const hh = small ? 3 : 5;
          const cy2 = small ? s.y - 4 : s.y - 6;
          if (Math.abs(bx - s.x) < R + hw && Math.abs(by - cy2) < R + hh) return true;
        }
      }
    }
    return false;
  };
  for (let i = 0; i < steps; i++) {
    const sx = dx / steps, sy = dy / steps;
    const ox = nx, oy = ny;
    // axis-separated slide
    nx += sx;
    if (blocked(nx, ny) && !blocked(ox, ny)) nx = ox;
    ny += sy;
    if (blocked(nx, ny) && !blocked(nx, oy)) ny = oy;
    // corner slide: fully blocked, but a wall corner is catching you —
    // glide around it instead of sticking
    if (nx === ox && ny === oy) {
      const l = Math.hypot(sx, sy) || 1;
      const px = (-sy / l) * l, py = (sx / l) * l;
      if (!blocked(nx + px, ny + py)) { nx += px * 0.65; ny += py * 0.65; }
      else if (!blocked(nx - px, ny - py)) { nx -= px * 0.65; ny -= py * 0.65; }
    }
  }
  return { x: nx, y: ny };
}

export function tileAtSafe(world: World, wx: number, wy: number): number {
  return world.tileAt(clamp(wx, 0, 1 << 28), clamp(wy, 0, 1 << 28));
}
