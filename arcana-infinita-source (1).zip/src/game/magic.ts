/* ============================================================
   magic.ts — THE GRIMOIRE.
   16 schools of magic x 16 spell forms = 256 base spells,
   each leveling independently, plus unrestricted spell
   FUSION creating hybrid dual-element spells (thousands of
   possible combinations).
   ============================================================ */
import {
  ELEMENT_IDS, FORM_IDS, clamp,
  type ElementId, type FormId, type GameCtx, type SpellDef,
} from './core';
import { SIGILS } from './world';
import { SCHOOL_SIG, unlockLevelFor as schoolUnlock } from './schools';

export const SCHOOL_MAX = 40;
export const SPELL_MAX = 10;
export const FUSE_COST = 40;

// ---------- element definitions ----------
export interface ElementDef {
  id: ElementId;
  name: string;
  school: string;       // fancy school name
  prefixes: string[];   // for spell names
  noun: string;         // for fusion names
  blurb: string;
  summonName: string;
  dmg: number;
  mana: number;
}

export const ELEMENTS: Record<ElementId, ElementDef> = {
  fire: {
    id: 'fire', name: 'Fire', school: 'Pyromancy',
    prefixes: ['Ember', 'Pyre', 'Cinder', 'Flame'], noun: 'the Pyre',
    blurb: 'EXPLOSIVE CHAIN REACTIONS. Slain foes erupt, igniting the ground; burning foes take +25% from everything and pop when they die.',
    summonName: 'Cinder Imp', dmg: 1.1, mana: 1.0,
  },
  frost: {
    id: 'frost', name: 'Frost', school: 'Cryomancy',
    prefixes: ['Rime', 'Frost', 'Hoarfrost', 'Winter'], noun: 'Rime',
    blurb: 'GLACIAL STACKER. Every hit is a frost stack — 3 stacks FREEZE solid. Frozen foes SHATTER for +50% damage.',
    summonName: 'Frost Sprite', dmg: 0.95, mana: 1.0,
  },
  lightning: {
    id: 'lightning', name: 'Lightning', school: 'Fulgurmancy',
    prefixes: ['Spark', 'Storm', 'Volt', 'Thunder'], noun: 'the Storm',
    blurb: 'INSTANT arcs. No travel time, no escape — bolts strike the moment you think, then CHAIN to nearby foes. Devastating vs soaked.',
    summonName: 'Storm Sprite', dmg: 1.0, mana: 1.0,
  },
  earth: {
    id: 'earth', name: 'Earth', school: 'Geomancy',
    prefixes: ['Stone', 'Boulder', 'Granite', 'Quake'], noun: 'the Mountain',
    blurb: 'ARTILLERY. Lobbed mortars quake on impact, hurl foes and briefly STUN. +50% vs already stunned or rooted foes.',
    summonName: 'Stone Golem', dmg: 1.15, mana: 1.05,
  },
  wind: {
    id: 'wind', name: 'Wind', school: 'Aeromancy',
    prefixes: ['Gale', 'Zephyr', 'Breeze', 'Squall'], noun: 'Gales',
    blurb: 'MOBILITY STORM. Cheap, blistering piercing gales; casting while moving gives a TAILWIND dash. Faster cooldowns than any school.',
    summonName: 'Gale Wisp', dmg: 0.9, mana: 0.9,
  },
  water: {
    id: 'water', name: 'Water', school: 'Hydromancy',
    prefixes: ['Tide', 'Brook', 'Deluge', 'Mist'], noun: 'the Deep',
    blurb: 'THE ENABLER. Soaks foes: they take +50% from frost AND lightning. Your own water fields cleanse burn and poison, and restore mana.',
    summonName: 'Tide Elemental', dmg: 0.95, mana: 0.95,
  },
  poison: {
    id: 'poison', name: 'Poison', school: 'Toxomancy',
    prefixes: ['Venom', 'Blight', 'Toxin', 'Spore'], noun: 'Blight',
    blurb: 'ESCALATING PLAGUE. Every hit stacks — each stack raises damage taken and the rot; 3+ stacks CONTAGIOUSLY SPREAD on death.',
    summonName: 'Plague Sprite', dmg: 0.9, mana: 0.95,
  },
  blood: {
    id: 'blood', name: 'Blood', school: 'Hemomancy',
    prefixes: ['Crimson', 'Blood', 'Vitae', 'Sanguine'], noun: 'the Crimson',
    blurb: 'PAYS IN BLOOD, not mana. Spells cost HP (60% of the mana price) and carve it back — heals for a share of ALL damage dealt.',
    summonName: 'Crimson Bat', dmg: 1.0, mana: 1.0,
  },
  shadow: {
    id: 'shadow', name: 'Shadow', school: 'Umbromancy',
    prefixes: ['Gloom', 'Umbra', 'Dusk', 'Shade'], noun: 'Umbra',
    blurb: 'CURSE OF DREAD. Soul-seeking shades pass through walls; hits DOOM foes — they deal 30% less damage and may flee in terror.',
    summonName: 'Shade Wraith', dmg: 1.05, mana: 1.0,
  },
  death: {
    id: 'death', name: 'Death', school: 'Necromancy',
    prefixes: ['Grave', 'Bone', 'Soul', 'Mortis'], noun: 'the Grave',
    blurb: 'NECROMANCY. Casts devour nearby corpses (+40% each); kills RISE as thralls. Death kills yield +50% aether.',
    summonName: 'Risen Skeleton', dmg: 1.0, mana: 1.0,
  },
  radiant: {
    id: 'radiant', name: 'Radiant', school: 'Luxomancy',
    prefixes: ['Dawn', 'Holy', 'Sun', 'Lumina'], noun: 'Dawn',
    blurb: 'SANCTIFYING LIGHT. Kills leave healing sanctuary ground. +60% vs the undead; purging evil mends your wounds.',
    summonName: 'Light Spirit', dmg: 1.0, mana: 1.05,
  },
  arcane: {
    id: 'arcane', name: 'Arcane', school: 'Mysticism',
    prefixes: ['Arcane', 'Aether', 'Rune', 'Mana'], noun: 'Aether',
    blurb: 'THE MANA ENGINE. Hits refund mana; missiles split into seeking motes. Cast at full mana for a FREE ARCANE SURGE.',
    summonName: 'Mana Wisp', dmg: 0.95, mana: 0.9,
  },
  time: {
    id: 'time', name: 'Time', school: 'Chronomancy',
    prefixes: ['Hour', 'Chrono', 'Temporal', 'Sand'], noun: 'the Hour',
    blurb: 'TEMPORAL LOCK. Hits are hour charges — 3 charges STOP TIME (1.6s stun). Impacts drag foes into slow molasses.',
    summonName: 'Hour Echo', dmg: 0.85, mana: 1.2,
  },
  void: {
    id: 'void', name: 'Void', school: 'Abyssomancy',
    prefixes: ['Abyss', 'Void', 'Null', 'Rift'], noun: 'the Abyss',
    blurb: 'DEVOURING GRAVITY. Impacts tear wells that drag foes in; kills near rifts are SWALLOWED for bonus aether.',
    summonName: 'Voidling', dmg: 1.1, mana: 1.15,
  },
  nature: {
    id: 'nature', name: 'Nature', school: 'Verdomancy',
    prefixes: ['Bloom', 'Thorn', 'Wild', 'Root'], noun: 'the Wild',
    blurb: 'THE WILD RECLAIMS. Strikes entangle roots; the slain bloom into healing spore pods. Endless sustain.',
    summonName: 'Treant Sapling', dmg: 0.95, mana: 0.95,
  },
  chaos: {
    id: 'chaos', name: 'Chaos', school: 'Pandemonium',
    prefixes: ['Wild', 'Mad', 'Discord', 'Frenzied'], noun: 'Pandemonium',
    blurb: 'WILD MAGIC. Every cast rolls a random element; hits can erupt into RANDOM RITUALS. Unpredictable, catastrophic, fun.',
    summonName: 'Chaos Imp', dmg: 1.15, mana: 1.1,
  },
  crystal: {
    id: 'crystal', name: 'Crystal', school: 'Crystallomancy',
    prefixes: ['Prism', 'Shard', 'Facet', 'Gem'], noun: 'the Prism',
    blurb: 'REFRACTING LIGHT. Impacts split shards into two new angles. Shards that fly far enough accelerate to a PRISM (+50%).',
    summonName: 'Facet Dancer', dmg: 1.0, mana: 1.0,
  },
  metal: {
    id: 'metal', name: 'Metal', school: 'Ferrumancy',
    prefixes: ['Blade', 'Iron', 'Steel', 'Grind'], noun: 'the Forge',
    blurb: 'BLADE DANCER. Projectiles ORBIT you as whirling steel, reaping all they touch, then fling outward on command of time itself.',
    summonName: 'Iron Sentinel', dmg: 0.95, mana: 1.05,
  },
  gravity: {
    id: 'gravity', name: 'Gravity', school: 'Graviturgy',
    prefixes: ['Mass', 'Well', 'Collapse', 'Kernel'], noun: 'the Well',
    blurb: 'MASS COLLAPSE. Impacts are crush points that drag every foe inward; heavy foes get SLAMMED to the ground. Kills implode.',
    summonName: 'Kernel Wisp', dmg: 1.05, mana: 1.1,
  },
  sound: {
    id: 'sound', name: 'Sound', school: 'Sonomancy',
    prefixes: ['Echo', 'Shriek', 'Reverb', 'Crescendo'], noun: 'the Chord',
    blurb: 'ECHO CHAMBER. Near-instant ripples STAGGER foes mid-swing, and every wave ECHOES once behind you for 40% again.',
    summonName: 'Chorus Orb', dmg: 0.9, mana: 0.9,
  },
  bone: {
    id: 'bone', name: 'Bone', school: 'Osteomancy',
    prefixes: ['Femur', 'Marrow', 'Ossify', 'Relic'], noun: 'the Ossuary',
    blurb: 'THE OSSUARY. Hits OSSIFY armor (+15% damage taken); the slain burst into homing bone darts that hunt their kin.',
    summonName: 'Bone Warden', dmg: 1.0, mana: 0.95,
  },
  beast: {
    id: 'beast', name: 'Beast', school: 'Theriomancy',
    prefixes: ['Fang', 'Claw', 'Feral', 'Pack'], noun: 'the Pack',
    blurb: 'THE PACK HUNTS. Hits stack PACK MARKS — at 3 marks a spirit beast LUNGES from you with doubled fangs. Summon more.',
    summonName: 'Spirit Wolf', dmg: 1.0, mana: 1.0,
  },
  plasma: {
    id: 'plasma', name: 'Plasma', school: 'Plasmamancy',
    prefixes: ['Arc', 'Fusion', 'Corona', 'Helios'], noun: 'the Star',
    blurb: 'STELLAR FUSION. Every impact burns AND arcs at once — fire and lightning fused into one screaming star. Ground melts.',
    summonName: 'Plasma Serpent', dmg: 1.2, mana: 1.15,
  },
  mirror: {
    id: 'mirror', name: 'Mirror', school: 'Speculum',
    prefixes: ['Mirror', 'Glass', 'Reversal', 'Simulacrum'], noun: 'the Reflection',
    blurb: 'HALL OF MIRRORS. Expired spells REFLECT backward for half power; hits may spawn mirrored twins from your other side.',
    summonName: 'Mirror Double', dmg: 0.9, mana: 1.0,
  },
};

// ---------- form definitions ----------
export interface FormDef {
  id: FormId;
  name: string;
  noun: string;
  blurb: string;
  dmg: number;
  mana: number;
  cd: number;
}

export const FORMS: Record<FormId, FormDef> = {
  bolt: { id: 'bolt', name: 'Bolt', noun: 'Bolt', blurb: 'A swift projectile.', dmg: 11, mana: 8, cd: 0.3 },
  volley: { id: 'volley', name: 'Volley', noun: 'Volley', blurb: 'A fan of 5 projectiles.', dmg: 7, mana: 17, cd: 0.65 },
  orb: { id: 'orb', name: 'Orb', noun: 'Orb', blurb: 'A slow, massive sphere that pierces foes.', dmg: 26, mana: 18, cd: 0.95 },
  beam: { id: 'beam', name: 'Ray', noun: 'Ray', blurb: 'An instant ray that pierces everything in line.', dmg: 17, mana: 22, cd: 0.75 },
  wave: { id: 'wave', name: 'Wave', noun: 'Wave', blurb: 'A spectral wave that passes through walls.', dmg: 14, mana: 16, cd: 0.85 },
  nova: { id: 'nova', name: 'Nova', noun: 'Nova', blurb: 'A ring of 14 projectiles bursts around you.', dmg: 9, mana: 24, cd: 1.15 },
  storm: { id: 'storm', name: 'Storm', noun: 'Storm', blurb: '10 strikes fall upon the target area.', dmg: 13, mana: 30, cd: 2.4 },
  field: { id: 'field', name: 'Field', noun: 'Field', blurb: 'A lingering zone of devastation.', dmg: 5.5, mana: 26, cd: 1.7 },
  trap: { id: 'trap', name: 'Rune', noun: 'Rune', blurb: 'A hidden rune that detonates when foes approach.', dmg: 36, mana: 20, cd: 1.5 },
  ward: { id: 'ward', name: 'Ward', noun: 'Ward', blurb: 'A protective ward that absorbs damage.', dmg: 0, mana: 30, cd: 7 },
  aura: { id: 'aura', name: 'Aura', noun: 'Aura', blurb: 'An aura clings to you, affecting all nearby.', dmg: 4.5, mana: 22, cd: 2.6 },
  enchant: { id: 'enchant', name: 'Brand', noun: 'Brand', blurb: 'Empowers staff strikes; boosts this element +25%.', dmg: 0, mana: 18, cd: 5 },
  summon: { id: 'summon', name: 'Summon', noun: 'Summon', blurb: 'Summons an ally to fight beside you.', dmg: 0, mana: 35, cd: 4 },
  blink: { id: 'blink', name: 'Step', noun: 'Step', blurb: 'Blink through space itself.', dmg: 0, mana: 12, cd: 0.9 },
  mend: { id: 'mend', name: 'Mend', noun: 'Mend', blurb: 'Restores health.', dmg: 30, mana: 25, cd: 2.6 },
  ritual: { id: 'ritual', name: 'Ritual', noun: 'Ritual', blurb: 'A grand ritual of catastrophic power.', dmg: 75, mana: 55, cd: 12 },
};

// unlock order: form -> school level required (curve lives in schools.ts)
export const UNLOCK_ORDER: Array<{ form: FormId; lvl: number }> = [
  { form: 'bolt', lvl: 1 },
  { form: 'mend', lvl: 2 },
  { form: 'ward', lvl: 4 },
  { form: 'volley', lvl: 5 },
  { form: 'orb', lvl: 7 },
  { form: 'nova', lvl: 9 },
  { form: 'beam', lvl: 11 },
  { form: 'field', lvl: 12 },
  { form: 'blink', lvl: 14 },
  { form: 'storm', lvl: 16 },
  { form: 'trap', lvl: 18 },
  { form: 'wave', lvl: 20 },
  { form: 'enchant', lvl: 22 },
  { form: 'aura', lvl: 24 },
  { form: 'summon', lvl: 26 },
  { form: 'ritual', lvl: 30 },
];

export function unlockLevelFor(el: ElementId, form: FormId): number {
  return schoolUnlock(el, form);
}

export function schoolIdentity(el: ElementId): string {
  return SCHOOL_SIG[el].tagline;
}

function prefixFor(el: ElementId, form: FormId): string {
  const arr = ELEMENTS[el].prefixes;
  const idx = FORM_IDS.indexOf(form);
  return arr[idx % arr.length];
}

export function spellName(el: ElementId, form: FormId): string {
  return `${prefixFor(el, form)} ${FORMS[form].noun}`;
}

const BASE_IDS: string[] = [];
for (const el of ELEMENT_IDS) for (const form of FORM_IDS) BASE_IDS.push(`${el}.${form}`);
export const ALL_SPELL_IDS = BASE_IDS;

export function baseSpellDef(el: ElementId, form: FormId): SpellDef {
  const E = ELEMENTS[el], F = FORMS[form];
  return {
    id: `${el}.${form}`,
    el, el2: null, form,
    name: spellName(el, form),
    desc: `${SCHOOL_SIG[el].tagline} ${E.blurb}`,
    dmg: Math.round(F.dmg * E.dmg * 10) / 10,
    mana: Math.round(F.mana * E.mana * 10) / 10,
    cd: F.cd,
    unlock: unlockLevelFor(el, form),
  };
}

// ---------- fusion ----------
export function fusionId(elA: ElementId, formA: FormId, elB: ElementId): string {
  const els = [elA, elB].sort();
  return `hyb:${els[0]}|${formA}|${els[1]}`;
}

export function parseSpellId(id: string): { el: ElementId; form: FormId; el2: ElementId | null } | null {
  if (id.startsWith('hyb:')) {
    const parts = id.slice(4).split('|');
    if (parts.length !== 3) return null;
    const [elA, form, elB] = parts;
    if (!ELEMENTS[elA as ElementId] || !ELEMENTS[elB as ElementId] || !FORMS[form as FormId]) return null;
    return { el: elA as ElementId, form: form as FormId, el2: elB as ElementId };
  }
  const [el, form] = id.split('.');
  if (!ELEMENTS[el as ElementId] || !FORMS[form as FormId]) return null;
  return { el: el as ElementId, form: form as FormId, el2: null };
}

export function spellDef(id: string): SpellDef | null {
  const p = parseSpellId(id);
  if (!p) return null;
  if (!p.el2) return baseSpellDef(p.el, p.form);
  const primary = p.el, secondary = p.el2;
  const E1 = ELEMENTS[primary], E2 = ELEMENTS[secondary], F = FORMS[p.form];
  const name = `${prefixFor(primary, p.form)} ${F.noun} of ${E2.noun}`;
  const dmg = Math.round(F.dmg * ((E1.dmg + E2.dmg) / 2) * 1.12 * 10) / 10;
  const mana = Math.round(F.mana * ((E1.mana + E2.mana) / 2) * 1.15 * 10) / 10;
  return {
    id,
    el: primary, el2: secondary, form: p.form,
    name,
    desc: `${F.blurb} Dual element: ${E1.name} at full power, ${E2.name} at 45% potency. ${ELEMENTS[primary].blurb.split('.')[0]}, with ${ELEMENTS[secondary].blurb.toLowerCase()}`,
    dmg, mana, cd: F.cd, unlock: 0, fused: true,
  };
}

export function canFuse(G: GameCtx, idA: string, idB: string): { ok: boolean; reason: string; result?: SpellDef } {
  if (idA === idB) return { ok: false, reason: 'Choose two different spells.' };
  const pa = parseSpellId(idA), pb = parseSpellId(idB);
  if (!pa || !pb) return { ok: false, reason: 'Invalid spell.' };
  if (pa.el === pb.el && pa.el2 === pb.el2 && pa.form === pb.form) return { ok: false, reason: 'These spells are identical.' };
  // form chosen from higher spell level
  const lvlA = G.prog.spells[idA]?.lvl ?? 1;
  const lvlB = G.prog.spells[idB]?.lvl ?? 1;
  const form = lvlB > lvlA ? pb.form : pa.form;
  const elA = pa.el, elB = pb.el;
  const id = fusionId(elA, form, elB);
  if (G.prog.fused.includes(id)) return { ok: false, reason: 'This fusion already exists in your grimoire.' };
  return { ok: true, reason: '', result: spellDef(id)! };
}

// ---------- progression math ----------
// v3: schools level via SKILL POINTS (+2 lvls per point); casting fills the
// bar toward bonus points. Bar need scales off half-lvls to match.
export function schoolXpNeed(lvl: number): number { return Math.floor(26 * Math.pow(Math.max(1, Math.floor(lvl / 2)), 1.42) * 0.9); }
export function charXpNeed(lvl: number): number { return Math.floor(55 * Math.pow(lvl, 1.45)); }
export function spellXpNeed(lvl: number): number { return Math.floor(16 * Math.pow(lvl, 1.4)); }

export function attuneSlots(G: GameCtx): number {
  return clamp(2 + Math.floor(G.prog.lvl / 5) + G.prog.slotsExtra, 2, 8);
}

// ---------- power / cost ----------
export function schoolLvl(G: GameCtx, el: ElementId): number {
  return G.prog.schools[el]?.lvl ?? 1;
}
export function spellLvl(G: GameCtx, id: string): number {
  return G.prog.spells[id]?.lvl ?? 1;
}

export function spellDamage(G: GameCtx, def: SpellDef): number {
  const s = schoolLvl(G, def.el);
  const sl = spellLvl(G, def.id);
  let m = 1
    + 0.05 * (s - 1)
    + 0.06 * (sl - 1)
    + 0.018 * (G.prog.lvl - 1);
  // classes & skill tree
  if (G.prog.cls === 'elementalist') m *= 1.12;
  m *= 1 + 0.035 * (G.prog.universal?.intellect ?? 0);
  if (G.prog.sigils.includes('void')) m *= 1.1;
  if (G.prog.sigils.includes(def.el)) m *= 1.15;
  if (G.prog.sigils.includes('ashen') && def.el === 'fire') m *= 1.15;
  if (G.prog.sigils.includes('frost') && def.el === 'frost') m *= 1.15;
  if (G.prog.sigils.includes('maw') && def.el === 'nature') m *= 1.15;
  if (G.player.enchant && def.el === G.player.enchant.el) m *= 1.25;
  // dopamine engine: combo + overdrive
  m *= 1 + Math.min(0.3, G.combo.n * 0.02);
  if (G.overdrive > 0) m *= 1.35;
  // death school: corpse essence consumed amplifies the spell
  if (def.el === 'death') m *= 1 + 0.4 * G.corpseBonus;
  return def.dmg * m;
}

export function spellMana(G: GameCtx, def: SpellDef): number {
  const s = schoolLvl(G, def.el);
  return Math.max(3, def.mana * (1 - Math.min(0.3, 0.007 * (s - 1))));
}

export function spellCd(G: GameCtx, def: SpellDef): number {
  let cd = def.cd;
  cd *= SCHOOL_SIG[def.el]?.proj.cdMul ?? 1; // AEROMANCY casts faster than everything
  if (G.prog.sigils.includes('storm')) cd *= 0.88;
  if (G.player.buffHaste > 0) cd *= 0.65;
  if (G.overdrive > 0) cd *= 0.7;
  return Math.max(0.09, cd);
}

export function mendAmount(G: GameCtx, def: SpellDef): number {
  const s = schoolLvl(G, def.el);
  const sl = spellLvl(G, def.id);
  return def.dmg * (1 + 0.06 * (s - 1)) * (1 + 0.07 * (sl - 1));
}

// ---------- unlock checking ----------
export function knownSpells(G: GameCtx): string[] {
  return Object.keys(G.prog.spells);
}

export function checkUnlocks(G: GameCtx): string[] {
  const unlocked: string[] = [];
  for (const el of ELEMENT_IDS) {
    const s = G.prog.schools[el];
    if (!s) continue;
    for (const form of FORM_IDS) {
      const lvl = unlockLevelFor(el, form);
      const id = `${el}.${form}`;
      if (s.lvl >= lvl && !G.prog.spells[id]) {
        G.prog.spells[id] = { lvl: 1, xp: 0 };
        unlocked.push(id);
      }
    }
  }
  return unlocked;
}
