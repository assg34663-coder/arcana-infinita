/* ============================================================
   enemies.ts — bestiary, AI archetypes, elite affixes,
   world spawner, and death/loot handling.
   ============================================================ */
import {
  TAU, clamp, angTo, dist, rand, randR, chance, pick, circleHit,
  type Enemy, type EnemyKind, type ElementId, type GameCtx, type BiomeId,
} from './core';
import { elColor, elColor2, SPR } from './sprites';
import {
  makeBullet, burst, spawnParticle, addText, damagePlayer,
  spawnPickup, explosion, damageEnemy, damageBoss,
  bumpCombo, schoolKill, addRing,
} from './fx';
import { moveWithCollision, getLocations } from './world';
import { inVillage } from './villages';
import { createMinion } from './casting';
import { trackKill } from './quests';
import { relicVal, spawnRelicDrop, spawnEchoDrop } from './items';

// ---------- bestiary ----------
const KIND_LIST: EnemyKind[] = [
  { id: 'slime', name: 'Bogling', sprite: 'slime', hp: 26, dmg: 6, speed: 38, r: 6, xp: 9, aether: 4, tier: 1, ai: 'melee', el: 'nature', atkRange: 16, atkCd: 1.2, biomes: ['grass', 'forest', 'darkwood', 'beach', 'swamp'], corpse: true },
  { id: 'bat', name: 'Cave Bat', sprite: 'bat', hp: 16, dmg: 5, speed: 78, r: 5, xp: 8, aether: 3, tier: 1, ai: 'melee', el: 'shadow', atkRange: 14, atkCd: 1.0, fly: true, biomes: ['grass', 'forest', 'darkwood', 'tundra', 'volcanic', 'arcane'], corpse: false },
  { id: 'imp', name: 'Cinder Imp', sprite: 'imp', hp: 22, dmg: 9, speed: 52, r: 6, xp: 12, aether: 5, tier: 1, ai: 'ranged', el: 'fire', atkRange: 170, atkCd: 1.9, bulletSpeed: 130, biomes: ['volcanic', 'wastes', 'desert'], corpse: true },
  { id: 'wisp', name: 'Feral Wisp', sprite: 'wisp', hp: 18, dmg: 8, speed: 55, r: 5, xp: 11, aether: 4, tier: 1, ai: 'orbiter', el: 'arcane', atkRange: 160, atkCd: 2.4, bulletSpeed: 110, fly: true, biomes: ['arcane', 'grass', 'forest'], corpse: false },
  { id: 'skel', name: 'Rattling Bones', sprite: 'skel', hp: 30, dmg: 10, speed: 44, r: 6, xp: 13, aether: 6, tier: 1, ai: 'melee', el: 'death', atkRange: 17, atkCd: 1.3, undead: true, parryMelee: true, biomes: ['wastes', 'darkwood', 'tundra', 'desert'], corpse: true },
  { id: 'shroom', name: 'Sporeling', sprite: 'shroom', hp: 24, dmg: 8, speed: 30, r: 6, xp: 10, aether: 4, tier: 1, ai: 'melee', el: 'poison', atkRange: 15, atkCd: 1.5, biomes: ['forest', 'swamp', 'darkwood'], corpse: true },

  { id: 'cultist', name: 'Hollow Cultist', sprite: 'cultist', hp: 55, dmg: 14, speed: 48, r: 6, xp: 26, aether: 12, tier: 2, ai: 'ranged', el: 'shadow', atkRange: 200, atkCd: 2.1, bulletSpeed: 140, biomes: ['wastes', 'arcane', 'darkwood'], corpse: true },
  { id: 'fsprite', name: 'Frost Sprite', sprite: 'fsprite', hp: 48, dmg: 12, speed: 58, r: 6, xp: 24, aether: 11, tier: 2, ai: 'ranged', el: 'frost', atkRange: 190, atkCd: 1.8, bulletSpeed: 150, fly: true, biomes: ['tundra'], corpse: false },
  { id: 'scorp', name: 'Dune Stalker', sprite: 'scorp', hp: 70, dmg: 16, speed: 66, r: 7, xp: 28, aether: 13, tier: 2, ai: 'charger', el: 'earth', atkRange: 190, atkCd: 2.6, biomes: ['desert', 'beach'], corpse: true },
  { id: 'witch', name: 'Bog Witch', sprite: 'witch', hp: 60, dmg: 13, speed: 42, r: 6, xp: 27, aether: 12, tier: 2, ai: 'ranged', el: 'poison', atkRange: 210, atkCd: 2.3, bulletSpeed: 120, biomes: ['swamp'], corpse: true },
  { id: 'golem', name: 'Stone Golem', sprite: 'golem', hp: 130, dmg: 20, speed: 26, r: 8, xp: 34, aether: 16, tier: 2, ai: 'melee', el: 'earth', atkRange: 20, atkCd: 1.8, parryMelee: true, biomes: ['volcanic', 'desert', 'arcane'], corpse: true },
  { id: 'wraith', name: 'Barrow Wraith', sprite: 'wraith', hp: 52, dmg: 15, speed: 40, r: 6, xp: 30, aether: 14, tier: 2, ai: 'ghost', el: 'shadow', atkRange: 16, atkCd: 1.4, undead: true, passWalls: true, biomes: ['wastes', 'darkwood', 'arcane'], corpse: false },

  { id: 'hound', name: 'Ashen Hound', sprite: 'hound', hp: 95, dmg: 22, speed: 92, r: 7, xp: 48, aether: 22, tier: 3, ai: 'charger', el: 'fire', atkRange: 210, atkCd: 2.4, biomes: ['volcanic', 'wastes', 'desert'], corpse: true },
  { id: 'djinn', name: 'Thunder Djinn', sprite: 'djinn', hp: 88, dmg: 20, speed: 60, r: 7, xp: 50, aether: 24, tier: 3, ai: 'orbiter', el: 'lightning', atkRange: 190, atkCd: 2.0, bulletSpeed: 170, fly: true, biomes: ['arcane', 'grass', 'desert'], corpse: false },
  { id: 'knight', name: 'Blood Knight', sprite: 'knight', hp: 150, dmg: 26, speed: 55, r: 7, xp: 55, aether: 26, tier: 3, ai: 'melee', el: 'blood', atkRange: 20, atkCd: 1.5, parryMelee: true, biomes: ['wastes', 'tundra', 'arcane'], corpse: true },
  { id: 'plague', name: 'Plague Bearer', sprite: 'plague', hp: 110, dmg: 18, speed: 38, r: 7, xp: 52, aether: 24, tier: 3, ai: 'ranged', el: 'poison', atkRange: 220, atkCd: 2.2, bulletSpeed: 110, biomes: ['swamp', 'wastes'], corpse: true },
  { id: 'tendril', name: 'Void Tendril', sprite: 'tendril', hp: 120, dmg: 22, speed: 34, r: 8, xp: 56, aether: 26, tier: 3, ai: 'ranged', el: 'void', atkRange: 230, atkCd: 2.5, bulletSpeed: 100, biomes: ['wastes', 'arcane'], corpse: true },
  { id: 'gargoyle', name: 'Iron Gargoyle', sprite: 'gargoyle', hp: 160, dmg: 24, speed: 70, r: 7, xp: 58, aether: 27, tier: 3, ai: 'charger', el: 'earth', atkRange: 200, atkCd: 2.7, fly: true, biomes: ['arcane', 'volcanic', 'tundra'], corpse: true },
  { id: 'chaos', name: 'Chaos Spawn', sprite: 'chaos', hp: 100, dmg: 21, speed: 56, r: 7, xp: 60, aether: 30, tier: 3, ai: 'ranged', el: 'chaos', atkRange: 200, atkCd: 1.9, bulletSpeed: 140, biomes: ['arcane', 'wastes'], corpse: true },
  { id: 'fwarden', name: 'Frost Warden', sprite: 'fwarden', hp: 170, dmg: 25, speed: 46, r: 7, xp: 62, aether: 30, tier: 3, ai: 'melee', el: 'frost', atkRange: 22, atkCd: 1.7, parryMelee: true, biomes: ['tundra'], corpse: true },

  // the weaver's parts — spawned & choreographed by spider.ts (never naturally)
  { id: 'weaver_leg', name: 'Weaver Leg', sprite: 'slime', hp: 90, dmg: 0, speed: 0, r: 5, xp: 16, aether: 5, tier: 1, ai: 'melee', el: 'shadow', atkRange: 0, atkCd: 99, biomes: [], corpse: false },
  { id: 'weaver_body', name: 'The Weaver', sprite: 'slime', hp: 560, dmg: 0, speed: 0, r: 13, xp: 0, aether: 0, tier: 1, ai: 'melee', el: 'shadow', atkRange: 0, atkCd: 99, biomes: [], corpse: false },

  // mini-boss parts — spawned & choreographed by minibosses.ts (never naturally)
  { id: 'mb_maw', name: 'The Cinder Maw', sprite: 'slime', hp: 680, dmg: 0, speed: 0, r: 15, xp: 0, aether: 0, tier: 1, ai: 'melee', el: 'fire', atkRange: 0, atkCd: 99, biomes: [], corpse: false },
  { id: 'mb_roc', name: 'The Storm Roc', sprite: 'slime', hp: 560, dmg: 0, speed: 0, r: 12, xp: 0, aether: 0, tier: 1, ai: 'melee', el: 'lightning', atkRange: 0, atkCd: 99, biomes: [], corpse: false },
  { id: 'mb_roc_wing', name: 'Roc Wing', sprite: 'slime', hp: 120, dmg: 0, speed: 0, r: 6, xp: 20, aether: 8, tier: 1, ai: 'melee', el: 'lightning', atkRange: 0, atkCd: 99, biomes: [], corpse: false },
  { id: 'mb_choir', name: 'The Bone Choir', sprite: 'slime', hp: 470, dmg: 0, speed: 0, r: 14, xp: 0, aether: 0, tier: 1, ai: 'melee', el: 'death', atkRange: 0, atkCd: 99, biomes: [], corpse: false },
  { id: 'mb_choir_skull', name: 'Choir Skull', sprite: 'slime', hp: 70, dmg: 0, speed: 0, r: 5, xp: 14, aether: 6, tier: 1, ai: 'melee', el: 'death', atkRange: 0, atkCd: 99, biomes: [], corpse: false },
  { id: 'mb_mimic', name: 'The Vault Mimic', sprite: 'slime', hp: 600, dmg: 0, speed: 0, r: 13, xp: 0, aether: 0, tier: 1, ai: 'melee', el: 'shadow', atkRange: 0, atkCd: 99, biomes: [], corpse: false },
];

export const KINDS: Record<string, EnemyKind> = {};
for (const k of KIND_LIST) KINDS[k.id] = k;

export function tierOfDistance(G: GameCtx, x: number, y: number): number {
  const d = Math.hypot(x, y);
  // NG+ — THE WEALD INVERTS: every foe fights one ring stronger per layer
  return clamp(1 + Math.floor(d / 1000) + (G.prog.ngPlus ?? 0), 1, 12);
}

// HARD MODE: global lethality multipliers (Elden-Ring tuning)
export const DIFF = { dmg: 1.28, hp: 1.15, bullet: 1.15, cd: 0.85, contact: 0.9, aggro: 400 };

// doom curse: doomed foes deal 30% less damage
function foeDmg(e: Enemy, base: number): number {
  return base * e.dmgMul * (e.st.doom ? 0.7 : 1);
}

// ---------- spawning ----------
export function spawnEnemy(G: GameCtx, kindId: string, x: number, y: number, tier: number, eliteChance = 0): Enemy {
  const k = KINDS[kindId];
  let elite: Enemy['elite'] = null;
  if (chance(eliteChance)) elite = pick(['frenzied', 'titan', 'volatile', 'arcane'] as const);
  let hpMul = (1 + 0.4 * (tier - 1)) * DIFF.hp;
  let dmgMul = (1 + 0.3 * (tier - 1)) * DIFF.dmg;
  let scale = 1;
  let speed = k.speed;
  if (elite === 'titan') { hpMul *= 3; dmgMul *= 1.3; scale = 1.4; }
  if (elite === 'frenzied') { speed *= 1.55; dmgMul *= 1.2; }
  const hp = k.hp * hpMul;
  const e: Enemy = {
    x, y, vx: 0, vy: 0, r: k.r * scale,
    hp, maxHp: hp, team: 'enemy', st: {},
    flash: 0, dead: false, deadT: 0, face: 1, anim: rand(0, 9),
    undead: k.undead, fly: k.fly ?? undefined, passWalls: k.passWalls ?? undefined,
    scale, kind: k, tier, elite,
    state: 'chase', aiT: rand(0, 2), atkT: rand(0, k.atkCd), windup: 0,
    roamX: x, roamY: y, dmgMul, hpMul,
    contactT: 0, spawnGuard: 0.5,
  };
  if (k.fly) e.fly = true;
  G.enemies.push(e);
  return e;
}

function pickSpawnKind(G: GameCtx, biome: BiomeId, tier: number): string {
  const pool = KIND_LIST.filter((k) => k.biomes.includes(biome) && k.tier <= tier);
  if (pool.length === 0) return 'slime';
  // prefer higher-tier as tier grows
  const weights = pool.map((k) => 1 + (k.tier === Math.min(tier, 3) ? 2 : 0) + (tier >= 3 && k.tier === 3 ? 1.5 : 0));
  let total = weights.reduce((a, b) => a + b, 0);
  let roll = rand(0, total);
  for (let i = 0; i < pool.length; i++) {
    roll -= weights[i];
    if (roll <= 0) return pool[i].id;
  }
  return pool[0].id;
}

export function updateSpawner(G: GameCtx, dt: number): void {
  G.spawnT -= dt;
  const tier = tierOfDistance(G, G.player.x, G.player.y);
  // a crowded, living world — you should never struggle to find a fight
  const cap = Math.min(13 + tier * 2, 32);
  // shrines & villages are sanctuaries: no spawning while the mage rests
  let inSanctuary = false;
  for (const loc of getLocations()) {
    if (loc.kind === 'shrine' && dist(G.player.x, G.player.y, loc.x, loc.y) < 250) { inSanctuary = true; break; }
  }
  if (inVillage(G.player.x, G.player.y)) inSanctuary = true;
  if (G.spawnT <= 0) {
    G.spawnT = randR(0.9, 1.9);
    if (!inSanctuary && G.mode === 'play') {
      // packs: mostly loners, but pairs and trios keep the world dangerous
      const room = cap - G.enemies.length;
      let pack = 1;
      if (chance(0.42)) pack = 2;
      if (chance(0.14)) pack = 3;
      pack = Math.min(pack, room);
      for (let i = 0; i < pack; i++) {
        const a = rand(0, TAU) + i * 2.1;
        const d = randR(310, 540);
        const x = G.player.x + Math.cos(a) * d;
        const y = G.player.y + Math.sin(a) * d;
        if (G.world.solidAt(x, y)) continue;
        if (inVillage(x, y)) continue; // villages are safe ground
        const biome = G.world.biomeAt(x, y);
        if (biome === 'ocean') continue;
        const kindId = pickSpawnKind(G, biome, tier);
        spawnEnemy(G, kindId, x, y, tier, 0.07 + tier * 0.018);
      }
    }
  }
  // despawn far (the weaver manages its own parts)
  for (const e of G.enemies) {
    if (!e.puppet && dist(e.x, e.y, G.player.x, G.player.y) > 1050) e.dead = true;
  }
}

// ---------- enemy bullets ----------
export function enemyBullet(
  G: GameCtx, e: Enemy, ang: number, speed: number, opts: { dmgMul?: number; r?: number; homing?: number; parryable?: boolean; life?: number; kind?: 'bolt' | 'orb' | 'shard'; pierce?: number } = {},
): void {
  makeBullet(G, {
    x: e.x + Math.cos(ang) * 8, y: e.y + Math.sin(ang) * 8,
    vx: Math.cos(ang) * speed * DIFF.bullet, vy: Math.sin(ang) * speed * DIFF.bullet,
    r: opts.r ?? 3.5,
    dmg: foeDmg(e, e.kind.dmg * (opts.dmgMul ?? 0.8)),
    el: e.kind.el, el2: null, team: 'enemy',
    life: opts.life ?? 3, kind: opts.kind ?? 'bolt',
    color: elColor(e.kind.el), color2: elColor2(e.kind.el),
    homing: opts.homing ?? 0, parryable: opts.parryable ?? false,
    trail: 0.4, from: e,
  });
}

// ---------- AI ----------
export function updateEnemies(G: GameCtx, dt: number): void {
  const p = G.player;
  const enemies = G.enemies;
  for (const e of enemies) {
    if (e.dead) continue;
    e.anim += dt;
    e.flash = Math.max(0, e.flash - dt);
    e.spawnGuard = Math.max(0, e.spawnGuard - dt);
    e.contactT = Math.max(0, e.contactT - dt);
    e.atkT -= dt;
    // status ticks
    if (e.st.burn) {
      e.st.burn.t -= dt;
      e.hp -= e.st.burn.dps * dt;
      if (G.frame % 12 === 0) spawnParticle(G, { x: e.x + randR(-4, 4), y: e.y - 4, vy: -22, life: 0.4, size: 2, color: '#ff7a3e', glow: true });
      if (e.st.burn.t <= 0) delete e.st.burn;
      if (e.hp <= 0) { handleEnemyDeath(G, e, 'fire'); continue; }
    }
    if (e.st.poison) {
      e.st.poison.t -= dt;
      e.hp -= e.st.poison.dps * dt;
      if (e.st.poison.t <= 0) delete e.st.poison;
      if (e.hp <= 0) { handleEnemyDeath(G, e, 'poison'); continue; }
    }
    if (e.st.chill) { e.st.chill.t -= dt; if (e.st.chill.t <= 0) delete e.st.chill; }
    if (e.st.stun) { e.st.stun.t -= dt; if (e.st.stun.t <= 0) delete e.st.stun; }
    if (e.st.frozen) {
      e.st.frozen.t -= dt;
      if (e.st.frozen.t <= 0) { delete e.st.frozen; burst(G, e.x, e.y, '#cfeefc', 6, 60); }
    }
    if (e.st.root) { e.st.root.t -= dt; if (e.st.root.t <= 0) delete e.st.root; }
    if (e.st.wet) { e.st.wet.t -= dt; if (e.st.wet.t <= 0) delete e.st.wet; }
    if (e.st.amp) { e.st.amp.t -= dt; if (e.st.amp.t <= 0) delete e.st.amp; }
    if (e.st.fear) { e.st.fear.t -= dt; if (e.st.fear.t <= 0) delete e.st.fear; }
    if (e.st.doom) { e.st.doom.t -= dt; if (e.st.doom.t <= 0) delete e.st.doom; }
    if (e.st.frzStack) { e.st.frzStack.t -= dt; if (e.st.frzStack.t <= 0) delete e.st.frzStack; }
    if (e.st.plague) { e.st.plague.t -= dt; if (e.st.plague.t <= 0) { delete e.st.plague; delete e.st.amp; } }
    if (e.st.tStop) { e.st.tStop.t -= dt; if (e.st.tStop.t <= 0) delete e.st.tStop; }

    // the weaver's parts are puppets — spider.ts choreographs everything
    if (e.puppet) continue;

    if (e.st.stun || e.st.frozen) { e.vx *= 0.9; e.vy *= 0.9; integrateEnemy(G, e, dt); continue; }

    const spdMult = (e.st.chill?.mult ?? 1) * (e.elite === 'frenzied' ? 1 : 1);
    const d = dist(e.x, e.y, p.x, p.y);
    const ang = angTo(e.x, e.y, p.x, p.y);
    const canSee = d < DIFF.aggro;
    // sanctuary leash: foes flee the shrine's light while you rest within it
    for (const loc of getLocations()) {
      if (loc.kind === 'shrine' && dist(p.x, p.y, loc.x, loc.y) < 250 && dist(e.x, e.y, loc.x, loc.y) < 330) {
        e.st.fear = { t: 0.4 };
      }
    }
    const fleeing = !!e.st.fear;

    if (fleeing) {
      e.vx += -Math.cos(ang) * e.kind.speed * spdMult * dt * 4;
      e.vy += -Math.sin(ang) * e.kind.speed * spdMult * dt * 4;
      integrateEnemy(G, e, dt);
      continue;
    }

    switch (e.kind.ai) {
      case 'melee': {
        if (canSee) {
          if (e.state !== 'windup' && e.state !== 'attack') e.state = 'chase';
          if (d > e.kind.atkRange) {
            e.vx += Math.cos(ang) * e.kind.speed * spdMult * dt * 5;
            e.vy += Math.sin(ang) * e.kind.speed * spdMult * dt * 5;
          } else if (e.atkT <= 0 && e.state !== 'windup') {
            e.state = 'windup'; e.windup = 0.4;
          }
        }
        if (e.state === 'windup') {
          e.windup -= dt;
          e.vx *= 0.8; e.vy *= 0.8;
          if (e.windup <= 0) {
            e.state = 'attack'; e.aiT = 0.25;
            e.atkT = e.kind.atkCd;
            // lunge + parryable slash projectile
            e.vx += Math.cos(ang) * 220; e.vy += Math.sin(ang) * 220;
            if (e.kind.parryMelee) {
              makeBullet(G, {
                x: e.x + Math.cos(ang) * 10, y: e.y + Math.sin(ang) * 10,
                vx: Math.cos(ang) * 165, vy: Math.sin(ang) * 165,
                r: 9, dmg: foeDmg(e, e.kind.dmg * 0.9), el: e.kind.el, el2: null,
                team: 'enemy', life: 0.4, kind: 'shard', passWalls: true,
                parryable: true, color: '#ffd75e', color2: '#fff8d8', from: e,
              });
            }
          }
        } else if (e.state === 'attack') {
          e.aiT -= dt;
          if (e.aiT <= 0) e.state = 'chase';
        }
        break;
      }
      case 'ranged': {
        const want = e.kind.atkRange * 0.8;
        if (canSee) {
          if (d > want + 40) {
            e.vx += Math.cos(ang) * e.kind.speed * spdMult * dt * 4;
            e.vy += Math.sin(ang) * e.kind.speed * spdMult * dt * 4;
          } else if (d < want - 60) {
            e.vx -= Math.cos(ang) * e.kind.speed * spdMult * dt * 3;
            e.vy -= Math.sin(ang) * e.kind.speed * spdMult * dt * 3;
          } else {
            // strafe
            e.vx += Math.cos(ang + Math.PI / 2) * e.kind.speed * spdMult * dt * 2 * (e.face || 1);
            e.vy += Math.sin(ang + Math.PI / 2) * e.kind.speed * spdMult * dt * 2 * (e.face || 1);
            if (chance(0.01)) e.face = -(e.face || 1);
          }
          if (e.atkT <= 0 && d < e.kind.atkRange + 60 && e.state !== 'windup') {
            e.state = 'windup'; e.windup = 0.5;
          }
        }
        if (e.state === 'windup') {
          e.windup -= dt;
          e.vx *= 0.85; e.vy *= 0.85;
          if (e.windup <= 0) {
            e.state = 'chase';
            e.atkT = e.kind.atkCd * DIFF.cd * randR(0.9, 1.2);
            const n = e.tier >= 3 ? 3 : e.tier >= 2 ? 2 : 1;
            for (let i = 0; i < n; i++) {
              const a2 = ang + (i - (n - 1) / 2) * 0.18;
              enemyBullet(G, e, a2, e.kind.bulletSpeed ?? 140, e.elite === 'arcane' ? { homing: 1.2 } : {});
            }
            if (e.elite === 'arcane') {
              for (let i = 0; i < 8; i++) enemyBullet(G, e, (i / 8) * TAU, 110, { dmgMul: 0.6 });
            }
            G.audio.sfx('cast', randR(0.7, 1), 0.5);
          }
        }
        break;
      }
      case 'charger': {
        if (e.state === 'attack') {
          e.aiT -= dt;
          if (e.aiT <= 0) { e.state = 'chase'; e.vx *= 0.2; e.vy *= 0.2; }
        } else if (e.state === 'windup') {
          e.windup -= dt;
          e.vx *= 0.7; e.vy *= 0.7;
          if (e.windup <= 0) {
            e.state = 'attack'; e.aiT = 0.55;
            e.atkT = e.kind.atkCd;
            e.vx = Math.cos(ang) * 330; e.vy = Math.sin(ang) * 330;
            G.audio.sfx('dodge', 0.6, 0.8);
          }
        } else if (canSee) {
          if (d > e.kind.atkRange) {
            e.vx += Math.cos(ang) * e.kind.speed * spdMult * dt * 4.5;
            e.vy += Math.sin(ang) * e.kind.speed * spdMult * dt * 4.5;
          } else if (e.atkT <= 0) {
            e.state = 'windup'; e.windup = 0.5;
          }
        }
        break;
      }
      case 'orbiter': {
        if (canSee) {
          const tang = ang + Math.PI / 2 * (e.face || 1);
          const radial = (d - 150) * 0.02;
          e.vx += (Math.cos(tang) + Math.cos(ang) * radial) * e.kind.speed * spdMult * dt * 4;
          e.vy += (Math.sin(tang) + Math.sin(ang) * radial) * e.kind.speed * spdMult * dt * 4;
          if (chance(0.008)) e.face = -(e.face || 1);
          if (e.atkT <= 0 && d < e.kind.atkRange) {
            e.atkT = e.kind.atkCd;
            const base = rand(0, TAU);
            for (let i = 0; i < 4; i++) enemyBullet(G, e, base + (i / 4) * TAU, (e.kind.bulletSpeed ?? 120), { dmgMul: 0.5 });
            G.audio.sfx('cast', 1.1, 0.4);
          }
        }
        break;
      }
      case 'summoner': {
        // witch variant: keeps distance, occasionally spawns minions
        if (canSee) {
          if (d < 140) {
            e.vx -= Math.cos(ang) * e.kind.speed * spdMult * dt * 3;
            e.vy -= Math.sin(ang) * e.kind.speed * spdMult * dt * 3;
          }
          if (e.atkT <= 0) {
            e.atkT = e.kind.atkCd * 1.6;
            if (chance(0.35) && G.enemies.length < 30) {
              const spawnKind = e.tier >= 3 ? 'shroom' : 'slime';
              for (let i = 0; i < 2; i++) {
                spawnEnemy(G, spawnKind, e.x + randR(-20, 20), e.y + randR(-20, 20), Math.max(1, e.tier - 1), 0);
              }
              burst(G, e.x, e.y, elColor(e.kind.el), 8, 60);
            } else {
              enemyBullet(G, e, ang, e.kind.bulletSpeed ?? 120, {});
            }
          }
        }
        break;
      }
      case 'ghost': {
        if (canSee || d < 500) {
          e.vx += Math.cos(ang) * e.kind.speed * spdMult * dt * 2.2;
          e.vy += Math.sin(ang) * e.kind.speed * spdMult * dt * 2.2;
        }
        break;
      }
    }

    integrateEnemy(G, e, dt);

    // separation
    for (const o of enemies) {
      if (o === e || o.dead) continue;
      const dd = dist(e.x, e.y, o.x, o.y);
      const min = e.r + o.r;
      if (dd < min && dd > 0.01) {
        const push = (min - dd) * 4;
        const a2 = angTo(o.x, o.y, e.x, e.y);
        e.vx += Math.cos(a2) * push * dt * 10;
        e.vy += Math.sin(a2) * push * dt * 10;
      }
    }

    // contact damage
    if (!p.dead && e.spawnGuard <= 0 && circleHit(e.x, e.y, e.r, p.x, p.y, p.r)) {
      if (e.contactT <= 0) {
        e.contactT = 1.0;
        damagePlayer(G, foeDmg(e, e.kind.dmg * DIFF.contact), e.kind.el, { melee: true, from: e });
        const a2 = angTo(e.x, e.y, p.x, p.y);
        p.vx += Math.cos(a2) * 120; p.vy += Math.sin(a2) * 120;
      }
      // frost ward chills melee attackers
      if (p.ward?.el === 'frost' && !e.undead) {
        e.st.chill = { t: 1.5, mult: 0.4 };
        if (chance(0.3)) e.st.stun = { t: 0.5 };
      }
      if (p.ward?.el === 'fire') {
        damageEnemy(G, e, 6 + (G.prog.schools.fire?.lvl ?? 1) * 0.4, 'fire', { silent: true });
      }
    }
  }

  // volatile elite explosions + cleanup
  for (const e of enemies) {
    if (e.dead && e.elite === 'volatile' && !e.exploded) {
      e.exploded = true;
      explosion(G, e.x, e.y, 52, 18 + e.tier * 6, 'fire', 'enemy', {});
    }
  }
  let w = 0;
  for (let i = 0; i < enemies.length; i++) {
    if (!enemies[i].dead || enemies[i].deadT > 0) enemies[w++] = enemies[i];
  }
  enemies.length = w;
}

function integrateEnemy(G: GameCtx, e: Enemy, dt: number): void {
  const drag = e.fly ? 3.4 : 6;
  e.vx *= 1 - clamp(drag * dt, 0, 0.9);
  e.vy *= 1 - clamp(drag * dt, 0, 0.9);
  const maxS = 400;
  const sp = Math.hypot(e.vx, e.vy);
  if (sp > maxS) { e.vx = (e.vx / sp) * maxS; e.vy = (e.vy / sp) * maxS; }
  const mv = moveWithCollision(G.world, e.x, e.y, e.vx, e.vy, e.r, dt, !!e.passWalls);
  e.x = mv.x; e.y = mv.y;
  if (Math.abs(e.vx) > 6) e.face = e.vx > 0 ? 1 : -1;
}

// ---------- death & loot ----------
export function handleEnemyDeath(G: GameCtx, e: Enemy, el: ElementId): void {
  if (e.dead) return;
  e.dead = true;
  const tierMul = 1 + 0.55 * (e.tier - 1);
  let aether = Math.round(e.kind.aether * tierMul * randR(0.8, 1.3) * (e.elite ? 3 : 1));
  if (el === 'death') aether = Math.round(aether * 1.5);
  aether = Math.round(aether * (1 + relicVal(G, 'aetherGain'))); // RELIC: the toll collector
  G.prog.aether += aether;
  G.prog.kills++;
  const xpGain = e.kind.xp * tierMul * (e.elite ? 2.5 : 1) * (1 + 0.08 * relicVal(G, 'scholar')); // RELIC: the sage's hollow skull
  gainXp(G, xpGain);
  if (G.prog.sigils.includes('hollow')) {
    G.player.hp = Math.min(G.player.maxHp, G.player.hp + 2);
  }
  // RELICS: kill-tribute — the grey tithe mends, the collector pays
  const hok = relicVal(G, 'healOnKill');
  if (hok > 0 && !G.player.dead) G.player.hp = Math.min(G.player.maxHp, G.player.hp + hok);
  // dopamine engine: combo + hitstop + kill flash
  bumpCombo(G);
  if (G.combo.n >= 3) G.hitstop = Math.max(G.hitstop, 0.025);
  if (e.elite) {
    G.hitstop = Math.max(G.hitstop, 0.07);
    G.odFlash = Math.max(G.odFlash, 0.18);
    addRing(G, e.x, e.y, 6, 200, '#ffd75e', 0.4, 2.5);
  }
  // school on-kill signature
  schoolKill(G, e, el);
  // quest tracking
  trackKill(G, e.kind.id, el, !!e.elite, e.tier);
  burst(G, e.x, e.y, elColor(e.kind.el), 12, 100);
  burst(G, e.x, e.y, '#ffffff', 5, 70);
  addText(G, e.x, e.y - 8, `+${xpGain.toFixed(0)} xp`, '#ffd75e', 4);
  // corpse
  if (e.kind.corpse ?? true) {
    if (G.corpses.length > 30) G.corpses.shift();
    G.corpses.push({ x: e.x, y: e.y, sprite: e.kind.sprite, t: 0, flip: chance(0.5), used: false });
  }
  // NECROMANCY: the dead rise to serve their killer
  if (el === 'death') {
    const sl = G.prog.schools.death?.lvl ?? 1;
    if (chance(Math.min(0.65, 0.18 + sl * 0.012 + (G.prog.cls === 'necromancer' ? 0.10 : 0)))) {
      const m = createMinion(G, 'death', e.x, e.y, sl, 8);
      if (m) {
        addText(G, e.x, e.y - 18, 'RISEN!', '#e2e8dc', 6, true);
        addRing(G, e.x, e.y, 4, 120, '#a8b0a0', 0.35, 2);
      }
    }
  }
  // drops (hard world: healing is rarer) · RELIC: sash of nine pockets
  if (chance(0.07 + relicVal(G, 'lootLuck') * 0.05)) spawnPickup(G, 'vial', e.x, e.y);
  if (chance(0.05 + relicVal(G, 'lootLuck') * 0.04)) spawnPickup(G, 'draught', e.x, e.y);
  // RELIC: echo of a dead god — the slain sometimes weep shards
  const eLuck = relicVal(G, 'echoLuck');
  if (eLuck > 0 && chance(Math.min(0.5, eLuck * 0.06))) spawnEchoDrop(G, e.x, e.y, 1);
  // RELIC DROPS: elites carry trinkets — one in sixteen carries something rarer
  if (e.elite && chance(0.06)) spawnRelicDrop(G, e.x, e.y);
  const shards = e.elite ? randi(2, 4) : chance(0.5) ? 1 : 0;
  for (let i = 0; i < shards; i++) spawnPickup(G, 'aether', e.x, e.y, Math.max(1, Math.round(aether / Math.max(1, shards))));
  G.cb.enemyDie(e, el);
}

function randi(a: number, b: number): number {
  return Math.floor(rand(a, b + 1));
}

export function gainXp(G: GameCtx, amount: number): void {
  const p = G.prog;
  p.xp += amount;
  while (p.xp >= 55 * Math.pow(p.lvl, 1.45) && p.lvl < 60) {
    p.xp -= 55 * Math.pow(p.lvl, 1.45);
    p.lvl++;
    G.player.maxHp += 6;
    G.player.maxMana += 4;
    G.player.hp = Math.min(G.player.maxHp, G.player.hp + G.player.maxHp * 0.25);
    // SKILL POINTS: every level grants 1, every 4th grants a bonus point
    const pts = 1 + (p.lvl % 4 === 0 ? 1 : 0);
    p.points += pts;
    p.pointsEarned += pts;
    G.audio.sfx('levelup');
    burst(G, G.player.x, G.player.y - 6, '#ffd75e', 18, 90, { dir: -Math.PI / 2, spread: 1.2 });
    addText(G, G.player.x, G.player.y - 18, `LEVEL ${p.lvl}`, '#ffd75e', 8, true);
    addText(G, G.player.x, G.player.y - 30, `+${pts} SKILL POINT${pts > 1 ? 'S' : ''}  [K]`, '#c95ee8', 5, true);
    G.uiV++;
  }
}

// ---------- rendering ----------
export function drawEnemies(G: GameCtx): void {
  const ctx = G.ctx;
  for (const e of G.enemies) {
    if (e.dead) continue;
    if (e.puppet) continue; // the weaver renders itself procedurally
    const spr = SPR[e.kind.sprite];
    if (!spr) continue;
    const wob = Math.sin(e.anim * 6) * 1;
    ctx.save();
    ctx.translate(Math.round(e.x), Math.round(e.y + wob * 0.4));
    if (e.face < 0) ctx.scale(-1, 1);
    if (e.scale && e.scale !== 1) ctx.scale(e.scale, e.scale);
    // shadow
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.ellipse(0, spr.height / 2 - 1, spr.width * 0.35, 2.4, 0, 0, TAU); ctx.fill();
    ctx.globalAlpha = 1;
    const moving = Math.hypot(e.vx, e.vy) > 12;
    if (moving) {
      // real walk cycle: legs slice swings while the body bobs
      const f = Math.floor(e.anim * 8) % 4;
      const swing = [0, 1.5, 0, -1.5][f];
      const bobY = [0, -1, 0, -0.5][f];
      const legH = Math.min(4, Math.floor(spr.height * 0.28));
      const bodyH = spr.height - legH;
      ctx.drawImage(spr, 0, 0, spr.width, bodyH, -spr.width / 2, -spr.height / 2 + bobY, spr.width, bodyH);
      ctx.drawImage(spr, 0, bodyH, spr.width, legH, -spr.width / 2 + swing, -spr.height / 2 + bodyH + bobY, spr.width, legH);
    } else {
      ctx.drawImage(spr, -spr.width / 2, -spr.height / 2);
    }
    if (e.state === 'windup') {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.4 + 0.3 * Math.sin(G.time * 30);
      ctx.drawImage(spr, -spr.width / 2, -spr.height / 2);
      ctx.globalCompositeOperation = 'source-over';
    }
    if (e.flash > 0) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = clamp(e.flash * 6, 0, 1);
      ctx.drawImage(spr, -spr.width / 2, -spr.height / 2);
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
    }
    if (e.st.chill) {
      ctx.globalAlpha = 0.3; ctx.fillStyle = '#9edbe8';
      ctx.fillRect(-spr.width / 2, -spr.height / 2, spr.width, spr.height);
      ctx.globalAlpha = 1;
    }
    if (e.st.frozen) {
      // locked in ice
      ctx.globalAlpha = 0.55; ctx.fillStyle = '#bfe8f8';
      ctx.fillRect(-spr.width / 2 - 1, -spr.height / 2 - 2, spr.width + 2, spr.height + 3);
      ctx.globalAlpha = 0.95; ctx.fillStyle = '#e8fbff';
      ctx.fillRect(-spr.width / 2 - 1, -spr.height / 2 - 2, spr.width + 2, 1);
      ctx.fillRect(-spr.width / 2 + 1, -spr.height / 2 - 4, 2, 2);
      ctx.fillRect(spr.width / 2 - 3, -spr.height / 2 - 3, 2, 3);
      ctx.globalAlpha = 1;
    }
    if (e.elite) {
      ctx.strokeStyle = e.elite === 'titan' ? '#ffb03e' : e.elite === 'frenzied' ? '#ff5a5a' : e.elite === 'volatile' ? '#ff7a3e' : '#c95ee8';
      ctx.lineWidth = 1;
      ctx.strokeRect(-spr.width / 2 - 1.5, -spr.height / 2 - 1.5, spr.width + 3, spr.height + 3);
    }
    ctx.restore();
    // hp bar
    if (e.hp < e.maxHp) {
      const w = 16 * (e.scale ?? 1);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(e.x - w / 2 - 1, e.y - e.r - 9, w + 2, 3);
      ctx.fillStyle = '#e2552e';
      ctx.fillRect(e.x - w / 2, e.y - e.r - 8, w * clamp(e.hp / e.maxHp, 0, 1), 1.6);
    }
    // minion-related lifesteal visuals handled in fx
  }
}

// minions update & draw
export function updateMinions(G: GameCtx, dt: number): void {
  const p = G.player;
  for (const m of G.minions) {
    if (m.dead) continue;
    m.anim += dt;
    m.life -= dt;
    m.flash = Math.max(0, m.flash - dt);
    if (m.life <= 0) { m.dead = true; burst(G, m.x, m.y, elColor(m.el), 8, 60); continue; }
    // healer behavior
    if (m.el === 'radiant') {
      if (dist(m.x, m.y, p.x, p.y) > 60) {
        const a = angTo(m.x, m.y, p.x, p.y);
        m.vx += Math.cos(a) * m.speed * dt * 4; m.vy += Math.sin(a) * m.speed * dt * 4;
      } else if (p.hp < p.maxHp) {
        p.hp = Math.min(p.maxHp, p.hp + 2.2 * dt);
        if (G.frame % 20 === 0) spawnParticle(G, { x: p.x + randR(-6, 6), y: p.y - 6, vy: -16, life: 0.6, size: 2, color: '#ffe89e', glow: true });
      }
      integrateMinion(G, m, dt);
      continue;
    }
    // find target
    let target: { x: number; y: number; r: number } | null = null;
    let bd = 260 * 260;
    for (const e of G.enemies) {
      if (e.dead) continue;
      const d = (e.x - m.x) ** 2 + (e.y - m.y) ** 2;
      if (d < bd) { bd = d; target = e; }
    }
    const boss = G.boss;
    if (boss && !boss.dead && (boss.x - m.x) ** 2 + (boss.y - m.y) ** 2 < bd) target = boss;
    if (target) {
      const d = dist(m.x, m.y, target.x, target.y);
      const ang = angTo(m.x, m.y, target.x, target.y);
      if (m.ranged) {
        if (d > 120) { m.vx += Math.cos(ang) * m.speed * dt * 4; m.vy += Math.sin(ang) * m.speed * dt * 4; }
        m.atkT -= dt;
        if (m.atkT <= 0 && d < 230) {
          m.atkT = m.atkCd;
          makeBullet(G, {
            x: m.x, y: m.y, vx: Math.cos(ang) * m.bulletSpeed, vy: Math.sin(ang) * m.bulletSpeed,
            r: 3, dmg: m.dmg, el: m.el, el2: null, team: 'player', life: 2,
            kind: 'bolt', color: elColor(m.el), color2: elColor2(m.el), trail: 0.4, from: m,
          });
        }
      } else {
        if (d > 14) {
          m.vx += Math.cos(ang) * m.speed * dt * 5; m.vy += Math.sin(ang) * m.speed * dt * 5;
        }
        m.atkT -= dt;
        if (m.atkT <= 0 && d < 16 + target.r) {
          m.atkT = m.atkCd;
          if ('defId' in target) {
            damageBoss(G, target as never, m.dmg, m.el, false);
          } else {
            damageEnemy(G, target as never, m.dmg, m.el, { from: m });
          }
          burst(G, target.x, target.y, elColor(m.el), 4, 60);
        }
      }
    } else {
      // follow player
      const d = dist(m.x, m.y, p.x, p.y);
      if (d > 60) {
        const a = angTo(m.x, m.y, p.x, p.y);
        m.vx += Math.cos(a) * m.speed * dt * 3.4; m.vy += Math.sin(a) * m.speed * dt * 3.4;
      }
    }
    integrateMinion(G, m, dt);
  }
  let w = 0;
  for (let i = 0; i < G.minions.length; i++) if (!G.minions[i].dead) G.minions[w++] = G.minions[i];
  G.minions.length = w;
}

function integrateMinion(G: GameCtx, m: Minion2, dt: number): void {
  m.vx *= 1 - clamp(4 * dt, 0, 0.9);
  m.vy *= 1 - clamp(4 * dt, 0, 0.9);
  const mv = moveWithCollision(G.world, m.x, m.y, m.vx, m.vy, m.r, dt, !!m.passWalls);
  m.x = mv.x; m.y = mv.y;
  if (Math.abs(m.vx) > 5) m.face = m.vx > 0 ? 1 : -1;
}

type Minion2 = import('./core').Minion;

export function drawMinions(G: GameCtx): void {
  const ctx = G.ctx;
  for (const m of G.minions) {
    if (m.dead) continue;
    const spr = SPR[m.sprite];
    if (!spr) continue;
    ctx.save();
    ctx.translate(Math.round(m.x), Math.round(m.y + Math.sin(m.anim * 6) * 0.5));
    if (m.face < 0) ctx.scale(-1, 1);
    const fade = m.life < 3 ? (Math.sin(G.time * 12) > 0 ? 0.5 : 1) : 1;
    ctx.globalAlpha = fade;
    ctx.drawImage(spr, -spr.width / 2, -spr.height / 2);
    if (m.flash > 0) {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = clamp(m.flash * 6, 0, 1) * fade;
      ctx.drawImage(spr, -spr.width / 2, -spr.height / 2);
    }
    ctx.restore();
  }
}


