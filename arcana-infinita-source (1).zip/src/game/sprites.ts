/* ============================================================
   sprites.ts — procedural pixel art. Every sprite is authored
   as a compact string map + palette, rendered once to an
   offscreen canvas at boot. Tiles are generated with seeded
   noise speckles. No external assets needed.
   ============================================================ */
import { ELEMENT_IDS, mulberry32, type ElementId, type FormId } from './core';

export type Spr = Record<string, HTMLCanvasElement>;
export const SPR: Spr = {};

// --- ground system registries (filled once by initSprites) ---
// LUX_TILES[family] = mood-major canvas array: [mood0v0, mood0v1, ..., mood1v0, ...]
export const LUX_TILES: Record<string, HTMLCanvasElement[]> = {};
// ARENA_FLOORS[bossId][tier 0..2] = variant canvases
export const ARENA_FLOORS: Record<string, HTMLCanvasElement[][]> = {};
// ARENA_KITS[bossId] = pseudo-3D structure sprites
export const ARENA_KITS: Record<string, ArenaKit> = {};

export function makeSprite(rows: string[], pal: Record<string, string>, scale = 1): HTMLCanvasElement {
  const h = rows.length, w = rows[0].length;
  const c = document.createElement('canvas');
  c.width = w * scale; c.height = h * scale;
  const g = c.getContext('2d')!;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const ch = rows[y][x];
      if (ch === '.' || ch === ' ') continue;
      const col = pal[ch];
      if (!col) continue;
      g.fillStyle = col;
      g.fillRect(x * scale, y * scale, scale, scale);
    }
  }
  return c;
}

export function mirrorRows(rows: string[]): string[] {
  return rows.map((r) => r + r.slice(0, -1).split('').reverse().join(''));
}

function flipCanvas(src: HTMLCanvasElement): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = src.width; c.height = src.height;
  const g = c.getContext('2d')!;
  g.translate(src.width, 0); g.scale(-1, 1);
  g.drawImage(src, 0, 0);
  return c;
}

const corpseCache = new Map<string, HTMLCanvasElement>();
export function corpseOf(name: string): HTMLCanvasElement {
  let c = corpseCache.get(name);
  if (!c) {
    const src = SPR[name];
    c = document.createElement('canvas');
    c.width = src.width; c.height = src.height;
    const g = c.getContext('2d')!;
    g.filter = 'grayscale(1) brightness(0.55)';
    g.drawImage(src, 0, 0);
    corpseCache.set(name, c);
  }
  return c;
}

// ============================================================
// PALETTES
// ============================================================
const P = {
  player: { h: '#3b2a4f', H: '#57406f', s: '#e8b796', e: '#1a1020', r: '#6d3a8e', R: '#8e54b3', d: '#4a2866', b: '#2c1e38', g: '#f2d16b' },
  slime: { G: '#7ed957', g: '#4e9e35', e: '#ffffff', d: '#2f6b1e' },
  bat: { b: '#5a4a6e', B: '#7a6890', e: '#ff5a5a', w: '#3d3350' },
  imp: { i: '#c2452e', I: '#e26a3d', e: '#ffd75e', h: '#7a2617', w: '#3a120b' },
  wisp: { w: '#b8e8ff', W: '#e6f9ff', e: '#41e8d2', o: '#6fa8c9' },
  skel: { b: '#d8d3c0', B: '#a8a290', e: '#7ce8ff', d: '#6e6a5c', w: '#4a463c' },
  shroom: { c: '#b05ac9', C: '#d18ae0', s: '#e8d9b0', e: '#3a2438', d: '#7a3a92' },
  cultist: { r: '#2c2436', R: '#453a56', e: '#c94ce8', s: '#b9a58c', d: '#1a1522' },
  fsprite: { i: '#aee6f2', I: '#e2f7fc', e: '#2e8ba8', d: '#6db8cc', w: '#ffffff' },
  scorp: { s: '#c9963f', S: '#e0b25e', e: '#3a2410', d: '#8a6425' },
  witch: { r: '#3f5a3a', R: '#5a7a50', s: '#9cb07a', e: '#d8ff5e', h: '#243020', p: '#8fd94e' },
  golem: { s: '#8a8578', S: '#a8a294', e: '#5ec98a', d: '#5e5a4e', m: '#6e695e' },
  wraith: { w: '#4a3a5e', W: '#6e5a86', e: '#b4f0ff', d: '#2e2440', t: '#c9b8e8' },
  hound: { h: '#8e2f1e', H: '#c24a26', e: '#ffd75e', d: '#5a1c10', t: '#3a120b' },
  djinn: { b: '#3f6e8a', B: '#5e9ab8', e: '#fff45e', d: '#2a4a5e', c: '#a8e8ff' },
  knight: { a: '#8a2f3f', A: '#b8495c', e: '#ffd75e', d: '#5a1c28', s: '#c9c2b0' },
  plague: { r: '#4a5e2e', R: '#6a7e42', e: '#c9ff4e', s: '#a8b87a', d: '#2e3a1c' },
  tendril: { v: '#5e2e7a', V: '#8a4aa8', e: '#e85eff', d: '#3a1a4e', t: '#c95ee8' },
  gargoyle: { s: '#7a7e8a', S: '#9aa0aa', e: '#ff9e4e', d: '#4a4e58', w: '#5e626e' },
  chaos: { c: '#c94ce8', C: '#5ee8b8', e: '#ffd75e', d: '#7a2e5e', m: '#e8e05e' },
  fwarden: { i: '#6e9eaa', I: '#9ec9d4', e: '#b4f0ff', d: '#4a6e7a', s: '#c9e8ee' },
};

// ============================================================
// CREATURE MAPS (mirrored halves for symmetric bodies)
// ============================================================
function enemyMaps(): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  const m = mirrorRows;

  out.slime = m([
    '....GGg',
    '..GGGgg',
    '.GGggge',
    'Gggggge',
    'ggggggd',
    'ggggggd',
    '.gggggd',
  ]);
  out.bat = m([
    'wb......w',
    'wbb....bB',
    '.bbBeeBe.',
    '..bBBBb..',
    '...bbb...',
  ]);
  out.imp = m([
    'w....iI..',
    '.w..iIi..',
    '..w.iIie.',
    '.wiiIIIi.',
    'w.iIiiIi.',
    '..iIiiii.',
    '...hh.hh.',
  ]);
  out.wisp = m([
    '....WWw.',
    '..WWWoW.',
    '.WoWWWo.',
    '.WWWoWe.',
    '..oWWo..',
    '....w...',
  ]);
  out.skel = m([
    '...bbb...',
    '..bBBbB..',
    '..beBeb..',
    '...bbb...',
    '..dBBBd..',
    '.wBbBbBw.',
    '.w.bbb.w.',
    '...b.b...',
    '..wb.bw..',
  ]);
  out.shroom = m([
    '..dCCCd..',
    '.cCCCCCc.',
    'cCceCceCc',
    'dcccccccd',
    '...sss...',
    '..ss.ss..',
  ]);
  out.cultist = m([
    '...rrr...',
    '..rRRRr..',
    '..reRee..',
    '..sRRRs..',
    '.rRRRRRr.',
    '.rRrrrRr.',
    '.rRrrrRr.',
    '..rrrrr..',
    '..d.r.d..',
  ]);
  out.fsprite = m([
    '...wIw...',
    '..wIiIw..',
    '.wIiIiIe.',
    '.wIiIiIw.',
    '..wIiIw..',
    '...wIw...',
    '....d....',
  ]);
  out.scorp = [
    'd..........',
    '.d.....sS..',
    '..d...sSS..',
    'SSd..sSs...',
    '.sSssSSs...',
    '..sSSSSse..',
    '..sSSSSse..',
    'SSd..sSs...',
    '.d.....sS..',
  ];
  out.witch = m([
    '...hhhh...',
    '..hhHHhh..',
    '..hHHHHh..',
    '...sRRs...',
    '..reReer..',
    '.pRrRRrRp.',
    '.pRrrrrRp.',
    '..rRRRRr..',
    '..rrrrrr..',
  ]);
  out.golem = m([
    '..mSSSm..',
    '.mSSSSSm.',
    '.mSeSeSm.',
    '.mSSSSSm.',
    'dSSSSSSSd',
    'dSsSSSsSd',
    'dmSdSdSmd',
    '..dS.Sd..',
    '.dS...Sd.',
  ]);
  out.wraith = m([
    '...dWd...',
    '..dWWWd..',
    '..WeWeW..',
    '..dWWWd..',
    '.tWWWWWW.',
    '.tWdWWdW.',
    '..tWWWW..',
    '...tWt...',
    '....t....',
  ]);
  out.hound = [
    'tHh..........',
    '.tHhh...hH...',
    '..hHHhhHHHh..',
    '..hHHHHHHHe..',
    '...hHHHHHHh..',
    '..hHHHHHHhh..',
    '..hH.hH.hHh..',
    '..hh.hh..hh..',
  ];
  out.djinn = m([
    '....cBc....',
    '...cBBBc...',
    '..cBeBebc..',
    '..cBBBBBc..',
    '.cBdBdBdBc.',
    '.cBBBBBBBc.',
    '..dBdBdBd..',
    '...dBdBd...',
    '....d.d....',
  ]);
  out.knight = m([
    '..dAAAAd..',
    '.dAAsAsAd.',
    '.dAeAAeAd.',
    '.dAAAAAAd.',
    'dAdAAAAdAd',
    'dAdAdddAdA',
    'dAdAdAdAdA',
    '.d.AdAd.d.',
    '...dd.dd..',
  ]);
  out.plague = m([
    '...rrr...',
    '..rRRRr..',
    '..reRee..',
    '..rRRRr..',
    '.rRsRsRr.',
    '.rRrrrRr.',
    '.rRrerRr.',
    '..rrrrr..',
    '..d...d..',
  ]);
  out.tendril = m([
    '..t..V..t..',
    '.tV.VVV.Vt.',
    '.tVVVeVVVt.',
    'VtVVVVVVVtV',
    'tVVdVdVdVVt',
    '.tVVVVVVVt.',
    '..tVdVdVt..',
    '...ttVtt...',
    '.....t.....',
  ]);
  out.gargoyle = m([
    'w.........w',
    'ww.sssss.ww',
    'w.sSSSSSs.w',
    'w.sSeSeSs.w',
    '..sSSSSSs..',
    '..dsssssd..',
    '..dsdsdsd..',
    '...d.d.d...',
    '...w...w...',
  ]);
  out.chaos = m([
    '...cCm...',
    '..cCmCc..',
    '.cCmeCmC.',
    '.CmcCcmm.',
    '..CmCcC..',
    '...dCd...',
    '....d....',
  ]);
  out.fwarden = m([
    '..I.II.I..',
    '.iIsiIsiI.',
    '.iIeeeIei.',
    '.iIiiiiIi.',
    'IiIiiiiIiI',
    'IiIdiIdiIi',
    '.iIiIiIiI.',
    '..Ii..iI..',
    '..II..II..',
  ]);
  return out;
}

// ============================================================
// PLAYER
// ============================================================
const PLAYER_PAL = P.player;
const PLAYER_TOP = [
  '....hhhh....',
  '...hhHHhh...',
  '..hhHHHHhh..',
  '...ssssss...',
  '...sesess...',
  '....ssss....',
  '..RrrrrrrR..',
  '.RRrrrrrrRR.',
  '.RrrrrrrrrR.',
  '.rrRrrrrRrr.',
];
export function playerFrames(): { idle: string[]; walk: string[] } {
  return {
    idle: [...PLAYER_TOP, '.rrrrrrrrrr.', '..rrrrrrrr..', '..rrrrrrrr..', '...rrrrrr...', '...bb..bb...', '...bb..bb...'],
    walk: [...PLAYER_TOP, '.rrrrrrrrrr.', '..rrrrrrrr..', '..rrrrrrrr..', '...rrrrrr...', '..bb....bb..', '.bb......bb.'],
  };
}

// 4-frame walk cycle: stride -> pass -> stride(other) -> pass, with vertical bob
export function playerWalkFrames(): string[][] {
  const robe = ['.rrrrrrrrrr.', '..rrrrrrrr..', '..rrrrrrrr..', '...rrrrrr...'];
  const legs = [
    ['..bb....bb..', '.bb......bb.'],   // wide stride
    ['...bb..bb...', '..bb....bb..'],   // passing
    ['....bbbb....', '...bb..bb...'],   // together
    ['..bb....bb..', '...bb..bb...'],   // passing (other)
  ];
  return legs.map((l) => [...PLAYER_TOP, ...robe, ...l]);
}

// ============================================================
// BOSSES (mirrored)
// ============================================================
function bossMaps(): Record<string, string[]> {
  const m = mirrorRows;
  return {
    // Grum, the Ashen Tyrant — horned fire giant
    boss_ashen: m([
      'R..r..RR..',
      '.R.rr.RR..',
      '.RRrrRRR..',
      '..RrRRRR..',
      '..reRReR..',
      '..rRRRRR..',
      '...RRRR...',
      '..RRddRR..',
      '.RRRddRRR.',
      '.RRRddRRR.',
      'RRRRRRRRRR',
      'RRdRRRRdRR',
      'RRd.RR.dRR',
      'RR..RR..RR',
      'dd..dd..dd',
    ]),
    // Ylva, Frost Queen — crowned iceling
    boss_frost: m([
      '...W.I..',
      '..WIWW..',
      '..WWWW..',
      '.wWWeWe.',
      '.wWWWWW.',
      '.wWwWwW.',
      'iWWWWWi.',
      '.WWdWWW.',
      '.WdWWdW.',
      '.W.WW.W.',
      '...W..W.',
    ]),
    // The Hollow King — crowned skull lord
    boss_hollow: m([
      'b.b..b.b',
      '.bBbbBb.',
      '.bBBBBb.',
      '.beBBeB.',
      '.bBBBBb.',
      '..bBBb..',
      '.bBBBBb.',
      'bBbBBbBb',
      'b.bBB.b.',
      '..bBBb..',
      '..b..b..',
    ]),
    // Tem Kaa, Stormfather — cloud djinn
    boss_storm: m([
      '..cCCc...',
      '.cCCCCc..',
      'cCCECCCc.',
      'cCCCCCCc.',
      '.cCggCc..',
      '..cCCc...',
      '.cCcCc...',
      '..c.c.c..',
      '...c.c...',
    ]),
    // The Verdant Maw — plant horror
    boss_maw: m([
      '.d.gGg..',
      'dggGGGg.',
      'dgGeGgGg',
      '.ggGgGgg',
      '.dggGggd',
      '..dgggd.',
      '...dgd..',
      '....d...',
    ]),
    // Nerissa, Tide Empress — siren of the deep
    boss_tide: m([
      '...W.T..',
      '..WTWW..',
      '.wWWeWe.',
      '.wWWWWW.',
      '.wWwWwW.',
      'TWWWWWT.',
      '.TWdWWT.',
      '.W.TW.W.',
      '...T..T.',
    ]),
    // Aeon, the Chrono Warden — clockwork sentinel
    boss_aeon: m([
      '.mMMmMMm.',
      'mMMMMMMm.',
      'mMmeMeme.',
      'mMMMdMMm.',
      'mMMMMMMm.',
      '.mMmMmMm.',
      '.mMMMMm..',
      '..mMMm...',
      '..m..m...',
    ]),
    // The Nameless Void — a tear in reality
    boss_void: m([
      'v..........v',
      '.vV......Vv.',
      '.vVVv..vVVv.',
      '..vVVVVVVv..',
      '..vVveeVvV..',
      '..vVVVVVVv..',
      '...vVVVVv...',
      '...vVvvVv...',
      '....vVVv....',
      '.....vv.....',
    ]),
  };
}

// ============================================================
// MINIONS
// ============================================================
function minionMaps(): Record<string, string[]> {
  const m = mirrorRows;
  return {
    min_skel: m([
      '..bbb..',
      '.bBBbB.',
      '.beBeb.',
      '..bbb..',
      '.dBBBd.',
      'wBbBbBw',
      '.wb.bw.',
      '...b.b.',
    ]),
    min_imp: m([
      '.iI.',
      'iIi.',
      'iIie',
      'iIi.',
      '.h.h',
    ]),
    min_wisp: [
      '.WW.',
      'WoWo',
      'WWeW',
      '.oo.',
    ],
    min_golem: m([
      '.SSS.',
      'SeSeS',
      'SSSSS',
      'dSdSd',
      '.d.d.',
    ]),
    min_wraith: m([
      '.dWd.',
      'WeWeW',
      'dWWWd',
      'tWWWt',
      '.t.t.',
    ]),
    min_treant: m([
      'gGggg',
      'GgggG',
      'ddgdd',
      '.ddd.',
      '.d.d.',
    ]),
    min_bat: m([
      'w...w',
      'wBeBw',
      '.wBw.',
      '..w..',
    ]),
    min_healer: m([
      '.WWW.',
      'WeWeW',
      'WWWWW',
      '.WdW.',
      '..d..',
    ]),
    min_tide: m([
      '.WWW.',
      'WoWoW',
      'WWWWW',
      '.WWW.',
      '..o..',
    ]),
    min_gale: m([
      'w.w.w',
      '.wWw.',
      'wWeWw',
      '.www.',
    ]),
    min_void: m([
      '.vVv.',
      'VeVeV',
      'vVVVv',
      '.vdv.',
    ]),
  };
}

// ============================================================
// DECOR & OBJECTS
// ============================================================
function decorMaps(): Record<string, string[]> {
  return {
    tree: [
      '....GGGG....',
      '..GGGGGGGG..',
      '.GGGgGGgGGG.',
      'GGGgGGGgGGGG',
      'GGGGGGGGGGGG',
      '.GGgGGGGgGG.',
      '..GGGGGGGG..',
      '...GGggGG...',
      '....tttt....',
      '....tttt....',
      '....tttt....',
      '...tttttt...',
    ],
    pine: [
      '.....GG.....',
      '....GGGG....',
      '...GGgGGG...',
      '....gGGg....',
      '...GGGgGG...',
      '..GGgGGgGG..',
      '.....tt.....',
      '.....tt.....',
      '....tttt....',
    ],
    deadtree: [
      '..t.....t...',
      '...t...t....',
      '....t.t.....',
      '.....tt.....',
      '..t..tt..t..',
      '...tttttt...',
      '.....tt.....',
      '....tttt....',
    ],
    cactus: [
      '...gg...',
      '..gGgg..',
      '.gg.gg..',
      'ggg.gg.g',
      'gGggggg.',
      '.gg.gg..',
      '...gg...',
      '...gg...',
    ],
    rock: [
      '..ssss..',
      '.ssSSss.',
      'ssSSSSss',
      'ssSSSsss',
      '.ssssss.',
    ],
    crystal: [
      '...c....',
      '..cCc...',
      '..cCc...',
      '.ccCcc..',
      '.cCCCc..',
      'ccCCCcc.',
      'ccCCCcc.',
      '.ccccc..',
    ],
    bones: [
      'bb..bb..bb',
      '.bbbbb.bb.',
      '..bbb.bb..',
      'b..bb..b..',
    ],
    flower: [
      '..pP..',
      '.pPPp.',
      '..PP..',
      '...g..',
      '..g.g.',
    ],
    stump: [
      '.ttttt.',
      'tTttTtt',
      'ttttttt',
      '.ttttt.',
    ],
    icespike: [
      '..i....',
      '..ii...',
      '.iIii..',
      '.iIiii.',
      'iIIiIii',
      'iIiiIii',
    ],
    lavarock: [
      '..ssLss.',
      '.sLLsLss',
      'ssLsLLss',
      '.ssLsLs.',
    ],
    pillar: [
      '.ssssss.',
      '.sSSSSs.',
      '..sSSs..',
      '..sSSs..',
      '..sSSs..',
      '..sSSs..',
      '.sssssss',
      '.sSSSSSs',
    ],
    mushroom_big: [
      '...ccc...',
      '.ccCcCcc.',
      'ccCcCcCcc',
      'ccccccccc',
      '...sWs...',
      '...sWs...',
    ],
    shrine: [
      '....gggggg....',
      '..gg.GGGG.gg..',
      '.gg..GggG..gg.',
      'gg....gg....gg',
      'g....gggg....g',
      '.g...gGGg...g.',
      '..gg.gGGg.gg..',
      '....gGGGGg....',
      '.....gggg.....',
    ],
    altar: [
      '..c.cc.c..',
      '.cCCCCCc..',
      'cC.eCe.Cc.',
      'cCCCCCCCc.',
      '.cCCCCCc..',
      '..ccccc...',
      '...sss....',
      '..sssss...',
    ],
    stain: [
      '..aaa..',
      '.aAAAa.',
      'aAAAAAa',
      '.aAAAa.',
      '..aaa..',
    ],
    bush: [
      '..GGGg..',
      '.GGgGGG.',
      'GGgGGgGG',
      '.gGGGg..',
    ],
    log: [
      '..tttttt..',
      '.tTTTTTTt.',
      'tttttttttt',
    ],
    pebbles: [
      '..s..s..',
      '.sS.s..s',
      '..s..S..',
    ],
    reeds: [
      '.g..g..',
      '.g.gg.g',
      '.Gg.gG.',
      '..g.g..',
      '..g.g..',
    ],
    lilypad: [
      '..wwww..',
      '.wwWwww.',
      '..wwww..',
    ],
    snowdrift: [
      '..wwww..',
      '.wwWWww.',
      'wwWWWWww',
    ],
    boulder: [
      '..ssss..',
      '.ssSSss.',
      'ssSSSSss',
      'ssSSSsss',
      'ssssssss',
      '.ssssss.',
    ],
    sapling: [
      '..g..',
      '.gGg.',
      '..g..',
      '..t..',
      '..t..',
    ],
    skullpile: [
      '..bb.bb..',
      '.bbbbbbb.',
      'bb.bbb.bb',
      '.bb...bb.',
      '..b.b.b..',
    ],
    roots: [
      '..t..t..',
      '.t.tt.t.',
      't.t..t.t',
      '.t....t.',
    ],
    cattail: [
      '.c..c.',
      '.C..C.',
      '.g..g.',
      '.g..g.',
      '.g.gg.',
      '..g.g.',
    ],
    shell: [
      '..p..',
      '.pPp.',
      'pPPPp',
      '.ppp.',
    ],
    mushroom: [
      '..cc.',
      '.cCc.',
      '.sss.',
      '..s..',
    ],
    crystal_shard: [
      '..c..',
      '.cCc.',
      '.cCc.',
      'ccCcc',
      '.ccc.',
    ],
    vial: [
      '..w..',
      '.wWw.',
      'wRRRw',
      'wRRRw',
      '.www.',
    ],
    draught: [
      '..w..',
      '.wWw.',
      'wMMMw',
      'wMMMw',
      '.www.',
    ],
    shard: [
      '.aA.',
      'aAAa',
      'aAa.',
      '.a..',
    ],
    chest: [
      '.gggggggg.',
      'gbbbbbbbbg',
      'gbBBBBBBbg',
      'gbBggggBbg',
      'gggggggggg',
      'gbbbbbbbbg',
      'gbbBggBbbg',
      '.gggggggg.',
    ],
    tower: [
      '..cCCc..',
      '.cCCCCc.',
      '.cCeeCc.',
      '..ssss..',
      '..sSSs..',
      '..sSSs..',
      '..sSsS..',
      '..sSSs..',
      '..sSsS..',
      '..sSSs..',
      '.ssSSss.',
      '.ssssss.',
    ],
    obelisk: [
      '..vVVv..',
      '.vVeEVv.',
      '.vVVVVv.',
      '..vVVv..',
      '..vVVv..',
      '..vVVv..',
      '..vVVv..',
      '..vVVv..',
      '.vvVVvv.',
      'vvVVVVvv',
    ],
    campfire: [
      '..fFf..',
      '.fFFFf.',
      'fFeEFf.',
      '.ffff..',
      'w.ww..w',
      '.wwww..',
    ],
    spring: [
      '..wwww..',
      '.wWWWWw.',
      'wWeeWWWw',
      'wWWWWWWw',
      '.wWWWWw.',
      '..wwww..',
    ],
    gate: [
      'p',
    ],
    barrow: [
      '..dddddd..',
      '.ddDDDDdd.',
      'ddDDddDDdd',
      'dDDd..dDDd',
      'dDd....dDd',
      'dDd.dd.dDd',
      'ddd.dd.ddd',
      '...ssss...',
    ],
    tent: [
      '...pp...',
      '..pPPp..',
      '.pPPPPp.',
      '.pPddPp.',
      'pPPddPPp',
      'pPPPPPPp',
      'pppppppp',
    ],
    geyser: [
      '..cCCc..',
      '.cCCeCc.',
      'cCeCCeCc',
      'cCCCCCCc',
      '.sCCCCs.',
      '..ssss..',
    ],
    // --- village buildings (villages.ts) ---
    house_a: [
      '...........hHHHh..........',
      '.........hhHHHhh..........',
      '.......hhhHHHHHhhh........',
      '.....hhhhHHHHHHHhhhh......',
      '...hhhhhHHHHHHHHHhhhhh....',
      '.hhhhhhhHHHHHHHHHhhhhhhh..',
      'hhhhhhhhhhhHHHHHhhhhhhhhhh',
      '..DDDDDDDDDDDDDDDDDDDDDD..',
      '..wppppppppppppppppppppw..',
      '..wppeEeppppppppppeEeppw..',
      '..wppeEeppppppppppeEeppw..',
      '..wppppppppppppppppppppw..',
      '..wppppppppdddpppppppppw..',
      '..wppppppppdddpppppppppw..',
      '..wppppppppdddpppppppppw..',
      '..wppppppppdddpppppppppw..',
      '..wppppppppdddpppppppppw..',
      '..wppppppppdddpppppppppw..',
      '.sSSSSSSSSSSSSSSSSSSSSSSs.',
      '.sSSDSSSSDSSSSDSSSSDSSSSs.',
      '.sSSDSSSSDSSSSDSSSSDSSSSs.',
      '.DDDDDDDDDDDDDDDDDDDDDDDD.',
    ],
    house_b: [
      '............rrr....ccc....',
      '..........rrrRrrr..ccc....',
      '........rrrrRRRrrrr.cc....',
      '......rrrrrRRRRRrrrrcc....',
      '....rrrrrrRRRRRRRrrrrrr...',
      '..rrrrrrrRRRRRRRRRrrrrrrr.',
      '.rrrrrrrrRRRRRRRRRrrrrrrrr',
      'rrrrrrrrrrrRRRRRRRRrrrrrrr',
      'rrrrrrrrrrRRRRRRRRRRrrrrrr',
      '..DDDDDDDDDDDDDDDDDDDDDD..',
      '..wqqqqqqqqqqqqqqqqqqqqw..',
      '..wqqeEeqqqqqqqqqqeEeqqw..',
      '..wqqeEeqqqqqqqqqqeEeqqw..',
      '..wqqqqqqqqqqqqqqqqqqqqw..',
      '..wqqqqqqqqdddqqqqqqqqqw..',
      '..wqqqqqqqqdddqqqqqqqqqw..',
      '..wqqqqqqqqdddqqqqqqqqqw..',
      '..wqqqqqqqqdddqqqqqqqqqw..',
      '..wqqqqqqqqdddqqqqqqqqqw..',
      '..wqqqqqqqqdddqqqqqqqqqw..',
      '.sSSSSSSSSSSSSSSSSSSSSSSs.',
      '.sSSDSSSSDSSSSDSSSSDSSSSs.',
      '.sSSDSSSSDSSSSDSSSSDSSSSs.',
      '.DDDDDDDDDDDDDDDDDDDDDDDD.',
    ],
    well: [
      '.....hHHh.....',
      '...hhHHHHhh...',
      '..hhhhHHhhhh..',
      '.wwwwwwwwwwww.',
      '.w..........w.',
      '.w...aa.....w.',
      '.w...aa.....w.',
      '.ssssssssssss.',
      '.sDDDDDDDDDDs.',
      '.sDlDDDDDDlDs.',
      '.ssssssssssss.',
      '..ssssssssss..',
      '..sSSssSSsss..',
      '..dddddddddd..',
    ],
    stall: [
      '..rrrrrrrrrrrrrr..',
      '.rrWWrrWWrrWWrrWW.',
      '.rrWWrrWWrrWWrrWW.',
      '.rrWWrrWWrrWWrrWW.',
      '.w..............w.',
      '.w..............w.',
      '.w.gg..gg..gg...w.',
      '.wwwwwwwwwwwwwwww.',
      '.wppppppppppppppw.',
      '.wpPppPppPppPpppw.',
      '.w..ww..ww..ww..w.',
      '.D..DD..DD..DD..D.',
    ],
    fence: [
      '..W....W..',
      '..w....w..',
      'wwwwwwwwww',
      '..w....w..',
      '..w....w..',
      'wwwwwwwwww',
      '..w....w..',
      '..w....w..',
    ],
  };
}

// ============================================================
// TILE GENERATION (procedural speckle textures)
// ============================================================
export type TileSet = Record<string, HTMLCanvasElement[]>;

function speckleTile(
  base: string, specks: Array<[string, number]>, seed: number,
  w = 16, h = 16, extra?: (g: CanvasRenderingContext2D, rng: () => number) => void,
): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d')!;
  g.fillStyle = base; g.fillRect(0, 0, w, h);
  const rng = mulberry32(seed);
  for (const [col, density] of specks) {
    g.fillStyle = col;
    const n = Math.floor(w * h * density);
    for (let i = 0; i < n; i++) {
      const x = Math.floor(rng() * w), y = Math.floor(rng() * h);
      g.fillRect(x, y, 1, 1);
    }
  }
  if (extra) extra(g, rng);
  return c;
}

function waterTile(seed: number, deep: boolean, frame: number): HTMLCanvasElement {
  const base = deep ? '#1d4e5e' : '#2e7d8a';
  const c = document.createElement('canvas');
  c.width = 16; c.height = 16;
  const g = c.getContext('2d')!;
  g.fillStyle = base; g.fillRect(0, 0, 16, 16);
  const rng = mulberry32(seed + frame * 77);
  g.fillStyle = deep ? '#26677a' : '#3f95a0';
  for (let i = 0; i < 9; i++) {
    const x = Math.floor(rng() * 16), y = Math.floor(rng() * 16);
    g.fillRect(x, y, 3, 1);
  }
  g.fillStyle = deep ? '#163d4a' : '#266e7a';
  for (let i = 0; i < 6; i++) {
    const x = Math.floor(rng() * 16), y = Math.floor(rng() * 16);
    g.fillRect(x, y, 2, 1);
  }
  return c;
}

function lavaTile(seed: number, frame: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 16; c.height = 16;
  const g = c.getContext('2d')!;
  g.fillStyle = '#4a1a10'; g.fillRect(0, 0, 16, 16);
  const rng = mulberry32(seed + frame * 131);
  const cols = frame === 0 ? ['#e2552e', '#f2882e', '#ffd75e'] : ['#c2441e', '#e2691e', '#f2b03e'];
  for (const col of cols) {
    g.fillStyle = col;
    for (let i = 0; i < 12; i++) {
      const x = Math.floor(rng() * 16), y = Math.floor(rng() * 16);
      g.fillRect(x, y, 1 + Math.floor(rng() * 3), 1);
    }
  }
  return c;
}

export function buildTiles(): TileSet {
  const T: TileSet = {};
  let s = 0;
  const n = () => ++s;
  T.grass = [0, 1, 2].map((v) => speckleTile('#4e8e3a', [['#5ea847', 0.10], ['#3e7530', 0.08], ['#6ab354', 0.03]], n() + v * 991));
  T.grass_dry = [0].map(() => speckleTile('#7a9e3e', [['#8ab04e', 0.09], ['#638230', 0.08]], n()));
  T.forest = [0, 1].map((v) => speckleTile('#3a6e30', [['#2e5a26', 0.12], ['#4a8238', 0.06], ['#5e4a2e', 0.04]], n() + v * 77));
  T.darkwood = [0].map(() => speckleTile('#2e3a30', [['#242e26', 0.12], ['#3a4a3c', 0.06], ['#4e2e5e', 0.02]], n()));
  T.sand = [0, 1].map((v) => speckleTile('#d8c07a', [['#c9ae62', 0.09], ['#e8d494', 0.06]], n() + v * 55));
  T.snow = [0, 1].map((v) => speckleTile('#dfe8ec', [['#c9d6dd', 0.08], ['#f2f8fa', 0.05]], n() + v * 33));
  T.swamp = [0].map(() => speckleTile('#4a5e3a', [['#3a4a2e', 0.12], ['#5e7248', 0.05], ['#3a5e5e', 0.03]], n()));
  T.rock = [0].map(() => speckleTile('#6e6a60', [['#5a564e', 0.10], ['#82807a', 0.06]], n()));
  T.wastes = [0].map(() => speckleTile('#4a3a52', [['#3a2c42', 0.12], ['#5e4a68', 0.06], ['#8a4aa8', 0.015]], n()));
  T.arcane = [0].map((v) => speckleTile('#5e5872', [['#4e4860', 0.1], ['#7a72a0', 0.05], ['#b8a8e8', 0.02]], n() + v * 17, 16, 16, (g) => {
    g.strokeStyle = '#c9b8f2'; g.lineWidth = 1;
    g.strokeRect(3.5, 3.5, 9, 9);
  }));
  T.volcanic = [0].map(() => speckleTile('#3a2a28', [['#2e1f1e', 0.12], ['#54352e', 0.05], ['#8a3a1e', 0.02]], n()));
  T.water_deep = [0, 1].map((f) => waterTile(n(), true, f));
  T.water_shallow = [0, 1].map((f) => waterTile(n(), false, f));
  T.lava = [0, 1].map((f) => lavaTile(n(), f));
  T.arena = [0].map(() => speckleTile('#5e5a55', [['#4e4a46', 0.1], ['#6e6a64', 0.06]], n(), 16, 16, (g, rng) => {
    g.strokeStyle = '#3e3a38'; g.lineWidth = 1;
    g.strokeRect(0.5, 0.5, 15, 15);
    if (rng() > 0.6) { g.fillStyle = '#4e3e3e'; g.fillRect(4, 4, 3, 2); }
  }));
  T.path = [0].map(() => speckleTile('#9e8a62', [['#8a7752', 0.1], ['#b09e74', 0.05]], n()));
  T.tundra_rock = [0].map(() => speckleTile('#8a9aa0', [['#74848c', 0.1], ['#a8b8bd', 0.05]], n()));
  return T;
}

/* ============================================================
   GROUND LUXURY LAYER — the tile system v2.
   Every family is authored as MOODS (large-scale regional tint
   patches: whole meadows read lush or dry) x VARIANTS (per-tile
   detail: grass blades, pebbles, ripples, cracks, sparkles).
   game.ts picks mood by coarse region hash + variant by tile
   hash, so the ground never tiles visibly and never reads flat.
   ============================================================ */

type TileExtra = (g: CanvasRenderingContext2D, rng: () => number) => void;
interface MoodSpec { base: string; specks: Array<[string, number]>; extra?: TileExtra }

// --- tiny detail painters shared across families ---
function blades(g: CanvasRenderingContext2D, rng: () => number, n: number, dark: string, lite: string): void {
  for (let i = 0; i < n; i++) {
    const x = 1 + Math.floor(rng() * 14), y = 3 + Math.floor(rng() * 11);
    g.fillStyle = dark; g.fillRect(x, y, 1, 2);
    g.fillStyle = lite; g.fillRect(x, y - 1, 1, 1);
  }
}
function dots(g: CanvasRenderingContext2D, rng: () => number, n: number, col: string, s = 1): void {
  g.fillStyle = col;
  for (let i = 0; i < n; i++) g.fillRect(Math.floor(rng() * 16), Math.floor(rng() * 16), s, s);
}
function blotch(g: CanvasRenderingContext2D, rng: () => number, col: string, alpha: number, s: number): void {
  g.globalAlpha = alpha; g.fillStyle = col;
  g.fillRect(Math.floor(rng() * (16 - s)), Math.floor(rng() * (16 - s)), s, s);
  g.globalAlpha = 1;
}
function ripple(g: CanvasRenderingContext2D, rng: () => number, col: string): void {
  g.fillStyle = col;
  const y = 2 + Math.floor(rng() * 13);
  const x = Math.floor(rng() * 10);
  g.fillRect(x, y, 3 + Math.floor(rng() * 4), 1);
}
function crackLine(g: CanvasRenderingContext2D, rng: () => number, col: string): void {
  g.fillStyle = col;
  let x = 2 + Math.floor(rng() * 12), y = 2 + Math.floor(rng() * 12);
  for (let i = 0; i < 4; i++) {
    g.fillRect(x, y, 1, 1);
    x += rng() > 0.5 ? 1 : rng() > 0.5 ? -1 : 0;
    y += rng() > 0.4 ? 1 : -1;
    x = Math.max(0, Math.min(15, x)); y = Math.max(0, Math.min(15, y));
  }
}
function sparkle(g: CanvasRenderingContext2D, rng: () => number, col: string): void {
  if (rng() > 0.5) return;
  const x = 2 + Math.floor(rng() * 12), y = 2 + Math.floor(rng() * 12);
  g.fillStyle = col;
  g.fillRect(x, y, 1, 1);
  g.globalAlpha = 0.5; g.fillRect(x - 1, y, 1, 1); g.fillRect(x + 1, y, 1, 1); g.fillRect(x, y - 1, 1, 1); g.fillRect(x, y + 1, 1, 1);
  g.globalAlpha = 1;
}

function moodTiles(moods: MoodSpec[], variants: number, seed: number): HTMLCanvasElement[] {
  const out: HTMLCanvasElement[] = [];
  for (let mi = 0; mi < moods.length; mi++) {
    for (let vi = 0; vi < variants; vi++) {
      const m = moods[mi];
      out.push(speckleTile(m.base, m.specks, seed + mi * 97 + vi * 13 + 5, 16, 16, (g, rng) => {
        m.extra?.(g, rng);
      }));
    }
  }
  return out;
}

function buildLuxTiles(): Record<string, HTMLCanvasElement[]> {
  const L: Record<string, HTMLCanvasElement[]> = {};
  // --- GRASS: 4 moods (lush / meadow / dry / shaded) x 3 variants
  const grassFlower: TileExtra = (g, rng) => {
    blades(g, rng, 3, '#35682a', '#7ec25e');
    if (rng() > 0.72) dots(g, rng, 1, rng() > 0.5 ? '#f2ead0' : '#e8a8c9');
    if (rng() > 0.85) blotch(g, rng, '#8a744e', 0.22, 3);
  };
  L.grass = moodTiles([
    { base: '#4f9139', specks: [['#5ea847', 0.1], ['#3e7530', 0.08], ['#6ab354', 0.03]], extra: grassFlower },
    { base: '#4e8e3a', specks: [['#5ea847', 0.09], ['#3e7530', 0.09], ['#68b050', 0.02]], extra: (g, rng) => { blades(g, rng, 3, '#35682a', '#78bc56'); if (rng() > 0.6) blotch(g, rng, '#3a6e2c', 0.3, 2); } },
    { base: '#6e9a44', specks: [['#7fae50', 0.09], ['#5a8038', 0.08], ['#94bc62', 0.02]], extra: (g, rng) => { blades(g, rng, 2, '#4e7430', '#9cc46e'); if (rng() > 0.5) blotch(g, rng, '#98874e', 0.16, 3); } },
    { base: '#417c33', specks: [['#4e8e3c', 0.09], ['#31602a', 0.09]], extra: (g, rng) => { blades(g, rng, 2, '#2c5824', '#68a84e'); if (rng() > 0.5) blotch(g, rng, '#22481e', 0.28, 3); } },
  ], 3, 4100);
  // --- GRASS_DRY (kept for tile id 4): 1 mood x 2
  L.grass_dry = moodTiles([
    { base: '#7a9e3e', specks: [['#8ab04e', 0.09], ['#638230', 0.08]], extra: (g, rng) => { blades(g, rng, 3, '#5a7a2e', '#a8c46e'); if (rng() > 0.6) dots(g, rng, 1, '#c9b46e'); } },
  ], 2, 4300);
  // --- FOREST floor: 3 moods x 3
  L.forest = moodTiles([
    { base: '#3a6e30', specks: [['#2e5a26', 0.12], ['#4a8238', 0.06], ['#5e4a2e', 0.04]], extra: (g, rng) => { dots(g, rng, 2, '#2a5222'); if (rng() > 0.5) { g.fillStyle = '#5e4a2e'; g.fillRect(Math.floor(rng() * 13), Math.floor(rng() * 14), 3, 1); } } },
    { base: '#35662c', specks: [['#2a5222', 0.12], ['#447a34', 0.06]], extra: (g, rng) => { if (rng() > 0.45) blotch(g, rng, '#24481e', 0.3, 3); if (rng() > 0.6) dots(g, rng, 2, '#4e8838'); } },
    { base: '#3f7434', specks: [['#315c28', 0.11], ['#4e8a3c', 0.06], ['#6a9e46', 0.02]], extra: (g, rng) => { blades(g, rng, 2, '#2c5224', '#68a44e'); if (rng() > 0.7) dots(g, rng, 1, '#d8d3c0'); } },
  ], 3, 4500);
  // --- DARKWOOD: 2 moods x 3
  L.darkwood = moodTiles([
    { base: '#2e3a30', specks: [['#242e26', 0.12], ['#3a4a3c', 0.06], ['#4e2e5e', 0.02]], extra: (g, rng) => { if (rng() > 0.55) blotch(g, rng, '#1e2820', 0.35, 3); if (rng() > 0.75) dots(g, rng, 1, '#8a5ec9'); } },
    { base: '#28322a', specks: [['#1e2820', 0.13], ['#34423a', 0.05], ['#5e3a7e', 0.015]], extra: (g, rng) => { if (rng() > 0.6) crackLine(g, rng, '#161e18'); if (rng() > 0.7) dots(g, rng, 1, '#6a4a94'); } },
  ], 3, 4700);
  // --- SAND: 3 moods x 3 (pale / golden / red) with wind ripples + sparkles
  L.sand = moodTiles([
    { base: '#d8c07a', specks: [['#c9ae62', 0.09], ['#e8d494', 0.06]], extra: (g, rng) => { ripple(g, rng, '#c2a256'); ripple(g, rng, '#c2a256'); sparkle(g, rng, '#fff8e0'); } },
    { base: '#d0b56e', specks: [['#c0a256', 0.09], ['#e0cc8e', 0.05]], extra: (g, rng) => { ripple(g, rng, '#b89a4e'); if (rng() > 0.5) dots(g, rng, 1, '#a88e4e', 2); sparkle(g, rng, '#fff2cc'); } },
    { base: '#c9a862', specks: [['#b89050', 0.1], ['#dcbe7e', 0.05]], extra: (g, rng) => { ripple(g, rng, '#aa8848'); if (rng() > 0.65) dots(g, rng, 1, '#8a7040'); } },
  ], 3, 4900);
  // --- SNOW: 3 moods x 3 with glints + drifts + rare frozen grass
  L.snow = moodTiles([
    { base: '#dfe8ec', specks: [['#c9d6dd', 0.08], ['#f2f8fa', 0.05]], extra: (g, rng) => { sparkle(g, rng, '#ffffff'); if (rng() > 0.5) { g.fillStyle = '#eef6f8'; g.fillRect(Math.floor(rng() * 13), Math.floor(rng() * 13), 3, 1); } } },
    { base: '#d6e2e8', specks: [['#c2d2da', 0.08], ['#ecf4f6', 0.05]], extra: (g, rng) => { sparkle(g, rng, '#ffffff'); if (rng() > 0.6) dots(g, rng, 1, '#b8ccd4', 2); } },
    { base: '#e6eef0', specks: [['#d0dce2', 0.07], ['#f8fcfd', 0.05]], extra: (g, rng) => { sparkle(g, rng, '#ffffff'); if (rng() > 0.7) { g.fillStyle = '#9ab088'; g.fillRect(Math.floor(rng() * 14), Math.floor(rng() * 13), 1, 2); } } },
  ], 3, 5100);
  // --- SWAMP: 2 moods x 3 with stagnant puddles + bubbles
  L.swamp = moodTiles([
    { base: '#4a5e3a', specks: [['#3a4a2e', 0.12], ['#5e7248', 0.05], ['#3a5e5e', 0.03]], extra: (g, rng) => { if (rng() > 0.4) blotch(g, rng, '#35565a', 0.5, 3); if (rng() > 0.6) dots(g, rng, 1, '#8ab0a0'); } },
    { base: '#44582f', specks: [['#344426', 0.13], ['#546a40', 0.05], ['#3a5a52', 0.03]], extra: (g, rng) => { if (rng() > 0.5) blotch(g, rng, '#2e4e50', 0.45, 2); if (rng() > 0.65) crackLine(g, rng, '#2a3a20'); } },
  ], 3, 5300);
  // --- ROCK: 2 moods x 2 with cracks + lichen
  L.rock = moodTiles([
    { base: '#6e6a60', specks: [['#5a564e', 0.1], ['#82807a', 0.06]], extra: (g, rng) => { if (rng() > 0.4) crackLine(g, rng, '#4a463e'); if (rng() > 0.7) dots(g, rng, 1, '#6a8a4a'); } },
    { base: '#66625a', specks: [['#545048', 0.11], ['#7c7a72', 0.05]], extra: (g, rng) => { if (rng() > 0.5) crackLine(g, rng, '#443e36'); } },
  ], 2, 5500);
  // --- WASTES: 2 x 2 with embers + bone specks
  L.wastes = moodTiles([
    { base: '#4a3a52', specks: [['#3a2c42', 0.12], ['#5e4a68', 0.06], ['#8a4aa8', 0.015]], extra: (g, rng) => { if (rng() > 0.6) dots(g, rng, 1, '#c95ee8'); if (rng() > 0.7) dots(g, rng, 1, '#b0a898'); } },
    { base: '#423349', specks: [['#32253c', 0.13], ['#544264', 0.05]], extra: (g, rng) => { if (rng() > 0.5) crackLine(g, rng, '#2a1e33'); if (rng() > 0.75) dots(g, rng, 1, '#d8d0e0'); } },
  ], 2, 5700);
  // --- VOLCANIC: 2 x 2 with glow cracks
  L.volcanic = moodTiles([
    { base: '#3a2a28', specks: [['#2e1f1e', 0.12], ['#54352e', 0.05], ['#8a3a1e', 0.02]], extra: (g, rng) => { if (rng() > 0.45) crackLine(g, rng, '#c2522e'); if (rng() > 0.7) dots(g, rng, 1, '#f2a04e'); } },
    { base: '#332422', specks: [['#281a18', 0.13], ['#4c302a', 0.05]], extra: (g, rng) => { if (rng() > 0.55) crackLine(g, rng, '#a83e1e'); } },
  ], 2, 5900);
  // --- ARCANE: 2 x 2, keeps its rune squares, adds glints
  L.arcane = moodTiles([
    { base: '#5e5872', specks: [['#4e4860', 0.1], ['#7a72a0', 0.05], ['#b8a8e8', 0.02]], extra: (g, rng) => { g.strokeStyle = '#c9b8f2'; g.lineWidth = 1; g.strokeRect(3.5, 3.5, 9, 9); if (rng() > 0.5) sparkle(g, rng, '#e8dcff'); } },
    { base: '#565069', specks: [['#464058', 0.11], ['#706894', 0.05], ['#a898d8', 0.02]], extra: (g, rng) => { g.strokeStyle = '#b0a0e0'; g.lineWidth = 1; g.beginPath(); g.arc(8, 8, 4, 0, Math.PI * 2); g.stroke(); } },
  ], 2, 6100);
  // --- PATH: 2 x 2 — packed dirt, wheel ruts, pebbles
  L.path = moodTiles([
    { base: '#9e8a62', specks: [['#8a7752', 0.1], ['#b09e74', 0.05]], extra: (g, rng) => { if (rng() > 0.4) { g.fillStyle = '#7c6a48'; g.fillRect(1, 7 + Math.floor(rng() * 3), 14, 1); } if (rng() > 0.5) dots(g, rng, 2, '#a89a7e'); } },
    { base: '#96825c', specks: [['#826f4c', 0.1], ['#a89670', 0.05]], extra: (g, rng) => { if (rng() > 0.5) dots(g, rng, 2, '#b0a284', 2); if (rng() > 0.7) dots(g, rng, 1, '#6e5e42'); } },
  ], 2, 6300);
  // --- TUNDRA ROCK: frost-cracked stone
  L.tundra_rock = moodTiles([
    { base: '#8a9aa0', specks: [['#74848c', 0.1], ['#a8b8bd', 0.05]], extra: (g, rng) => { if (rng() > 0.4) crackLine(g, rng, '#5a6a72'); if (rng() > 0.6) dots(g, rng, 2, '#e8f2f6'); } },
  ], 2, 6500);
  // --- generic arena stone (also the fallback under wall structures)
  L.arena = moodTiles([
    { base: '#5e5a55', specks: [['#4e4a46', 0.1], ['#6e6a64', 0.06]], extra: (g, rng) => { g.strokeStyle = '#3e3a38'; g.lineWidth = 1; g.strokeRect(0.5, 0.5, 15, 15); if (rng() > 0.6) { g.fillStyle = '#4e3e3e'; g.fillRect(4, 4, 3, 2); } } },
    { base: '#5a564f', specks: [['#4a4640', 0.11], ['#66625c', 0.05]], extra: (g, rng) => { if (rng() > 0.5) crackLine(g, rng, '#3a3632'); } },
  ], 2, 6700);
  return L;
}

/* ============================================================
   BOSS ARENA FLOORS — themed 3-tier mosaics per boss.
   tier 0 = outer flagstone, 1 = rune ring, 2 = center emblem.
   3 variants each; game.ts picks by distance ring + hash.
   ============================================================ */
export const ARENA_FLOOR_IDS: Record<string, number[]> = {}; // bossId -> [t0,t1,t2] tile ids (world.ts owns carving)

interface ArenaFloorTheme {
  stone: [string, string]; mortar: string; inlay: string; inlay2: string;
  emblem: (g: CanvasRenderingContext2D) => void;
}

const ARENA_FLOOR_THEMES: Record<string, ArenaFloorTheme> = {
  ashen: {
    stone: ['#463631', '#3c2c28'], mortar: '#241a18', inlay: '#e2552e', inlay2: '#ffb05e',
    emblem: (g) => { // blazing wedge
      g.strokeStyle = '#e2552e'; g.lineWidth = 1.4;
      g.beginPath(); g.moveTo(8, 2); g.lineTo(12, 10); g.lineTo(8, 13); g.lineTo(4, 10); g.closePath(); g.stroke();
      g.fillStyle = '#ffb05e'; g.fillRect(8, 5, 1, 5); g.fillStyle = '#ff7a3e'; g.fillRect(6, 8, 4, 2);
    },
  },
  frost: {
    stone: ['#9ec2d0', '#8ab2c2'], mortar: '#628698', inlay: '#7ce8ff', inlay2: '#e8fbff',
    emblem: (g) => { // frozen sigil
      g.strokeStyle = '#7ce8ff'; g.lineWidth = 1.2;
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * Math.PI;
        g.beginPath(); g.moveTo(8 - Math.cos(a) * 5, 8 - Math.sin(a) * 5); g.lineTo(8 + Math.cos(a) * 5, 8 + Math.sin(a) * 5); g.stroke();
      }
      g.fillStyle = '#e8fbff'; g.fillRect(7, 7, 2, 2);
    },
  },
  hollow: {
    stone: ['#7e7a6c', '#6e6a5c'], mortar: '#4c483c', inlay: '#7ce8ff', inlay2: '#d8d3c0',
    emblem: (g) => { // skull sigil
      g.fillStyle = '#d8d3c0';
      g.fillRect(5, 4, 6, 5); g.fillRect(4, 6, 8, 3); g.fillRect(6, 10, 4, 2);
      g.fillStyle = '#1a1420'; g.fillRect(6, 6, 2, 2); g.fillRect(9, 6, 2, 2);
      g.fillStyle = '#7ce8ff'; g.fillRect(6, 6, 1, 1); g.fillRect(9, 6, 1, 1);
    },
  },
  storm: {
    stone: ['#44525e', '#3a4752'], mortar: '#26313a', inlay: '#ffd75e', inlay2: '#fff8d0',
    emblem: (g) => { // bolt sigil
      g.strokeStyle = '#ffd75e'; g.lineWidth = 1.4;
      g.beginPath(); g.moveTo(9, 2); g.lineTo(6, 8); g.lineTo(9, 8); g.lineTo(7, 14); g.stroke();
      g.fillStyle = '#fff8d0'; g.fillRect(8, 8, 1, 1);
    },
  },
  maw: {
    stone: ['#4c5e38', '#42522f'], mortar: '#2a3820', inlay: '#a8e06a', inlay2: '#d8ff9e',
    emblem: (g) => { // hungry maw
      g.strokeStyle = '#a8e06a'; g.lineWidth = 1.2;
      g.beginPath(); g.arc(8, 8, 5, 0, Math.PI * 2); g.stroke();
      g.fillStyle = '#1c2614'; g.fillRect(5, 6, 6, 4);
      g.fillStyle = '#d8ff9e';
      for (let i = 0; i < 4; i++) { g.fillRect(5 + i * 2, 6, 1, 1); g.fillRect(6 + i * 2, 9, 1, 1); }
    },
  },
  tide: {
    stone: ['#3a7a8a', '#316b7a'], mortar: '#1e4a56', inlay: '#8ad4de', inlay2: '#d8f6fa',
    emblem: (g) => { // wave spiral
      g.strokeStyle = '#8ad4de'; g.lineWidth = 1.2;
      g.beginPath(); g.arc(8, 8, 5, -Math.PI * 0.8, Math.PI * 0.9); g.stroke();
      g.beginPath(); g.arc(8, 8, 2.4, Math.PI * 0.6, Math.PI * 2.1); g.stroke();
      g.fillStyle = '#d8f6fa'; g.fillRect(10, 5, 1, 1);
    },
  },
  aeon: {
    stone: ['#8a7a4e', '#7a6c42'], mortar: '#4e4428', inlay: '#5ee8d8', inlay2: '#c9fff8',
    emblem: (g) => { // clockwork sigil
      g.strokeStyle = '#5ee8d8'; g.lineWidth = 1.1;
      g.beginPath(); g.arc(8, 8, 5, 0, Math.PI * 2); g.stroke();
      g.beginPath(); g.moveTo(8, 8); g.lineTo(8, 4); g.stroke();
      g.beginPath(); g.moveTo(8, 8); g.lineTo(11, 10); g.stroke();
      g.fillStyle = '#c9fff8'; g.fillRect(7, 7, 2, 2);
    },
  },
  void: {
    stone: ['#33264a', '#2a1f3e'], mortar: '#160f24', inlay: '#c95ee8', inlay2: '#f2c9ff',
    emblem: (g) => { // the unblinking eye
      g.strokeStyle = '#c95ee8'; g.lineWidth = 1.1;
      g.beginPath(); g.ellipse(8, 8, 6, 3.6, 0, 0, Math.PI * 2); g.stroke();
      g.fillStyle = '#e85eff'; g.beginPath(); g.arc(8, 8, 2, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#ffffff'; g.fillRect(8, 7, 1, 1);
    },
  },
};

function flagstone(g: CanvasRenderingContext2D, rng: () => number, a: string, b: string, mortar: string): void {
  // 2x2 stone blocks with shaded mortar joints
  g.fillStyle = a; g.fillRect(0, 0, 16, 16);
  g.fillStyle = b;
  if (rng() > 0.5) g.fillRect(0, 0, 8, 8); else g.fillRect(8, 0, 8, 8);
  if (rng() > 0.5) g.fillRect(0, 8, 8, 8);
  g.fillStyle = mortar;
  g.fillRect(0, 7, 16, 1); g.fillRect(0, 15, 16, 1);
  const off = rng() > 0.5 ? 7 : 8;
  g.fillRect(off, 0, 1, 8);
  g.fillRect(off === 7 ? 8 : 7, 8, 1, 8);
  // chips
  if (rng() > 0.6) { g.fillStyle = mortar; g.fillRect(Math.floor(rng() * 15), Math.floor(rng() * 15), 1, 1); }
}

function buildArenaFloors(): Record<string, HTMLCanvasElement[][]> {
  const out: Record<string, HTMLCanvasElement[][]> = {};
  for (const [id, th] of Object.entries(ARENA_FLOOR_THEMES)) {
    const tiers: HTMLCanvasElement[][] = [[], [], []];
    for (let vi = 0; vi < 3; vi++) {
      const seed = 7300 + vi * 61 + id.charCodeAt(0) * 7 + id.length * 3;
      // tier 0 — plain flagstone
      tiers[0].push(speckleTile(th.stone[0], [[th.stone[1], 0.1]], seed, 16, 16, (g, rng) => flagstone(g, rng, th.stone[0], th.stone[1], th.mortar)));
      // tier 1 — flagstone + glowing inlay arc (the rune ring)
      tiers[1].push(speckleTile(th.stone[0], [[th.stone[1], 0.1]], seed + 17, 16, 16, (g, rng) => {
        flagstone(g, rng, th.stone[0], th.stone[1], th.mortar);
        g.strokeStyle = th.inlay; g.lineWidth = 1;
        g.globalAlpha = 0.85;
        g.beginPath(); g.arc(8, 8, 6.4, rng() * 2, rng() * 2 + 2.4); g.stroke();
        g.globalAlpha = 0.4; g.fillStyle = th.inlay2;
        g.fillRect(3 + Math.floor(rng() * 10), 3 + Math.floor(rng() * 10), 1, 1);
        g.globalAlpha = 1;
      }));
      // tier 2 — darker ritual disc + the boss emblem
      tiers[2].push(speckleTile(th.stone[1], [[th.mortar, 0.08]], seed + 43, 16, 16, (g, rng) => {
        g.fillStyle = th.mortar; g.globalAlpha = 0.55;
        g.beginPath(); g.arc(8, 8, 7.4, 0, Math.PI * 2); g.fill();
        g.globalAlpha = 1;
        g.strokeStyle = th.inlay; g.lineWidth = 1;
        g.beginPath(); g.arc(8, 8, 7, 0, Math.PI * 2); g.stroke();
        th.emblem(g);
        sparkle(g, rng, th.inlay2);
      }));
    }
    out[id] = tiers;
  }
  return out;
}

/* ============================================================
   ARENA STRUCTURE KIT — walls, towers, braziers, banners,
   entrance arches. One kit per boss, tinted to its element.
   Drawn as pseudo-3D sprites over solid wall tiles.
   ============================================================ */
export interface ArenaKit {
  wall: HTMLCanvasElement; tower: HTMLCanvasElement; brazier: HTMLCanvasElement;
  banner0: HTMLCanvasElement; banner1: HTMLCanvasElement; arch: HTMLCanvasElement;
}

interface WallTheme { brick: string; brick2: string; mortar: string; cap: string; trim: string }

const WALL_THEMES: Record<string, WallTheme> = {
  ashen: { brick: '#4c3a34', brick2: '#3e2e2a', mortar: '#261c1a', cap: '#6a5248', trim: '#e2552e' },
  frost: { brick: '#a4c0d0', brick2: '#8cacc0', mortar: '#5e8296', cap: '#d8ecf4', trim: '#7ce8ff' },
  hollow: { brick: '#827e70', brick2: '#6e6a5c', mortar: '#48443a', cap: '#a29c8c', trim: '#7ce8ff' },
  storm: { brick: '#485662', brick2: '#3a4854', mortar: '#242e38', cap: '#66788a', trim: '#ffd75e' },
  maw: { brick: '#4e6038', brick2: '#425230', mortar: '#26341c', cap: '#688246', trim: '#a8e06a' },
  tide: { brick: '#3a768a', brick2: '#2e647a', mortar: '#1c4652', cap: '#58a2b2', trim: '#8ad4de' },
  aeon: { brick: '#8a7a4e', brick2: '#78683e', mortar: '#4a4026', cap: '#a89a68', trim: '#5ee8d8' },
  void: { brick: '#3a2a4e', brick2: '#2e2140', mortar: '#180f28', cap: '#564268', trim: '#e85eff' },
};

function buildArenaKit(): Record<string, ArenaKit> {
  const kits: Record<string, ArenaKit> = {};
  for (const [id, th] of Object.entries(WALL_THEMES)) {
    const seed = 8100 + id.charCodeAt(0) * 11 + id.length * 5;
    const rng0 = mulberry32(seed);
    // ---- wall block 16x26: brick courses + glowing trim course + cap ----
    const wall = document.createElement('canvas');
    wall.width = 16; wall.height = 26;
    {
      const g = wall.getContext('2d')!;
      g.fillStyle = th.mortar; g.fillRect(0, 0, 16, 26);
      for (let row = 0; row < 6; row++) {
        const y = row * 4 + 2;
        const off = row % 2 === 0 ? 0 : 4;
        for (let bx = -1; bx < 3; bx++) {
          const x = off + bx * 8;
          g.fillStyle = rng0() > 0.5 ? th.brick : th.brick2;
          g.fillRect(Math.max(0, x), y, Math.min(7, 16 - Math.max(0, x)), 3);
        }
      }
      // cap
      g.fillStyle = th.cap; g.fillRect(0, 0, 16, 3);
      g.fillStyle = 'rgba(255,255,255,0.18)'; g.fillRect(0, 0, 16, 1);
      // trim course glint
      g.fillStyle = th.trim; g.globalAlpha = 0.5;
      g.fillRect(rng0() > 0.5 ? 2 : 10, 1, 3, 1);
      g.globalAlpha = 1;
      // base shadow
      g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(0, 24, 16, 2);
    }
    // ---- corner tower 26x46: merlons + banner band ----
    const tower = document.createElement('canvas');
    tower.width = 26; tower.height = 46;
    {
      const g = tower.getContext('2d')!;
      const rng = mulberry32(seed + 3);
      g.fillStyle = th.mortar; g.fillRect(0, 6, 26, 40);
      for (let row = 0; row < 10; row++) {
        const y = row * 4 + 8;
        const off = row % 2 === 0 ? 0 : 4;
        for (let bx = -1; bx < 5; bx++) {
          const x = off + bx * 8;
          if (x + 7 < 0 || x > 26) continue;
          g.fillStyle = rng() > 0.5 ? th.brick : th.brick2;
          g.fillRect(Math.max(0, x), y, Math.min(7, 26 - Math.max(0, x)), 3);
        }
      }
      // merlons
      g.fillStyle = th.cap;
      g.fillRect(0, 2, 6, 6); g.fillRect(10, 2, 6, 6); g.fillRect(20, 2, 6, 6);
      g.fillStyle = 'rgba(255,255,255,0.2)';
      g.fillRect(0, 2, 26, 1);
      // trim band + glow stone
      g.fillStyle = th.trim; g.globalAlpha = 0.75; g.fillRect(3, 20, 20, 1); g.globalAlpha = 1;
      g.fillStyle = th.trim;
      g.fillRect(11, 26, 4, 3);
      g.fillStyle = 'rgba(0,0,0,0.4)'; g.fillRect(0, 44, 26, 2);
    }
    // ---- brazier 14x18 ----
    const brazier = document.createElement('canvas');
    brazier.width = 14; brazier.height = 18;
    {
      const g = brazier.getContext('2d')!;
      g.fillStyle = '#2a2226';
      g.fillRect(3, 14, 2, 4); g.fillRect(9, 14, 2, 4); g.fillRect(6, 13, 2, 4);
      g.fillStyle = th.brick2; g.fillRect(2, 8, 10, 5);
      g.fillStyle = th.brick; g.fillRect(2, 8, 10, 2);
      g.fillStyle = th.trim; g.globalAlpha = 0.8; g.fillRect(2, 8, 10, 1); g.globalAlpha = 1;
      g.fillStyle = '#1a1420'; g.fillRect(3, 9, 8, 2);
    }
    // ---- banner 12x26, two sway frames ----
    const banner = (frame: number): HTMLCanvasElement => {
      const c = document.createElement('canvas');
      c.width = 12; c.height = 26;
      const g = c.getContext('2d')!;
      const rng = mulberry32(seed + 9 + frame);
      g.fillStyle = '#5a4a30'; g.fillRect(5, 0, 2, 26);
      g.fillStyle = '#7a6848'; g.fillRect(5, 0, 1, 26);
      g.fillStyle = '#c9a84e'; g.fillRect(3, 1, 6, 2);
      const sway = frame === 1 ? 1 : 0;
      g.fillStyle = th.brick2;
      g.fillRect(2 + sway, 4, 8, 13);
      g.fillStyle = th.brick;
      g.fillRect(3 + sway, 5, 6, 11);
      g.fillStyle = th.trim;
      g.fillRect(3 + sway, 6, 6, 1);
      g.fillRect(4 + sway, 9, 4, 4);
      g.fillStyle = th.cap;
      g.fillRect(5 + sway, 10, 2, 2);
      // notched tail
      g.fillStyle = th.brick2;
      g.fillRect(2 + sway, 17, 3, 3); g.fillRect(7 + sway, 17, 3, 3);
      void rng;
      return c;
    };
    // ---- entrance arch 52x42 ----
    const arch = document.createElement('canvas');
    arch.width = 52; arch.height = 42;
    {
      const g = arch.getContext('2d')!;
      const rng = mulberry32(seed + 21);
      // pillars
      for (const px of [0, 42]) {
        g.fillStyle = th.mortar; g.fillRect(px, 10, 10, 32);
        for (let row = 0; row < 8; row++) {
          g.fillStyle = rng() > 0.5 ? th.brick : th.brick2;
          g.fillRect(px + 1, 12 + row * 4, 8, 3);
        }
        g.fillStyle = th.cap; g.fillRect(px - 1, 8, 12, 4);
        g.fillStyle = 'rgba(255,255,255,0.2)'; g.fillRect(px - 1, 8, 12, 1);
      }
      // lintel
      g.fillStyle = th.mortar; g.fillRect(0, 0, 52, 10);
      for (let bx = 0; bx < 6; bx++) {
        g.fillStyle = rng() > 0.5 ? th.brick : th.brick2;
        g.fillRect(bx * 9 + 1, 2, 7, 6);
      }
      g.fillStyle = th.cap; g.fillRect(0, 0, 52, 2);
      // keystone sigil
      g.fillStyle = th.trim;
      g.fillRect(24, 3, 4, 4);
      g.fillStyle = th.cap; g.fillRect(23, 2, 6, 1);
    }
    kits[id] = { wall, tower, brazier, banner0: banner(0), banner1: banner(1), arch };
  }
  return kits;
}

/* ============================================================
   EDGE TRANSITIONS — pre-rendered dither strips so biome
   boundaries blend instead of hard-stitching. EDGE_TILES[fam]
   holds 4 canvases (n/s/e/w) speckled with that family's edge
   color, dense toward the given side. game.ts stamps the
   neighbor's strip onto boundary tiles.
   ============================================================ */
export type EdgeSide = 'n' | 's' | 'e' | 'w';
export const EDGE_TILES: Record<string, Record<EdgeSide, HTMLCanvasElement>> = {};

// rank: who owns the boundary line (higher bleeds onto lower)
export const FAMILY_RANK: Record<string, number> = {
  water: 0, lava: 0.5, rock: 1, arena: 1, wastes: 2, volcanic: 2, arcane: 2,
  sand: 3, path: 4, swamp: 4.5, dark: 5.5, grass: 6, forest: 6, snow: 7, wall: -1,
};

const EDGE_COLORS: Record<string, string> = {
  water: '#dff2f4', lava: '#ff9e4e', rock: '#54504a', arena: '#4a4640',
  wastes: '#54426a', volcanic: '#2a1c1a', arcane: '#78709e',
  sand: '#c9ae62', path: '#a8946a', swamp: '#36462a', dark: '#222c24',
  grass: '#3a702c', forest: '#2a5222', snow: '#f4fafc',
};

function buildEdgeTiles(): void {
  for (const [fam, col] of Object.entries(EDGE_COLORS)) {
    const sides: Record<EdgeSide, HTMLCanvasElement> = {} as Record<EdgeSide, HTMLCanvasElement>;
    (['n', 's', 'e', 'w'] as EdgeSide[]).forEach((side, si) => {
      const c = document.createElement('canvas');
      c.width = 16; c.height = 16;
      const g = c.getContext('2d')!;
      const rng = mulberry32(9000 + fam.charCodeAt(0) * 31 + si * 7 + fam.length);
      g.fillStyle = col;
      // 4 bands marching away from the edge, thinning out
      for (let band = 0; band < 4; band++) {
        const p = [0.55, 0.3, 0.14, 0.05][band];
        for (let k = 0; k < 16 * p + 2; k++) {
          let x = 0, y = 0;
          const t = Math.floor(rng() * 16);
          if (side === 'n') { x = t; y = band; }
          else if (side === 's') { x = t; y = 15 - band; }
          else if (side === 'w') { x = band; y = t; }
          else { x = 15 - band; y = t; }
          g.fillRect(x, y, 1, 1);
        }
      }
      sides[side] = c;
    });
    EDGE_TILES[fam] = sides;
  }
}

// ============================================================
// SPELL GLYPHS
// ============================================================
const EL_COLORS: Record<ElementId, [string, string]> = {
  fire: ['#ff7a3e', '#ffd75e'],
  frost: ['#9edbe8', '#e8fbff'],
  lightning: ['#f2e35e', '#fffbd0'],
  earth: ['#b08a4e', '#e0c896'],
  wind: ['#9ee8c8', '#e2fff2'],
  water: ['#5eb8c9', '#c9f2f7'],
  poison: ['#8ed94e', '#d8ff9e'],
  blood: ['#d94e5e', '#ffb0b8'],
  shadow: ['#7a5ea8', '#c9b0f2'],
  death: ['#a8b0a0', '#e2e8dc'],
  radiant: ['#ffd75e', '#fff8d8'],
  arcane: ['#c95ee8', '#f2c9ff'],
  time: ['#e8c05e', '#fff2c9'],
  void: ['#5e3e8a', '#b88ae8'],
  nature: ['#6ab354', '#b8e89e'],
  chaos: ['#e85eb8', '#5ee8d8'],
  crystal: ['#f28ac9', '#ffe8f7'],
  metal: ['#b8c2cc', '#f2f7fa'],
  gravity: ['#8091c9', '#dfe8ff'],
  sound: ['#c9f2e4', '#ffffff'],
  bone: ['#e8e0c9', '#fffbe8'],
  beast: ['#c97e4e', '#ffd9a8'],
  plasma: ['#ff5ec9', '#a8f2ff'],
  mirror: ['#c9d8e8', '#f2fbff'],
};

export function elColor(el: ElementId): string { return EL_COLORS[el][0]; }
export function elColor2(el: ElementId): string { return EL_COLORS[el][1]; }

export function makeGlyph(el: ElementId, form: FormId): HTMLCanvasElement {
  const S = 16;
  const c = document.createElement('canvas');
  c.width = S; c.height = S;
  const g = c.getContext('2d')!;
  const [c1, c2] = EL_COLORS[el];
  const grad = g.createRadialGradient(8, 6, 1, 8, 8, 8);
  grad.addColorStop(0, c2); grad.addColorStop(0.6, c1); grad.addColorStop(1, 'rgba(20,10,30,0.9)');
  g.fillStyle = grad;
  g.beginPath(); g.arc(8, 8, 7, 0, Math.PI * 2); g.fill();
  g.strokeStyle = 'rgba(0,0,0,0.55)';
  g.lineWidth = 1;
  g.beginPath(); g.arc(8, 8, 7, 0, Math.PI * 2); g.stroke();
  // form sigil
  g.strokeStyle = '#ffffff';
  g.fillStyle = '#ffffff';
  g.lineWidth = 1.4;
  g.beginPath();
  switch (form) {
    case 'bolt': g.moveTo(4, 12); g.lineTo(12, 4); g.stroke(); break;
    case 'volley':
      g.moveTo(4, 11); g.lineTo(6, 5); g.moveTo(8, 12); g.lineTo(8, 5); g.moveTo(12, 11); g.lineTo(10, 5);
      g.stroke(); break;
    case 'orb': g.beginPath(); g.arc(8, 8, 3.5, 0, Math.PI * 2); g.stroke(); break;
    case 'beam': g.moveTo(2, 8); g.lineTo(14, 8); g.stroke(); g.fillRect(6, 6.5, 4, 3); break;
    case 'wave':
      g.moveTo(3, 9); g.quadraticCurveTo(5.5, 4, 8, 8); g.quadraticCurveTo(10.5, 12, 13, 7); g.stroke(); break;
    case 'nova':
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
        g.moveTo(8, 8); g.lineTo(8 + Math.cos(a) * 5.5, 8 + Math.sin(a) * 5.5);
      }
      g.stroke(); break;
    case 'storm': g.moveTo(8, 3); g.lineTo(8, 10); g.moveTo(5, 7); g.lineTo(8, 11); g.lineTo(11, 7); g.stroke(); break;
    case 'field': g.setLineDash([2, 2]); g.beginPath(); g.arc(8, 8, 4.5, 0, Math.PI * 2); g.stroke(); g.setLineDash([]); break;
    case 'trap': g.moveTo(5, 5); g.lineTo(11, 11); g.moveTo(11, 5); g.lineTo(5, 11); g.stroke(); break;
    case 'ward':
      g.moveTo(8, 3); g.lineTo(12, 5); g.lineTo(12, 9); g.lineTo(8, 13); g.lineTo(4, 9); g.lineTo(4, 5);
      g.closePath(); g.stroke(); break;
    case 'aura': g.beginPath(); g.arc(8, 8, 5.5, 0, Math.PI * 2); g.stroke(); g.beginPath(); g.arc(8, 8, 2.5, 0, Math.PI * 2); g.stroke(); break;
    case 'enchant': g.moveTo(4, 9); g.lineTo(8, 4); g.lineTo(12, 9); g.stroke(); break;
    case 'summon': g.moveTo(8, 4); g.lineTo(12, 12); g.lineTo(4, 12); g.closePath(); g.stroke(); break;
    case 'blink': g.moveTo(5, 5); g.lineTo(9, 8); g.lineTo(5, 11); g.moveTo(9, 5); g.lineTo(13, 8); g.lineTo(9, 11); g.stroke(); break;
    case 'mend': g.moveTo(8, 4); g.lineTo(8, 12); g.moveTo(4, 8); g.lineTo(12, 8); g.stroke(); break;
    case 'ritual':
      g.beginPath(); g.arc(8, 8, 5, 0, Math.PI * 2); g.stroke();
      g.moveTo(8, 4.5); g.lineTo(11, 11); g.lineTo(4.5, 7); g.lineTo(11.5, 7); g.lineTo(5, 11); g.closePath(); g.stroke(); break;
  }
  return c;
}

// ============================================================
// BOOT
// ============================================================
let booted = false;
export function initSprites(): void {
  if (booted) return;
  booted = true;

  // tiles
  const tiles = buildTiles();
  SPR.tile_grass = tiles.grass[0];
  SPR.tile_grass2 = tiles.grass[1];
  SPR.tile_grass3 = tiles.grass[2];
  SPR.tile_grass_dry = tiles.grass_dry[0];
  SPR.tile_forest = tiles.forest[0];
  SPR.tile_forest2 = tiles.forest[1];
  SPR.tile_darkwood = tiles.darkwood[0];
  SPR.tile_sand = tiles.sand[0];
  SPR.tile_sand2 = tiles.sand[1];
  SPR.tile_snow = tiles.snow[0];
  SPR.tile_snow2 = tiles.snow[1];
  SPR.tile_swamp = tiles.swamp[0];
  SPR.tile_rock = tiles.rock[0];
  SPR.tile_wastes = tiles.wastes[0];
  SPR.tile_arcane = tiles.arcane[0];
  SPR.tile_volcanic = tiles.volcanic[0];
  SPR.tile_water = tiles.water_deep[0];
  SPR.tile_water2 = tiles.water_deep[1];
  SPR.tile_shallow = tiles.water_shallow[0];
  SPR.tile_shallow2 = tiles.water_shallow[1];
  SPR.tile_lava = tiles.lava[0];
  SPR.tile_lava2 = tiles.lava[1];
  SPR.tile_arena = tiles.arena[0];
  SPR.tile_path = tiles.path[0];
  SPR.tile_tundra_rock = tiles.tundra_rock[0];

  // player
  const pf = playerFrames();
  SPR.player_idle = makeSprite(pf.idle, PLAYER_PAL);
  SPR.player_idle_flip = flipCanvas(SPR.player_idle);
  const wf = playerWalkFrames();
  wf.forEach((rows, i) => {
    SPR[`player_walk${i}`] = makeSprite(rows, PLAYER_PAL);
    SPR[`player_walk${i}_flip`] = flipCanvas(SPR[`player_walk${i}`]);
  });
  // enemies
  const em = enemyMaps();
  for (const [kind, pal] of Object.entries({
    slime: P.slime, bat: P.bat, imp: P.imp, wisp: P.wisp, skel: P.skel, shroom: P.shroom,
    cultist: P.cultist, fsprite: P.fsprite, scorp: P.scorp, witch: P.witch, golem: P.golem,
    wraith: P.wraith, hound: P.hound, djinn: P.djinn, knight: P.knight, plague: P.plague,
    tendril: P.tendril, gargoyle: P.gargoyle, chaos: P.chaos, fwarden: P.fwarden,
  })) {
    if (em[kind]) SPR[kind] = makeSprite(em[kind], pal);
  }

  // bosses (scale 2 for presence)
  const bm = bossMaps();
  const bossPal: Record<string, Record<string, string>> = {
    boss_ashen: { R: '#8e2f1e', r: '#c24a26', e: '#ffd75e', d: '#5a1c10', g: '#3a120b' },
    boss_frost: { W: '#aee6f2', I: '#e2f7fc', w: '#6db8cc', e: '#2e5a8a', i: '#d4f2fa', d: '#4a829e' },
    boss_hollow: { B: '#d8d3c0', b: '#8a8578', e: '#7ce8ff' },
    boss_storm: { C: '#5e9ab8', c: '#3f6e8a', E: '#fff45e', g: '#ffd75e' },
    boss_maw: { G: '#6ab354', g: '#4e8e3a', d: '#2e5a26', e: '#d8ff5e' },
    boss_tide: { W: '#5eb8c9', T: '#3a8a9e', w: '#8ad4de', e: '#ffd75e', d: '#2a6e7e' },
    boss_aeon: { M: '#b8a86e', m: '#8a7a4e', e: '#5ee8d8', d: '#6e5e3a' },
    boss_void: { V: '#8a4aa8', v: '#4e2a66', e: '#e85eff' },
  };
  for (const [k, rows] of Object.entries(bm)) SPR[k] = makeSprite(rows, bossPal[k], 2);

  // minions
  const mm = minionMaps();
  const minPal: Record<string, Record<string, string>> = {
    min_skel: P.skel, min_imp: P.imp, min_wisp: P.wisp, min_golem: P.golem,
    min_wraith: P.wraith, min_treant: { g: '#4e8e3a', G: '#6ab354', d: '#3a2a1e' },
    min_bat: P.bat, min_healer: { W: '#fff2c9', e: '#ffd75e', d: '#e0c896' },
    min_tide: { W: '#5eb8c9', o: '#3a8a9e' }, min_gale: { w: '#9ee8c8', W: '#e2fff2', e: '#3e8e6a' },
    min_void: { v: '#4e2a66', V: '#8a4aa8', e: '#e85eff', d: '#2e1a3e' },
  };
  for (const [k, rows] of Object.entries(mm)) SPR[k] = makeSprite(rows, minPal[k]);

  // decor & objects
  const dm = decorMaps();
  const decorPal: Record<string, Record<string, string>> = {
    tree: { G: '#4e8e3a', g: '#3a6e2c', t: '#5a4a30' },
    pine: { G: '#3a6e44', g: '#2e5a36', t: '#4a3a28' },
    deadtree: { t: '#4a4038' },
    cactus: { g: '#5e9e4e', G: '#7ab866' },
    rock: { s: '#7a766c', S: '#928e84' },
    crystal: { c: '#8a6ec9', C: '#b89ef2' },
    bones: { b: '#d8d3c0' },
    flower: { p: '#c95e8e', P: '#e88ab0', g: '#4e8e3a' },
    stump: { t: '#5a4a30', T: '#7a6848' },
    icespike: { i: '#8ec9d8', I: '#c9eef5' },
    lavarock: { s: '#4a3a34', L: '#e2552e' },
    pillar: { s: '#7a766c', S: '#928e84' },
    mushroom_big: { c: '#b05ac9', C: '#d18ae0', s: '#e8d9b0', W: '#f2ead0' },
    shrine: { g: '#8a8578', G: '#ffd75e' },
    altar: { c: '#8a6ec9', C: '#c9b0f2', e: '#5ee8d8', s: '#5a564e' },
    stain: { a: '#8a6e2e', A: '#ffd75e' },
    vial: { w: '#d8d3c0', W: '#e8e4d4', R: '#d94e5e' },
    draught: { w: '#d8d3c0', W: '#e8e4d4', M: '#5ee8c9' },
    shard: { a: '#c9a84e', A: '#ffe89e' },
    chest: { g: '#c9a84e', b: '#7a5a2e', B: '#a87e42', b2: '#7a5a2e' },
    tower: { c: '#5a6274', C: '#7a8496', e: '#9ee8ff', s: '#6e6a60', S: '#8a8578' },
    obelisk: { v: '#3a2a52', V: '#5e4280', e: '#c95ee8', E: '#f2c9ff' },
    campfire: { f: '#e2552e', F: '#ffd75e', e: '#ff9e4e', w: '#5a4a30' },
    spring: { w: '#3a8a9e', W: '#5eb8c9', e: '#e8fbff' },
    gate: { p: '#e2552e' },
    barrow: { d: '#3a3448', D: '#554d68', s: '#5a564e' },
    tent: { p: '#8a5e2e', P: '#c99e5e', d: '#2a1e14' },
    geyser: { c: '#4e7e8a', C: '#7ab8c9', e: '#9ee8ff', s: '#5a564e' },
    // village buildings
    house_a: { h: '#b08e46', H: '#d4b45e', w: '#6e4a2a', p: '#e6d8b4', s: '#8a8578', S: '#a29c8e', D: '#514d44', e: '#ffd75e', E: '#fff6b0', d: '#4a3220' },
    house_b: { r: '#5e6a8a', R: '#8492b4', c: '#6e6a60', w: '#5e422a', q: '#eee4c6', s: '#8a8578', S: '#a29c8e', D: '#514d44', e: '#ffd75e', E: '#fff6b0', d: '#3e2c1c' },
    well: { h: '#b08e46', H: '#d4b45e', w: '#6e4a2a', s: '#8a8578', S: '#a29c8e', D: '#22303c', l: '#7ab8c9', a: '#c9b490', d: '#565248' },
    stall: { r: '#c25a3e', W: '#ece0c2', w: '#6e4a2a', g: '#7ab85a', p: '#a87e4e', P: '#c09a62', D: '#514d44' },
    fence: { w: '#8a6a42', W: '#a8855a' },
    // world-density decor pass
    bush: { G: '#5e9e46', g: '#4a8238' },
    log: { t: '#6e5a38', T: '#8a7450' },
    pebbles: { s: '#8a8578', S: '#a29c8e' },
    reeds: { g: '#6a8a4a', G: '#8aa85a' },
    lilypad: { w: '#4e9e58', W: '#6ab874' },
    snowdrift: { w: '#e8f0f4', W: '#ffffff' },
    boulder: { s: '#6e6a60', S: '#8a8578' },
    sapling: { g: '#5e9e46', G: '#7ab858', t: '#6e5a38' },
    skullpile: { b: '#d8d3c0' },
    roots: { t: '#5a4a34' },
    cattail: { c: '#8a5a2e', C: '#a8723e', g: '#6a8a4a' },
    shell: { p: '#e8d8c8', P: '#f8f0e4' },
    mushroom: { c: '#b05ac9', C: '#d18ae0', s: '#e8d9b0' },
    crystal_shard: { c: '#8a6ec9', C: '#b89ef2' },
  };
  for (const [k, rows] of Object.entries(dm)) SPR[k] = makeSprite(rows, decorPal[k] ?? {});

  // ground luxury tiles + arena kits + edge transitions
  Object.assign(LUX_TILES, buildLuxTiles());
  Object.assign(ARENA_FLOORS, buildArenaFloors());
  Object.assign(ARENA_KITS, buildArenaKit());
  buildEdgeTiles();

  // spell glyphs
  for (const el of ELEMENT_IDS) {
    for (const form of ['bolt', 'volley', 'orb', 'beam', 'wave', 'nova', 'storm', 'field', 'trap', 'ward', 'aura', 'enchant', 'summon', 'blink', 'mend', 'ritual'] as FormId[]) {
      SPR[`glyph_${el}_${form}`] = makeGlyph(el, form);
    }
  }
}
