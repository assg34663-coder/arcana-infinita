import GameClient from '@/components/game/GameClient';

export default function Home() {
  return (
    <main className="fixed inset-0">
      <GameClient />
    </main>
  );
}
