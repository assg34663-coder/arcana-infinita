import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, Press_Start_2P } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const pixelFont = Press_Start_2P({
  variable: "--font-pixel",
  weight: "400",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Arcana Infinita — The Weald of a Thousand Spells",
  description:
    "An open-world 2D pixel action RPG. No quest, no chains — just you, hundreds of spells, spell fusion, necromancy, and eight brutal bullet-hell bosses. Dodge, parry, or die.",
  keywords: ["pixel RPG", "bullet hell", "magic", "open world", "browser game"],
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0d0a14",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        suppressHydrationWarning
        className={`${geistSans.variable} ${geistMono.variable} ${pixelFont.variable} antialiased bg-black text-foreground overflow-hidden`}
      >
        {children}
      </body>
    </html>
  );
}
